﻿Public Interface IFunctions
    ''' <summary>
    '''  登录SAP，成功，返回True，失败，返回False；

    ''' </summary>
    ''' <param name="User">用户</param>
    ''' <param name="PassWord">口令</param>
    ''' <param name="Language">语言，如ZH、EN等，可以传入null</param>
    ''' <returns>是否登录成功</returns>
    ''' <remarks></remarks>
    Function ConnectToSAP(ByVal User As String, ByVal Password As String, ByVal Language As String) As Boolean

    ''' <summary>
    ''' 设置调用的sap函数名称；

    ''' </summary>
    ''' <param name="sapFuncName">sap函数名称</param>
    ''' <remarks></remarks>
    Sub SetFuncName(ByVal sapFuncName As String)

    ''' <summary>
    ''' 设置Sap函数的传入调用参数；
    ''' </summary>
    ''' <param name="paramName">参数名称</param>
    ''' <param name="paramValue">参数值</param>
    ''' <remarks></remarks>
    Sub SetParamName(ByVal paramName As String, ByVal paramValue As Object)

    ''' <summary>
    ''' 设置sap的传入内表，用dt_value模拟这个内表；

    ''' </summary>
    ''' <param name="SapTableName">sap函数传入内表的名字</param>
    ''' <param name="dt_value">模拟的DataTable，要求与传入内表的字段名一致</param>
    ''' <remarks></remarks>
    Sub SetInPutTable(ByVal SapTableName As String, ByVal dt_value As DataTable)

    ''' <summary>
    ''' 设置sap的传入内表，用dt_value模拟这个内表；

    ''' </summary>
    ''' <param name="SapTableName">sap函数传入内表的名字</param>
    ''' <param name="dt_value">模拟的DataTable，要求与传入内表的字段名一致</param>
    ''' <remarks></remarks>
    Sub SetInPutTable311(ByVal SapTableName As String, ByVal dt_value As DataTable)

    ''' <summary>
    ''' 当参数设置完成后，执行函数调用；
    ''' </summary>
    ''' <remarks></remarks>
    Sub ExecFun()

    ''' <summary>
    ''' 根据字段列表（逗号分隔）建立指定字段的DataTable；

    ''' </summary>
    ''' <param name="fields">字段列表（逗号分隔）</param>
    ''' <returns>空表</returns>   
    ''' <remarks></remarks>
    Function CreateTable(ByVal fields As String) As DataTable

    ''' <summary>
    ''' 取得sap的传出参数值；
    ''' </summary>
    ''' <param name="paramName">传出参数名</param>
    ''' <returns>传出参数值</returns>
    ''' <remarks></remarks>
    Function GetOutPutParam(ByVal paramName As String) As String

    ''' <summary>
    ''' 把sap函数调用结构的传出内表转成dotNet的表；

    ''' </summary>
    ''' <param name="fields">sap传出内表的字段列表，字段间以逗号分隔</param>
    ''' <param name="SapTableName">sap传出内表的表名</param>
    ''' <param name="strTrim">是否清除前后空格</param>
    ''' <returns>把sap内表导出的dotnet表，字段都为string型</returns>
    ''' <remarks></remarks>
    Function GetOutPutTable(ByVal fields As String, ByVal SapTableName As String, ByVal strTrim As Boolean) As DataTable

    ''' <summary>
    ''' 关闭sap的连接

    ''' </summary>
    ''' <remarks></remarks>
    Sub DisConnectSAP()

    ''' <summary>
    ''' 返回sapTable
    ''' </summary>
    ''' <remarks></remarks>
    Sub GetTable(ByVal SapTableName As String, ByVal dt_value As System.Data.DataTable)

End Interface
