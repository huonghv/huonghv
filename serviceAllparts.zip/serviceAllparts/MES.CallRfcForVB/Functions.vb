﻿Public Class Functions
    Implements IFunctions

    Private m_sapObject As Object       'sap远程函数调用对象
    Protected m_sapFun As Object        'sap函数
    Private m_sapConnection As Object   '与SAP的连接


    ''' <summary>
    ''' 构造函数，传入sap的基本信息

    ''' </summary>
    ''' <param name="sapSystem">Sap系统，可以传入null</param>
    ''' <param name="applicationServer">SAP服务器ip</param>
    ''' <param name="Client">集团号，如800</param>
    ''' <param name="SystemNumber">系统编号，如00</param>
    ''' <remarks></remarks>
    Public Sub New(ByVal sapSystem As String, ByVal ApplicationServer As String, ByVal Client As String, ByVal SystemNumber As String)
        Me.m_sapObject = CreateObject("SAP.Functions")
        Me.m_sapConnection = Me.m_sapObject.Connection()

        If String.IsNullOrEmpty(sapSystem) = False Then
            Me.m_sapConnection.System = sapSystem
        End If

        Me.m_sapConnection.ApplicationServer = ApplicationServer
        Me.m_sapConnection.Client = Client
        Me.m_sapConnection.SystemNumber = SystemNumber
    End Sub
    ''' <summary>
    ''' 构造函数，传入sap的基本信息with Groupname version
    ''' </summary>
    ''' <param name="SapSystem">Sap系统，可以传入null</param>
    ''' <param name="Client">集团号，如800</param>
    ''' <param name="Messageserver">SAP服务器ip</param>
    ''' <param name="System">系统编号，如00</param>
    ''' <param name="Groupname">所屬群組</param>
    ''' <remarks></remarks>
    Public Sub New(ByVal SapSystem As String, ByVal Messageserver As String, ByVal Client As String, ByVal System As String, ByVal Groupname As String)
        Me.m_sapObject = CreateObject("SAP.Functions")
        Me.m_sapConnection = Me.m_sapObject.Connection()
        Me.m_sapConnection.Messageserver = Messageserver
        Me.m_sapConnection.client = Client
        Me.m_sapConnection.System = System
        Me.m_sapConnection.Groupname = Groupname
    End Sub

    ''' <summary>
    '''  登录SAP，成功，返回True，失败，返回False
    ''' </summary>
    ''' <param name="User">用户</param>
    ''' <param name="PassWord">口令</param>
    ''' <param name="Language">语言，如ZH、EN等，可以传入null</param>
    ''' <returns>是否登录成功</returns>
    ''' <remarks></remarks>
    Public Function ConnectToSAP(ByVal User As String, ByVal Password As String, ByVal Language As String) As Boolean Implements IFunctions.ConnectToSAP
        Me.m_sapConnection.user = User
        Me.m_sapConnection.Password = Password

        If String.IsNullOrEmpty(Language) = False Then
            Me.m_sapConnection.Language = Language
        Else
            Me.m_sapConnection.Language = "EN"
        End If

        Me.m_sapObject.AutoLogon = True                                '自动登录
        Return Me.m_sapObject.Connection.logon(0, True)                '登录是否成功
    End Function



    ''' <summary>
    ''' 根据字段列表（逗号分隔）建立指定字段的DataTable
    ''' </summary>
    ''' <param name="fields">字段列表（逗号分隔）</param>
    ''' <returns>空表</returns>
    ''' <remarks></remarks>
    Public Function CreateTable(ByVal fields As String) As System.Data.DataTable Implements IFunctions.CreateTable
        Dim dt As New DataTable
        Dim strs As String()
        Dim s As String

        strs = fields.Split(",")
        For Each s In strs
            dt.Columns.Add(s.Trim())
        Next

        Return dt
    End Function

    ''' <summary>
    ''' 关闭sap的连接

    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DisConnectSAP() Implements IFunctions.DisConnectSAP
        Me.m_sapConnection.logoff()
    End Sub

    ''' <summary>
    ''' 当参数设置完成后，执行函数调用

    ''' </summary>
    ''' <remarks></remarks>
    Public Sub ExecFun() Implements IFunctions.ExecFun
        If Me.m_sapFun.Call() = False Then
            Throw New Exception("Sap远程函数调用失败。")       '从SAP取数出错，退出函数

        End If
    End Sub

    ''' <summary>
    ''' 取得sap的传出参数值

    ''' </summary>
    ''' <param name="paramName">传出参数名</param>
    ''' <returns>传出参数值</returns>
    ''' <remarks></remarks>
    Public Function GetOutPutParam(ByVal paramName As String) As String Implements IFunctions.GetOutPutParam
        Dim param As Object
        param = Me.m_sapFun.Imports(paramName)
        If param Is Nothing Then
            Throw New Exception("Sap远程函数的参数名无效：" + paramName)
        End If

        If param.Value Is Nothing Then
            Return ""
        Else
            Return param.Value.ToString()
        End If
    End Function

    ''' <summary>
    ''' 把sap函数调用结构的传出内表转成dotNet的表
    ''' </summary>
    ''' <param name="fields">sap传出内表的字段列表，字段间以逗号分隔</param>
    ''' <param name="SapTableName">sap传出内表的表名</param>
    ''' <param name="strTrim">是否清除前后空格</param>
    ''' <returns>把sap内表导出的dotnet表，字段都为string型</returns>
    ''' <remarks></remarks>
    Public Function GetOutPutTable(ByVal fields As String, ByVal SapTableName As String, ByVal strTrim As Boolean) As System.Data.DataTable Implements IFunctions.GetOutPutTable
        '按字段列表建立表，fields中的字段列表用逗号分隔
        'Dim dt As DataTable
        'dt = Me.CreateTable(fields)

        '从sap表中读数据，循环sap中取得的数据，写入dt
        Dim sapdata As Object
        Dim saprow As Object
        Dim dr As DataRow                       '数据增加的新行

        Dim dc As DataColumn
        sapdata = Me.m_sapFun.Tables(SapTableName)

        Dim iCount As Integer = 1
        Dim dtTemp As DataTable
        dtTemp = New DataTable
        While iCount <= sapdata.COLUMNCOUNT
            dtTemp.Columns.Add(sapdata.COLUMNNAME(iCount))
            iCount = iCount + 1
        End While

        For Each saprow In sapdata.Rows
            dr = dtTemp.NewRow()
            For Each dc In dtTemp.Columns
                If strTrim = True Then
                    dr(dc.ColumnName) = saprow(dc.ColumnName).ToString().Trim()
                Else
                    dr(dc.ColumnName) = saprow(dc.ColumnName).ToString()
                End If
            Next
            dtTemp.Rows.Add(dr)
        Next

        Return dtTemp
    End Function

    ''' <summary>
    ''' 设置调用的sap函数名称
    ''' </summary>
    ''' <param name="sapFuncName">sap函数名称</param>
    ''' <remarks></remarks>
    Public Sub SetFuncName(ByVal sapFuncName As String) Implements IFunctions.SetFuncName
        Me.m_sapFun = Me.m_sapObject.Add(sapFuncName)
        If m_sapFun Is Nothing Then
            Throw New Exception("Sap远程函数名无效：" + sapFuncName)
        End If
    End Sub

    ''' <summary>
    ''' 设置sap的传入内表，用dt_value模拟这个内表
    ''' </summary>
    ''' <param name="SapTableName">sap函数传入内表的名字</param>
    ''' <param name="dt_value">模拟的DataTable，要求与传入内表的字段名一致</param>
    ''' <remarks></remarks>
    Public Sub SetInPutTable(ByVal SapTableName As String, ByVal dt_value As System.Data.DataTable) Implements IFunctions.SetInPutTable
        Dim sapdata As Object                       'sap传入内表
        Dim saprow As Object                        'sap传入内表的一行

        Dim dc As DataColumn
        Dim index As Integer

        sapdata = Me.m_sapFun.Tables(SapTableName)
        For index = 0 To dt_value.Rows.Count - 1    '循环表，并给sap传入内表赋值

            saprow = sapdata.Rows.Add()             '传入内表新增一行记录，下面为传入内表记录赋值

            For Each dc In dt_value.Columns
                saprow(dc.ColumnName) = dt_value.Rows(index)(dc.ColumnName).ToString()
            Next
        Next
    End Sub

    ''' <summary>
    ''' 设置sap的传入内表，用dt_value模拟这个内表
    ''' </summary>
    ''' <param name="SapTableName">sap函数传入内表的名字</param>
    ''' <param name="dt_value">模拟的DataTable，要求与传入内表的字段名一致</param>
    ''' <remarks></remarks>
    Public Sub SetInPutTable311(ByVal SapTableName As String, ByVal dt_value As System.Data.DataTable) Implements IFunctions.SetInPutTable311
        Dim sapdata As Object                       'sap传入内表
        Dim saprow As Object                        'sap传入内表的一行

        'Dim dc As DataColumn
        Dim index As Integer

        sapdata = Me.m_sapFun.Tables(SapTableName)
        For index = 0 To dt_value.Rows.Count - 1    '循环表，并给sap传入内表赋值

            saprow = sapdata.Rows.Add()             '传入内表新增一行记录，下面为传入内表记录赋值


            saprow(2) = dt_value.Rows(index)(0).ToString()
            saprow(6) = dt_value.Rows(index)(1).ToString()
        Next
    End Sub
    Public Sub GetTable(ByVal SapTableName As String, ByVal dt_value As System.Data.DataTable) Implements IFunctions.GetTable
        Dim sapdata As Object
        Dim saprow As Object
        Dim index As Integer
        Dim j As Integer
        sapdata = Me.m_sapFun.Tables(SapTableName)
        For index = 0 To dt_value.Rows.Count - 1
            saprow = sapdata.Rows.Add()
            For Each dc In dt_value.Columns
                j = dc.ColumnName.ToString()
                saprow(j) = dt_value.Rows(index)(dc.ColumnName).ToString()
            Next
        Next

    End Sub


    ''' <summary>
    ''' 设置Sap函数的传入调用参数

    ''' </summary>
    ''' <param name="paramName">参数名称</param>
    ''' <param name="paramValue">参数值</param>
    ''' <remarks></remarks>
    Public Sub SetParamName(ByVal paramName As String, ByVal paramValue As Object) Implements IFunctions.SetParamName
        Dim param As Object
        param = Me.m_sapFun.Exports(paramName)
        If param Is Nothing Then
            Throw New Exception("Sap远程函数的参数名无效：" + paramName)
        End If
        param.Value = paramValue
    End Sub
End Class
