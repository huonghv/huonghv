﻿Public Class RFCService
    Public Function SAPRFC8TABLE(ByVal RFCSERVER As String, ByVal RFCNAME As String, _
                 ByVal DS_IMPORT As Data.DataSet, ByVal DS_IN As Data.DataSet, ByVal TABLE_OUT As String) As Data.DataSet
        'Dim RFCNAME As String = "ZCMM_NSBG_0066" '"RFC_CUSTOMER_GET" 
        Dim functionCtrl, sapConnection As Object
        Dim myds As New Data.DataSet
        If RFCSERVER = "" Then
            Return myds
            Exit Function
        Else
            Dim RFCCON As String = ConfigurationManager.AppSettings(RFCSERVER)
            If RFCCON <> "" Then
                functionCtrl = CreateObject("SAP.Functions")
                sapConnection = functionCtrl.Connection
                sapConnection.Language = "EN"
                'sapConnection.SystemNumber = "0"

                'For i As Integer = 1 To RFCCON.Split(",").Length
                sapConnection.Applicationserver = RFCCON.Split(",")(0) '"10.150.4.88"
                sapConnection.Hostname = RFCCON.Split(",")(0) ' "10.150.4.88"
                sapConnection.Client = RFCCON.Split(",")(1) '"600"
                sapConnection.User = RFCCON.Split(",")(2) '"Ambit-ADM"
                sapConnection.password = RFCCON.Split(",")(3) '"formis"
                sapConnection.SystemNumber = RFCCON.Split(",")(4)
                'Next
            Else
                Return myds
                Exit Function
            End If
        End If

        'sapConnection.Client = "808"
        'sapConnection.Applicationserver = "10.134.28.99"
        'sapConnection.Hostname = "10.134.28.99"
        'sapConnection.User = "HCADM-PP"
        'sapConnection.password = "LK9I8"
        If sapConnection.logon(0, True) Then
            Dim RFCFunction As Object
            ' 透過RFC接口遠端運行SAP內部函數RFC_CUSTOMER_GET
            ' 賦要調用的SAP內建函數名
            RFCFunction = functionCtrl.Add(RFCNAME)
            'RFCFunction.Exports("KUNNR") = "0001083241" ' 向函數入口賦值（用戶代碼）
            'RFCFunction.Exports("NAME1") = "台灣*"
            'RFCFunction.Exports("KUNNR") = "000*"
            If Not DS_IMPORT Is Nothing Then
                Try
                    For j As Integer = 1 To DS_IMPORT.Tables(0).Rows.Count
                        For k As Integer = 1 To DS_IMPORT.Tables(0).Columns.Count
                            RFCFunction.Exports(DS_IMPORT.Tables(0).Columns(k - 1).ColumnName) = DS_IMPORT.Tables(0).Rows(j - 1)(k - 1).ToString
                        Next
                    Next
                Catch ex As Exception
                End Try
            End If

            If Not DS_IN Is Nothing Then
                Try
                    For i As Integer = 1 To DS_IN.Tables.Count
                        Dim S_TABLE As Object '-B_MATNR
                        S_TABLE = RFCFunction.tables(DS_IN.Tables(i - 1).TableName)
                        For j As Integer = 1 To DS_IN.Tables(i - 1).Rows.Count
                            Dim ObjRow As Object = S_TABLE.Rows.Add
                            For k As Integer = 1 To DS_IN.Tables(i - 1).Columns.Count
                                ObjRow(DS_IN.Tables(i - 1).Columns(k - 1).ColumnName) = DS_IN.Tables(i - 1).Rows(j - 1)(k - 1).ToString
                            Next
                        Next
                    Next
                Catch ex As Exception
                End Try
            End If

            'S_MATNR = RFCFunction.Exports("S_MATNR")
            'S_MATNR.B_MATNR = ""

            ' 向函數入口賦查詢表名稱
            'RFCTable = RFCFunction.Tables("CUSTOMER_T")
            'S_MATNR = RFCFunction.Tables("S_MATNR")
            'S_MATNR("B_MATNR", 1) = "26.2272.01"
            'RFCFunction.Exports("S_MATNR") = S_MATNR '"001.00002.002"

            '"ITAB_OUT")
            If RFCFunction.Call Then ' 調用成功遍歷顯示用戶所有資訊條目
                If TABLE_OUT <> "" Then
                    Dim K1 As Integer = 0
                    For i As Integer = 1 To TABLE_OUT.Split(",").Length
                        Dim myTableName As String = TABLE_OUT.Split(",")(i - 1)
                        If InStr(myTableName, "(") > 0 And InStr(myTableName, ")") > 0 Then
                            '產生Exports
                            K1 = K1 + 1
                            Dim myFieldNames As String = myTableName.Split(")")(0).Split("(")(1)
                            myTableName = "$EXPORTS" & K1
                            '建立DataSet
                            Dim Tempdt As New System.Data.DataTable(myTableName)
                            For R As Integer = 1 To myFieldNames.Split(";").Length
                                Tempdt.Columns.Add(myFieldNames.Split(";")(R - 1), System.Type.GetType("System.String"))
                            Next
                            myds.Tables.Add(Tempdt)
                            Dim MyRow As System.Data.DataRow
                            MyRow = myds.Tables(myTableName).NewRow()
                            For j As Integer = 1 To myFieldNames.Split(";").Length
                                MyRow(j - 1) = RFCFunction.Imports(myFieldNames.Split(";")(j - 1)).Value
                            Next
                            myds.Tables(myTableName).Rows.Add(MyRow)
                        Else
                            '產生Table
                            Dim Tempdt As New System.Data.DataTable(myTableName)
                            Dim RFCTable As Object
                            RFCTable = RFCFunction.Tables(myTableName)
                            Dim N As Integer = RFCTable.columncount 'columncount
                            For j As Integer = 1 To N
                                Tempdt.Columns.Add(RFCTable.ColumnName(j), System.Type.GetType("System.String"))
                            Next
                            myds.Tables.Add(Tempdt)
                            For R As Integer = 1 To RFCTable.rowcount
                                Dim MyRow As System.Data.DataRow
                                MyRow = myds.Tables(myTableName).NewRow()
                                For j As Integer = 1 To N
                                    MyRow(j - 1) = RFCTable(R, j)
                                Next
                                myds.Tables(myTableName).Rows.Add(MyRow)
                            Next R
                        End If
                        'RFCTable(i - 1) = RFCFunction.Tables(myTableName)
                    Next
                End If
GetReturn:

            Else
                'Me.WtxtMemo.Text = "No Any Record"
                myds = Nothing
            End If
            sapConnection.LogOff()
        Else
            ' Me.WtxtMemo.Text = "No connection to R/3!"
        End If
        Return myds
    End Function

    Public Function SAPRFC8IMPORT(ByVal RFCSERVER As String, ByVal RFCNAME As String, _
             ByVal DS_IN As Data.DataSet, ByVal TABLE_OUT As String) As Data.DataSet
        'Dim RFCNAME As String = "ZCMM_NSBG_0066" '"RFC_CUSTOMER_GET" 
        Dim functionCtrl, sapConnection As Object
        Dim myds As New Data.DataSet
        If RFCSERVER = "" Then
            Return myds
            Exit Function
        Else
            Dim RFCCON As String = ConfigurationManager.AppSettings(RFCSERVER)
            If RFCCON <> "" Then
                functionCtrl = CreateObject("SAP.Functions")
                sapConnection = functionCtrl.Connection
                sapConnection.Language = "EN"
                'sapConnection.SystemNumber = "0"

                'For i As Integer = 1 To RFCCON.Split(",").Length
                sapConnection.Applicationserver = RFCCON.Split(",")(0) '"10.150.4.88"
                sapConnection.Hostname = RFCCON.Split(",")(0) ' "10.150.4.88"
                sapConnection.Client = RFCCON.Split(",")(1) '"600"
                sapConnection.User = RFCCON.Split(",")(2) '"Ambit-ADM"
                sapConnection.password = RFCCON.Split(",")(3) '"formis"
                sapConnection.SystemNumber = RFCCON.Split(",")(4)
                'Next
            Else
                Return myds
                Exit Function
            End If
        End If

        'sapConnection.Client = "808"
        'sapConnection.Applicationserver = "10.134.28.99"
        'sapConnection.Hostname = "10.134.28.99"
        'sapConnection.User = "HCADM-PP"
        'sapConnection.password = "LK9I8"
        If sapConnection.logon(0, True) Then
            Dim RFCFunction As Object
            Dim RFCTable(0 To TABLE_OUT.Split(",").Length - 1) As Object
            ' 透過RFC接口遠端運行SAP內部函數RFC_CUSTOMER_GET
            ' 賦要調用的SAP內建函數名
            RFCFunction = functionCtrl.Add(RFCNAME)
            'RFCFunction.Exports("KUNNR") = "0001083241" ' 向函數入口賦值（用戶代碼）
            'RFCFunction.Exports("NAME1") = "台灣*"
            'RFCFunction.Exports("KUNNR") = "000*"

            For i As Integer = 1 To DS_IN.Tables.Count
                Dim S_TABLE As Object '-B_MATNR
                S_TABLE = RFCFunction.tables(DS_IN.Tables(i - 1).TableName)
                For j As Integer = 1 To DS_IN.Tables(i - 1).Rows.Count
                    For k As Integer = 1 To DS_IN.Tables(i - 1).Columns.Count
                        RFCFunction.Exports(DS_IN.Tables(i - 1).Columns(k - 1).ColumnName) = DS_IN.Tables(i - 1).Rows(j - 1)(k - 1).ToString
                        'Dim ObjRow As Object = S_TABLE.Rows.Add
                        'ObjRow(DS_IN.Tables(i - 1).Columns(k - 1).ColumnName) = DS_IN.Tables(i - 1).Rows(j - 1)(k - 1).ToString
                    Next
                Next
            Next

            'S_MATNR = RFCFunction.Exports("S_MATNR")
            'S_MATNR.B_MATNR = ""
            '向函數入口賦查詢表名稱
            'RFCTable = RFCFunction.Tables("CUSTOMER_T")
            'S_MATNR = RFCFunction.Tables("S_MATNR")
            'S_MATNR("B_MATNR", 1) = "26.2272.01"
            'RFCFunction.Exports("S_MATNR") = S_MATNR '"001.00002.002"
            For i As Integer = 1 To TABLE_OUT.Split(",").Length
                RFCTable(i - 1) = RFCFunction.Tables(TABLE_OUT.Split(",")(i - 1))
            Next
            '"ITAB_OUT")
            If RFCFunction.Call Then ' 調用成功遍歷顯示用戶所有資訊條目
                'Dim dc As New System.Data.DataColumn()
                'var_table = RFCFunction.tables.Item("WO_HEADER")
                For k As Integer = 1 To TABLE_OUT.Split(",").Length
                    Dim Tempdt As New System.Data.DataTable(TABLE_OUT.Split(",")(k - 1))
                    Dim N As Integer = RFCTable(k - 1).columncount 'columncount
                    For j As Integer = 1 To N
                        Tempdt.Columns.Add(RFCTable(k - 1).ColumnName(j), System.Type.GetType("System.String"))
                    Next
                    myds.Tables.Add(Tempdt)
                    For i As Integer = 1 To RFCTable(k - 1).rowcount
                        Dim MyRow As System.Data.DataRow
                        MyRow = myds.Tables(k - 1).NewRow()
                        For j As Integer = 1 To N
                            MyRow(j - 1) = RFCTable(k - 1)(i, j)
                        Next
                        myds.Tables(k - 1).Rows.Add(MyRow)
                    Next i
                Next

            Else
                'Me.WtxtMemo.Text = "No Any Record"
            End If

            sapConnection.LogOff()
        Else
            ' Me.WtxtMemo.Text = "No connection to R/3!"
        End If
        Return myds
    End Function
End Class
