﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.OracleClient;

namespace WebServiceGetGrnData.classes
{
    public class DBOP
    {
        OracleCommand oCmd = new OracleCommand();
        private OracleDataAdapter oAdp = new OracleDataAdapter();
       
        OracleConnection oCn;
        string strcon;
        public string getBuString(string bu)
        {
           
            if (bu == "NSD01")
            {
                strcon = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringNSD01"].ToString();
            }
            else if (bu == "NSDBPD")
            {
                strcon = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringNSDBPD"].ToString();
            }
            else if (bu == "NSD2SA")
            {
                strcon = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringNSD2SA"].ToString();
            }
            else if (bu == "NSD01T1")
            {
                strcon = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringNSD2SA"].ToString();
            }
            return strcon;
        }     
           
          
        public void OpenCon(string bu)
        {
            oCn = new OracleConnection();
            oCn.ConnectionString = getBuString(bu.ToUpper());

            if (oCn.State==ConnectionState.Closed)
            {
                oCn.Open();
            }
        }
        public void CloseConn()
        {

            if (oCn.State == ConnectionState.Open)
            {
                oCn.Close();
                oCn.Dispose();
            }
        }

        public DataTable excutSelectSQL(string strSQL)
        {            
            DataTable dt = new DataTable();
            oCmd.Connection = oCn;
            oCmd.CommandText = strSQL;
            oAdp.SelectCommand = oCmd;
            oAdp.Fill(dt);
            oCn.Close();
            oCn.Dispose();
            return (dt);
        }

        public int excutNoquery(string strSQL)
        {
            int a = 0;
            oCmd.Connection = oCn;
            oCmd.CommandText = strSQL;
            oCmd.CommandType = CommandType.Text;
            a = oCmd.ExecuteNonQuery();
            oCn.Close();
            oCn.Dispose();
            return a;

        }

        
          
    }
}
