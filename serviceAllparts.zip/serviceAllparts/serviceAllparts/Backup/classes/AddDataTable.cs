﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


namespace WebServiceGetGrnData.classes
{
    public class AddDataTable
    {
        public DataTable creatDataTable(string tableName, coLumData[] columnName)
        {
            DataTable tblDatas = new DataTable(tableName);
            DataColumn dc = null;
            dc = tblDatas.Columns.Add("ID", Type.GetType("System.Int32"));
            dc.AutoIncrement = true;//自動增加
            dc.AutoIncrementSeed = 1;//起始為１
            dc.AutoIncrementStep = 1;//步長為１
            dc.AllowDBNull = false;

            for (int i = 0; i < columnName.Length; i++)
            {
                dc = tblDatas.Columns.Add(columnName[i].columName, columnName[i].columType);
            }


            //dc = tblDatas.Columns.Add("Product", Type.GetType("System.String"));
            //dc = tblDatas.Columns.Add("Version", Type.GetType("System.String"));
            //dc = tblDatas.Columns.Add("Description", Type.GetType("System.String"));

            DataRow newRow;
            newRow = tblDatas.NewRow();
            newRow["Product"] = "這個地方是單元格的值";
            newRow["Version"] = "2.0";
            newRow["Description"] = "這個地方是單元格的描述";
            tblDatas.Rows.Add(newRow);
            newRow = tblDatas.NewRow();
            newRow["Product"] = "這個地方是單元格的值";
            newRow["Version"] = "3.0";
            newRow["Description"] = "這個地方是單元格的描述";
            tblDatas.Rows.Add(newRow);
            return tblDatas;
        }

       public struct coLumData
        {
           public  string columName;
           public Type columType;
            
        }

        

        public DataTable test()
        {
            coLumData Product = new coLumData();
            Product.columName = "Product";
            Product.columType = Type.GetType("System.String");

            coLumData Version = new coLumData();
            Version.columName = "Version";
            Version.columType = Type.GetType("System.String");

            coLumData Description = new coLumData();
            Description.columName = "Description";
            Description.columType = Type.GetType("System.String");

            coLumData[] coludata = { Product,Version,Description
                                       
                                   };


          DataTable dt=  creatDataTable("Datas", coludata);
          return dt;
        }
    }
}
