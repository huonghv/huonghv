﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OracleClient;

namespace WebServiceGetGrnData
{
    public class OperateDB
    {
        private OracleCommand oCmd = new OracleCommand();
		private OracleDataAdapter oAdp = new OracleDataAdapter();


		public OracleConnection  getcon1()
		{
			string connstring1 = "user id=web2;data source=egrn;password=nsd_web2pw69";
			OracleConnection conn = new OracleConnection (connstring1);
			conn.Open();
			return conn;
		}
	
		public void closecon1()

		{
			OracleConnection oCn = this.getcon1();
			oCn.Close();
			oCn.Dispose();
		}


		public DataTable DoSelectSQL(string strSQL )
		{
			OracleConnection oCn = this.getcon1();
			DataTable dt = new DataTable();		
			oCmd.Connection=oCn;
			oCmd.CommandText=strSQL;
			oAdp.SelectCommand=oCmd;
			oAdp.Fill(dt);
			//			oCn.Close();
			//			oCn.Dispose();
			return(dt);
		}


		public void DoNonQuerySQL(string strSQL)
		{
			
			OracleConnection oCn = this.getcon1();
			DataTable dt = new DataTable();	
			oCmd.Connection=oCn;
			oCmd.CommandText=strSQL;
			oCmd.ExecuteNonQuery();
			//			oCn.Close();
			//			oCn.Dispose();
		}

		public void BeginTrans()
		{
			OracleConnection oCn = this.getcon1();
			oCmd.Transaction=oCn.BeginTransaction();
			//			oCn.Close();
			//			oCn.Dispose();
		}
		public void Commit()
		{
			oCmd.Transaction.Commit();
		}
		public void RollBack()
		{
			oCmd.Transaction.Rollback();		
		}
	}




	public class OperateDB2
	{

		private OracleCommand oCmd = new OracleCommand();
		private OracleDataAdapter oAdp = new OracleDataAdapter();


		public OperateDB2()
		{

		}


        public OracleConnection getcon2()
        {
            string connstring2 = "user id=web2;data source=nsd01;password=nsd_web2pw69";
            OracleConnection conn = new OracleConnection(connstring2);
            conn.Open();
            return conn;
        }

        public OracleConnection getcon3(string strcon)
        {            
            OracleConnection conn = new OracleConnection(strcon);
            conn.Open();
            return conn;
        }

		public void closecon2()

		{
			OracleConnection oCn = this.getcon2();
			oCn.Close();
			oCn.Dispose();
		}
        public void closecon3(string strcon)
        {
            OracleConnection oCn = this.getcon3(strcon);
            oCn.Close();
            oCn.Dispose();
        }


		public DataTable DoSelectSQL(string strSQL )
		{
			OracleConnection oCn = this.getcon2();
			DataTable dt = new DataTable();		
			oCmd.Connection=oCn;
			oCmd.CommandText=strSQL;
			oAdp.SelectCommand=oCmd;
			oAdp.Fill(dt);
			//			oCn.Close();
			//			oCn.Dispose();
			return(dt);
		}


		public void DoNonQuerySQL(string strSQL)
		{
			
			OracleConnection oCn = this.getcon2();
			DataTable dt = new DataTable();	
			oCmd.Connection=oCn;
			oCmd.CommandText=strSQL;
			oCmd.ExecuteNonQuery();
			//			oCn.Close();
			//			oCn.Dispose();
		}

		public void BeginTrans()
		{
			OracleConnection oCn = this.getcon2();
			oCmd.Transaction=oCn.BeginTransaction();
			//			oCn.Close();
			//			oCn.Dispose();
		}
		public void Commit()
		{
			oCmd.Transaction.Commit();
		}
		public void RollBack()
		{
			oCmd.Transaction.Rollback();		
		}

    }
}
