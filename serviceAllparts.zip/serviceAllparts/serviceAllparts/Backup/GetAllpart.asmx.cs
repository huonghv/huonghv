using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using System.Data.OracleClient;
using WebServiceGetGrnData.classes;
using CallRfcCsharp;
using System.Threading;


namespace WebServiceGetGrnData
{
	/// <summary>
	/// GetGrnData ���K�n�y�z�C
	/// </summary>
	public class GetGrnData : System.Web.Services.WebService
	{
        string strResult2 = string.Empty;
        //public delegate string downdatat2(string astrdb, string aemp, string aplant);



		public GetGrnData()
		{
			//CODEGEN: ���� ASP.NET Web �A�ȳ]�p�u��һݪ��I�s�C
			InitializeComponent();
		}

		#region ����]�p�u�㲣�ͪ��{���X
		
		//Web �A�ȳ]�p�u�㪺���n��
		private IContainer components = null;
				
		/// <summary>
		/// �����]�p�u��䴩�ҥ�������k - �ФŨϥε{���X�s�边�ק�
		/// �o�Ӥ�k�����e�C
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// �M������ϥΤ����귽�C
		/// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
		
		#endregion

		// WEB �A�Ƚd��
		// HelloWorld() �d�ҪA�ȷ|�Ǧ^�r�� Hello World
		// �Y�n�ظm�A�Ш����U�C�U����ѡA�M���x�s�ëظm�o�ӱM��
		// �Y�n���ճo�� Web �A�ȡA�Ы� F5

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        

        [WebMethod]
        public DataSet GetGrnDoc(string strDoc_no, string strDb_Name)
        {
            DBOP dbot = new DBOP(); 
           

            DataTable dt = new DataTable();
            DataSet dtSet = new DataSet();
            string strResult = string.Empty;
            string strSql = string.Empty;
            strSql = "select * from mes1.c_emp where emp_no='F1321397'";
      
            try
            {
                strDb_Name = "NSD01";
                dbot.OpenCon(strDb_Name);
                dt=dbot.excutSelectSQL(strSql);                
                 
                dtSet.Tables.Add(dt);
                return dtSet;
            }
            catch(Exception e_getdoc)
            {
                return dtSet;
            }
            finally
            {
                dbot.CloseConn();
            }
        }

        [WebMethod]
        public string downdata(string strdb, string emp, string plant)
        {
            string strResult = string.Empty;


            sParamets st = new sParamets();
            connCallRfc concc = new connCallRfc();
            DataTable dt = concc.rfc3(strdb, emp, plant);

            //concc.rfc3(strdb, emp,plant);

            if (dt.Rows.Count > 0)
            {
                strResult = "OK";
                return strResult;
            }
            else
            {
                strResult = "DOWN FAIL�I";
                return strResult;
            }

        }


        [WebMethod]
        public string downdata2(string strdb, string emp, string plant)
        {


            connCallRfc concc = new connCallRfc();         


            concc.A = strdb;
            concc.B = emp;
            concc.C = plant;

            Thread th = new Thread(new ThreadStart(concc.rfc3_d));

            th.SetApartmentState(System.Threading.ApartmentState.STA);
            th.Start();
            th.Join();


            string strResult = string.Empty;

            sParamets st = new sParamets();
          
           // DataTable dt = concc.rfc3(strdb, emp, plant);

            //concc.rfc3(strdb, emp,plant);

            //if (dt.Rows.Count > 0)
            //{
            //    strResult = "OK";
            //    return strResult;
            //}
            //else
            //{
            //    strResult = "DOWN FAIL�I";
            //    return strResult;
            //}
            return "OK";

        }
        
       

        [WebMethod]
        public string test()
        {
            string strResult = string.Empty;

            sParamets st = new sParamets();


            Paramets[] ppp ={
             st.buildParamet("EMP",OracleType.VarChar,"Z3011",50,ParameterDirection.Input),
             st.buildParamet("PWD",OracleType.VarChar,"ALLPART1!",50,ParameterDirection.Input),
             st.buildParamet("RES",OracleType.VarChar,"",3000,ParameterDirection.Output)
             
                           };


            strResult = st.excutsp("MES1.AP_CHECK_WEB_PASSWORD", ppp, "NSD01");



            return strResult;
        }

        [WebMethod]
        public string whsCheckin(string g_location,string g_trsn,string g_inputdata,string g_empno,string g_ipaddress,string strBu)
        {
            string strResult = string.Empty;

            sParamets st = new sParamets();


            Paramets[] ppp ={
             st.buildParamet("g_location",OracleType.VarChar,g_location,50,ParameterDirection.Input),
             st.buildParamet("g_trsn",OracleType.VarChar,g_trsn,50,ParameterDirection.Input),
             st.buildParamet("g_inputdata",OracleType.VarChar,g_inputdata,50,ParameterDirection.Input),
             st.buildParamet("g_empno",OracleType.VarChar,g_empno,50,ParameterDirection.Input),
             st.buildParamet("g_ipaddress",OracleType.VarChar,g_ipaddress,50,ParameterDirection.Input),
             st.buildParamet("RES",OracleType.VarChar,"",3000,ParameterDirection.Output)
             
                           };


            strResult = st.excutsp("MES1.i_web_whs_checkin", ppp, strBu);



            return strResult;
        }


        [WebMethod]
        public string whsCheckInTestBack(string g_trsn, string strDb_Name)
        {
            DBOP dbot = new DBOP();


            DataTable dt = new DataTable();
            DataSet dtSet = new DataSet();
            string strResult = string.Empty;
            strResult = "FAIL";
            string strSql = string.Empty, strSql2 = string.Empty;
            strSql = "UPDATE MES4.R_WHS_LOCATION SET LOCATION='0-0-0' where tr_sn ='" + g_trsn + "'";
            strSql2 = " UPDATE mes4.r_sap_temp_test SET DATA2=''  WHERE data2 = '" + g_trsn + "' AND data6 = 'PDA'";
            try
            {
                strDb_Name = "NSD01";
                dbot.OpenCon(strDb_Name);
                dbot.excutNoquery(strSql);
                dbot.excutNoquery(strSql2);
                strResult = "OK";
                
            }
            catch (Exception e_222)
            {
                return strResult;
            }
            finally
            {
                dbot.CloseConn();
            }
            return strResult;

        }


        [WebMethod]
        public string checkAllpartEmp(string Emp_no, string PassWord, string strBu)
        {
             
            string strResult = string.Empty;
            string strDb_Name = string.Empty;
            sParamets st = new sParamets();
            DataTable dt = new DataTable();


            Paramets[] ppp ={
             st.buildParamet("EMP",OracleType.VarChar,Emp_no.ToUpper(),50,ParameterDirection.Input),
             st.buildParamet("PWD",OracleType.VarChar,PassWord.ToUpper(),50,ParameterDirection.Input),
             st.buildParamet("RES",OracleType.VarChar,"",3000,ParameterDirection.Output)             
                           };


            strResult = st.excutsp("MES1.AP_CHECK_WEB_PASSWORD", ppp, strBu.ToUpper());

            return strResult;
        }

        [WebMethod]
        public string whsPANDIAN(string g_location,string g_inputdata, string g_empno, string g_ipaddress, string strBu)   //�L�I
        {
            string strResult = string.Empty;

            sParamets st = new sParamets();


            Paramets[] ppp ={
             st.buildParamet("g_location",OracleType.VarChar,g_location,50,ParameterDirection.Input),
             st.buildParamet("g_inputdata",OracleType.VarChar,g_inputdata,50,ParameterDirection.Input),
             st.buildParamet("g_empno",OracleType.VarChar,g_empno,50,ParameterDirection.Input),
             st.buildParamet("g_ipaddress",OracleType.VarChar,g_ipaddress,50,ParameterDirection.Input),
             st.buildParamet("RES",OracleType.VarChar,"",3000,ParameterDirection.Output)
             
                           };


            strResult = st.excutsp("MES1.i_web_whs_PANDIAN", ppp, strBu);



            return strResult;
        }

        [WebMethod]
        public string whsPANDIAN_L(string g_location,string g_inputdata, string g_empno, string g_ipaddress, string strBu)   //�L�I
        {
            string strResult = string.Empty;

            sParamets st = new sParamets();


            Paramets[] ppp ={
             st.buildParamet("g_location",OracleType.VarChar,g_location,50,ParameterDirection.Input),
             st.buildParamet("g_inputdata",OracleType.VarChar,g_inputdata,50,ParameterDirection.Input),
             st.buildParamet("g_empno",OracleType.VarChar,g_empno,50,ParameterDirection.Input),
             st.buildParamet("g_ipaddress",OracleType.VarChar,g_ipaddress,50,ParameterDirection.Input),
             st.buildParamet("RES",OracleType.VarChar,"",3000,ParameterDirection.Output)
             
                           };


            strResult = st.excutsp("MES1.i_web_whs_PANDIAN_LOCATION", ppp, strBu);



            return strResult;
        }
        
        [WebMethod]
        public DataSet Whs_CheckinQuery(string str_emp, string strDb_Name)
        {
            DBOP dbot = new DBOP();


            DataTable dt = new DataTable();
            DataSet dtSet = new DataSet();
            string strResult = string.Empty;
            string strSql = string.Empty;
             
            strSql = "SELECT   a.cust_kp_no, SUM (qty) AS qty,min(start_time) as min_time   FROM mes4.r_whs_location a, mes1.c_whs_name_cust b " +
                   " WHERE  a.AREA=b.AREA  and  a.cust_kp_no = b.cust_kp_no   AND a.LOCATION = '0-0-0'    AND b.emp_no = '" + str_emp + "' " +
                   " group BY  a.cust_kp_no       order  BY min_time  asc ";

            try
            {
                 
                dbot.OpenCon(strDb_Name);
                dt = dbot.excutSelectSQL(strSql);


                dtSet.Tables.Add(dt);
                return dtSet;
            }
            catch (Exception e_getdoc)
            {
                return dtSet;
            }
            finally
            {
                dbot.CloseConn();
            }
        }

        [WebMethod]
        public DataSet Whs_CheckinQuery_DETAIL(string str_emp, string str_cust_kp_no, string strDb_Name)
        {
            DBOP dbot = new DBOP();


            DataTable dt = new DataTable();
            DataSet dtSet = new DataSet();
            string strResult = string.Empty;
            string strSql = string.Empty;

            strSql = "SELECT    a.tr_sn ,  qty,start_time " +
                     " FROM mes4.r_whs_location a, mes1.c_whs_name_cust b " +
                     " WHERE a.AREA=b.AREA   and  a.cust_kp_no = b.cust_kp_no " +
                     " AND a.LOCATION = '0-0-0' " +
                     " AND b.emp_no = '" + str_emp + "' " +
                     " and a.cust_kp_no ='" + str_cust_kp_no + "' " +
                     " order BY start_time asc";

            try
            {

                dbot.OpenCon(strDb_Name);
                dt = dbot.excutSelectSQL(strSql);


                dtSet.Tables.Add(dt);
                return dtSet;
            }
            catch (Exception e_getdoc)
            {
                return dtSet;
            }
            finally
            {
                dbot.CloseConn();
            }
        }

        [WebMethod]
        public DataSet Whs_UnCheck_Querry(string str_emp,  string strDb_Name)
        {
            DBOP dbot = new DBOP();


            DataTable dt = new DataTable();
            DataSet dtSet = new DataSet();
            string strResult = string.Empty;
            string strSql = string.Empty;

            strSql = "SELECT a.sap_qty,a.cust_kp_no, a.check_qty, a.allpart_qty, " +
                    " a.deff_qty" +
                    " FROM mes4.r_whs_check_result a, mes1.c_whs_name_cust b, mes1.c_emp c, mes4.r_stock d " +
                    " WHERE a.work_flag = '0' " +
                    " AND a.cust_kp_no = b.cust_kp_no " +
                    "  AND A.SAP_stock=D.SAP_stock"+
                    " AND D.AREA=C.FLOOR"+
                    " AND b.area = a.area " +
                    " AND b.area = c.FLOOR " +
                   " AND b.emp_no = c.emp_no " +
                    " AND C.emp_no = '" + str_emp + "'";

            try
            {

                dbot.OpenCon(strDb_Name);
                dt = dbot.excutSelectSQL(strSql);


                dtSet.Tables.Add(dt);
                return dtSet;
            }
            catch (Exception E_UNCHECK_Q)
            {
                return dtSet;
            }
            finally
            {
                dbot.CloseConn();
            }
        }

        [WebMethod]
        public DataSet Whs_UnCheck_qty(string str_emp, string str_trsn,string strDb_Name)//sap_qty,allpart_qty,check_qty
        {
            DBOP dbot = new DBOP();


            DataTable dt = new DataTable();
            DataSet dtSet = new DataSet();
            string strResult = string.Empty;
            string strSql = string.Empty;

            strSql = "SELECT b.cust_kp_no,a.allpart_qty,a.sap_qty,a.check_qty FROM MES4.R_whs_check_RESULT a,"+
                          " mes4.r_tr_sn b,mes1.c_whs_name_cust c where a.cust_kp_no=b.cust_kp_no " +
                          " and a.cust_kp_no=c.cust_kp_no"+
                          " and b.tr_sn = '"+str_trsn+"'"+
                          " and c.emp_no = '"+str_emp+"'";

            try
            {

                dbot.OpenCon(strDb_Name);
                dt = dbot.excutSelectSQL(strSql);


                dtSet.Tables.Add(dt);
                return dtSet;
            }
            catch (Exception E_UNCHECK_Q)
            {
                return dtSet;
            }
            finally
            {
                dbot.CloseConn();
            }
        }

      

        [WebMethod]
        public DataSet Whs_UnCheck_Querry_SingleKP_detail(string str_emp, string str_cust_kp_no, string strDb_Name)
        {
            DBOP dbot = new DBOP();


            DataTable dt = new DataTable();
            DataSet dtSet = new DataSet();
            string strResult = string.Empty;
            string strSql = string.Empty;


            strSql = " SELECT b.sap_qty, b.allpart_qty, b.check_qty, a.tr_sn, l_location AS LOCATION, " +
                     " a.check_qty AS qty " +
                     " FROM mes4.r_whs_check_detail a, mes4.r_whs_check_result b, mes1.c_emp c " +
                     " WHERE b.cust_kp_no = '" + str_cust_kp_no + "' " +
                     " AND a.work_flag = '0' " +
                     " AND a.cust_kp_no = b.cust_kp_no " +
                     " AND c.FLOOR = b.area " +
                     " AND c.emp_no = '" + str_emp + "' " +
                     " AND a.doc_no = b.doc_no ";

           

            try
            {

                dbot.OpenCon(strDb_Name);
                dt = dbot.excutSelectSQL(strSql);


                dtSet.Tables.Add(dt);
                return dtSet;
            }
            catch (Exception E_UNCHECK_Q)
            {
                return dtSet;
            }
            finally
            {
                dbot.CloseConn();
            }
        }

        /*[WebMethod]
       public DataSet Whs_PANDIAN_IST(string str_emp, string strDb_Name)
       {
           DBOP dbot = new DBOP();


           DataTable dt = new DataTable();
           DataSet dtSet = new DataSet();
           string strResult = string.Empty;
           string strSql = string.Empty;

          //�K�[DETAIL���ƾ�
           strSql = " insert into  mes4.r_whs_check_detail (tr_sn,cust_kp_no,work_flag,check_qty,EDIT_EMP,work_time,l_location)" +
           " select a.tr_sn,b.cust_kp_no,'0',a.qty,b.emp_no,sysdate,a.location from mes4.r_whs_location a, mes1.c_whs_name_cust b" +
          " where a.cust_kp_no=b.cust_kp_no" +
          " and b.emp_no = '" + str_emp + "' " +
         " and a. tr_sn not in(select tr_sn from mes4.r_whs_check_detail)";

           try
           {

               dbot.OpenCon(strDb_Name);
               dt = dbot.excutSelectSQL(strSql);


               dtSet.Tables.Add(dt);
               return dtSet;
           }
           catch (Exception P_IST)
           {
               return dtSet;
           }
           finally
           {
               dbot.CloseConn();
           }
       }*/
       

        //public DataTable checkAllpartEmp(string Emp_no, string PassWord, string strBu)
        //{

        //    string strResult = string.Empty;
        //    string strDb_Name = string.Empty;
        //    sParamets st = new sParamets();
        //    DataTable dt = new DataTable();


        //    Paramets[] ppp ={
        //     st.buildParamet("EMP",OracleType.VarChar,Emp_no,50,ParameterDirection.Input),
        //     st.buildParamet("PWD",OracleType.VarChar,PassWord,50,ParameterDirection.Input),
        //     st.buildParamet("RES",OracleType.VarChar,"",50,ParameterDirection.Output)             
        //                   };


        //    strResult = st.excutsp("MES1.AP_CHECK_WEB_PASSWORD", ppp, strBu);

        //    if (strResult.Substring(1, 2) == "OK")
        //    {
        //        AddDataTable adtb = new AddDataTable();
        //        adtb.test();
        //    }
        //    else
        //    {

        //        DBOP dbot = new DBOP();




        //        string strSql = string.Empty;
        //        strSql = "select * from mes1.c_emp where emp_no='" + Emp_no + "'";

        //        try
        //        {
        //            strDb_Name = strBu;
        //            dbot.OpenCon(strDb_Name);
        //            dt = dbot.excutSelectSQL(strSql);

        //        }
        //        catch (Exception e_getdoc)
        //        {
        //            return dt;
        //        }
        //        finally
        //        {
        //            dbot.CloseConn();
        //        }
        //        return dt;
        //    }
        //    return dt;
        //}


        //add your method 
	}
}
