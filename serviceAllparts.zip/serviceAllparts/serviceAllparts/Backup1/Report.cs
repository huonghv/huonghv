﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Collections;
using System.Xml;

namespace WebServiceGetGrnData
{
    public class Report1
    {
        private XmlDocument xml;   
        private string strID;

        protected string StrID
        {
            get { return strID; }
            set { strID = value; }
        }
        private string strSQL;

        protected string StrSQL
        {
            get { return strSQL; }
            set { strSQL = value; }
        }

        public string getsql(string path,string xmlid)
        {
            string strSQL="";
            string strFields = string.Empty;
            string strField1 = string.Empty, strField2 = string.Empty, strField3 = string.Empty;
            xml = new XmlDocument();
            xml.Load(path);
            XmlNode root = xml.ChildNodes[1];
            XmlNode ReportNode = root;
            foreach (XmlNode node in root.ChildNodes)
            {                
                if (node.Attributes["id"].Value == xmlid)
                {
                    foreach (XmlNode nodeitem in node.ChildNodes)
                    {

                        if (nodeitem.Attributes["id"].Value == "SQL")
                        {
                            strSQL = nodeitem.FirstChild.InnerText;
                        }
                        if (nodeitem.Attributes["id"].Value == "FIELDS")
                        {
                            foreach (XmlNode fielditem in nodeitem.ChildNodes)
                            {
                                if (fielditem.Attributes["id"].Value == "FIELD")
                                {
                                    strField1 = fielditem.Attributes["name"].Value;
                                    strField2 = fielditem.Attributes["option"].Value;
                                    strField3 = fielditem.Attributes["location"].Value;
                                }
                            }
                             
                        }
                        //if (nodeitem.Attributes["id"].Value == "FIELD")
                        //{
                        //    strField = nodeitem.FirstChild.InnerText;
                        //}
                    }
                }
               
            }


            return strSQL;
        }

    }


    public class ReportXml
    {
        private string strXmlURL;                   //the path of xml file
        private XmlDocument xml;                    // a XML document

        public ReportXml()
        {
        }
        public ReportXml(string strURL)
        {
            strXmlURL = strURL;
        }

        ///get the path of the xml file
        public string XmlURL
        {
            get { return strXmlURL; }
            set { strXmlURL = value; }
        }


        /// <summary>
        /// fill a report object with the content from the xml file
        /// </summary>
        /// <param name="XmlFileName"></param>
        /// <param name="report"></param>
        /// <returns></returns>
        public static bool FillReport(string XmlFileName, Report report)
        {
            XmlDocument xml = new XmlDocument();
            xml.Load(XmlFileName);
            XmlNode root = xml.ChildNodes[1];
            XmlNode ReportNode = root;
            bool blnFlag = false;
            foreach (XmlNode node in root.ChildNodes)
                if (node.Attributes["id"].Value == report.ID)
                {
                    ReportNode = node.Clone();
                    blnFlag = true;
                    break;
                }
            //if the node of the report can't be found ,exits the procedure;
            if (!blnFlag)
                return false;

            foreach (XmlNode rNode in ReportNode.ChildNodes)
            {
                switch (rNode.Name)
                {
                    case "title":
                        report.Title = rNode.InnerText;     //get the Title
                        break;
                    case "sql":
                        report.SQLTemplate = rNode.InnerText;//get the SQL statement;
                        break;
                    case "fields":
                        foreach (XmlNode node in rNode.ChildNodes)
                        {
                            Field field = new Field();
                            field.Name = node.Attributes["name"].Value;
                            field.Alias = node.Attributes["alias"].Value;
                            field.Operator = node.Attributes["operator"].Value;
                            field.Location = node.Attributes["location"].Value;
                            field.Flag = node.Attributes["flag"].Value;
                            field.Value = string.Empty;
                            report.AddFields(field);
                        }
                        break;
                    case "columns":
                        //added by zhixin 2004.05.22,altered 2004.05.26
                        foreach (XmlNode node in rNode.ChildNodes)
                        {
                            DataRow dr = report.ColumnCollection.NewRow();
                            foreach (XmlAttribute attr in node.Attributes)
                                dr[attr.Name] = attr.Value;
                            report.AddColumn(dr);
                        }
                        break;
                }//end switch
            }//end foreach
            //return report;
            return true;
        }
        /// <summary>
        /// Get GRN.XML Iceman 2009/02/27
        /// </summary>
        /// <param name="XmlFileName"></param>
        /// <param name="report"></param>
        /// <returns></returns>
        public static bool readGRN(string XmlFileName, Report reportGRN)
        {
            XmlDocument xml = new XmlDocument();
            xml.Load(XmlFileName);
            XmlNode root = xml.ChildNodes[1];
            XmlNode ReportNode = root;
            bool blnFlag = false;
            string Grntemp = "";
            foreach (XmlNode node in root.ChildNodes)
                if (node.Attributes["id"].Value == reportGRN.ID)
                {
                    ReportNode = node.Clone();
                    blnFlag = true;
                    break;
                }
            //if the node of the report can't be found ,exits the procedure;
            if (!blnFlag)
                return false;

            foreach (XmlNode rNode in ReportNode.ChildNodes)
            {
                switch (rNode.Name)
                {
                    case "RC":
                        Grntemp = "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "GRNNO":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "WareHose":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "SerialNumber":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "Date":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "ProductType":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "PartNO":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "Unit":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "Amount":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "AmountOK":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "AmountActual":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "WareHosePort":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "UnitPrice":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "Specification":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "CheckSerialNo":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "PONO":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "InvoiceNO":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "VendorCode":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "VendorName":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "CommissionOrder":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "CheckResult":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "SpecialPONO":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "Note":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "Creator":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "Reciever":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "IQC":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "WarehouseKeeper":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "SpecialPurchaser":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;
                    case "ProductHeader":
                        Grntemp = Grntemp + "<" + rNode.Name + ">" + rNode.InnerText + "<" + "/" + rNode.Name + ">";
                        break;

                }//end switch
            }//end foreach
            //return report;
            reportGRN.SQLTemplate = Grntemp;
            return true;
            //return true;
        }
        /// <summary>
        /// get a report object from xml file
        /// </summary>
        /// <param name="strID">report id to decide a unique report</param>
        /// <returns>return a report object if the node exists else return null</returns>
        public Report getReport(string strID)
        {
            xml = new XmlDocument();
            xml.Load(strXmlURL);
            XmlNode root = xml.ChildNodes[1];
            XmlNode ReportNode = root;
            bool blnFlag = false;
            foreach (XmlNode node in root.ChildNodes)
                if (node.Attributes["id"].Value == strID)
                {
                    ReportNode = node.Clone();
                    blnFlag = true;
                    break;
                }
            //if the node of the report can't be found ,exits the procedure;
            if (!blnFlag)
                return null;

            Report report = new Report();
            report.ID = strID;
            foreach (XmlNode rNode in ReportNode.ChildNodes)
            {
                switch (rNode.Name)
                {
                    case "title":
                        report.Title = rNode.InnerText;     //get the Title
                        break;
                    case "sql":
                        report.SQLTemplate = rNode.InnerText;//get the SQL statement;
                        break;
                    case "fields":
                        foreach (XmlNode node in rNode.ChildNodes)
                        {
                            Field field = new Field();
                            field.Name = node.Attributes["name"].Value;
                            field.Alias = node.Attributes["alias"].Value;
                            field.Operator = node.Attributes["operator"].Value;
                            field.Location = node.Attributes["location"].Value;
                            field.Flag = node.Attributes["flag"].Value;
                            field.Value = string.Empty;
                            report.AddFields(field);
                        }
                        break;
                    case "columns":
                        //added by zhixin 2004.05.22,altered 2004.05.26
                        foreach (XmlNode node in rNode.ChildNodes)
                        {
                            DataRow dr = report.ColumnCollection.NewRow();
                            foreach (XmlAttribute attr in node.Attributes)
                                dr[attr.Name] = attr.Value;
                            report.AddColumn(dr);
                        }
                        break;
                }//end switch
            }//end foreach
            return report;
        }//end getReport


        /// <summary>
        /// deletes a report node from file by the id
        /// </summary>
        /// <param name="strID">report ID to decide which one should be deleted</param>
        /// <returns>returns true if deletes successfully else false</returns>
        public bool DeleteReport(string strID)
        {
            xml = new XmlDocument();
            xml.Load(strXmlURL);
            XmlNode root = xml.ChildNodes[1];

            foreach (XmlNode node in root.ChildNodes)
                if (node.Attributes["id"].Value == strID)
                {
                    try
                    {
                        root.RemoveChild(node);
                        return true;
                    }
                    catch
                    {
                        throw;
                    }
                }
            return false;
        }

        /// <summary>
        /// adds a report node to the xml file
        /// </summary>
        /// <param name="report">report class</param>
        /// <returns>return true if adds successfully else false </returns>
        public void AddReport(Report report)
        {
            xml = new XmlDocument();
            xml.Load(strXmlURL);
            XmlNode root = xml.ChildNodes[1];

            XmlElement elemReport = xml.CreateElement("report");
            root.AppendChild(elemReport);
            //Creates id attribute
            XmlAttribute attrID = xml.CreateAttribute("id");
            attrID.Value = report.ID;
            elemReport.Attributes.Append(attrID);
            //creates Title element
            XmlElement elemTitle = xml.CreateElement("title");
            elemTitle.InnerText = report.Title;
            elemReport.AppendChild(elemTitle);
            //creates SQL Template element
            XmlElement elemSQL = xml.CreateElement("sql");
            elemSQL.InnerText = report.SQLTemplate;
            elemReport.AppendChild(elemSQL);
            //creates fields element
            XmlElement elemFields = xml.CreateElement("fields");
            elemReport.AppendChild(elemFields);
            //creates field collection
            for (int i = 0; i < report.FieldCollection.Count - 1; i++)
            {
                Field field = (Field)report.FieldCollection[i];
                //creates field element
                XmlElement elemField = xml.CreateElement("field");
                XmlAttribute attrName = xml.CreateAttribute("name");
                XmlAttribute attrAlias = xml.CreateAttribute("alias");
                XmlAttribute attrOperator = xml.CreateAttribute("operator");
                XmlAttribute attrLocation = xml.CreateAttribute("location");
                XmlAttribute attrFlag = xml.CreateAttribute("flag");
                attrName.Value = field.Name;
                attrAlias.Value = field.Alias;
                attrOperator.Value = field.Operator;
                attrLocation.Value = field.Location;
                attrFlag.Value = field.Flag;
                elemField.SetAttributeNode(attrName);
                elemField.SetAttributeNode(attrAlias);
                elemField.SetAttributeNode(attrOperator);
                elemField.SetAttributeNode(attrLocation);
                elemField.SetAttributeNode(attrFlag);
                elemFields.AppendChild(elemField);
            }
            //creates columnss element
            XmlElement elemColumns = xml.CreateElement("columns");
            elemReport.AppendChild(elemColumns);
            //creates column collection
            //for (int i = 0 ; i < report.ColumnCollection.Count - 1 ; i++)
            foreach (DataRow dr in report.ColumnCollection.Rows)
            {
                //creates column element
                XmlElement elemColumn = xml.CreateElement("column");
                XmlAttribute attrNo = xml.CreateAttribute("no");
                XmlAttribute attrColor = xml.CreateAttribute("color");
                XmlAttribute attrAlign = xml.CreateAttribute("align");
                XmlAttribute attrLink = xml.CreateAttribute("link");
                XmlAttribute attrVisible = xml.CreateAttribute("visible");
                attrNo.Value = dr["no"].ToString();
                attrColor.Value = dr["color"].ToString();
                attrAlign.Value = dr["align"].ToString();
                attrLink.Value = dr["link"].ToString();
                attrVisible.Value = dr["visible"].ToString();
                elemColumn.SetAttributeNode(attrNo);
                elemColumn.SetAttributeNode(attrColor);
                elemColumn.SetAttributeNode(attrAlign);
                elemColumn.SetAttributeNode(attrLink);
                elemColumn.SetAttributeNode(attrVisible);
                elemColumns.AppendChild(elemColumn);
            }
            xml.Save(strXmlURL);
        }

        public void UpdateReport(Report report)
        {
            this.DeleteReport(report.ID);
            this.AddReport(report);
            //            xml = new XmlDocument();
            //            xml.Load(strXmlURL);
            //            XmlNode root = xml.ChildNodes[1];
            //            XmlNode ReportNode;
            //            bool blnFlag = false;
            //            foreach(XmlNode node in root.ChildNodes )
            //                if (node.Attributes["id"].Value == report.ID)
            //                {   
            //                    ReportNode = node.Clone();
            //                    blnFlag = true;
            //                    break;
            //                }
            //            if (!blnFlag)
            //                return;
            //            ReportNode.ChildNodes[0].InnerText = report.Title;
            //            ReportNode.ChildNodes[1].InnerText = report.SQLStatment;
            //
        }
    }// end class


    /// <summary>
    /// 
    /// </summary>
    public class Field
    {
        protected string fName = string.Empty;
        protected string fAlias = string.Empty;
        protected string fOperator = string.Empty;
        protected string fLocation = string.Empty;
        protected string fValue = string.Empty;
        protected string fFlag = string.Empty;          //flag = 1: this field is a kind of code
        //   and is only required while transforming the sql
        // = 2: this field is a kind of name and is
        // only used to display as a condition
        // = 0 both

        public string Name
        {
            get { return fName; }
            set { fName = value; }
        }
        public string Alias
        {
            get { return fAlias; }
            set { fAlias = value; }
        }

        public string Operator
        {
            get { return fOperator; }
            set { fOperator = value; }
        }
        public string Location
        {
            get { return fLocation; }
            set { fLocation = value; }
        }
        public string Value
        {
            get { return fValue; }
            set { fValue = value; }
        }
        public string Flag
        {
            get { return fFlag; }
            set { fFlag = value; }
        }
        public Field()
        {
        }
        public Field(string lName, string lAlias, string lOperator,
            string lLocation, string lValue, string lFlag)
        {
            fName = lName;
            fAlias = lAlias;
            fOperator = lOperator;
            fLocation = lLocation;
            fValue = lValue;
            fFlag = lFlag;
        }
    }



    /// <summary>
    /// Achieve the SQL statment and related information of a report from xml file.
    /// </summary>
    public class Report
    {
        protected string strID;
        protected string strTitle;
        protected string strSQL;
        protected string strSQLTemp;
        protected ArrayList Fields;
        protected DataTable ColumnTable;
        protected int iFieldCount = -1;
        protected DataTable fDataTable = null;
        //        protected CommonDB custAdp;
        protected ReportXml reports;

        protected string strStartDate = string.Empty, //variables about the datetime parameters
            strEndDate = string.Empty,
            strStartTime = string.Empty,
            strEndTime = string.Empty,
            strStartDateField = string.Empty,
            strStartDateOperator = string.Empty,
            strStartDateLocation = string.Empty,
            strEndDateField = string.Empty,
            strEndDateOperator = string.Empty,
            strEndDateLocation = string.Empty;

        public Report()
        {
            Fields = new ArrayList();
            //fDataTable = new DataTable();
            this.CreateColumnTable();
        }
        public Report(string strId)
        {
            strID = strId;
            //fDataTable = new DataTable();
            Fields = new ArrayList();
            this.CreateColumnTable();
        }

        public string ID
        {
            get { return strID; }
            set { strID = value; }
        }
        public string Title
        {
            get { return strTitle; }
            set { strTitle = value; }
        }
        public string SQLStatment
        {
            get { return strSQL; }
            set { strSQL = value; }
        }
        public string SQLTemplate
        {
            get { return strSQLTemp; }
            set { strSQLTemp = value; }
        }
        public ArrayList FieldCollection
        {
            get { return Fields; }
        }
        public DataTable ColumnCollection
        {
            get { return ColumnTable; }
        }

        public int FieldCount
        {
            get { return Fields.Count; }
        }
        public int ColumnCount
        {
            get { return ColumnTable.Rows.Count; }
        }
        public string StartDate
        {
            set { this.strStartDate = value; }
            get { return this.strStartDate; }
        }
        public string EndDate
        {
            set { this.strEndDate = value; }
            get { return this.strEndDate; }
        }
        //        public DataTable dataTable
        //        {
        //            get {return fDataTable;}
        //        }

        private void CreateColumnTable()
        {
            ColumnTable = new DataTable("columns");
            ColumnTable.Columns.Add(new DataColumn("no", System.Type.GetType("System.String")));
            ColumnTable.Columns.Add(new DataColumn("color", System.Type.GetType("System.String")));
            ColumnTable.Columns.Add(new DataColumn("align", System.Type.GetType("System.String")));
            ColumnTable.Columns.Add(new DataColumn("link", System.Type.GetType("System.String")));
            ColumnTable.Columns.Add(new DataColumn("visible", System.Type.GetType("System.String")));
        }



        /// <summary>
        /// Reset the content of the all properties of the report object
        /// </summary>
        public void Reset()
        {
            //this.fDataTable.Clear();
            this.Fields.Clear();
            this.ColumnTable.Rows.Clear();
            this.iFieldCount = -1;
            strStartDate = string.Empty; //variables about the datetime parameters
            strEndDate = string.Empty;
            strStartTime = string.Empty;
            strEndTime = string.Empty;
            strStartDateField = string.Empty;
            strStartDateOperator = string.Empty;
            strStartDateLocation = string.Empty;
            strEndDateField = string.Empty;
            strEndDateOperator = string.Empty;
            strEndDateLocation = string.Empty;
        }

        /// <summary>
        /// add a field object to the arraylist
        /// </summary>
        /// <param name="field">the field object to be added</param>
        public void AddFields(Field field)
        {
            Fields.Add(field);
        }

        /// <summary>
        /// overload function,add a field object to the arraylist
        /// </summary>
        /// <param name="strName">the name of the field stuct</param>
        /// <param name="strAlias"></param>
        /// <param name="strOperator"></param>
        /// <param name="strLocation"></param>
        /// <param name="strValue"></param>
        public void AddFields(string strName, string strAlias, string strOperator,
            string strLocation, string strValue, string strFlag)
        {
            Field field = new Field();
            field.Name = strName;
            field.Alias = strAlias;
            field.Operator = strOperator;
            field.Location = strLocation;
            field.Value = strValue;
            field.Flag = strFlag;
            this.AddFields(field);
        }

        /// <summary>
        /// fill the value to array,it is required that the sequence of the value added must 
        /// be the same as that of the "fileds" Node in the xml file
        /// </summary>
        /// <param name="strValue">the value to be added</param>
        public void AddValue(string strValue)
        {
            try
            {
                iFieldCount++;
                Field field = (Field)Fields[iFieldCount];

                //20050930簡文彬將ToUpper去掉。

                //field.Value = strValue.ToUpper().Trim();
                //Deleted the function of Trim() by King 20080617
                //field.Value = strValue.Trim();
                field.Value = strValue;
            }
            catch (Exception ex)
            {
                string strEx = ex.Message;
                throw;
            }
        }

        /// <summary>
        /// 設定Filed為起始index
        /// </summary>
        public void ClearValue()
        {
            iFieldCount = -1;
        }

        /// <summary>
        /// binds a value to a field according to the index
        /// </summary>
        /// <param name="index">indicates which field the value is binded with</param>
        /// <param name="strValue">the value to be added</param>
        public void AddValue(int index, string strValue)
        {
            try
            {
                Field field = (Field)Fields[index];

                //20050930簡文彬將ToUpper去掉。

                //field.Value = strValue.ToUpper().Trim();
                //Deleted the function of Trim() by King 20080617
                //field.Value = strValue.Trim();
                field.Value = strValue;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void AddValueList(ArrayList lValueList)
        {
            try
            {
                for (int i = 0; i < lValueList.Count; i++)
                {
                    Field field = (Field)Fields[i];
                    field.Value = lValueList[i].ToString();
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// achieves the title and sql statement of the report from the xml file;
        /// </summary>
        public virtual void TransformSQL()
        {
            string strReplace = string.Empty,
                strLocation = string.Empty;
            strSQL = strSQLTemp;    //get the sql template
            foreach (Field field in Fields)
            {
                //if this field is a kind of name,ignore and try next one
                if (field.Flag.Equals("2") || field.Flag.Equals("3"))
                    continue;
                switch (field.Alias.ToUpper())
                {
                    case "START DATE": strStartDate = field.Value;
                        strStartDateField = field.Name;
                        strStartDateOperator = field.Operator;
                        strStartDateLocation = field.Location;
                        continue;
                    case "END DATE": strEndDate = field.Value;
                        strEndDateField = field.Name;
                        strEndDateOperator = field.Operator;
                        strEndDateLocation = field.Location;

                        continue;
                    case "START TIME": strStartTime = field.Value;
                        continue;
                    case "END TIME": strEndTime = field.Value;
                        continue;
                }

                switch (field.Operator.ToUpper())
                {
                    case "INSTR":
                        strReplace = " AND INSTR(" + field.Name + ","
                            + "'" + field.Value + "'" + ")>0";
                        break;
                    case "LIKE":
                        strReplace = " AND " + field.Name + " "
                            + " LIKE '%" + field.Value + "%' ";
                        break;
                    case "LLIKE":
                        strReplace = " AND " + field.Name + " "
                            + " LIKE '" + field.Value + "%' ";
                        break;
                    case "LIKEL":
                        strReplace = " AND " + field.Name + " "
                            + " LIKE '%" + field.Value + "' ";
                        break;
                    //add by 20150802 fj begin
                    case "LIKEOR":
                        strReplace = " AND ( " + field.Name + " "
                            + " LIKE '%" + field.Value + "%' ";
                        break;
                    case "ORLIKE":
                        strReplace = " OR " + field.Name + " "
                            + " LIKE '%" + field.Value + "%' )";
                        break;
                    //add by 20150802 fj     end 
                    case "MULTIOR":
                        strReplace = " AND ( " + toSQL.TransferMultiOr(field.Name, field.Value) + " )";
                        break;
                    case "ADD":
                        strReplace = " AND " + field.Name + " >= TO_DATE("
                            + "'" + field.Value + "','YYYY-MM-DD') and " + field.Name + " < TO_DATE("
                            + "'" + field.Value + "','YYYY-MM-DD')+1";
                        break;
                    case "ADD2":
                        strReplace = " AND " + field.Name + " >= TO_DATE("
                            + "'" + field.Value + "','YYYY-MM-DD') and " + field.Name + " < TO_DATE("
                            + "'" + field.Value + "','YYYY-MM-DD')+3";
                        break;
                    case "IN":
                        strReplace = " AND " + field.Name + " IN ( "
                            + toSQL.CondtionToSQL(field.Value) + ")";
                        break;
                    case "NIN":
                        strReplace = " AND " + field.Name + "NOT  IN ( "
                            + toSQL.CondtionToSQL1(field.Value) + ")";
                        break;
                    case "NULL":
                        strReplace = field.Value;
                        break;
                    case "IS":
                        strReplace = field.Name + " " + field.Value + " OR ";
                        break;
                    //Added by King 20080616 begin
                    case "IIS":
                        strReplace = field.Name + " = '" + field.Value + "' OR ";
                        break;
                    //Added by King 20080616 end
                    case "SOS":
                        strReplace = field.Name + field.Value + " ) ";
                        break;
                    //Added by cx 20151110   not and
                    case "NOAND":
                        strReplace = " '" + field.Value + "'  ";
                        break;
                    case "ISS":
                        strReplace = " AND " + field.Name + " " + field.Value;
                        break;
                    case "BETWEEN":
                        strReplace = " AND " + field.Name + " BETWEEN TO_DATE("
                            + "'" + field.Value + "','YYYY/MM/DD')";
                        break;
                    case "TIMEBETWEEN":
                        strReplace = " AND " + field.Name + " BETWEEN TO_DATE("
                            + "'" + field.Value + "','YYYY/MM/DD HH24:MI:SS')";
                        break;
                    case "TIMELINK":
                        strReplace = " AND TO_DATE("
                            + "'" + field.Value + "','YYYY/MM/DD HH24:MI:SS')";
                        break;
                    case "LINK":
                        strReplace = " AND TO_DATE("
                            + "'" + field.Value + "','YYYY/MM/DD')";
                        break;
                    case "END1":
                        strReplace = " AND TO_DATE("
                            + "'" + field.Value + "','YYYY/MM/DD')+1";
                        break;
                    case "END2":
                        strReplace = " AND TO_DATE("
                            + "'" + field.Value + "','YYYY/MM/DD')+2";
                        break;
                    case "END3":
                        strReplace = " AND " + field.Name + " "
                                + " = " + "TO_DATE( '" + field.Value + "','YYYY/MM/DD HH24:MI:SS') ";
                        break;
                    case "END":
                        strReplace = " AND TO_DATE("
                            + "'" + field.Value + "','YYYY/MM/DD')";
                        break;
                    case "NN":
                        if (field.Value.ToUpper().Equals("NULL"))
                        {
                            strReplace = " AND " + field.Name + " "
                                + "IS NULL";
                        }
                        else
                        {
                            strReplace = " AND " + field.Name + " "
                                + " IS NOT NULL";
                        }
                        break;
                    case "B7RK":
                        if (field.Value.ToUpper().Equals("B7RK"))
                        {
                            strReplace = " AND " + field.Name + " "
                                + "=" + " '" + field.Value + "' ";
                            strReplace = strReplace + " AND b.location_flag='1'";

                        }
                        else
                            strReplace = " AND " + field.Name + " "
                                + "=" + " '" + field.Value + "' ";
                        break;
                    case "TB":
                        strReplace = "" + field.Value + "";
                        break;
                    case "LESS":
                        //Added by RenjieWang 20110420 end
                        strReplace = " AND " + field.Name + " <=TO_DATE("
                            + "'" + field.Value + "','YYYY/MM/DD')";
                        break;
                    case "PKG":
                        strReplace = " AND " + field.Name + "= MES1.GET_TRSN_FOR_PKGID('" + field.Value + "')";
                        break;
                    case "ORL":
                        strReplace = " AND ( " + field.Name + " "
                            + " = '" + field.Value + "' ";
                        break;
                    case "ORR":
                        strReplace = " OR " + field.Name + " "
                            + " = '" + field.Value + "' )";
                        break;
                    default:
                        if (!field.Value.ToUpper().Equals("NULL"))
                        {
                            strReplace = " AND " + field.Name + " "
                                + field.Operator + " '" + field.Value + "' ";
                        }
                        else
                        {
                            strReplace = " AND " + field.Name + " IS NULL ";
                        }
                        break;
                }
                strLocation = field.Location;
                if (field.Value == string.Empty)
                    strSQL = strSQL.Replace(strLocation, string.Empty);
                else
                    strSQL = strSQL.Replace(strLocation, strReplace);
            }
            HandleDateTimeCondition();
        }//end TransformSQL

        public virtual void TransformSQL(int ExecuteSQL)
        {
            TransformSQL();

        }

        public void FillDataTable()
        {
            //            custAdp = new CommonDB();     
            //            fDataTable = new DataTable();
            //            custAdp.SQLstring = strSQL;
            //            custAdp.FillDataTable(fDataTable);          
        }

        /// <summary>
        ///deals with the DateTime Condition independently           
        /// </summary>
        private void HandleDateTimeCondition()
        {
            string starttime = strStartDate,
                endtime = strEndDate;
            string strSQL_Date = string.Empty;
            //start date and end date could not be null at the same time;
            if (strStartDate == string.Empty && strEndDate == string.Empty)
            {
                if (!strEndDateLocation.Equals(string.Empty))
                    strSQL = strSQL.Replace(strEndDateLocation, string.Empty);
                if (!strStartDateLocation.Equals(string.Empty))
                    strSQL = strSQL.Replace(strStartDateLocation, string.Empty);
                return;
            }

            //            if (!strStartDate.Equals(string.Empty))
            //            {
            //                if (!strStartTime.Equals(string.Empty))
            //                    starttime += " " + strStartTime;
            //                else
            //                {
            //                    if (strStartDate.Length == 10)
            //                        starttime += " 00:00:00";
            //                    else 
            //                        starttime = strStartDate;
            //                }
            //            }
            //   
            //            if (!strEndDate.Equals(string.Empty))
            //            {
            //                if (!strEndTime.Equals(string.Empty))
            //                    endtime += " " + strEndTime;
            //                else
            //                {
            //                    if (strEndDate.Length == 10)
            //                        endtime += " 23:59:59";
            //                    else
            //                        endtime = strEndDate;
            //                }
            //            }   

            if (strStartDate != string.Empty && strEndDate == string.Empty)
            {
                if (strStartDate.Length == 10 && strStartTime.Equals(string.Empty))
                    strSQL_Date = " AND " + strStartDateField + " " + strStartDateOperator
                        + " TO_DATE('" + strStartDate + "','YYYY-MM-DD')";
                else
                {
                    if (strStartDate.Length > 10)
                        strSQL_Date = " AND " + strStartDateField + " " + strStartDateOperator
                            + " TO_DATE('" + strStartDate + "','YYYY-MM-DD HH24:MI:SS') ";
                    if (!strStartTime.Equals(string.Empty))
                        strSQL_Date = " AND " + strStartDateField + " " + strStartDateOperator
                            + " TO_DATE('" + strStartDate + " " + strStartTime + "',"
                            + " 'YYYY-MM-DD HH24:MI:SS') ";
                }
            }

            if (strStartDate == string.Empty && strEndDate != string.Empty)
            {
                if (strEndDate.Length == 10 && strEndTime.Equals(string.Empty))
                    strSQL_Date = " AND " + strEndDateField + " " + strEndDateOperator
                        + " TO_DATE('" + strEndDate + "','YYYY-MM-DD')";
                else
                {
                    if (strEndDate.Length > 10)
                        strSQL_Date = " AND " + strEndDateField + " " + strEndDateOperator
                            + " TO_DATE('" + strEndDate + "','YYYY-MM-DD HH24:MI:SS') ";
                    if (!strEndTime.Equals(string.Empty))
                        strSQL_Date = " AND " + strEndDateField + " " + strEndDateOperator
                            + " TO_DATE('" + strEndDate + " " + strEndTime + "',"
                            + " 'YYYY-MM-DD HH24:MI:SS') ";
                }
            }
            if (!strStartDate.Equals(string.Empty) && !strEndDate.Equals(string.Empty))
            {
                if (strStartDate.Length == 10 && strEndTime.Equals(string.Empty))
                {
                    DateTime dtNextEndDate = DateTime.Parse(strEndDate).AddDays(1);

                    strSQL_Date = " AND " + strStartDateField + " >= TO_DATE('" + strStartDate
                        + "','YYYY-MM-DD') AND " + strEndDateField + " < TO_DATE('"
                        + dtNextEndDate.ToString("yyyy-MM-dd")
                        + "','YYYY-MM-DD') ";
                }
                else
                {
                    if (strStartDate.Length > 10)
                    {
                        strSQL_Date = " AND " + strStartDateField + " BETWEEN TO_DATE('"
                            + strStartDate + "','YYYY-MM-DD HH24:MI:SS') AND TO_DATE('"
                            + strEndDate + "','YYYY-MM-DD HH24:MI:SS') ";
                    }
                    if (!strStartTime.Equals(string.Empty))
                    {
                        strSQL_Date = " AND " + strStartDateField + " BETWEEN TO_DATE('"
                            + strStartDate + " " + strStartTime + "','YYYY-MM-DD HH24:MI:SS') "
                            + " AND TO_DATE('" + strEndDate + " " + strEndTime + "',"
                            + " 'YYYY-MM-DD HH24:MI:SS') ";
                    }
                }
            }

            strSQL = strSQL.Replace(strStartDateLocation, strSQL_Date);
        }  // end HandleDateTimeCondition         

        /// <summary>
        /// Adds a column to the report, added by zhixin 2004.05.26
        /// </summary>
        /// <param name="strNo"></param>
        /// <param name="strColor"></param>
        /// <param name="strAlign"></param>
        /// <param name="strLink"></param>
        /// <param name="strVisible"></param>
        public void AddColumn(string strNo, string strColor, string strAlign,
            string strLink, string strVisible)
        {
            DataRow dr = ColumnTable.NewRow();
            dr["no"] = strNo;
            dr["color"] = strColor;
            dr["align"] = strAlign;
            dr["link"] = strLink;
            dr["visible"] = strVisible;
            ColumnTable.Rows.Add(dr);
        }

        /// <summary>
        /// Adds a column to the report, added by zhixin 2004.05.26
        /// </summary>
        /// <param name="dr"></param>
        public void AddColumn(DataRow dr)
        {
            ColumnTable.Rows.Add(dr);
        }

        /// <summary>
        /// get the value of the field by the Alias
        /// </summary>
        /// <param name="lAlias"></param>
        /// <returns></returns>
        public string getFieldValue(string lAlias)
        {
            string strResult = string.Empty;
            for (int i = 0; i < Fields.Count; i++)
            {
                Field field = (Field)Fields[i];
                if (field.Alias == lAlias)
                {
                    strResult = field.Value;
                    break;
                }
            }
            return strResult;
        }

        /// <summary>
        /// transforms the field to an arraylist which contains DictionaryEntry
        /// </summary>
        /// <returns>array list contianing the alias and the value of fieldcollection</returns>
        public ArrayList FieldsToDictionaryEntryList()
        {
            ArrayList al = new ArrayList();
            foreach (Field field in Fields)
            {
                //if this field is a kind of code,ignore and try next one;
                if (field.Flag == "1" || field.Value.Equals(string.Empty))
                    continue;
                DictionaryEntry de = new DictionaryEntry(field.Alias, field.Value);
                switch (field.Alias.ToUpper())
                {
                    case "START TIME": continue;
                    case "END TIME": continue;
                    case "START DATE": de.Value = strStartDate + " " + strStartTime;
                        break;
                    case "END DATE": de.Value = strEndDate + " " + strEndTime;
                        break;
                }
                al.Add(de);
            }
            return al;
        }// end FieldToArrayList

        /// <summary>
        /// Transforms the fields to an ArrayList which contains 3d string
        /// </summary>
        /// <returns>an ArrayList object</returns>
        public ArrayList FieldToArrayList()
        {
            ArrayList al = new ArrayList();
            foreach (Field field in Fields)
            {
                string[] strTemp = new string[3];
                strTemp[0] = field.Alias;
                strTemp[1] = field.Value;
                strTemp[2] = field.Flag;
                switch (field.Alias.ToUpper())
                {
                    case "START TIME": continue;
                    case "END TIME": continue;
                    case "START DATE":
                        if (!strStartTime.Equals(string.Empty))
                            strTemp[1] = strStartDate + " " + strStartTime;
                        break;
                    case "END DATE":
                        if (!strEndTime.Equals(string.Empty))
                            strTemp[1] = strEndDate + " " + strEndTime;
                        break;
                }
                al.Add(strTemp);
            }
            return al;
        } // end fieldtoarraylist

    }//end class Report


    /// <summary>
    /// Summary description for toSQL.
    /// </summary>
    public class toSQL
    {
        public toSQL()
        {
        }
        /// <summary>
        /// transforms the data in a definited column of a datatable into 
        /// a string array like 'xxxx1',xxxx2',xxxx3'
        /// </summary>
        /// <param name="dt">a datatable</param>
        /// <param name="intCol">the column no of the datatable</param>
        /// <returns>a string</returns>
        public static string toList(DataTable dt, int intCol)
        {
            string strList = "''";
            //            if (dt.Rows.Count > 0 )
            //            {
            //                strList = "'" + dt.Rows[0][intCol].ToString() + "'" ;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                strList += ",'" + dt.Rows[i][intCol].ToString() + "'";
            }
            //            }
            return strList;
        }
        /// <summary>
        /// override method which transforms the first column of a datatable
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static string toList(DataTable dt)
        {
            return toList(dt, 0);
        }

        /// <summary>
        /// transforms the data in a definited column of a datatable into 
        /// a string array like 'xxxx1',xxxx2',xxxx3'
        /// </summary>
        /// <param name="dt">a datatable</param>
        /// <param name="intCol">the column no of the datatable</param>
        /// <returns>a string</returns>
        public static string toStringList(DataTable dt, int intCol)
        {
            string strList = "";
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i == 0)
                    strList = dt.Rows[i][intCol].ToString();
                else
                    strList += "," + dt.Rows[i][intCol].ToString();
            }
            return strList;
        }

        /// <summary>
        /// override method which transforms the first column of a datatable
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static string toStringList(DataTable dt)
        {
            return toStringList(dt, 0);
        }

        /// <summary>
        /// changes a string like xxxx,xxxx,xxxx,... 
        /// into this formation 'xxxx','xxxx',xxxx',....
        /// </summary>
        /// <param name="strCondition">the string to be transformed</param>
        /// <returns></returns>
        public static string CondtionToSQL(string strCondition)
        {
            string[] arrTemp = strCondition.Split(',');
            string strTemp = string.Empty;
            if (arrTemp.Length == 1)
                return "'" + strCondition + "'";

            foreach (string str in arrTemp)
                if (strTemp.Equals(string.Empty))
                {
                    strTemp = "'" + str + "'";
                }
                else
                {
                    strTemp += ",'" + str + "'";
                }
            return strTemp;
        }
        public static string CondtionToSQL1(string strCondition)
        {
            string[] arrTemp = strCondition.Split(',');
            string strTemp = string.Empty;
            if (arrTemp.Length == 1)
                return "'" + strCondition + "'";

            foreach (string str in arrTemp)
                strTemp += ",'" + str + "'";
            strTemp = strTemp.Substring(1, strTemp.Length - 1);
            return strTemp;
        }

        //added by winjoy   2008/12/22
        public static string TransferMultiOr(string strname, string strvalue)
        {
            string strTemp = string.Empty;
            string[] arrTemp = strvalue.Split(',');
            if (arrTemp.Length == 0)
            {
                strTemp = strname + " like '%" + strvalue + "%'";
            }
            else
            {
                for (int i = 0; i < arrTemp.Length; i++)
                {
                    if (i == arrTemp.Length - 1)
                    {
                        strTemp = strTemp + strname + " like '%" + arrTemp[i].ToString() + "%'";
                    }
                    else
                    {
                        strTemp = strTemp + strname + " like '%" + arrTemp[i].ToString() + "%' OR ";
                    }
                }
            }
            return strTemp;
        }
        /// <summary>
        /// transforms a string like xxxx1,xxxx2,xxxx3,....
        /// into a short formation like xxxx1(+),
        /// however, preserves the original string 
        /// if the string has only one element xxxx1
        /// </summary>
        /// <param name="strCondition">the string to be transformed</param>
        /// <returns>a string with formation as xxxx1(+) or xxxx1</returns>
        public static string GetConditionDesc(string strCondition)
        {
            string[] arrTemp = strCondition.Split(',');
            if (arrTemp.Length == 1)
                return strCondition;
            else
                return arrTemp[0] + "(+)";
        }
    }


}
