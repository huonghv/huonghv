﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using SAPFunctionsOCX;
using SAPLogonCtrl;
using SAPTableFactoryCtrl;

namespace CallRfcCsharp
{
    public class CallRfc
    {

    }

    public class objs
    {
        private string a;
        public string A
        {
            get { return a; }
            set { a = value; }
        }

        private string b;
        public string B
        {
            get { return b; }
            set { b = value; }
        }

        private string c;
        public string C
        {
            get { return c; }
            set { c = value; }
        }
    }

    public class connCallRfc
    {
        private string a;
        public string A
        {
            get { return a; }
            set { a = value; }
        }

        private string b;
        public string B
        {
            get { return b; }
            set { b = value; }
        }

        private string c;
        public string C
        {
            get { return c; }
            set { c = value; }
        }

        SAPLogonCtrl.SAPLogonControlClass Login = new SAPLogonCtrl.SAPLogonControlClass();

        public string connect()
        {
            string result = string.Empty;

            Login.User = "NSGBG";
            Login.Password = "MESEDICU";
            Login.Client = "800";
            // Login.Language = "EN";
            // Login.ApplicationServer = "10.134.108.111";
            Login.MessageServer = "10.134.108.111";
            Login.GroupName = "CNSBG_800";
            Login.System = "LPD";
            Login.SystemNumber = 10;

            SAPLogonCtrl.Connection Conn = (SAPLogonCtrl.Connection)Login.NewConnection();

            if (Conn.Logon(null, true))
            {
                result = "连接SAP成功";
                Conn.Logoff();
            }
            else
            {
                result = "连接SAP失败";
            }

            return result;
        }

        public void connecttest()
        {
            string result = string.Empty;

            Login.User = "NSGBG";
            Login.Password = "MESEDICU";
            Login.Client = "800";
            // Login.Language = "EN";
            // Login.ApplicationServer = "10.134.108.111";
            Login.MessageServer = "10.134.108.111";
            Login.GroupName = "CNSBG_800";
            Login.System = "LPD";
            Login.SystemNumber = 10;

            SAPLogonCtrl.Connection Conn = (SAPLogonCtrl.Connection)Login.NewConnection();

            if (Conn.Logon(null, true))
            {
                result = "连接SAP成功";
                Conn.Logoff();
            }
            else
            {
                result = "连接SAP失败";
            }
        }

        public SAPLogonCtrl.Connection rconnect()
        {
            string result = string.Empty;

            Login.User = "NSGBG";
            Login.Password = "MESEDICU";
            Login.Client = "800";
            // Login.Language = "EN";
            // Login.ApplicationServer = "10.134.108.111";
            Login.MessageServer = "10.134.108.111";
            Login.GroupName = "CNSBG_800";
            Login.System = "LPD";
            Login.SystemNumber = 10;

            SAPLogonCtrl.Connection Conn = (SAPLogonCtrl.Connection)Login.NewConnection();

            if (Conn.Logon(null, true))
            {
                result = "连接SAP成功";
            }
            else
            {
                result = "连接SAP失败";
            }

            return Conn;
        }

        public void rfc3_d()
        {
            rfc_data(a, b, c);
        }

        public void rfc_data(string strdb, string emp, string plant)
        {
            string strSQL = string.Empty;
            DataTable dt = new DataTable();
            DataTable dtfdb = new DataTable();
            OPDB opdb = new OPDB();
            opdb.OpenCon(strdb);
            strSQL = "select cust_kp_no from mes1.c_whs_name_cust  where emp_no ='" + emp + "'";

            dtfdb = opdb.excutSelectSQL(strSQL);
            opdb.CloseConn();

            SAPLogonCtrl.SAPLogonControlClass login = new SAPLogonCtrl.SAPLogonControlClass();

            login.User = "NSGBG";
            login.Password = "MESEDICU";
            login.Client = "800";

            login.MessageServer = "10.134.108.111";
            login.GroupName = "CNSBG_800";
            login.System = "LPD";

            login.SystemNumber = 10;

            SAPLogonCtrl.Connection conn = (SAPLogonCtrl.Connection)login.NewConnection();

            if (conn.Logon(null, true))
            {
                SAPFunctionsOCX.SAPFunctionsClass func = new SAPFunctionsOCX.SAPFunctionsClass();
                func.Connection = conn;
                SAPFunctionsOCX.IFunction ifunc = (SAPFunctionsOCX.IFunction)func.Add("ZCMM_NSBG_0025");
                SAPFunctionsOCX.IParameter gclient = (SAPFunctionsOCX.IParameter)ifunc.get_Exports("PLANT");
                gclient.Value = plant;

                SAPTableFactoryCtrl.Tables tables = (SAPTableFactoryCtrl.Tables)ifunc.Tables;
                SAPTableFactoryCtrl.Table options = (SAPTableFactoryCtrl.Table)tables.get_Item("IN_MAT");

                if (dtfdb.Rows.Count > 0)
                {
                    for (int i = 0; i < dtfdb.Rows.Count; i++)
                    {
                        string aa = dtfdb.Rows[i][0].ToString();
                        options.AppendGridData(1, 1, 1, aa);
                        //if (i == 50)
                        //{
                        //    break;
                        //}
                    }
                }

                ifunc.Call();

                SAPTableFactoryCtrl.Tables ENQs = (SAPTableFactoryCtrl.Tables)ifunc.Tables;              //get all the tables
                SAPTableFactoryCtrl.Table OUT_STOCK = (SAPTableFactoryCtrl.Table)ENQs.get_Item("OUT_STOCK");  //Get table 'ENQ'
                SAPTableFactoryCtrl.Table IN_LOC = (SAPTableFactoryCtrl.Table)ENQs.get_Item("IN_LOC");  //Get table 'ENQ'
                SAPTableFactoryCtrl.Table IN_MAT = (SAPTableFactoryCtrl.Table)ENQs.get_Item("IN_MAT");  //Get table 'ENQ'

                string str_doc = string.Empty, str_floor = string.Empty;

                opdb.OpenCon(strdb);
                strSQL = "select to_char(sysdate,'YMMDD')||to_char(emp_no),substr(floor,1,1) " +
                    "From mes1.c_emp where emp_no ='" + emp + "'";
                dtfdb = opdb.excutSelectSQL(strSQL);
                str_doc = dtfdb.Rows[0][0].ToString();
                str_floor = dtfdb.Rows[0][1].ToString();

                if (OUT_STOCK.RowCount > 0)
                {
                    dt = creatDatatable(OUT_STOCK);
                    string x = string.Empty;
                    string y = string.Empty;
                    string a = string.Empty;
                    dt = creatDatatable(OUT_STOCK);
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        x = dt.Rows[i][0].ToString();
                        y = dt.Rows[i][2].ToString();
                        a = dt.Rows[i][1].ToString();
                        opdb.OpenCon(strdb);
                        strSQL = "insert into  mes4.R_WHS_pandian_table(CUST_KP_NO,sap_qty,EMP_NO,sap_stock,DOC_NO,area)  values('" + x.ToUpper().ToString() + "','" + y.ToUpper().ToString() + "','" + emp + "','" + a.ToUpper().ToString() + "','" + str_doc + "','" + str_floor + "')";

                        dtfdb = opdb.excutSelectSQL(strSQL);
                    }
                    opdb.OpenCon(strdb); //未操作的數據更新
                    strSQL = "delete mes4.r_whs_check_result where work_flag='0' and edit_emp='" + emp + "'";
                    dtfdb = opdb.excutSelectSQL(strSQL);

                    opdb.OpenCon(strdb);//WHS detail表數據

                    strSQL = "insert into  mes4.r_whs_check_detail (tr_sn,cust_kp_no,work_flag,check_qty,EDIT_EMP,l_location,doc_no,AREA,work_time)" +
                    " select distinct a.tr_sn,b.cust_kp_no,'0',A.QTY,b.emp_no,a.location,'" + str_doc + "',C.floor,sysdate  from mes4.r_whs_location a, mes1.c_whs_name_cust b ," +
                    " mes1.c_empstock c" +
                    " where a.cust_kp_no=b.cust_kp_no" +
                    " and b.emp_no=c.emp_no" +
                    " and b.emp_no ='" + emp + "'" +
                   "  and a.location not in('0-0-0',' ')" +
                      " and a.area=b.area" +
                         " and a.tr_sn not in(select tr_sn from mes4.r_whs_check_detail where area=(select floor from mes1.c_empstock where emp_no='" + emp + "'))" +
                     " and a.cust_kp_no not in(select cust_kp_no from mes4.r_whs_check_result where work_flag='1' and area =(select distinct floor from mes1.c_empstock where emp_no='" + emp + "'))" +
                    " and b.cust_kp_no not in(select kp_no from mes1.c_solder_base)";
                    dtfdb = opdb.excutSelectSQL(strSQL);

                    opdb.OpenCon(strdb);
                    strSQL = "insert into mes4.r_whs_check_detail(tr_sn,cust_kp_no,work_flag,check_qty,EDIT_EMP,l_location,doc_no)" +
                     " select distinct a.tr_sn,b.cust_kp_no,'0',A.QTY,b.edit_emp,a.location,'" + str_doc + "' from MES4.R_KITTING_LOCATION a, mes1.C_KITTING_STOCK_CONFIG b ,MES4.R_sap_stock d," +
                     " mes1.c_empstock c" +
                    " where a.cust_kp_no=b.cust_kp_no" +
                    " and a.cust_kp_no=d.cust_kp_no" +
                    " and b.edit_emp=c.emp_no" +
                    " and b.edit_emp ='" + emp + "'" +
                   "  and a.location not in('0-0-0',' ')" +
                      " and a.area=b.buding" +
                    " and a.tr_sn not in(select tr_sn from mes4.r_whs_check_detail)" +
                       " and a.cust_kp_no not in(select cust_kp_no from mes4.r_whs_check_result where work_flag='1')" +
                    " and b.cust_kp_no not in(select kp_no from mes1.c_solder_base)";
                    dtfdb = opdb.excutSelectSQL(strSQL);

                    /*opdb.OpenCon(strdb);//result中轉表

                    strSQL = "insert into mes4.r_whs_pandian_table(cust_kp_no,sap_qty,allpart_qty,emp_no,area,SAP_STOCK,doc_no)" +
                    " select a.cust_kp_no,'0',sum(a.qty),b.emp_no,d.area,STOCK_LOCATION,'" + str_doc + "'from mes4.r_whs_location a," +
                    " mes1.c_whs_name_cust b, MES4.R_SAP_STOCK C, mes4.r_stock d  " +
                    " where b.emp_no ='" + emp + "'" +
                    " and a.cust_kp_no=b.cust_kp_no" +
                    " and b.cust_kp_no=c.cust_kp_no" +
                    " and a.location not in('0-0-0',' ')" +
                    " and c.STOCK_LOCATION=d.sap_stock" +
                     " AND  D.area  =(SELECT floor from mes1.c_empstock where emp_no ='" + emp + "' )" +//houqi
                       " and a.area=d.area" +
                    " group by a.cust_kp_no,b.emp_no,d.area,STOCK_LOCATION";
                    dtfdb = opdb.excutSelectSQL(strSQL);*/

                    opdb.OpenCon(strdb);
                    strSQL = "insert into mes4.r_whs_pandian_table(cust_kp_no,sap_qty,allpart_qty,emp_no,area,SAP_STOCK,doc_no)" +
  " SELECT  distinct CWNC.CUST_KP_NO,'0',sum(a.qty),ce.emp_no,CE.FLOOR,RS.SAP_STOCK,'" + str_doc + "'" +
  " FROM MES1.C_EMP CE, MES4.R_STOCK RS, MES1.C_WHS_NAME_CUST CWNC,MES4.R_whs_location a" +
  "  WHERE CWNC.EMP_NO = CE.EMP_NO" +
  " and a.cust_kp_no=cwnc.cust_kp_no" +
  " AND CWNC.AREA = RS.AREA" +
  " AND CE.FLOOR = RS.AREA" +
  " AND rs.SAP_STOCK like '%L'" +
  " AND CE.EMP_NO = '" + emp + "'" +
  " and a.location not in('0-0-0',' ')" +
  " and a.area=(select floor from mes1.c_empstock where emp_no='" + emp + "')" +
  " group by CWNC.CUST_KP_NO,CE.FLOOR,RS.SAP_STOCK,CE.EMP_no,ce.floor";
                    dtfdb = opdb.excutSelectSQL(strSQL);

                    opdb.OpenCon(strdb);
                    strSQL = " insert into mes4.r_whs_pandian_table" +
                   " select a.cust_kp_no,'0',sum(a.qty),b.edit_emp,d.area,STOCK_LOCATION,'" + str_doc + "'from MES4.R_KITTING_LOCATION a," +
                   " mes1.C_KITTING_STOCK_CONFIG b, MES4.R_SAP_STOCK C ,mes4.r_stock D " +
                   " where b.EDIT_emp ='" + emp + "'" +
                   " and a.cust_kp_no=b.cust_kp_no" +
                   " and b.cust_kp_no=c.cust_kp_no" +
                   " and a.location not in('0-0-0',' ')" +
                    " and c.STOCK_LOCATION=d.sap_stock" +
                      " and a.area=d.area" +
                   " group by a.cust_kp_no,b.edit_emp,d.area,STOCK_LOCATION";
                    dtfdb = opdb.excutSelectSQL(strSQL);


                    opdb.OpenCon(strdb);//添加result裱中數據
                    strSQL = "insert into mes4.r_whs_check_result (cust_kp_no,sap_qty,allpart_qty,edit_emp,area,sap_stock,doc_no,work_time)" +
                                " select a.cust_kp_no,sum(a.sap_qty),nvl(sum(a.allpart_qty),0),a.emp_no,a.area,a.sap_stock,a.doc_no,sysdate from mes4.r_whs_pandian_table a,mes1.c_empstock b" +
                                " where a.emp_no='" + emp + "'" +
                                " and a.doc_no='" + str_doc + "' " +
                                " and a.emp_no=b.emp_no" +
                                " and a.sap_stock=b.stock" +
                                " and a.cust_kp_no not in(select cust_kp_no from mes4.r_whs_check_result where work_flag='1' and area =(select distinct floor from mes1.c_empstock where emp_no='" + emp + "'))" +
                                " and a.cust_kp_no in(select distinct cust_kp_no from mes1.c_material_check_config where floor=(select distinct floor from mes1.c_empstock where emp_no='" + emp + "'))" +
                                " and a.cust_kp_no in(select distinct cust_kp_no from MES1.C_WHS_NAME_CUST where emp_no='" + emp + "')" +
                                " gROUP BY a.CUST_KP_NO,a.EMP_NO,a.AREA,a.SAP_STOCK,a.doc_no";
                    dtfdb = opdb.excutSelectSQL(strSQL);

                    //opdb.OpenCon(strdb);
                    //strSQL = "delete mes4.r_whs_check_result  where ALLPART_qty='0'";
                    //dtfdb = opdb.excutSelectSQL(strSQL);

                    opdb.OpenCon(strdb);//7天之內 沿用最早work_time 單號
                    strSQL = "update mes4.r_whs_check_result" +
     " SET DOC_no=(select distinct doc_no from mes4.r_whs_check_result " +
     " where tO_date(sysdate)-to_date((select min(work_time) from mes4.r_whs_check_result " +
     " where edit_emp='" + emp + "') )<'7' and  edit_emp='" + emp + "'" +
     " and work_time =(select min(work_time) from mes4.r_whs_check_result where edit_emp='" + emp + "' and work_flag='1'))," +
     " WORK_time=(select min(work_time) from mes4.r_whs_check_result where edit_emp='" + emp + "' AND WORK_flag='1')" +
     " where   tO_date(sysdate)-to_date((select min(work_time) from mes4.r_whs_check_result where edit_emp='" + emp + "' ) )<'7'" +
     " and cust_kp_no not in(select cust_kp_no from mes1.c_material_check_config where type_flag='1')" +
      " and edit_emp='" + emp + "'";
                    dtfdb = opdb.excutSelectSQL(strSQL);

                    opdb.OpenCon(strdb);
                    strSQL = " UPDATE MES4.R_whs_check_result " +
     " set doc_no='" + str_doc + "' ," +
     " work_time=sysdate" +
     " where doc_no is null" +
     " and doc_no is null ";
                    dtfdb = opdb.excutSelectSQL(strSQL);

                }
                opdb.OpenCon(strdb);//刪除中轉表

                strSQL = "delete mes4.r_whs_check_result where allpart_qty='0' and sap_qty='0'";
                dtfdb = opdb.excutSelectSQL(strSQL);

                opdb.OpenCon(strdb);//刪除中轉表

                strSQL = "delete mes4.r_whs_pandian_table  where doc_no='" + str_doc + "'";
                dtfdb = opdb.excutSelectSQL(strSQL);
            }

            opdb.CloseConn();
        }

        public DataTable rfc3(string strdb, string emp, string plant)
        {
            string strSQL = string.Empty;
            DataTable dt = new DataTable();
            DataTable dtfdb = new DataTable();
            OPDB opdb = new OPDB();
            opdb.OpenCon(strdb);

            strSQL = "select cust_kp_no from mes1.c_whs_name_cust  where emp_no ='" + emp + "'";

            dtfdb = opdb.excutSelectSQL(strSQL);
            opdb.CloseConn();

            SAPFunctionsOCX.SAPFunctionsClass func = new SAPFunctionsOCX.SAPFunctionsClass();
            func.Connection = rconnect();
            SAPFunctionsOCX.IFunction ifunc = (SAPFunctionsOCX.IFunction)func.Add("ZCMM_NSBG_0025");           //Call Function module 'ENQUEUE_READ'
            SAPFunctionsOCX.IParameter gclient = (SAPFunctionsOCX.IParameter)ifunc.get_Exports("PLANT");  //Get the import paremeter
            gclient.Value = plant;

            SAPTableFactoryCtrl.Tables tables = (SAPTableFactoryCtrl.Tables)ifunc.Tables;
            SAPTableFactoryCtrl.Table options = (SAPTableFactoryCtrl.Table)tables.get_Item("IN_MAT");

            if (dtfdb.Rows.Count > 0)
            {
                for (int i = 0; i < dtfdb.Rows.Count; i++)
                {
                    string aa = dtfdb.Rows[i][0].ToString();
                    options.AppendGridData(1, 1, 1, aa);
                    //if (i==50)
                    //{
                    //    break;
                    //}
                }
            }

            //options.AppendGridData(1, 1, 1, "26-100243-01");
            //options.AppendGridData(2, 1, 1, "11-1153-02");

            ifunc.Call();
            // SAPFunctionsOCX.IParameter NUMBER = (SAPFunctionsOCX.IParameter)ifunc.get_Imports("SUBRC");
            SAPTableFactoryCtrl.Tables ENQs = (SAPTableFactoryCtrl.Tables)ifunc.Tables;              //get all the tables
            SAPTableFactoryCtrl.Table OUT_STOCK = (SAPTableFactoryCtrl.Table)ENQs.get_Item("OUT_STOCK");  //Get table 'ENQ'
            SAPTableFactoryCtrl.Table IN_LOC = (SAPTableFactoryCtrl.Table)ENQs.get_Item("IN_LOC");  //Get table 'ENQ'
            SAPTableFactoryCtrl.Table IN_MAT = (SAPTableFactoryCtrl.Table)ENQs.get_Item("IN_MAT");  //Get table 'ENQ'

            string str_doc = string.Empty, str_floor = string.Empty;

            opdb.OpenCon(strdb);
            strSQL = "elect to_char(sysdate,'YMMDD')||to_char(emp_no),substr(floor,1,1) " +
                  "From mes1.c_emp where emp_no ='" + emp + "'";
            dtfdb = opdb.excutSelectSQL(strSQL);
            str_doc = dtfdb.Rows[0][0].ToString();
            str_floor = dtfdb.Rows[0][1].ToString();

            if (OUT_STOCK.RowCount > 0)
            {
                dt = creatDatatable(OUT_STOCK);
                string x = string.Empty;
                string y = string.Empty;
                string a = string.Empty;
                dt = creatDatatable(OUT_STOCK);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    x = dt.Rows[i][0].ToString();
                    y = dt.Rows[i][2].ToString();
                    a = dt.Rows[i][1].ToString();
                    opdb.OpenCon(strdb);
                    strSQL = "insert into  mes4.R_WHS_pandian_table(CUST_KP_NO,sap_qty,EMP_NO,sap_stock,DOC_NO,area)  values('" + x.ToUpper().ToString() + "','" + y.ToUpper().ToString() + "','" + emp + "','" + a.ToUpper().ToString() + "','" + str_doc + "','" + str_floor + "')";

                    dtfdb = opdb.excutSelectSQL(strSQL);
                }

                opdb.OpenCon(strdb);
                strSQL = "delete mes4.r_whs_check_result where work_flag='0'  and edit_emp='" + emp + "'";
                dtfdb = opdb.excutSelectSQL(strSQL);

                opdb.OpenCon(strdb);


                strSQL = "insert into  mes4.r_whs_check_detail (tr_sn,cust_kp_no,work_flag,check_qty,EDIT_EMP,work_time,l_location,doc_no,AREA)" +
            " select distinct a.tr_sn,b.cust_kp_no,'0',A.QTY,b.emp_no,sysdate,a.location,'" + str_doc + "',C.floor  from mes4.r_whs_location a, mes1.c_whs_name_cust b ," +
            " mes1.c_empstock c" +
            " where a.cust_kp_no=b.cust_kp_no" +
            " and b.emp_no=c.emp_no" +
            " and b.emp_no ='" + emp + "'" +
           "  and a.location not in('0-0-0',' ')" +
              " and a.area=b.area" +
            " and a.tr_sn not in(select tr_sn from mes4.r_whs_check_detail)" +
            " and a.cust_kp_no not in(select cust_kp_no from mes4.r_whs_check_result where work_flag='1')" +
            " and b.cust_kp_no not in(select kp_no from mes1.c_solder_base)";
                dtfdb = opdb.excutSelectSQL(strSQL);

                opdb.OpenCon(strdb);
                strSQL = "insert into mes4.r_whs_check_detail(tr_sn,cust_kp_no,work_flag,check_qty,EDIT_EMP,work_time,l_location,doc_no)" +
                 " select distinct a.tr_sn,b.cust_kp_no,'0',A.QTY,b.edit_emp,sysdate,a.location,'" + str_doc + "' from MES4.R_KITTING_LOCATION a, mes1.C_KITTING_STOCK_CONFIG b ,MES4.R_sap_stock d," +
                 " mes1.c_empstock c" +
                " where a.cust_kp_no=b.cust_kp_no" +
                " and a.cust_kp_no=d.cust_kp_no" +
                " and b.edit_emp=c.emp_no" +
                " and b.edit_emp ='" + emp + "'" +
               "  and a.location not in('0-0-0',' ')" +
                  " and a.area=b.buding" +
                " and a.tr_sn not in(select tr_sn from mes4.r_whs_check_detail)" +
                " and b.cust_kp_no not in(select kp_no from mes1.c_solder_base)";
                dtfdb = opdb.excutSelectSQL(strSQL);

                /*opdb.OpenCon(strdb);
                strSQL = "insert into mes4.r_whs_pandian_table(cust_kp_no,sap_qty,allpart_qty,emp_no,area,SAP_STOCK,doc_no)" +
                " select a.cust_kp_no,'0',sum(a.qty),b.emp_no,d.area,STOCK_LOCATION,'" + str_doc + "'from mes4.r_whs_location a," +
                " mes1.c_whs_name_cust b, MES4.R_SAP_STOCK C, mes4.r_stock d  " +
                " where b.emp_no ='" + emp + "'" +
                " and a.cust_kp_no=b.cust_kp_no" +
                " and b.cust_kp_no=c.cust_kp_no" +
                " and a.location not in('0-0-0',' ')" +
                " and c.STOCK_LOCATION=d.sap_stock" +
                   " and a.area=d.area" +
                " group by a.cust_kp_no,b.emp_no,d.area,STOCK_LOCATION";
                dtfdb = opdb.excutSelectSQL(strSQL);*/

                opdb.OpenCon(strdb);
                strSQL = "insert into mes4.r_whs_pandian_table(cust_kp_no,sap_qty,allpart_qty,emp_no,area,SAP_STOCK,doc_no)" +
" SELECT  distinct CWNC.CUST_KP_NO,'0',sum(a.qty),ce.emp_no,CE.FLOOR,RS.SAP_STOCK,'" + str_doc + "'" +
" FROM MES1.C_EMP CE, MES4.R_STOCK RS, MES1.C_WHS_NAME_CUST CWNC,MES4.R_whs_location a" +
" HERE CWNC.EMP_NO = CE.EMP_NO" +
" and a.cust_kp_no=cwnc.cust_kp_no" +
" AND CWNC.AREA = RS.AREA" +
" AND CE.FLOOR = RS.AREA" +
" AND rs.SAP_STOCK like '%L'" +
" AND CE.EMP_NO = '" + emp + "'" +
" and a.area=(select floor from mes1.c_empstock where emp_no='" + emp + "')" +
" group by CWNC.CUST_KP_NO,CE.FLOOR,RS.SAP_STOCK,CE.EMP_no,ce.floor";
                dtfdb = opdb.excutSelectSQL(strSQL);

                opdb.OpenCon(strdb);
                strSQL = " insert into mes4.r_whs_pandian_table" +
               " select a.cust_kp_no,'0',sum(a.qty),b.edit_emp,d.area,STOCK_LOCATION,'" + str_doc + "'from MES4.R_KITTING_LOCATION a," +
               " mes1.C_KITTING_STOCK_CONFIG b, MES4.R_SAP_STOCK C ,mes4.r_stock D " +
               " where b.EDIT_emp ='" + emp + "'" +
               " and a.cust_kp_no=b.cust_kp_no" +
               " and b.cust_kp_no=c.cust_kp_no" +
               " and a.location not in('0-0-0',' ')" +
                " and c.STOCK_LOCATION=d.sap_stock" +
                  " and a.area=d.area" +
               " group by a.cust_kp_no,b.edit_emp,d.area,STOCK_LOCATION";
                dtfdb = opdb.excutSelectSQL(strSQL);


                opdb.OpenCon(strdb);
                strSQL = "insert into mes4.r_whs_check_result (cust_kp_no,sap_qty,allpart_qty,edit_emp,area,sap_stock,doc_no,work_time)" +
                      " select a.cust_kp_no,sum(a.sap_qty),nvl(sum(a.allpart_qty),0),a.emp_no,a.area,a.sap_stock,a.doc_no,sysdate from mes4.r_whs_pandian_table a,mes1.c_empstock b" +
                      " where a.emp_no='" + emp + "'" +
                      " and a.doc_no='" + str_doc + "' " +
                      " and a.emp_no=b.emp_no" +
                      " and a.sap_stock=b.stock" +
                      " and a.cust_kp_no in(select distinct cust_kp_no from mes1.c_material_check_config where floor=(select distinct floor from mes1.c_empstock where emp_no='" + emp + "'))" +
                       " and a.cust_kp_no not in(select cust_kp_no from mes4.r_whs_check_result where work_flag='1' )" +
                      " gROUP BY a.CUST_KP_NO,a.EMP_NO,a.AREA,a.SAP_STOCK,a.doc_no";
                dtfdb = opdb.excutSelectSQL(strSQL);

                opdb.OpenCon(strdb);   //當前時間減去第一次dowload時間，<7執行，7天之內單號一致 
                strSQL = "update mes4.r_whs_check_result" +
" SET DOC_no=(select distinct doc_no from mes4.r_whs_check_result " +
" where tO_date(sysdate)-to_date((select min(work_time) from mes4.r_whs_check_result " +
" where edit_emp='" + emp + "') )<'7' and  edit_emp='" + emp + "'" +
" and work_time =(select min(work_time) from mes4.r_whs_check_result where edit_emp='" + emp + "' and work_flag='1'))," +
" WORK_time=(select min(work_time) from mes4.r_whs_check_result where edit_emp='" + emp + "' AND WORK_flag='1')" +
" where   tO_date(sysdate)-to_date((select min(work_time) from mes4.r_whs_check_result where edit_emp='" + emp + "' ) )<'7'" +
" and cust_kp_no not in(select cust_kp_no from mes1.c_material_check_config where type_flag='1')" +
" and edit_emp='" + emp + "'";
                dtfdb = opdb.excutSelectSQL(strSQL);

                opdb.OpenCon(strdb);
                strSQL = " UPDATE MES4.R_whs_check_result " +
 " set doc_no='" + str_doc + "' ," +
 " work_time=sysdate" +
 " where doc_no is null" +
 " and doc_no is null ";
                dtfdb = opdb.excutSelectSQL(strSQL);
                //opdb.OpenCon(strdb);
                //strSQL = "delete mes4.r_whs_check_result  where ALLPART_qty='0'";
                //dtfdb = opdb.excutSelectSQL(strSQL); 

                opdb.OpenCon(strdb);
                strSQL = "delete mes4.r_whs_pandian_table  where doc_no='" + str_doc + "'";
                dtfdb = opdb.excutSelectSQL(strSQL);
            }

            opdb.CloseConn();
            return dt;
        }

        public DataTable creatDatatable(SAPTableFactoryCtrl.Table a)
        {
            DataTable dt = new DataTable();
            for (int i = 1; i <= a.ColumnCount; i++)
            {
                dt.Columns.Add(a.get_ColumnName(i));
            }
            //DataRow dr = dt.NewRow();
            for (int i = 1; i <= a.RowCount; i++)
            {
                DataRow dr = dt.NewRow();
                for (int j = 0; j < a.ColumnCount; j++)
                {
                    dr[j] = a.get_Value(i, j + 1).ToString();
                }
                dt.Rows.Add(dr);
            }

            return dt;
        }

        public DataTable rfc4(string strdb, string emp, string plant)
        {
            string strSQL = string.Empty;
            DataTable dt = new DataTable();
            DataTable dtfdb = new DataTable();
            OPDB opdb = new OPDB();

            opdb.OpenCon(strdb);
            strSQL = "select cust_kp_no from mes1.c_whs_name_cust  where emp_no ='" + emp + "'";

            dtfdb = opdb.excutSelectSQL(strSQL);
            opdb.CloseConn();

            SAPFunctionsOCX.SAPFunctionsClass func = new SAPFunctionsOCX.SAPFunctionsClass();

            Login.User = "NSGBG";
            Login.Password = "MESEDICU";
            Login.Client = "800";
            // Login.Language = "EN";
            // Login.ApplicationServer = "10.134.108.111";
            Login.MessageServer = "10.134.108.111";
            Login.GroupName = "CNSBG_800";
            Login.System = "LPD";

            Login.SystemNumber = 10;
            // SAPLogonCtrl.Connection Conn = (SAPLogonCtrl.Connection)Login.NewConnection();
            func.Connection = Login.NewConnection();

            if (func.AutoLogon)
            {
                // func.Connection = Conn;

                SAPFunctionsOCX.IFunction ifunc = (SAPFunctionsOCX.IFunction)func.Add("ZCMM_NSBG_0025");           //Call Function module 'ENQUEUE_READ'
                SAPFunctionsOCX.IParameter gclient = (SAPFunctionsOCX.IParameter)ifunc.get_Exports("PLANT");  //Get the import paremeter
                gclient.Value = plant;

                SAPTableFactoryCtrl.Tables tables = (SAPTableFactoryCtrl.Tables)ifunc.Tables;
                SAPTableFactoryCtrl.Table options = (SAPTableFactoryCtrl.Table)tables.get_Item("IN_MAT");

                if (dtfdb.Rows.Count > 0)
                {
                    for (int i = 0; i < dtfdb.Rows.Count; i++)
                    {
                        string aa = dtfdb.Rows[i][0].ToString();
                        options.AppendGridData(1, 1, 1, aa);
                        //if (i == 50)
                        //{
                        //    break;
                        //}
                    }
                }
                ifunc.Call();

                SAPTableFactoryCtrl.Tables ENQs = (SAPTableFactoryCtrl.Tables)ifunc.Tables;              //get all the tables
                SAPTableFactoryCtrl.Table OUT_STOCK = (SAPTableFactoryCtrl.Table)ENQs.get_Item("OUT_STOCK");  //Get table 'ENQ'
                SAPTableFactoryCtrl.Table IN_LOC = (SAPTableFactoryCtrl.Table)ENQs.get_Item("IN_LOC");  //Get table 'ENQ'
                SAPTableFactoryCtrl.Table IN_MAT = (SAPTableFactoryCtrl.Table)ENQs.get_Item("IN_MAT");  //Get table 'ENQ'

                string str_doc = string.Empty, str_floor = string.Empty;

                opdb.OpenCon(strdb);
                strSQL = "select to_char(sysdate,'YMMDDHH')||to_char(emp_no),substr(floor,1,1) " +
               "From mes1.c_emp where emp_no ='" + emp + "'";
                dtfdb = opdb.excutSelectSQL(strSQL);
                str_doc = dtfdb.Rows[0][0].ToString();
                str_floor = dtfdb.Rows[0][1].ToString();

                if (OUT_STOCK.RowCount > 0)
                {
                    dt = creatDatatable(OUT_STOCK);
                }
            }
            return dt;
        }

        public class connectSap
        {

        }
    }
}
