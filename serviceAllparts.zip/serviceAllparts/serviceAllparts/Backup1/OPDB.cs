﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Data.OracleClient;

namespace CallRfcCsharp
{
    class OPDB
    {
        OracleCommand oCmd = new OracleCommand();
        private OracleDataAdapter oAdp = new OracleDataAdapter();

        OracleConnection oCn;
        string strcon;

        public string getBuString(string bu)
        {
            if (bu == "LH-HWT")
            {
                strcon = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringLHHWT"].ToString();
            }
            else if (bu == "LH-CPEI")
            {
                strcon = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringLHCPEI"].ToString();
            }
            else if (bu == "NN-MBD")
            {
                strcon = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringNNMBD"].ToString();
            }
            else if (bu == "NN-CPEI")
            {
                strcon = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringNNCPEI"].ToString();
            }
            else
            {
                strcon = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringLHHWT"].ToString();
            }
            return strcon;
        } 

        public void OpenCon(string bu)
        {
            oCn = new OracleConnection();
            oCn.ConnectionString = getBuString(bu.ToUpper());

            if (oCn.State == ConnectionState.Closed)
            {
                oCn.Open();
            }
        }

        public void CloseConn()
        {
            if (oCn.State == ConnectionState.Open)
            {
                oCn.Close();
                oCn.Dispose();
            }
        }

        public DataTable excutSelectSQL(string strSQL)
        {
            DataTable dt = new DataTable();
            oCmd.Connection = oCn;
            oCmd.CommandText = strSQL;
            oAdp.SelectCommand = oCmd;
            oAdp.Fill(dt);
            oCn.Close();
            oCn.Dispose();
            return (dt);
        }

        public DataTable excutInsertSQL(string strSQL)
        {
            DataTable dt = new DataTable();
            oCmd.Connection = oCn;
            oCmd.CommandText = strSQL;
            oAdp.InsertCommand= oCmd;
            //oAdp.Fill(dt);
            oCn.Close();
            oCn.Dispose();
            return (dt);
        }

        public int excutNoquery(string strSQL)
        {
            int a = 0;
            oCmd.Connection = oCn;
            oCmd.CommandText = strSQL;
            oCmd.CommandType = CommandType.Text;
            a = oCmd.ExecuteNonQuery();
            oCn.Close();
            oCn.Dispose();
            return a;
        }
    }
}
