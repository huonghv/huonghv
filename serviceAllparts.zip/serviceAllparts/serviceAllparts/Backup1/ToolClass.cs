﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using WebServiceGetGrnData.classes;
using System.Data.OracleClient;
using MES.CallRfcForVB;

namespace WebServiceGetGrnData
{
    public class ToolClass
    {
        DataTable dt ;
        DataSet ds ;

        public DataSet createDataSet(string columnName, string message)
        {
            dt = new DataTable();
            ds = new DataSet();
            if (columnName.Length > 0)
            {
                dt.Columns.Add(columnName);
            }
            else
            {
                dt.Columns.Add("data1");
            }

            DataRow dr = dt.NewRow();
            if (message.Length>0)
	        {
                dr[0] = message;
	        }
            else
            {
                 dr[0] ="DATAERROR" ;
            }
            dt.Rows.Add(dr);
            ds.Tables.Add(dt);
            return ds;
        }

        //LCR測試用；
        public static string CheckLcrSP(string strType, string strKP, string strDocNo, string strTRSN, string strWO, string strPNO, string strEMP, string strIP, string strDC, string strLC, string strData1, string strData2, string strValue, string strbu)
        {
            string strResult = string.Empty;
            sParamets st = new sParamets();

            Paramets[] ppp ={
             st.buildParamet("g_transtype",OracleType.VarChar,strType,50,ParameterDirection.Input),
             st.buildParamet("g_kp_no",OracleType.VarChar,strKP.ToUpper(),50,ParameterDirection.Input),
             st.buildParamet("g_doc_no",OracleType.VarChar,strDocNo,50,ParameterDirection.Input),
             st.buildParamet("g_tr_sn",OracleType.VarChar,strTRSN,50,ParameterDirection.Input),
             st.buildParamet("g_wo",OracleType.VarChar,strWO,50,ParameterDirection.Input),
             st.buildParamet("g_pno",OracleType.VarChar,strPNO,50,ParameterDirection.Input),
             st.buildParamet("g_emp",OracleType.VarChar,strEMP,50,ParameterDirection.Input),
             st.buildParamet("g_ip",OracleType.VarChar,strIP,50,ParameterDirection.Input),
             st.buildParamet("g_dc",OracleType.VarChar,strDC,50,ParameterDirection.Input),
             st.buildParamet("g_lc",OracleType.VarChar,strLC,50,ParameterDirection.Input),
             st.buildParamet("g_data1",OracleType.VarChar,strData1,50,ParameterDirection.Input),
             st.buildParamet("g_data2",OracleType.VarChar,strData2,50,ParameterDirection.Input),
             st.buildParamet("g_test_value",OracleType.VarChar,strValue,50,ParameterDirection.Input),
             st.buildParamet("g_min_value",OracleType.Number,"",50,ParameterDirection.Input),
             st.buildParamet("g_max_value",OracleType.Number,"",50,ParameterDirection.Input),
             st.buildParamet("g_test_type",OracleType.VarChar,"",10,ParameterDirection.Input),
             st.buildParamet("g_frequency",OracleType.Number,"",50,ParameterDirection.Input),
             st.buildParamet("g_check_flag",OracleType.VarChar,"",10,ParameterDirection.Input),
             st.buildParamet("res",OracleType.VarChar,"",3000,ParameterDirection.Output)
                           };
            ppp[13].ParaType = ParameterDirection.Output;
            ppp[14].ParaType = ParameterDirection.Output;
            ppp[15].ParaType = ParameterDirection.Output;
            ppp[16].ParaType = ParameterDirection.Output;
            ppp[17].ParaType = ParameterDirection.Output;
            ppp[18].ParaType = ParameterDirection.Output;
            try
            {
                st.excutsp("MES1.check_lcr_sp", ppp, strbu);
                strResult = ppp[18].IValue.ToString();
                if (strType == "TC0001")
                {
                    if (ppp[18].IValue.ToString().Substring(0, 2) == "OK" && ppp[17].IValue.ToString() == "Y")
                    {
                        strResult = "OK," + ppp[15].IValue.ToString() + "," + ppp[16].IValue.ToString() + "," + ppp[13].IValue.ToString() + "," + ppp[14].IValue.ToString();
                    }
                    else
                    {
                        strResult = ppp[18].IValue.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                strResult = ex.Message;
            }
            return strResult;
        }
        
        public static bool ExecProgramParameter(string strProgramType, string strProgramName, string strFunctionName, string strFunctionObject, string strFunctionValue1, string strData1, string strdb)
        {
            bool bExistFlag = false;
            //string strConString = System.Web.HttpContext.Current.Session["conString"].ToString();
            WebServiceGetGrnData.classes.sParamets sParamet = new WebServiceGetGrnData.classes.sParamets();
            string strSQL = "SELECT *                                              " +
                            "FROM mes1.c_program_parameter                         " +
                            "WHERE     program_type = '" + strProgramType + "'                " +
                            "      AND program_name = '" + strProgramName + "'                " +
                            "      AND function_name = '" + strFunctionName + "'              " +
                            "      AND function_object = '" + strFunctionObject + "'          " +
                            "      AND function_value1 = '" + strFunctionValue1 + "'          " +
                            "      AND data1 = '" + strData1 + "'                              ";
            DBOP dbot = new DBOP();
            dbot.OpenCon(strdb);
            DataTable dtTemp = dbot.excutSelectSQL(strSQL);
            if (dtTemp.Rows.Count > 0)
            {
                bExistFlag = true;
            }
            else
            {
                bExistFlag = false;
            }

            return bExistFlag;
        }

        public static bool  CheckPrivilege(string empno, string apname, string function, string bu)
        {
            bool bExistFlag = true;
            DBOP dbot = new DBOP();
            string strSQL = " SELECT CA.EMP_NO,CA.AP_NAME,CA.FUNCTION_NAME "
                + "   FROM MES1.C_AP_CONFIG CA,MES1.C_EMP CB "
                + "  WHERE CA.EMP_NO = CB.EMP_NO"
                + "    AND CA.AP_NAME ='" + apname + "'"
                + "    AND CA.FUNCTION_NAME ='" + function + "'"
                + "    AND CA.EMP_NO ='" + empno.ToUpper() + "'";
            dbot.OpenCon(bu);
            DataTable dtTemp = dbot.excutSelectSQL(strSQL);
            if (dtTemp.Rows.Count > 0)
            {
                bExistFlag = true;
            }
            else
            {
                bExistFlag = false;
            }
            return bExistFlag;
        }

        public static string ExecuteMATERIAL_GT_SP(string strType, string strName, string strMac, string doc_no, string actionid, string strDb_Name)
        {
            string strResult = string.Empty;
            sParamets st = new sParamets();
            Paramets[] ppp ={
                        st.buildParamet("var_type",OracleType.VarChar,strType,50,ParameterDirection.Input),
                        st.buildParamet("var_tr_sn",OracleType.VarChar,strName,50,ParameterDirection.Input),
                        st.buildParamet("var_mac",OracleType.VarChar,strMac,50,ParameterDirection.Input),
                        st.buildParamet("var_docno",OracleType.VarChar,doc_no,50,ParameterDirection.Input),
                        st.buildParamet("var_code",OracleType.VarChar,actionid,50,ParameterDirection.Input),   
                        st.buildParamet("var_message",OracleType.VarChar,"",3000,ParameterDirection.Output)     
                                };
            strResult = st.excutsp("MES1.MATERIAL_GT_SP", ppp, strDb_Name, "var_message");
            return strResult;
        }

        //調用RFC
        public static string SAP_Update311(string sp, DataTable dt, string plant, string strFrom, string strTO, string strbu)
        {
            DataTable dtTemp = new DataTable();
            DBOP dbot = new DBOP();
            string sql, date = string.Empty;
            string SAP_Update = string.Empty;
            bool StockCount_Flag = false;
            //连接SAP
            //连接SAP测试库


            //获取数据库的连接方式

            string strSQL = "SELECT * FROM MES1.C_SAP_CONFIG WHERE SAP_GROUPNAME='CNSBG_800' AND ROWNUM=1";
            dbot.OpenCon(strbu);
            dtTemp = dbot.excutSelectSQL(strSQL);
            //CallRfcForVB.Functions sapFunction = new Functions(null, "10.134.108.152", "800", "00");
            if (dtTemp.Rows.Count < 1)
            {
                return "系統中沒有配置SAP連接方式，請找IT配置";
            }
            else
            {
                MES.CallRfcForVB.Functions sapFunction = new Functions(null,
                    dtTemp.Rows[0]["SAP_IP"].ToString(),
                    dtTemp.Rows[0]["SAP_CLIENT"].ToString(),
                    dtTemp.Rows[0]["SAP_SYSTEM"].ToString(),
                    dtTemp.Rows[0]["SAP_GROUPNAME"].ToString());

                //登陆SAP
                // if (sapFunction.ConnectToSAP("NSGBG", "MESEDICU", "zf"))
                if (sapFunction.ConnectToSAP(dtTemp.Rows[0]["SAP_ACCOUNT"].ToString(), dtTemp.Rows[0]["SAP_PWD"].ToString(), dtTemp.Rows[0]["SAP_LANGUAGE"].ToString()))
                {
                    //月結時若拋賬時間點在配置的時間段內，則賬算到指定拋賬日期data4
                    sql = "SELECT data2, data3,                                                       " +
                        "       TO_CHAR (TO_DATE (data4, 'YYYY/MM/DD HH24:MI:SS'), 'MM/DD/YYYY') data4" +
                        "  FROM mes4.r_sap_temp                                                       " +
                        " WHERE data1 = 'SAP-CO'                                                      " +
                        "   AND SYSDATE >= TO_DATE (data2, 'YYYY/MM/DD HH24:MI:SS')                   " +
                        "   AND SYSDATE <= TO_DATE (data3, 'YYYY/MM/DD HH24:MI:SS')                   ";
                    dbot.OpenCon(strbu);
                    dtTemp = dbot.excutSelectSQL(sql);
                    if (dtTemp.Rows.Count > 0)
                    {
                        date = dtTemp.Rows[0]["data4"].ToString();
                        StockCount_Flag = true;
                    }
                    sapFunction.SetFuncName(sp);
                    DataTable saptable = new DataTable();
                    //object saptable= sapFunction.GetTable("IN_TAB");
                    saptable.Columns.Add("2");
                    saptable.Columns.Add("6");
                    if (ToolClass.ExecProgramParameter("AP", "INTERFACE", "311", "311-VERSION", "Y", "NORMAL", strbu))
                    {
                        saptable.Columns.Add("9");
                    }
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        //sapFunction.SetInPutTable("IN_TAB",dt);
                        //增加传入一行


                        DataRow dr = saptable.NewRow();

                        dr["2"] = dt.Rows[i]["PART_NO"].ToString();
                        dr["6"] = dt.Rows[i]["QTY"].ToString();
                        if (ToolClass.ExecProgramParameter("AP", "INTERFACE", "311", "311-VERSION", "Y", "NORMAL", strbu))
                        {
                            dr["9"] = dt.Rows[i]["KP_VERSION"].ToString();
                        }
                        saptable.Rows.Add(dr);

                    }
                    sapFunction.SetParamName("PLANT", plant);
                    sapFunction.SetParamName("I_LOCATION", strTO);
                    sapFunction.SetParamName("O_LOCATION", strFrom);
                    sapFunction.GetTable("IN_TAB", saptable);
                    if (StockCount_Flag)
                    {
                        sapFunction.SetParamName("PSTNG_DATE", date);
                    }

                    sapFunction.ExecFun();
                    SAP_Update = sapFunction.GetOutPutParam("O_MBLNR").ToString();
                    if (sapFunction.GetOutPutTable("", "OUT_TAB", true).Rows.Count > 0)
                    {
                        for (int j = 0; j < sapFunction.GetOutPutTable("", "OUT_TAB", true).Rows.Count; j++)
                        {
                            SAP_Update = SAP_Update + sapFunction.GetOutPutTable("", "OUT_TAB", true).Rows[j][1].ToString() + "," + sapFunction.GetOutPutTable("", "OUT_TAB", true).Rows[j][7].ToString() + ",;";
                        }
                    }
                    else
                    {
                        SAP_Update = "OK," + SAP_Update;
                    }
                    sapFunction.DisConnectSAP();
                }
                else
                {
                    SAP_Update = "連接SAP失敗";
                }

                return SAP_Update;
            }
        }
        
    }
}
