﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebServiceGetGrnData.classes
{
    
    public class Models
    {
        public bool isNumberic(string str)
        {
            Int32 result = -1;
            try
            {

                result = Convert.ToInt32(str);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public class BC311querry
        {
            public string PNQTY { get; set; }
            public string SNQTY { get; set; }
        }

        public class BC311querryDetail
        {
            public string PART_NO { get; set; }
            public string QTY { get; set; }
            public string SNQTY { get; set; }
        }
        public class BC311OptionQuerry_311detail
        {
            public string TR_SN { get; set; }
            public string PART_NO { get; set; }
            public string QTY { get; set; }
            public string TIME { get; set; }
        }

    }
}