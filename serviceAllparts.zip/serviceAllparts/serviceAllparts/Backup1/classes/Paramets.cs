﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.OracleClient;

namespace WebServiceGetGrnData.classes
{
    public class sParamets
    {
        OracleCommand oCmd = new OracleCommand();
        string strcon;
        OracleConnection oCn = new OracleConnection();

        public string test()
        {
            Paramets[] ParametData ={
                                        buildParamet("EMP",OracleType.VarChar,"Z3011",50,ParameterDirection.Input),
                                         buildParamet("PWD",OracleType.VarChar,"ALLPART1!",50,ParameterDirection.Input),
                                         buildParamet("RES",OracleType.VarChar,"",50,ParameterDirection.Output)
                                    };
            return excutsp("MES1.AP_CHECK_WEB_PASSWORD", ParametData, "NSD01");
        }

        public string getBuString(string bu)
        {
            if (bu == "LH-HWT")
            {
                strcon = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringLHHWT"].ToString();
            }
            else if (bu == "LH-CPEI")
            {
                strcon = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringLHCPEI"].ToString();
            }
            else if (bu == "NN-MBD")
            {
                strcon = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringVNMBD"].ToString();
            }
            else if (bu == "NN-CPEI")
            {
                strcon = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringNNCPEI"].ToString();
            }
            else
            {
                strcon = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringVNMBD"].ToString();
            }
            return strcon;
        }

        public string excutsp(string spName, Paramets[] datas, string bu)
        {
            oCn.ConnectionString = getBuString(bu);

            oCn.Open();
            oCmd.Connection = oCn;
            oCmd.CommandType = CommandType.StoredProcedure;
            oCmd.CommandText = spName;          // "MES1.AP_CHECK_WEB_PASSWORD";
            OracleParameterCollection oParam = oCmd.Parameters;
            oParam.Clear();

            for (int i = 0; i < datas.Length; i++)
            {
                if (datas[i].ParaType == ParameterDirection.Input)
                {
                    oParam.Add(new OracleParameter(datas[i].PName, datas[i].IType, datas[i].ISize));
                    oParam[datas[i].PName].Value = datas[i].IValue;
                }
                else if (datas[i].ParaType == ParameterDirection.Output)
                {
                    oParam.Add(new OracleParameter(datas[i].PName, datas[i].IType, datas[i].ISize));
                    oParam[datas[i].PName].Direction = ParameterDirection.Output;
                }
            }

            oCmd.ExecuteNonQuery();
            string strReturnMessage = oCmd.Parameters["RES"].Value.ToString();
            oCn.Close();
            oCn.Dispose();
            return strReturnMessage;
        }

        // by WeiKai.2019.11.22 SP返回變量名有時不是RES；用這個方法可以指定返回用的是哪個變量
        public string excutsp(string spName, Paramets[] datas, string bu, string teturnParamName)
        {
            oCn.ConnectionString = getBuString(bu);

            oCn.Open();
            oCmd.Connection = oCn;
            oCmd.CommandType = CommandType.StoredProcedure;
            oCmd.CommandText = spName;          // "MES1.AP_CHECK_WEB_PASSWORD";
            OracleParameterCollection oParam = oCmd.Parameters;
            oParam.Clear();

            for (int i = 0; i < datas.Length; i++)
            {
                if (datas[i].ParaType == ParameterDirection.Input)
                {
                    oParam.Add(new OracleParameter(datas[i].PName, datas[i].IType, datas[i].ISize));
                    oParam[datas[i].PName].Value = datas[i].IValue;
                }
                else if (datas[i].ParaType == ParameterDirection.Output)
                {
                    oParam.Add(new OracleParameter(datas[i].PName, datas[i].IType, datas[i].ISize));
                    oParam[datas[i].PName].Direction = ParameterDirection.Output;
                }
            }

            oCmd.ExecuteNonQuery();
            string strReturnMessage = oCmd.Parameters[teturnParamName].Value.ToString();
            oCn.Close();
            oCn.Dispose();
            return strReturnMessage;
        }

        public Paramets buildParamet(string ParametsName, OracleType iType, string iValue, int iSize, ParameterDirection ptype)
        {
            Paramets p = new Paramets();
            p.PName = ParametsName;
            p.IType = iType;
            p.IValue = iValue;
            p.ISize = iSize;
            p.ParaType = ptype;
            return p;
        }
        public Paramets buildParamet(string ParametsName, OracleType iType, string iValue, ParameterDirection ptype)
        {
            Paramets p = new Paramets();
            p.PName = ParametsName;
            p.IType = iType;
            p.IValue = iValue;
            p.ParaType = ptype;
            return p;
        }
    }

    public class Paramets
    {
        string pName;

        public string PName
        {
            get { return pName; }
            set { pName = value; }
        }
        OracleType iType;

        public OracleType IType
        {
            get { return iType; }
            set { iType = value; }
        }
        string iValue;

        public string IValue
        {
            get { return iValue; }
            set { iValue = value; }
        }

        int iSize;

        public int ISize
        {
            get { return iSize; }
            set { iSize = value; }
        }

        ParameterDirection paraType;

        public ParameterDirection ParaType
        {
            get { return paraType; }
            set { paraType = value; }
        }
    }
}
