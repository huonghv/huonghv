using System;
using System.Data.OracleClient;
using System.Data;
using System.Collections;

namespace WebServiceGetGrnData
{
    /// <summary>
    /// �}�o���:	2004.10.10
    /// �}�o�H��:	�X���s
    /// �\��:		�HOracle���������ƾڳX�����M��{ICommonDBService���f�M�D�n�]�A���}�M�����ƾڮw�챵�M
    ///				�}�l�N�����@�ӨưȤ�SQL�y�y�����浥�\��
    ///	�ܧ�O��:	2004.12.24 �X���s�[�W��IDBUtitlity���f����{�N�X�M�D�n�H�q�A�Ⱦ��W���o���e�ɶ�			
    /// </summary>	
    public class CommonOracleDB : ICommonDBService
    {
        #region protected variable
        protected OracleConnection cnn;
        protected OracleDataAdapter adp;
        protected OracleCommand cmd;
        protected string strSQL;
        #endregion

        #region Construction function
        public CommonOracleDB(string strCnn)
        {
            cnn = new OracleConnection(strCnn);
            adp = new OracleDataAdapter();
            cmd = new OracleCommand("", cnn);
            adp.SelectCommand = cmd;
        }

        public CommonOracleDB(OracleConnection AdoCnn)
        {
            cnn = new OracleConnection();
            cnn = AdoCnn;
            adp = new OracleDataAdapter();
            cmd = new OracleCommand("", cnn);
            adp.SelectCommand = cmd;
        }
        #endregion

        #region Property
        /// <summary>
        /// SQL�y�y
        /// </summary>
        public string SQLCommand
        {
            get { return strSQL; }
            set { strSQL = value; }
        }
        #endregion

        #region IDBService ����

        /// <summary>
        /// �}�l�@�Өư�
        /// </summary>
        public void BeginTransaction()
        {
            this.OpenConnection();
            cmd.Transaction = cnn.BeginTransaction();
        }

        /// <summary>
        /// ����@�Өư�
        /// </summary>
        public void CommitTransaction()
        {
            cmd.Transaction.Commit();
        }

        /// <summary>
        /// �^�u�@�Өư�
        /// </summary>
        public void RollBackTransaction()
        {
            cmd.Transaction.Rollback();
        }

        /// <summary>
        /// ���}�챵
        /// </summary>
        public void OpenConnection()
        {
            if (cnn.State == ConnectionState.Closed)
                cnn.Open();
        }

        /// <summary>
        /// �����챵
        /// </summary>
        public void CloseConnection()
        {
            if (cnn.State == ConnectionState.Open)
                cnn.Close();
        }

        /// <summary>
        /// ����@�Ӥ���^�Ȫ�SQL�y�y�M�P�ɤ��|����ư�
        /// </summary>
        /// <param name="strSQL">�ݰ��檺SQL�y�y</param>
        /// <returns>���v�T���O����</returns>
        public int ExecuteNOQuery(string strSQL)
        {
            cmd.CommandText = strSQL;
            cmd.CommandType = CommandType.Text;
            return cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// ����@�Ӭd�ߥ\�઺SQL�y�y�M�}�HDataReader�����}��^
        /// </summary>
        /// <param name="strSQL">�ݰ��檺SQL�y�y</param>
        /// <returns>DataReader�������ƾڶ�</returns>
        public object ExecuteDataReader(string strSQL)
        {
            cmd.CommandText = strSQL;
            cmd.CommandType = CommandType.Text;
            return cmd.ExecuteReader();
        }

        /// <summary>
        /// ����@�Ӥ���^�Ȫ�SQL�y�y�M�P�ɶi��ưȪ�����
        /// </summary>
        /// <param name="strSQL">�ݰ��檺SQL</param>
        /// <returns>���v�T���O����</returns>
        public int ExecuteCommitSQL(string strSQL)
        {
            int intResult = 0;
            try
            {
                this.BeginTransaction();
                cmd.CommandText = strSQL;
                cmd.CommandType = CommandType.Text;
                intResult = cmd.ExecuteNonQuery();
                this.CommitTransaction();
            }
            catch
            {
                try
                {
                    this.RollBackTransaction();
                }
                catch
                {
                    throw;
                }
                throw;
            }
            finally
            {

                this.CloseConnection();
            }
            return intResult;
        }

        /// <summary>
        /// �]�m�R�O,�q�{���奻���� 
        /// </summary>
        /// <param name="strSQL"></param>
        public void SetCommandText(string strSQL)
        {
            cmd.CommandText = strSQL;
            cmd.CommandType = CommandType.Text;
        }
        /// <summary>
        /// �M�ũR�O�Ѽ�
        /// </summary>
        public void ClearCommandParameter()
        {
            cmd.Parameters.Clear();
        }

        /// <summary>
        /// �W�[�@�өR�O�Ѽ�
        /// </summary>
        public void AddCommandParameter(string parameterName, object value)
        {
            cmd.Parameters.Add(parameterName, value);
        }

        //		/// <summary>
        //		/// �W�[�@�өR�O�Ѽ�
        //		/// </summary>
        //		/// <returns>��^�@�ӰѼ�����</returns>
        //		public object AddCommandParameter(string parameterName,object dbtype)
        //		{
        //			try
        //			{
        //				OracleType otTemp = (OracleType)dbtype;
        //				OracleParameter para=cmd.Parameters.Add(parameterName,otTemp);			
        //				return para;
        //			}
        //			catch
        //			{
        //				throw;
        //			}
        //		}


        public object AddCommandParameter(string parameterName, object dbtype, int size)
        {
            try
            {
                OracleType otTemp = (OracleType)dbtype;
                OracleParameter para;
                if (size < 0)
                    para = cmd.Parameters.Add(parameterName, otTemp);
                else
                    para = cmd.Parameters.Add(parameterName, otTemp, size);
                return para;
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// ����SQL�y�y
        /// </summary>
        /// <returns></returns>
        public int ExecuteNOQuery()
        {
            try
            {
                return cmd.ExecuteNonQuery();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// ����@�Ӭd�ߥ\�઺SQL�y�y�M�}�HDataTable�����}��^
        /// </summary>
        /// <param name="strSQL">�ݰ��檺SQL�y�y</param>
        /// <returns>DataTable�������ƾڶ�</returns>
        public DataTable ExecuteDataTable(string strSQL)
        {

            DataTable dtTemp = new DataTable();
            cmd.CommandText = strSQL;
            cmd.CommandType = CommandType.Text;
            //cmd.Parameters.Clear();
            try
            {
                adp.Fill(dtTemp);
            }
            catch (Exception ex)
            {

            }
            return dtTemp;
        }

        /// <summary>
        /// ����d��SQL�y�y�M�}�Ωұo�ƾڶ�R���w��DataTable
        /// </summary>
        /// <param name="strSQL">�ݰ��檺SQL�y�y</param>
        /// <param name="dtTemp">�ݶ�R��DataTable</param>
        public void FillDataTable(string strSQL, DataTable dtTemp)
        {
            cmd.CommandText = strSQL;
            cmd.CommandType = CommandType.Text;
            adp.Fill(dtTemp);
        }

        /// <summary>
        /// ����d��SQL�y�y�M��^�@�Ӽжq��
        /// </summary>
        /// <param name="strSQL"></param>
        public object ExecuteScalar(string strSQL)
        {

            cmd.CommandText = strSQL;
            cmd.CommandType = CommandType.Text;
            return cmd.ExecuteScalar();

        }

        /// <summary>
        /// �ոmCommandText��SP����
        /// </summary>
        /// <param name="strSP"></param>
        public void SetCommandSP(string strSP)
        {
            cmd.CommandText = strSP;
            cmd.CommandType = CommandType.StoredProcedure;
        }

        #endregion

        #region IDBUtility ����

        public DateTime GetServerCurrentTime()
        {
            strSQL = "SELECT SYSDATE FROM DUAL ";
            try
            {
                this.OpenConnection();
                this.ClearCommandParameter();
                return (DateTime)this.ExecuteScalar(strSQL);
            }
            catch (Exception ex)
            {
                throw new Exception("GetServerCurrentTime error:" + ex.Message);
            }
            finally
            {
                this.CloseConnection();
            }
        }

        #endregion
    }
}
