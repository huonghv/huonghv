using System;
using System.Data.OracleClient;
using System.Configuration;
using System.Web;
using System.Collections;
using System.Data;

namespace WebServiceGetGrnData
{
    /// <summary>
    /// �}�o���:	2004.02.20
    /// �}�o�H��:	�X���s
    /// �\��:		�n���Τ����M��{�n���Τ᪺�ˬd�Τ�O�_�s�b�N���Τ�K�X���\��
    /// �ܧ�O��:	2004/12/28 �X���s�[�WUserName,Department�ݩ�
    ///				2005.03.26 �X���s���h������DBClass.CommonDB�����~�ӡM�ӲΤ@�ϥ�DBLib.ICommonDBService���f�ӳX�ݼƾڮw�M
    ///					�}�W�[CurrentDBInterface�ݩʡM�H���w�Τ���e�ϥΪ��ƾڮw�챵���f
    ///				2005.06.12 �X���s�[�WEmail�ݩʤ�HasEMail()��k	
    /// </summary>
    public class User
    {
        protected string fUserID;           //�Τ�ID
        protected string fPassword;         //�Τ�K�X
        protected ArrayList arrCustCode;        //�Τ�ү�d��CustCode�C��
        protected bool fExists = false;               //
        protected string fUserName = string.Empty;			//���u�m�W
        protected string fDepartment = string.Empty;		//���u���ݳ���
        protected string fEMail = string.Empty;
        protected string fArael = string.Empty;               //���u���ݰϰ� iceman
        protected string flanguage = string.Empty; //�y������
        protected ICommonDBService fCommonDB;
        protected string strSQL = string.Empty;

        public User(ICommonDBService lCommonDB)
        {
            fCommonDB = lCommonDB;
            arrCustCode = new ArrayList();
            fUserName = string.Empty;
            fDepartment = string.Empty;
            flanguage = string.Empty;
        }

        public User(ICommonDBService lCommonDB, string strUserID, string strPWD)
            : this(lCommonDB)
        {
            //arrCustCode = new ArrayList();
            fUserID = strUserID;
            fPassword = strPWD;

            //fUserName = string.Empty;
            //fDepartment = string.Empty;
        }

        #region Public Property

        /// <summary>
        /// ���u���M�Y�Τ�b��
        /// </summary>
        public string UserID
        {
            get { return fUserID; }
            set { fUserID = value; }
        }
        // �y������
        public string Language_VERSION
        {
            get { return flanguage; }
            set { flanguage = value; }
        }
        /// <summary>
        /// �n���K�X
        /// </summary>
        public string PassWord
        {
            get { return fPassword; }
            set { fPassword = value; }
        }

        /// <summary>
        /// ���u�m�W
        /// </summary>
        public string UserName
        {
            get { return fUserName; }
            set { fUserName = value; }
        }

        /// <summary>
        /// ���u���ݳ���
        /// </summary>
        public string Department
        {
            get { return fDepartment; }
            set { fDepartment = value; }
        }

        /// <summary>
        /// added by zhixin 2005.06.12
        /// �l��a�}
        /// </summary>
        public string EMail
        {
            get { return fEMail; }
            set { fEMail = value; }
        }

        public string Area
        {
            get { return fArael; }
            set { fArael = value; }
        }

        /// <summary>
        /// �Τ᪺���e�챵�ƾڮw���f
        /// </summary>
        public ICommonDBService CurrentDBInterface
        {
            get { return fCommonDB; }
            set { fCommonDB = value; }
        }

        //whether user exists in the DB
        public bool Exists
        {
            get { return fExists; }
        }

        #endregion

        #region Public Operation
        /// <summary>
        /// added by zhixin 2005.06.12
        /// �P�_���u�O�_��Email
        /// </summary>
        /// <returns></returns>
        public bool HasEMail()
        {
            return !fEMail.Equals(string.Empty);
        }

        /// <summary>
        /// Checks that whether the user exists in the DB
        /// </summary>
        public void CheckUser()
        {
            string strSQL_PWD;

            if (fPassword == "")
                strSQL_PWD = " and EMP_PassWord is null ";
            else
                strSQL_PWD = " and EMP_PassWord = '" + fPassword + "'";


            //            cmd.CommandText = " select Emp_No,Emp_Name,Dpt_Name,Emp_PassWord "
            //                + " from mes1.c_emp "
            //                + " where Emp_No = '" + fUserID + "'"
            //                + strSQL_PWD;
            strSQL = " SELECT EMP_NO,EMP_NAME,DPT_NAME,EMP_PASSWORD, EMAIL,FLOOR "
                + " FROM MES1.C_EMP "
                + " WHERE EMP_NO = :EMP_NO AND EMP_PASSWORD = :EMP_PASSWORD ";
            fCommonDB.ClearCommandParameter();
            fCommonDB.AddCommandParameter("EMP_NO", fUserID);
            if (fPassword.Equals(string.Empty))
            {
                fCommonDB.AddCommandParameter("EMP_PASSWORD", DBNull.Value);
            }
            else
            {
                fCommonDB.AddCommandParameter("EMP_PASSWORD", fPassword);
            }
            OracleDataReader reader;
            try
            {
                fCommonDB.OpenConnection();
                //reader = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);                    
                reader = (OracleDataReader)fCommonDB.ExecuteDataReader(strSQL);
                //fExists = reader.Read();              
                if (reader.Read())
                {
                    fExists = true;
                    fUserName = reader["EMP_NAME"].ToString();
                    fDepartment = reader["DPT_NAME"].ToString();
                    fEMail = reader["EMAIL"].ToString();
                    fArael = reader["FLOOR"].ToString();
                }
                else
                {
                    fExists = false;
                }
                reader.Close();
            }
            catch { throw; }
            finally
            {
                fCommonDB.CloseConnection();
                //cnn.Dispose();
            }
        }
        /// <summary>
        /// change the user's password
        /// </summary>
        /// <param name="newPWD">new password</param>
        /// <returns>thw row count updated successfully</returns>
        public int ChangePassWord(string newPWD)
        {
            int iResult = 0;
            try
            {
                fCommonDB.OpenConnection();
                fCommonDB.BeginTransaction();

                strSQL = " UPDATE MES1.C_EMP SET EMP_PASSWORD = :EMP_PASSWORD,LAST_CHANGE_PASSWORD_TIME=SYSDATE "
                    + "   WHERE EMP_NO = :EMP_NO "
                    + "		AND ROWNUM = 1 ";
                fCommonDB.ClearCommandParameter();
                fCommonDB.AddCommandParameter("EMP_NO", this.fUserID);
                fCommonDB.AddCommandParameter("EMP_PASSWORD", newPWD);
                iResult = fCommonDB.ExecuteNOQuery(strSQL);

                fCommonDB.CommitTransaction();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                fCommonDB.CloseConnection();
            }
            return iResult;
        }

        /// <summary>
        /// get the custcode the user owns
        /// </summary>
        public void getCustCode()
        {
            OracleDataReader reader;
            try
            {
                fCommonDB.OpenConnection();

                strSQL = "SELECT CUST_CODE FROM MES1.C_EMP_CUST"
                    + " WHERE EMP_NO = :EMP_NO ";
                fCommonDB.ClearCommandParameter();
                fCommonDB.AddCommandParameter("EMP_NO", fUserID);
                reader = (OracleDataReader)fCommonDB.ExecuteDataReader(strSQL);
                string str;
                while (reader.Read())
                {
                    str = reader.GetString(0);
                    arrCustCode.Add(str);
                }
                reader.Close();
            }
            finally
            {
                fCommonDB.CloseConnection();
            }
        }

        /// <summary>
        /// formats the cust_code list as such formation :XXX,XXX,XXX,...
        /// </summary>
        /// <returns></returns>
        public string getCustCodeList()
        {
            string strTemp = "";
            for (int i = 0; i < arrCustCode.Count; i++)
            {
                if (i == 0)
                    strTemp = arrCustCode[i].ToString();
                else
                    strTemp += "," + arrCustCode[i].ToString();
            }
            return strTemp;//+ ",'INTEL','CISCO'";
        }
        #endregion
    }

    /// <summary>
    /// Summary description for Login.
    /// </summary>
    ///
    public class LoginUser : User
    {
        protected string fUserIP;     //client IP	
        protected DateTime fInTime;           //login time
        //      private DataSet dsFunction;         //the report functions and their modules which the user can access;  
        protected Function fReportFunction;
        protected DataTable fFunctionTable;
        protected string fUserStatus;

        OracleCommand oCmd = new OracleCommand();
        OracleConnection oCn = new OracleConnection(System.Configuration.ConfigurationSettings.AppSettings["OracleConnectionString"]);
        
        public LoginUser(ICommonDBService lCommonDB, string strName, string strPWD, string strIP, string strversion)
            : base(lCommonDB, strName, strPWD)
        {
            fUserIP = strIP;
            flanguage = strversion;
            fFunctionTable = new DataTable();
        }

        public LoginUser(ICommonDBService lCommonDB)
            : base(lCommonDB)
        {
            fFunctionTable = new DataTable();
        }

        /// <summary>
        /// �n���ɶ��M
        /// </summary>
        public DateTime InTime
        {
            get { return fInTime; }
            set { fInTime = value; }
        }


        /// <summary>
        /// �n��IP
        /// </summary>
        public string IP
        {
            get { return fUserIP; }
            set { fUserIP = value; }
        }

        /// <summary>
        /// �n�����A
        /// </summary>
        public string UserStatus
        {
            get { return fUserStatus; }
            set { fUserStatus = value; }
        }

        /// <summary>
        /// �n���Τ��X�ݪ����\�ඵ
        /// </summary>
        public Function ReportFunction
        {
            get { return fReportFunction; }
        }
        /// <summary>
        /// login function,achieves the user's CustCode and accessible report set 
        /// if the user is valid,meanwhile, the user's information is also recorded 
        /// </summary>
        /// <returns></returns>
        public bool Login()
        {
            return Login(true);
        }

        /// <summary>
        /// added by zhixin 2005.03.27
        /// ������ơM�W�[�@�ӰѼƨӧP�_�O�_���Ĥ@���n���M�p�O�M�h�����e�ɶ����n���ɶ��M�_�h�{���w���n���ɶ�
        ///	�W�[����ƬO�]���Ҽ{��P�@�n���Τ�b�|�ܴ����ݭn�������P��Ʈw�M�b�o�ر��p�U�M���|���Ʈw������
        /// �������s�n���M�o�O�קK�Ѥ_�h�������ӦbMES4.R_Login�������J�\�h�n���ɶ��ܬ۪񪺰O��
        /// </summary>
        /// <param name="bolFirstTime"></param>
        /// <returns></returns>
        public bool Login(bool bolFirstTime)
        {
            try
            {
                this.CheckUser();
                if (fExists)
                {
                    if (bolFirstTime)
                    {
                        this.fInTime = fCommonDB.GetServerCurrentTime();
                    }
                    LogUserInfo();
                    //get the cust_code owned by the user if the user exists
                    getCustCode();
                    getUserFunctions();
                }
                return fExists;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Logout()
        {
            try
            {
                this.fCommonDB.CloseConnection();
            }
            catch
            {
            }
        }

        /// <summary>
        /// achieves all the report that the user can access
        /// </summary>
        public void getUserFunctions()
        {
            try
            {
                fCommonDB.OpenConnection();

                string strReturnMessage = string.Empty;

                try
                {
                    oCn.Open();
                    oCmd.Connection = oCn;
                    oCmd.CommandType = CommandType.StoredProcedure;
                    oCmd.CommandText = "MES1.AP_CHECK_WEB_PASSWORD";
                    OracleParameterCollection oParam = oCmd.Parameters;
                    oParam.Clear();
                    oParam.Add(new OracleParameter("EMP", OracleType.VarChar, 50));
                    oParam["EMP"].Value = fUserID;
                    oParam.Add(new OracleParameter("PWD", OracleType.VarChar, 50));
                    oParam["PWD"].Value = fPassword;
                    oParam.Add(new OracleParameter("RES", OracleType.VarChar, 50));
                    oParam["RES"].Direction = ParameterDirection.Output;
                    oCmd.ExecuteNonQuery();
                    strReturnMessage = oCmd.Parameters["RES"].Value.ToString();
                    if (strReturnMessage == "�K�X�w�g�L��" || fUserID == fPassword)
                    {
                        if (fUserID == fPassword)
                        {
                            strReturnMessage = "����ϥήz�K�X";
                        }

                        flanguage = "2";
                    }

                    fUserStatus = strReturnMessage;

                    if (strReturnMessage != "OK")
                    {
                        flanguage = "2";
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    oCn.Close();
                    oCmd.Dispose();
                }

                if (flanguage == "1")
                {
                    strSQL = " SELECT A.FUNCTION_CODE, A.FUNCTION_NAME FUNCTION_DESC1, A.DESCRIPTION FUNCTION_DESC2, "
                        + "	 A.LAYER, A.SORT, A.PARENT_CODE, A.FUNCTION_PATH FILE_PATH "
                        + "  FROM MES1.C_WMS_WEB_CONFIG  A,  MES1.C_AP_CONFIG B "
                        + "  WHERE B.AP_NAME = 'WEB' "
                        + "  AND A.FUNCTION_CODE = B.FUNCTION_NAME "
                        + "  AND B.EMP_NO = :EMP_NO ";
                }
                else if (flanguage == "2")
                {
                    strSQL = " SELECT A.FUNCTION_CODE, A.CN_DESCRIPTION  FUNCTION_DESC1, A.FUNCTION_NAME FUNCTION_DESC2, "
                        + "	 A.LAYER, A.SORT, A.PARENT_CODE, A.FUNCTION_PATH FILE_PATH "
                        + "  FROM MES1.C_WMS_WEB_CONFIG  A,  MES1.C_AP_CONFIG B "
                        + "  WHERE B.AP_NAME = 'WEB'  AND B.FUNCTION_NAME='WEB' "
                        + "  AND A.FUNCTION_CODE = B.FUNCTION_NAME "
                        + "  AND B.EMP_NO = :EMP_NO ";
                }
                else
                {
                    strSQL = " SELECT A.FUNCTION_CODE, A.CN_DESCRIPTION  FUNCTION_DESC1, A.FUNCTION_NAME FUNCTION_DESC2, "
                        + "	 A.LAYER, A.SORT, A.PARENT_CODE, A.FUNCTION_PATH FILE_PATH "
                        + "  FROM MES1.C_WMS_WEB_CONFIG  A,  MES1.C_AP_CONFIG B "
                        + "  WHERE B.AP_NAME = 'WEB' "
                        + "  AND A.FUNCTION_CODE = B.FUNCTION_NAME "
                        + "  AND B.EMP_NO = :EMP_NO ";
                }

                fCommonDB.ClearCommandParameter();
                fCommonDB.AddCommandParameter("EMP_NO", fUserID);
                fFunctionTable = fCommonDB.ExecuteDataTable(strSQL);
                fReportFunction = new Function("WEB");
                fReportFunction.Initialize(fFunctionTable);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                fCommonDB.CloseConnection();
            }
        }

        /// <summary>
        /// judges whether the user could access the report defined by strReportID
        /// </summary>
        /// <param name="strReportID">the report ID</param>
        /// <returns>true if there is,else false</returns>
        public bool CanAccessReport(string strReportID)
        {
            this.UpdateLastQueryTime();
            if (fFunctionTable == null)
                return false;
            DataRow[] rows = fFunctionTable.Select("FUNCTION_CODE='" + strReportID + "'");
            return rows.Length > 0;
        }


        /// <summary>
        /// log the user information to the session variables
        /// </summary>
        public void LogUserInfo()
        {
            try
            {
                fCommonDB.OpenConnection();
                fCommonDB.BeginTransaction();

                //�p�G
                strSQL = "SELECT 1 FROM MES4.R_LOGIN "
                    + " WHERE USER_ID = :USER_ID "
                    + "		AND IP = :IP "
                    + "		AND IN_TIME = :IN_TIME ";
                fCommonDB.ClearCommandParameter();
                fCommonDB.AddCommandParameter("USER_ID", fUserID);
                fCommonDB.AddCommandParameter("IP", fUserIP);
                fCommonDB.AddCommandParameter("IN_TIME", fInTime);
                if (Convert.ToInt32(fCommonDB.ExecuteScalar(strSQL)) == 1)
                {
                    strSQL = " UPDATE MES4.R_LOGIN SET LAST_QUERY = SYSDATE "
                        + " WHERE USER_ID = :USER_ID AND IP = :IP AND IN_TIME = :IN_TIME";
                    fCommonDB.ClearCommandParameter();
                    fCommonDB.AddCommandParameter("USER_ID", fUserID);
                    fCommonDB.AddCommandParameter("IP", fUserIP);
                    fCommonDB.AddCommandParameter("IN_TIME", fInTime);
                    fCommonDB.ExecuteNOQuery(strSQL);
                }
                else
                {
                    strSQL = " INSERT INTO MES4.R_LOGIN "
                        + "	(USER_ID, IP, IN_TIME, LAST_QUERY) "
                        + " VALUES(:USER_ID, :IP, :IN_TIME, SYSDATE) ";
                    fCommonDB.ClearCommandParameter();
                    fCommonDB.AddCommandParameter("USER_ID", fUserID);
                    fCommonDB.AddCommandParameter("IP", fUserIP);
                    fCommonDB.AddCommandParameter("IN_TIME", fInTime);
                    fCommonDB.ExecuteNOQuery(strSQL);
                }
                fCommonDB.CommitTransaction();
            }
            catch (Exception ex)
            {
                fCommonDB.RollBackTransaction();
                throw ex;
            }
            finally
            {
                fCommonDB.CloseConnection();
            }
        }// end logUserinfo

        /// <summary>
        /// updates the user's last query time,the procedure is executed 
        /// when the user accesses every report 
        /// </summary>
        public void UpdateLastQueryTime()
        {
            try
            {
                fCommonDB.OpenConnection();
                fCommonDB.BeginTransaction();

                strSQL = " UPDATE MES4.R_LOGIN SET LAST_QUERY = SYSDATE "
                    + " WHERE USER_ID = :USER_ID AND IP = :IP AND IN_TIME = :IN_TIME";
                fCommonDB.ClearCommandParameter();
                fCommonDB.AddCommandParameter("USER_ID", fUserID);
                fCommonDB.AddCommandParameter("IP", fUserIP);
                fCommonDB.AddCommandParameter("IN_TIME", fInTime);
                fCommonDB.ExecuteNOQuery(strSQL);

                fCommonDB.CommitTransaction();
            }
            catch (Exception ex)
            {
                fCommonDB.RollBackTransaction();
                throw ex;
            }
            finally
            {
                fCommonDB.CloseConnection();
            }
        }//end updatelastquerytime
    }// end class

    /// <summary>
    /// �}�o���:	2004.08.29
    /// �}�o�H��:	�X���s
    /// �\��y�z:	Function���M�D�n�O�O�s�U��涵�M
    /// �ܧ�O��:	�L
    /// </summary>
    public class Function
    {
        protected string fCode = string.Empty;
        protected string fDescription1 = string.Empty,
            fDescription2 = string.Empty;
        protected string fFilePath = string.Empty;
        protected int fLayer = 0;
        protected int fSort = 0;
        protected FunctionCollection fChildFunctions;
        protected Function fParent = null;

        public Function(string lCode)
        {
            fCode = lCode;
            fChildFunctions = new FunctionCollection();
        }

        /// <summary>
        /// �\�ඵ���l�\�ඵ���X
        /// </summary>
        public FunctionCollection ChildFunctions
        {
            get { return fChildFunctions; }
            set { fChildFunctions = value; }
        }

        /// <summary>
        /// �\�ඵ�N�X
        /// </summary>
        public string Code
        {
            get { return fCode; }
            set { fCode = value; }
        }

        /// <summary>
        /// �\�ඵ�y�z1
        /// </summary>
        public string Description1
        {
            get { return fDescription1; }
            set { fDescription1 = value; }
        }

        /// <summary>
        /// �\�ඵ�y�z2
        /// </summary>
        public string Description2
        {
            get { return fDescription2; }
            set { fDescription2 = value; }
        }

        /// <summary>
        /// �\�ඵ�ҹ����������|
        /// </summary>
        public string FilePath
        {
            get { return fFilePath; }
            set { fFilePath = value; }
        }

        /// <summary>
        /// �\�ඵ�����˥\�ඵ
        /// </summary>
        public Function Parent
        {
            get { return fParent; }
            set { fParent = value; }
        }

        /// <summary>
        /// �\�ඵ�Ҧb���h
        /// </summary>
        public int Layer
        {
            get { return fLayer; }
            set { fLayer = value; }
        }

        /// <summary>
        /// �\�ඵ���ƧǧǸ�
        /// </summary>
        public int Sort
        {
            get { return fSort; }
            set { fSort = value; }
        }

        #region Public Operation

        /// <summary>
        /// ���\�ඵ�O�_�٦��l�\�ඵ
        /// </summary>
        /// <returns></returns>
        public bool HasChildFunction()
        {
            return fChildFunctions.Count > 0;
        }

        /// <summary>
        /// ���\�ඵ�O�_���W�챵
        /// </summary>
        /// <returns></returns>
        public bool HasHyperLink()
        {
            return !fFilePath.Equals(string.Empty) && !fFilePath.ToUpper().Equals("N/A");
        }

        /// <summary>
        /// �ϥΥ\�ඵ�ƾڪ��Ӫ�l�ƥ���
        /// </summary>
        /// <param name="dtFunction">�\�ඵ�ƾڪ�</param>
        public void Initialize(DataTable dtFunction)
        {
            Function childFunction;
            DataRow[] arrRow;
            DataRow row;
            arrRow = dtFunction.Select("FUNCTION_CODE = '" + fCode + "'");
            if (arrRow.Length == 0)
            {
                return;
            }
            row = arrRow[0];
            this.fDescription1 = row["FUNCTION_DESC1"].ToString();
            this.fDescription2 = row["FUNCTION_DESC2"].ToString();
            this.fFilePath = row["FILE_PATH"].ToString();
            this.fLayer = Convert.ToInt32(row["LAYER"].ToString());
            this.fSort = Convert.ToInt32(row["SORT"].ToString());

            arrRow = dtFunction.Select("PARENT_CODE = '" + fCode + "'", "SORT");
            foreach (DataRow cRow in arrRow)
            {
                childFunction = new Function(cRow["FUNCTION_CODE"].ToString());
                this.fChildFunctions.Add(childFunction);
                childFunction.Initialize(dtFunction);
            }
        }

        #endregion

    }//end of class Function

    /// <summary>
    /// �}�o���:	2005.03.26
    /// �}�o�H��:	�X���s
    /// �\��y�z:	�\�ඵ���X��
    /// �ܧ�O��:	�L
    /// </summary>
    public class FunctionCollection : CollectionBase
    {
        public Function this[int index]
        {
            get
            {
                return ((Function)List[index]);
            }
            set
            {
                List[index] = value;
            }
        }

        public int Add(Function value)
        {
            return (List.Add(value));
        }

        public int IndexOf(Function value)
        {
            return (List.IndexOf(value));
        }

        public void Insert(int index, Function value)
        {
            List.Insert(index, value);
        }

        public void Remove(Function value)
        {
            List.Remove(value);
        }

        public bool Contains(Function value)
        {
            // If value is not of type Function, this will return false.
            return (List.Contains(value));
        }

        protected override void OnInsert(int index, Object value)
        {
            if (value.GetType() != Type.GetType("website.Class.Function"))
                throw new ArgumentException("value must be of type website.Class.Function.", "value");
        }

        protected override void OnRemove(int index, Object value)
        {
            if (value.GetType() != Type.GetType("website.Class.Function"))
                throw new ArgumentException("value must be of type website.Class.Function.", "value");
        }

        protected override void OnSet(int index, Object oldValue, Object newValue)
        {
            if (newValue.GetType() != Type.GetType("website.Class.Function"))
                throw new ArgumentException("newValue must be of type website.Class.Function.", "newValue");
        }

        protected override void OnValidate(Object value)
        {
            if (value.GetType() != Type.GetType("website.Class.Function"))
                throw new ArgumentException("value must be of type website.Class.Function.");
        }
    }
}
