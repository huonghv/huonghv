﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OracleClient;

using System.Collections;
namespace WebServiceGetGrnData
{
    public class ExecuteSP
    {
        #region 
        public static DataTable ExecuteSPReturnDataTableOld(string strSPName, OracleParameter[] paras)
        {
            DataTable dtTemp = new DataTable();
            string strSQL = strSPName;
            string strResult = string.Empty;
            string strEmpNo = System.Web.HttpContext.Current.Session["empno"].ToString();
            string strConString = System.Web.HttpContext.Current.Session["conString"].ToString();

            dtTemp = OracleHelper.ExecuteDataTable(strConString, CommandType.StoredProcedure, strSQL, paras);

            return dtTemp;
        }
        #endregion

        /// <summary>
        /// 調SP返回全部執行參數
        /// </summary>
        /// <param name="strSPName">SP名稱</param>
        /// <param name="htExistsParamList">傳入的執行參數</param>
        /// <returns>返回所有執行參數</returns>
        public static Hashtable ExecuteSPReturnParameters(string strSPName, Hashtable htOracleParamList, string strConString)
        {
           // string strConString = System.Web.HttpContext.Current.Session["conString"].ToString();
            OracleConnection conn = new OracleConnection(strConString);
            OracleCommand cmd = new OracleCommand(strSPName, conn);
            try
            {
                OracleParameter[] oraParams = GetSPParamList(strSPName, htOracleParamList, strConString);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddRange(oraParams);
                if (conn.State != ConnectionState.Open)
                    conn.Open();
                cmd.ExecuteNonQuery();
                Hashtable result = new Hashtable();
                foreach (OracleParameter item in cmd.Parameters)
                    result.Add(item.ParameterName, item.Value);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in " + strSPName + " :" + ex.Message);
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
        }
        private static OracleParameter[] GetSPParamList(string strSPName, Hashtable htExistsParamList, string strConString)
        {
           // string strConString = System.Web.HttpContext.Current.Session["conString"].ToString();
            DataTable dtTemp = new DataTable();
            string spuser = "MES1";
            string spname = strSPName;
            string[] sp = strSPName.Split('.');
            if (sp.Length == 2)
            {
                spuser = sp[0];
                spname = sp[1];
            }
            Hashtable ht = new Hashtable();
            foreach (string str in htExistsParamList.Keys)
            {
                if (ht.ContainsKey(str.ToUpper()) == false)
                {
                    ht.Add(str.ToUpper(), htExistsParamList[str]);
                }
            }
            string strSQL = string.Format("SELECT  upper(argument_name) column_name, POSITION - 1 seq, data_type, in_out" +
                                "    FROM all_arguments                                                 " +
                                "   WHERE owner = '{0}' AND object_name = '{1}'                        " +
                                "ORDER BY SEQUENCE                                                      ", spuser, spname);
            dtTemp = OracleHelper.ExecuteDataTable(strConString, CommandType.Text, strSQL, null);
            if (dtTemp.Rows.Count == 0)
                throw new Exception("Invalid SP Name,please call IT check:" + strSPName);
            OracleParameter[] oraParas = new OracleParameter[dtTemp.Rows.Count];
            for (int i = 0; i < dtTemp.Rows.Count; i++)
            {
                oraParas[i] = new OracleParameter(dtTemp.Rows[i]["column_name"].ToString(), DBNull.Value);
                //oraParas[i].ParameterName = dtTemp.Rows[i]["column_name"].ToString();
                //if (dtTemp.Rows[i]["data_type"].ToString().ToUpper() == "NUMBER")
                //oraParas[i].Value = 0;
                if (ht.ContainsKey(oraParas[i].ParameterName))
                    oraParas[i].Value = ht[oraParas[i].ParameterName];
                if (dtTemp.Rows[i]["in_out"].ToString().ToUpper() == "OUT")
                {
                    oraParas[i].Direction = ParameterDirection.Output;
                    switch (dtTemp.Rows[i]["data_type"].ToString().ToUpper())
                    {
                        case "NUMBER":
                            oraParas[i].OracleType = OracleType.Number;
                            break;
                        case "REF CURSOR":
                            oraParas[i].OracleType = OracleType.Cursor;
                            break;
                        default:
                            oraParas[i].OracleType = OracleType.VarChar;
                            oraParas[i].Size = 2000;
                            break;
                    }
                }
            }
            return oraParas;
        }
        /// <summary>
        /// 調SP返回字符串；
        /// </summary>
        /// <returns>返回字符串</returns>
        public static string ExecuteSPReturnString(string strSPName, string strOutParaPosition, string strConString, params string[] parameters)
        {
            string strResult = string.Empty;
            string strSQL = strSPName;
          //  string strEmpNo = System.Web.HttpContext.Current.Session["empno"].ToString();
          //  string strConString = System.Web.HttpContext.Current.Session["conString"].ToString();
            OracleParameter[] oraParas = new OracleParameter[parameters.Length];

            for (int i = 0; i < parameters.Length; i++)
            {
                //第一個參數是輸出參數；

                if (strOutParaPosition == "first")
                {
                    if (i == 0)
                    {
                        OracleParameter orapara = new OracleParameter("", OracleType.VarChar, 2000);
                        orapara.Direction = ParameterDirection.Output;
                        oraParas[i] = orapara;
                    }
                    else
                    {
                        OracleParameter orapara = new OracleParameter();
                        orapara.OracleType = OracleType.VarChar;
                        orapara.Value = parameters[i];
                        oraParas[i] = orapara;
                    }
                }

                //最后一個參數是輸出參數；

                if (strOutParaPosition == "last")
                {
                    if (i == parameters.Length - 1)
                    {
                        OracleParameter orapara = new OracleParameter("", OracleType.VarChar, 2000);
                        orapara.Direction = ParameterDirection.Output;
                        oraParas[i] = orapara;
                    }
                    else
                    {
                        OracleParameter orapara = new OracleParameter();
                        orapara.OracleType = OracleType.VarChar;
                        orapara.Value = parameters[i];
                        oraParas[i] = orapara;
                    }
                }
            }

            //讓SP的參數名與要傳的參數數組對應；

            DataTable dtParas = GetSPPataList(strSPName.Substring(strSPName.IndexOf(".") + 1), strConString);
            for (int i = 0; i < dtParas.Rows.Count; i++)
            {
                oraParas[i].ParameterName = dtParas.Rows[i]["argument_name"].ToString();
            }

            try
            {
                OracleHelper.ExecuteNonQuery(strConString, CommandType.StoredProcedure, strSQL, oraParas);

                if (strOutParaPosition == "last")
                {
                    strResult = oraParas[parameters.Length - 1].Value.ToString();
                }
                else
                {
                    strResult = oraParas[0].Value.ToString();
                }
            }
            catch (Exception ex)
            {
                strResult = ex.Message;
            }

            return strResult;
        }

        /// <summary>
        /// 調SP返回DataTable；

        /// </summary>
        /// <param name="strSPName">SP名字</param>
        /// <param name="strOutParaPosition">輸出參數所在的位置，要么是第一個，要么是最后一個</param>
        /// <param name="parameters">參數列表</param>
        /// <returns>返回DataTable</returns>
        public static DataTable ExecuteSPReturnDataTable(string strSPName, string strOutParaPosition, string strConString, params string[] parameters)
        {
            DataTable dtTemp = new DataTable();
            string strSQL = strSPName;
            string strEmpNo = System.Web.HttpContext.Current.Session["empno"].ToString();
            //string strConString = System.Web.HttpContext.Current.Session["conString"].ToString();
            OracleParameter[] oraParas = new OracleParameter[parameters.Length];

            for (int i = 0; i < parameters.Length; i++)
            {
                //第一個參數是輸出參數；

                if (strOutParaPosition == "first")
                {
                    if (i == 0)
                    {
                        OracleParameter orapara = new OracleParameter("", OracleType.Cursor);
                        orapara.Direction = ParameterDirection.Output;
                        oraParas[i] = orapara;
                    }
                    else
                    {
                        OracleParameter orapara = new OracleParameter();
                        orapara.OracleType = OracleType.VarChar;
                        orapara.Value = parameters[i];
                        oraParas[i] = orapara;
                    }
                }

                //最后一個參數是輸出參數；

                if (strOutParaPosition == "last")
                {
                    if (i == parameters.Length - 1)
                    {
                        OracleParameter orapara = new OracleParameter("", OracleType.Cursor);
                        orapara.Direction = ParameterDirection.Output;
                        oraParas[i] = orapara;
                    }
                    else
                    {
                        OracleParameter orapara = new OracleParameter();
                        orapara.OracleType = OracleType.VarChar;
                        orapara.Value = parameters[i];
                        oraParas[i] = orapara;
                    }
                }
            }

            //讓SP的參數名與要傳的參數數組對應；

            DataTable dtParas = GetSPPataList(strSPName.Substring(strSPName.IndexOf(".") + 1), strConString);
            for (int i = 0; i < dtParas.Rows.Count; i++)
            {
                oraParas[i].ParameterName = dtParas.Rows[i]["argument_name"].ToString();
            }

            try
            {
                dtTemp = OracleHelper.ExecuteDataTable(strConString, CommandType.StoredProcedure, strSQL, oraParas);
            }
            catch (Exception)
            {
                dtTemp = null;
            }

            return dtTemp;
        }

        /// <summary>
        /// 根據SP的名字取SP的參數列表；
        /// </summary>
        /// <param name="strSPName"></param>
        /// <returns></returns>
        public static DataTable GetSPPataList(string strSPName, string strConString)
        {
            DataTable dtTemp = new DataTable();
          //  string strConString = System.Web.HttpContext.Current.Session["conString"].ToString();
            string strSQL = "SELECT argument_name, position-1                      " +
                            "FROM all_arguments                                    " +
                            "WHERE owner = 'MES1' AND object_name = :object_name   " +
                            "ORDER BY sequence                                     ";
            OracleParameter[] oraParas = new OracleParameter[]{
                    new OracleParameter(":object_name",strSPName.ToUpper())
            };
            dtTemp = OracleHelper.ExecuteDataTable(strConString, CommandType.Text, strSQL, oraParas);

            return dtTemp;
        }

        //LCR測試用；
        public static string CheckLcrSP(string strType, string strKP, string strDocNo, string strTRSN, string strWO, string strPNO, string strEMP, string strIP, string strDC, string strLC, string strData1, string strData2, string strValue, string strConString)
        {
            string strSQL = "mes1.check_lcr_sp";
          //  string strConString = System.Web.HttpContext.Current.Session["conString"].ToString();
            string strResult = string.Empty;

            OracleParameter[] oraParas = new OracleParameter[]{
                    new OracleParameter("g_transtype",strType),
                    new OracleParameter("g_kp_no",strKP.ToUpper()),
                    new OracleParameter("g_doc_no",strDocNo),
                    new OracleParameter("g_tr_sn",strTRSN),
                    new OracleParameter("g_wo",strWO),
                    new OracleParameter("g_pno",strPNO),
                    new OracleParameter("g_emp",strEMP),
                    new OracleParameter("g_ip",strIP),
                    new OracleParameter("g_dc",strDC),
                    new OracleParameter("g_lc",strLC),
                    new OracleParameter("g_data1",strData1),
                    new OracleParameter("g_data2",strData2),
                    new OracleParameter("g_test_value",strValue),
                    new OracleParameter("g_min_value",OracleType.Number),
                    new OracleParameter("g_max_value",OracleType.Number),
                    new OracleParameter("g_test_type",OracleType.VarChar,10),
                    new OracleParameter("g_frequency",OracleType.Number),
                    new OracleParameter("g_check_flag",OracleType.VarChar,10),
                    new OracleParameter("res",OracleType.VarChar,100)
            };
            oraParas[13].Direction = ParameterDirection.Output;
            oraParas[14].Direction = ParameterDirection.Output;
            oraParas[15].Direction = ParameterDirection.Output;
            oraParas[16].Direction = ParameterDirection.Output;
            oraParas[17].Direction = ParameterDirection.Output;
            oraParas[18].Direction = ParameterDirection.Output;

            try
            {
                OracleHelper.ExecuteNonQuery(strConString, CommandType.StoredProcedure, strSQL, oraParas);
                strResult = oraParas[18].Value.ToString();
                if (strType == "TC0001")
                {
                    if (oraParas[18].Value.ToString().Substring(0, 2) == "OK" && oraParas[17].Value.ToString() == "Y")
                    {
                        strResult = "OK," + oraParas[15].Value.ToString() + "," + oraParas[16].Value.ToString() + "," + oraParas[13].Value.ToString() + "," + oraParas[14].Value.ToString();
                    }
                    else
                    {
                        strResult = oraParas[18].Value.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                strResult = ex.Message;
            }

            return strResult;
        }

        #region split_trsn_new 已改成SP，此處沒用；
        //SPLIT_TRSN_NEW;
        //public static string SplitTrSnNewBak(string strTRSN, string strNewQty, string strEmp, string strLcrValue, string strData1, string strData2, string strData3, string strData4)
        //{
        //    string strSQL = "mes1.split_trsn_new";
        //    string strConString = System.Web.HttpContext.Current.Session["conString"].ToString();
        //    string strResult = string.Empty;
        //    bool bFlag = false;
        //    string strNewTrSn = string.Empty;
        //    int iQty = 0;
        //    string strLocationFlag = string.Empty;
        //    OracleParameter[] oraParas;

        //    bFlag = Tools.CheckProgramParameter("SP", "SPLIT_TRSN_NEW", "CHECK_LCR", "LCR_DATA", "Y", "NORMAL");
        //    if (bFlag == true)
        //    {
        //        oraParas = new OracleParameter[]{
        //            new OracleParameter("g_oldsn",strTRSN),
        //            new OracleParameter("g_qty",strNewQty),
        //            new OracleParameter("g_emp",strEmp),
        //            new OracleParameter("g_lcr_testdata",strLcrValue),
        //            new OracleParameter("g_data1",strData1),
        //            new OracleParameter("g_data2",strData2),
        //            new OracleParameter("g_data3",strData3),
        //            new OracleParameter("g_data4",strData4),
        //            new OracleParameter("g_newsn",OracleType.VarChar,50),
        //            new OracleParameter("res",OracleType.VarChar,200)
        //        };
        //    }
        //    else
        //    {
        //        oraParas = new OracleParameter[]{
        //            new OracleParameter("g_oldsn",strTRSN),
        //            new OracleParameter("g_qty",strNewQty),
        //            new OracleParameter("g_emp",strEmp),
        //            new OracleParameter("g_lcr_testdata",""),
        //            new OracleParameter("g_data1",""),
        //            new OracleParameter("g_data2",""),
        //            new OracleParameter("g_data3",""),
        //            new OracleParameter("g_data4",""),
        //            new OracleParameter("g_newsn",OracleType.VarChar,50),
        //            new OracleParameter("res",OracleType.VarChar,200)
        //        };
        //    }

        //    oraParas[8].Direction = ParameterDirection.Output;
        //    oraParas[9].Direction = ParameterDirection.Output;

        //    try
        //    {
        //        DBHelper.OracleHelper.ExecuteNonQuery(strConString, CommandType.StoredProcedure, strSQL, oraParas);
        //        strResult = oraParas[8].Value.ToString() + "," + oraParas[9].Value.ToString();
        //    }
        //    catch (Exception ex)
        //    {
        //        strResult = ex.Message;
        //        return strResult;
        //    }

        //    strNewTrSn = oraParas[8].Value.ToString();
        //    if (oraParas[9].Value.ToString().Substring(0, 2) == "OK")
        //    {
        //        //取location_flag；

        //        strSQL = "SELECT * FROM mes4.r_tr_sn WHERE tr_sn = :tr_sn";
        //        OracleParameter[] oraParaSN = new OracleParameter[]{
        //            new OracleParameter("tr_sn",strTRSN)
        //        };

        //        DataTable dtTemp = DBHelper.OracleHelper.ExecuteDataTable(strConString, CommandType.Text, strSQL, oraParaSN);
        //        strLocationFlag = dtTemp.Rows[0]["location_flag"].ToString();
        //        iQty = int.Parse(dtTemp.Rows[0]["ext_qty"].ToString());

        //        //向r_tr_sn_adjust表插入記錄；
        //        strSQL = "INSERT INTO mes4.r_tr_sn_adjust                                                          " +
        //                "(sub_tr_sn,tr_sn,qty,ext_qty,sub_qty,location_flag,work_time,emp_no,request_emp)         " +
        //                "VALUES                                                                                   " +
        //                "(:sub_tr_sn,:tr_sn,:qty,:ext_qty,:sub_qty,:location_flag,:work_time,:emp_no,:request_emp)";
        //        OracleParameter[] oraParaAdjust = new OracleParameter[]{
        //            new OracleParameter("sub_tr_sn",strNewTrSn),
        //            new OracleParameter("tr_sn",strTRSN),
        //            new OracleParameter("qty",iQty),
        //            new OracleParameter("ext_qty",iQty-int.Parse(strNewQty)),
        //            new OracleParameter("sub_qty",strNewQty),
        //            new OracleParameter("location_flag",strLocationFlag),
        //            new OracleParameter("work_time","sysdate"),
        //            new OracleParameter("emp_no",System.Web.HttpContext.Current.Session["empno"].ToString()),
        //            new OracleParameter("request_emp",strEmp)
        //        };
        //        DBHelper.OracleHelper.ExecuteNonQuery(strConString, CommandType.Text, strSQL, oraParaAdjust);

        //        //如果要檢查09碼的話，則向mes4.r_tr_sn_extend插入記錄；

        //        bFlag = Tools.CheckProgramParameter("AP", "TR-IQC", "IQC-SCAN 09CODE", "CHECK-09CODE", "Y", "NORMAL");
        //        if (bFlag == true)
        //        {
        //            strSQL = "INSERT INTO mes4.r_tr_sn_extend                                                " +
        //                    "(tr_sn, cust_kp_no, mfr_code, mfr_name, cust_po, cust_track_no,                " +
        //                    "track_wo, whs_move_desc,receive_type, data1, data2, data3, data4, data5, data6)" +
        //                    "   SELECT :new_tr_sn,cust_kp_no,mfr_code,mfr_name,                             " +
        //                    "          cust_po,cust_track_no,track_wo,whs_move_desc,                        " +
        //                    "          receive_type,data1,data2,data3,data4,data5,data6                     " +
        //                    "   FROM mes4.r_tr_sn_extend                                                    " +
        //                    "   WHERE tr_sn = :tr_sn AND ROWNUM = 1                                         ";
        //            OracleParameter[] oraParaExtend = new OracleParameter[]{
        //                    new OracleParameter("new_tr_sn",strNewTrSn),
        //                    new OracleParameter("tr_sn",strTRSN)
        //            };
        //            DBHelper.OracleHelper.ExecuteNonQuery(strConString, CommandType.Text, strSQL, oraParaExtend);
        //        }

        //        //向r_whs_location插入記錄；

        //        strSQL = "select * from mes4.r_whs_location where tr_sn=:tr_sn";
        //        OracleParameter[] oraParaLocation = new OracleParameter[]{
        //                    new OracleParameter("tr_sn",strTRSN)
        //        };
        //        dtTemp.Rows.Clear();
        //        dtTemp = DBHelper.OracleHelper.ExecuteDataTable(strConString, CommandType.Text, strSQL, oraParaLocation);

        //        if (dtTemp.Rows.Count > 0)
        //        {
        //            strSQL = "UPDATE mes4.r_whs_location a  " +
        //                    "SET qty   =                   " +
        //                    "       (SELECT ext_qty        " +
        //                    "        FROM mes4.r_tr_sn     " +
        //                    "        WHERE tr_sn = a.tr_sn)" +
        //                    "WHERE tr_sn = :tr_sn          ";
        //            OracleParameter[] oraParaWhsLocation = new OracleParameter[]{
        //                    new OracleParameter("tr_sn",strNewTrSn)
        //            };
        //            DBHelper.OracleHelper.ExecuteNonQuery(strConString, CommandType.Text, strSQL, oraParaWhsLocation);
        //        }
        //        else
        //        {
        //            strSQL = "INSERT INTO mes4.r_whs_location_new                       " +
        //                    "   SELECT location, :new_tr_sn, :new_qty, cust_kp_no,      " +
        //                    "          data2, over_time, print_type, print_data,SYSDATE " +
        //                    "   FROM mes4.r_whs_location                                " +
        //                    "   WHERE tr_sn = :tr_sn                                    ";
        //            OracleParameter[] oraParaWhsLocationNew = new OracleParameter[]{
        //                    new OracleParameter("new_tr_sn",strNewTrSn),
        //                    new OracleParameter("new_qty",strNewQty),
        //                    new OracleParameter("tr_sn",strNewTrSn)
        //            };
        //            DBHelper.OracleHelper.ExecuteNonQuery(strConString, CommandType.Text, strSQL, oraParaWhsLocationNew);
        //        }
        //    }

        //    return strResult;
        //}
        #endregion

        //根據二維條碼或TRSN取TRSN，對應的FUNCTION是GET_SCAN_SN；

        public static string GetScanSN(string strTrSn, string strConString)
        {
            string strResult = string.Empty;
            DataTable dtTemp = new DataTable();

          //  string strConString = System.Web.HttpContext.Current.Session["conString"].ToString();
            string strSQL = "select mes1.get_scan_sn(:tr_sn) as tr_sn from dual";
            OracleParameter[] oraParas = new OracleParameter[]{
                    new OracleParameter(":tr_sn",strTrSn.ToUpper())
            };
            dtTemp = OracleHelper.ExecuteDataTable(strConString, CommandType.Text, strSQL, oraParas);

            return dtTemp.Rows[0]["tr_sn"].ToString();
        }
    }
}