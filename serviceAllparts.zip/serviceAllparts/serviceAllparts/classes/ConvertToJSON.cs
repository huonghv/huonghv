﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace WebServiceGetGrnData.classes
{
    public static class ConvertToJSON
    {
        public static string ConverJosngstring(string jsonstr)
        {
            if (jsonstr != null)
            {
                JObject jsonobject = (JObject)JsonConvert.DeserializeObject(jsonstr);
                string json = Newtonsoft.Json.JsonConvert.SerializeObject(jsonobject, Newtonsoft.Json.Formatting.Indented, new Newtonsoft.Json.Converters.IsoDateTimeConverter { DateTimeFormat = "yyyy-MM-dd HH:mm:ss" });
                return json;
            }
            else
            {
                return "";
            }
        }


    }

    public class ReturnMessageModel
    {
        /// <summary>
        /// 狀態,0表示成功,1表示失敗
        /// </summary>
        //public string Status { get; set; }
        /// <summary>
        /// 錯誤代碼,有時沒有,只做特殊判斷用
        /// </summary>
        public int code { get; set; }
        /// <summary>
        /// 提示信息
        /// </summary>
        public string message { get; set; }
        /// <summary>
        /// 數據
        /// </summary>
        public object data { get; set; }
    }
}