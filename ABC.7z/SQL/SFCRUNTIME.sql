﻿-------------------------------------------------
-- Export file for user SFCRUNTIME@JNPTEST     --
-- Created by HuongHV on 8/1/2022, 11:09:57 AM --
-------------------------------------------------

set define off
spool SFCRUNTIME.log

prompt
prompt Creating table BROADCOM_CSV_DETAIL
prompt ==================================
prompt
create table SFCRUNTIME.BROADCOM_CSV_DETAIL
(
  filename VARCHAR2(200),
  recno    INTEGER,
  v1       VARCHAR2(4000),
  v2       VARCHAR2(4000),
  v3       VARCHAR2(4000),
  v4       VARCHAR2(4000),
  v5       VARCHAR2(4000),
  v6       VARCHAR2(4000),
  v7       VARCHAR2(4000),
  v8       VARCHAR2(4000),
  v9       VARCHAR2(4000),
  v10      VARCHAR2(4000),
  v11      VARCHAR2(4000),
  v12      VARCHAR2(4000),
  v13      VARCHAR2(4000),
  v14      VARCHAR2(4000),
  v15      VARCHAR2(4000),
  v16      VARCHAR2(4000),
  v17      VARCHAR2(4000),
  v18      VARCHAR2(4000),
  v19      VARCHAR2(4000),
  v20      VARCHAR2(4000),
  v21      VARCHAR2(4000),
  v22      VARCHAR2(4000),
  v23      VARCHAR2(4000),
  v24      VARCHAR2(4000),
  v25      VARCHAR2(4000),
  v26      VARCHAR2(4000),
  v27      VARCHAR2(4000),
  v28      VARCHAR2(4000),
  v29      VARCHAR2(4000),
  v30      VARCHAR2(4000),
  v31      VARCHAR2(4000),
  v32      VARCHAR2(4000),
  v33      VARCHAR2(4000),
  v34      VARCHAR2(4000),
  v35      VARCHAR2(4000),
  v36      VARCHAR2(4000),
  v37      VARCHAR2(4000),
  v38      VARCHAR2(4000),
  v39      VARCHAR2(4000),
  v40      VARCHAR2(4000),
  v41      VARCHAR2(4000),
  v42      VARCHAR2(4000),
  v43      VARCHAR2(4000),
  v44      VARCHAR2(4000),
  v45      VARCHAR2(4000),
  v46      VARCHAR2(4000),
  v47      VARCHAR2(4000),
  v48      VARCHAR2(4000),
  v49      VARCHAR2(4000),
  v50      VARCHAR2(4000),
  v51      VARCHAR2(4000),
  v52      VARCHAR2(4000),
  v53      VARCHAR2(4000),
  v54      VARCHAR2(4000),
  v55      VARCHAR2(4000),
  v56      VARCHAR2(4000),
  v57      VARCHAR2(4000),
  v58      VARCHAR2(4000),
  v59      VARCHAR2(4000),
  v60      VARCHAR2(4000),
  v61      VARCHAR2(4000),
  v62      VARCHAR2(4000),
  v63      VARCHAR2(4000),
  v64      VARCHAR2(4000),
  v65      VARCHAR2(4000),
  v66      VARCHAR2(4000),
  v67      VARCHAR2(4000),
  v68      VARCHAR2(4000),
  v69      VARCHAR2(4000),
  v70      VARCHAR2(4000),
  v71      VARCHAR2(4000),
  v72      VARCHAR2(4000),
  v73      VARCHAR2(4000),
  v74      VARCHAR2(4000),
  v75      VARCHAR2(4000),
  v76      VARCHAR2(4000),
  v77      VARCHAR2(4000),
  v78      VARCHAR2(4000),
  v79      VARCHAR2(4000),
  v80      VARCHAR2(4000),
  v81      VARCHAR2(4000),
  v82      VARCHAR2(4000),
  v83      VARCHAR2(4000),
  v84      VARCHAR2(4000),
  v85      VARCHAR2(4000),
  v86      VARCHAR2(4000),
  v87      VARCHAR2(4000),
  v88      VARCHAR2(4000),
  v89      VARCHAR2(4000),
  v90      VARCHAR2(4000),
  v91      VARCHAR2(4000),
  v92      VARCHAR2(4000),
  v93      VARCHAR2(4000),
  v94      VARCHAR2(4000),
  v95      VARCHAR2(4000),
  v96      VARCHAR2(4000),
  v97      VARCHAR2(4000),
  v98      VARCHAR2(4000),
  v99      VARCHAR2(4000),
  v100     VARCHAR2(4000),
  createdt DATE
)
;
grant select, insert, update, delete on SFCRUNTIME.BROADCOM_CSV_DETAIL to TEST;

prompt
prompt Creating table BROADCOM_CSV_HEAD
prompt ================================
prompt
create table SFCRUNTIME.BROADCOM_CSV_HEAD
(
  filename VARCHAR2(255),
  createdt DATE,
  status   VARCHAR2(10)
)
;
grant select, insert, update, delete on SFCRUNTIME.BROADCOM_CSV_HEAD to TEST;

prompt
prompt Creating table C_CARRIER
prompt ========================
prompt
create table SFCRUNTIME.C_CARRIER
(
  id            VARCHAR2(50),
  carrierno     VARCHAR2(50),
  carrier_skuno VARCHAR2(50),
  usetimes      INTEGER,
  valid_flag    VARCHAR2(10),
  edittime      DATE,
  editby        VARCHAR2(30)
)
;
create index SFCRUNTIME.IDX_C_CARRIER0 on SFCRUNTIME.C_CARRIER (ID, CARRIERNO, CARRIER_SKUNO);
create unique index SFCRUNTIME.PK_C_CARRIER on SFCRUNTIME.C_CARRIER (ID);

prompt
prompt Creating table C_CARRIER_SKUNO_INFO
prompt ===================================
prompt
create table SFCRUNTIME.C_CARRIER_SKUNO_INFO
(
  id            VARCHAR2(50),
  carrier_skuno VARCHAR2(50),
  carrier_type  VARCHAR2(50),
  carrier_name  VARCHAR2(50),
  customer_name VARCHAR2(50),
  carrier_mfr   VARCHAR2(50),
  location      VARCHAR2(50),
  suselimit     INTEGER,
  maxuselimit   INTEGER,
  linkqty       INTEGER,
  valid_flag    VARCHAR2(10),
  edittime      DATE,
  editby        VARCHAR2(30)
)
;
comment on column SFCRUNTIME.C_CARRIER_SKUNO_INFO.suselimit
  is '單次使用上限';
comment on column SFCRUNTIME.C_CARRIER_SKUNO_INFO.maxuselimit
  is '最大使用上限';
comment on column SFCRUNTIME.C_CARRIER_SKUNO_INFO.valid_flag
  is '是否生效(0/1)';
create index SFCRUNTIME.C_CARRIER_SKUNO_INFO on SFCRUNTIME.C_CARRIER_SKUNO_INFO (CARRIER_SKUNO, VALID_FLAG);
create unique index SFCRUNTIME.C_CARRIER_SKUNO_INFO0 on SFCRUNTIME.C_CARRIER_SKUNO_INFO (ID);

prompt
prompt Creating table C_REPAIR_SN_CONTROL
prompt ==================================
prompt
create table SFCRUNTIME.C_REPAIR_SN_CONTROL
(
  id          NVARCHAR2(50),
  sn          NVARCHAR2(50),
  station     NVARCHAR2(50),
  repaircount NUMBER,
  reason      NVARCHAR2(50),
  edittime    DATE,
  editby      NVARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_C_REPAIR_SN_CONTROL on SFCRUNTIME.C_REPAIR_SN_CONTROL (ID);
grant select, insert, update, delete on SFCRUNTIME.C_REPAIR_SN_CONTROL to TEST;

prompt
prompt Creating table C_STATION_SCAN_LOG
prompt =================================
prompt
create table SFCRUNTIME.C_STATION_SCAN_LOG
(
  id            VARCHAR2(50) not null,
  scankey       VARCHAR2(50),
  errmsg        VARCHAR2(150),
  station       VARCHAR2(20),
  line          VARCHAR2(10),
  ip            VARCHAR2(15),
  empno         VARCHAR2(10),
  actionname    VARCHAR2(50),
  classname     VARCHAR2(100),
  exceptionflag VARCHAR2(10),
  enableflag    VARCHAR2(10),
  createtime    DATE,
  createby      VARCHAR2(10)
)
;
grant select, insert, update, delete on SFCRUNTIME.C_STATION_SCAN_LOG to TEST;

prompt
prompt Creating table C_USER_FUNCTION
prompt ==============================
prompt
create table SFCRUNTIME.C_USER_FUNCTION
(
  id           VARCHAR2(50),
  functionname VARCHAR2(50),
  userid       VARCHAR2(50),
  role         VARCHAR2(50),
  createby     VARCHAR2(50),
  createtime   DATE
)
;
create unique index SFCRUNTIME.PK_C_USER_FUNCTION on SFCRUNTIME.C_USER_FUNCTION (ID);
grant select, insert, update, delete on SFCRUNTIME.C_USER_FUNCTION to TEST;

prompt
prompt Creating table HPE_EDI_810
prompt ==========================
prompt
create table SFCRUNTIME.HPE_EDI_810
(
  id              VARCHAR2(50),
  f_id            NUMBER not null,
  f_850_860_id    NUMBER,
  f_idoc_filename VARCHAR2(100),
  f_inv_no        VARCHAR2(30) not null,
  f_inv_line      VARCHAR2(10) not null,
  f_inv_date      DATE not null,
  f_po            VARCHAR2(10) not null,
  f_po_line       VARCHAR2(10) not null,
  f_inv_cpn       VARCHAR2(30) not null,
  f_inv_cpn_desc  VARCHAR2(200) not null,
  f_inv_mpn       VARCHAR2(30) not null,
  f_inv_mpn_desc  VARCHAR2(200) not null,
  f_inv_qty       NUMBER not null,
  f_inv_price     NUMBER(10,3) not null,
  f_inv_total_amt NUMBER(19,3) not null,
  f_dn            VARCHAR2(20) not null,
  f_so            VARCHAR2(20) not null,
  f_party_bt      CLOB not null,
  f_party_st      CLOB not null,
  f_party_sf      CLOB not null,
  f_810_filename  VARCHAR2(100),
  f_lasteditdt    DATE default sysdate,
  f_inv_tax       NUMBER(10,3)
)
;
create index SFCRUNTIME.IDX_HPE_EDI_810 on SFCRUNTIME.HPE_EDI_810 (F_PO, F_PO_LINE);
create unique index SFCRUNTIME.PK_HPE_EDI_810 on SFCRUNTIME.HPE_EDI_810 (ID);

prompt
prompt Creating table HPE_EDI_850
prompt ==========================
prompt
create table SFCRUNTIME.HPE_EDI_850
(
  id              VARCHAR2(50),
  f_id            NUMBER,
  f_site          VARCHAR2(10),
  f_po            VARCHAR2(30),
  f_po_type       VARCHAR2(10),
  f_po_date       DATE,
  f_po_comment    VARCHAR2(30),
  f_companycode   VARCHAR2(20),
  f_inco_term     VARCHAR2(20),
  f_n1_st         CLOB,
  f_n1_da         CLOB,
  f_n1_bt         CLOB,
  f_n1_pd         CLOB,
  f_line          VARCHAR2(10),
  f_line_qty      NUMBER,
  f_line_price    NUMBER(10,3),
  f_pn            VARCHAR2(30),
  f_pn_desc       VARCHAR2(100),
  po_sch_line     NUMBER,
  f_sch_qty       NUMBER,
  f_sch_dr_date   DATE,
  f_lastedit_dt   DATE,
  f_filename      VARCHAR2(255),
  edit_time       DATE,
  flag            VARCHAR2(10),
  f_pip_type      VARCHAR2(5),
  f_pc_code       VARCHAR2(10),
  f_po_ver        VARCHAR2(10),
  f_ship_mode     VARCHAR2(10),
  f_carrier       VARCHAR2(20),
  f_line_left_qty NUMBER,
  f_ship_date     DATE
)
;
create index SFCRUNTIME.IDX_HPE_EDI_850 on SFCRUNTIME.HPE_EDI_850 (F_PO, F_LINE);
create unique index SFCRUNTIME.PK_HPE_EDI_850 on SFCRUNTIME.HPE_EDI_850 (ID);

prompt
prompt Creating table HPE_EDI_855
prompt ==========================
prompt
create table SFCRUNTIME.HPE_EDI_855
(
  id            VARCHAR2(50),
  f_sfc_id      NUMBER,
  f_850_id      NUMBER,
  f_po          VARCHAR2(50),
  f_date        DATE,
  f_line        VARCHAR2(50),
  f_mpn         VARCHAR2(50),
  f_cpn         VARCHAR2(50),
  f_mpn_desc    VARCHAR2(30),
  f_line_price  NUMBER(10,3),
  f_line_qty    NUMBER,
  f_reason_code VARCHAR2(10),
  f_ack_esd     DATE,
  f_ack_edd     DATE,
  f_ack_qty     NUMBER,
  edit_time     DATE,
  edit_emp      VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_HPE_EDI_855 on SFCRUNTIME.HPE_EDI_855 (F_PO, F_LINE);
create unique index SFCRUNTIME.PK_HPE_EDI_855 on SFCRUNTIME.HPE_EDI_855 (ID);

prompt
prompt Creating table HPE_EDI_856
prompt ==========================
prompt
create table SFCRUNTIME.HPE_EDI_856
(
  id                   VARCHAR2(50),
  f_id                 NUMBER not null,
  f_filename           VARCHAR2(255),
  f_to_no              VARCHAR2(20) not null,
  f_to_date            DATE not null,
  f_to_shipdate        DATE not null,
  f_to_dn              VARCHAR2(20) not null,
  f_to_dn_line         VARCHAR2(10) not null,
  f_to_pkg_qty         VARCHAR2(20),
  f_to_netweight       VARCHAR2(20),
  f_to_grossweight     VARCHAR2(20),
  f_to_volume          VARCHAR2(20),
  f_to_trailerno       VARCHAR2(20),
  f_carrier_type       VARCHAR2(5),
  f_carrier_code       VARCHAR2(20),
  f_carrier_tran_type  VARCHAR2(5),
  f_carrier_ref_no     VARCHAR2(30),
  f_carrier_trailer_no VARCHAR2(30),
  f_st_name            VARCHAR2(100),
  f_st_contact         VARCHAR2(50),
  f_st_contact_mail    VARCHAR2(50),
  f_st_customercode    VARCHAR2(100),
  f_st_address         VARCHAR2(100),
  f_st_city            VARCHAR2(100),
  f_st_postcode        VARCHAR2(100),
  f_st_state_code      VARCHAR2(10),
  f_st_country_code    VARCHAR2(10),
  f_po_no              VARCHAR2(50),
  f_po_line_no         VARCHAR2(10),
  f_po_line_qty        VARCHAR2(10),
  f_po_date            DATE,
  f_pkg_id             VARCHAR2(20),
  f_pkg_qty            VARCHAR2(20),
  f_pkg_gross_weight   VARCHAR2(20),
  f_pkg_dimension      VARCHAR2(100),
  f_item_mpn           VARCHAR2(50) not null,
  f_item_cpn           VARCHAR2(50) not null,
  f_item_sn            VARCHAR2(20) not null,
  f_item_coo           VARCHAR2(10) not null,
  f_lasteditdt         DATE
)
;
create index SFCRUNTIME.IDX1_HPE_EDI_856 on SFCRUNTIME.HPE_EDI_856 (F_TO_DN);
create index SFCRUNTIME.IDX_HPE_EDI_856 on SFCRUNTIME.HPE_EDI_856 (F_PO_NO, F_PO_LINE_NO);
create unique index SFCRUNTIME.PK_HPE_EDI_856 on SFCRUNTIME.HPE_EDI_856 (ID);

prompt
prompt Creating table HPE_EDI_860
prompt ==========================
prompt
create table SFCRUNTIME.HPE_EDI_860
(
  id              VARCHAR2(50),
  f_id            VARCHAR2(50),
  f_site          VARCHAR2(10),
  f_pip_type      VARCHAR2(5),
  f_pc_code       VARCHAR2(10),
  f_po            VARCHAR2(30),
  f_po_type       VARCHAR2(10),
  f_po_date       DATE,
  f_po_comment    VARCHAR2(30),
  f_po_ver        VARCHAR2(10),
  f_companycode   VARCHAR2(20),
  f_inco_term     VARCHAR2(20),
  f_ship_mode     VARCHAR2(10),
  f_carrier       VARCHAR2(20),
  f_n1_st         CLOB,
  f_n1_da         CLOB,
  f_n1_bt         CLOB,
  f_n1_pd         CLOB,
  f_line          CLOB,
  f_line_qty      NUMBER,
  f_line_left_qty NUMBER,
  f_line_price    NUMBER(10,3),
  f_pn            VARCHAR2(30),
  f_pn_desc       VARCHAR2(100),
  f_ship_date     DATE,
  po_sch_line     VARCHAR2(50),
  f_sch_qty       NUMBER,
  f_sch_dr_date   DATE,
  f_lastedit_dt   DATE,
  f_filename      VARCHAR2(255),
  createtime      DATE
)
;
create unique index SFCRUNTIME.PK_HPE_EDI_860 on SFCRUNTIME.HPE_EDI_860 (ID);

prompt
prompt Creating table HPE_SHIP_DATA
prompt ============================
prompt
create table SFCRUNTIME.HPE_SHIP_DATA
(
  id                   VARCHAR2(50),
  f_to_no              VARCHAR2(20) not null,
  f_to_date            DATE not null,
  f_to_shipdate        DATE not null,
  f_to_dn              VARCHAR2(20) not null,
  f_to_dn_line         VARCHAR2(10) not null,
  f_to_trailerno       VARCHAR2(20),
  f_carrier_type       VARCHAR2(5),
  f_carrier_code       VARCHAR2(20),
  f_carrier_tran_type  VARCHAR2(5),
  f_carrier_ref_no     VARCHAR2(30),
  f_carrier_trailer_no VARCHAR2(30),
  f_st_name            VARCHAR2(100),
  f_st_contact         VARCHAR2(50),
  f_st_contact_mail    VARCHAR2(50),
  f_st_customercode    VARCHAR2(100),
  f_st_address         VARCHAR2(100),
  f_st_city            VARCHAR2(100),
  f_st_postcode        VARCHAR2(100),
  f_st_state_code      VARCHAR2(10),
  f_st_country_code    VARCHAR2(10),
  f_po_no              VARCHAR2(50),
  f_po_line_no         VARCHAR2(10),
  f_po_line_qty        VARCHAR2(10),
  f_po_date            DATE,
  createtime           DATE default sysdate,
  edittime             DATE default sysdate,
  create_emp           VARCHAR2(20),
  edit_emp             VARCHAR2(20)
)
;
create index SFCRUNTIME.IDX1_HPE_SHIP_DATA on SFCRUNTIME.HPE_SHIP_DATA (F_TO_DN);
create index SFCRUNTIME.IDX_HPE_SHIP_DATA on SFCRUNTIME.HPE_SHIP_DATA (F_PO_NO, F_PO_LINE_NO);
create unique index SFCRUNTIME.PK_HPE_SHIP_DATA on SFCRUNTIME.HPE_SHIP_DATA (ID);

prompt
prompt Creating table H_KEYPART_DETAIL
prompt ===============================
prompt
create table SFCRUNTIME.H_KEYPART_DETAIL
(
  id            VARCHAR2(50),
  sn            VARCHAR2(50),
  keypart_sn    VARCHAR2(50),
  station_name  VARCHAR2(50),
  part_no       VARCHAR2(50),
  seq_no        NUMBER,
  category_name VARCHAR2(50),
  category      VARCHAR2(50),
  original_csn  VARCHAR2(50),
  mpn           VARCHAR2(50),
  old_mpn       VARCHAR2(50),
  mfr_name      VARCHAR2(50),
  old_mfr_name  VARCHAR2(50),
  create_emp    VARCHAR2(50),
  create_time   DATE,
  edit_emp      VARCHAR2(50),
  edit_time     DATE
)
;
create index SFCRUNTIME.IDX_H_KEYPART_DETAIL0 on SFCRUNTIME.H_KEYPART_DETAIL (SN, KEYPART_SN, STATION_NAME, PART_NO);
create unique index SFCRUNTIME.PK_H_KEYPART_DETAIL on SFCRUNTIME.H_KEYPART_DETAIL (ID);

prompt
prompt Creating table H_MRB_GT
prompt =======================
prompt
create table SFCRUNTIME.H_MRB_GT
(
  id               VARCHAR2(50),
  workorderno      VARCHAR2(50),
  sap_station_code VARCHAR2(50),
  from_storage     VARCHAR2(50),
  to_storage       VARCHAR2(50),
  total_qty        NUMBER,
  confirmed_flag   VARCHAR2(1),
  zcpp_flag        VARCHAR2(1),
  sap_flag         VARCHAR2(1),
  skuno            VARCHAR2(50),
  sap_message      VARCHAR2(150),
  edit_emp         VARCHAR2(50),
  edit_time        DATE
)
;
create index SFCRUNTIME.IDX_H_MRB_GT0 on SFCRUNTIME.H_MRB_GT (WORKORDERNO);
create unique index SFCRUNTIME.PK_H_MRB_GT on SFCRUNTIME.H_MRB_GT (ID);

prompt
prompt Creating table H_SMT_CAPACITY
prompt =============================
prompt
create table SFCRUNTIME.H_SMT_CAPACITY
(
  station              VARCHAR2(50),
  building             VARCHAR2(50),
  floor                VARCHAR2(50),
  smtcode              VARCHAR2(50),
  lasteditdate         DATE,
  sequence             INTEGER,
  qtybyhour            INTEGER,
  start_time           DATE,
  stop_time            DATE,
  utilization_time     FLOAT,
  actual_quantity      INTEGER,
  yield_quantity       INTEGER,
  first_pass_quantity  INTEGER,
  rework_pass_quantity INTEGER,
  upload_status        INTEGER,
  upload_count         INTEGER,
  upload_error_code    VARCHAR2(100),
  upload_error_message VARCHAR2(200)
)
;

prompt
prompt Creating table H_SN_KEYPART_DETAIL
prompt ==================================
prompt
create table SFCRUNTIME.H_SN_KEYPART_DETAIL
(
  id            VARCHAR2(50),
  r_sn_id       VARCHAR2(50),
  sn            VARCHAR2(50),
  keypart_sn    VARCHAR2(50),
  station_name  VARCHAR2(50),
  part_no       VARCHAR2(50),
  seq_no        NUMBER,
  category_name VARCHAR2(50),
  category      VARCHAR2(50),
  original_csn  VARCHAR2(50),
  mpn           VARCHAR2(50),
  old_mpn       VARCHAR2(50),
  mfr_name      VARCHAR2(50),
  old_mfr_name  VARCHAR2(50),
  valid         VARCHAR2(2),
  create_emp    VARCHAR2(50),
  create_time   DATE,
  edit_emp      VARCHAR2(50),
  edit_time     DATE
)
;
create index SFCRUNTIME.IDX_H_SN_KEYPART_DETAIL0 on SFCRUNTIME.H_SN_KEYPART_DETAIL (KEYPART_SN, SN, STATION_NAME, PART_NO);
create unique index SFCRUNTIME.PK_H_SN_KEYPART_DETAIL on SFCRUNTIME.H_SN_KEYPART_DETAIL (ID);

prompt
prompt Creating table H_WO_HEADER
prompt ==========================
prompt
create table SFCRUNTIME.H_WO_HEADER
(
  id         VARCHAR2(50),
  aufnr      VARCHAR2(50),
  werks      VARCHAR2(50),
  auart      VARCHAR2(50),
  matnr      VARCHAR2(50),
  revlv      VARCHAR2(50),
  kdauf      VARCHAR2(50),
  gstrs      VARCHAR2(50),
  gamng      VARCHAR2(50),
  kdmat      VARCHAR2(50),
  aedat      VARCHAR2(50),
  aenam      VARCHAR2(50),
  matkl      VARCHAR2(50),
  maktx      VARCHAR2(200),
  erdat      VARCHAR2(50),
  gsups      VARCHAR2(50),
  erfzeit    VARCHAR2(50),
  gltrs      VARCHAR2(50),
  glups      VARCHAR2(50),
  lgort      VARCHAR2(50),
  ablad      VARCHAR2(50),
  rohs_value VARCHAR2(50),
  ftrmi      VARCHAR2(50),
  mvgr3      VARCHAR2(50),
  wemng      VARCHAR2(50),
  bismt      VARCHAR2(50),
  charg      VARCHAR2(50),
  saenr      VARCHAR2(50),
  aetxt      VARCHAR2(50),
  gltrp      VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_H_WO_HEADER0 on SFCRUNTIME.H_WO_HEADER (AUFNR, REVLV);
create unique index SFCRUNTIME.PK_H_WO_HEADER on SFCRUNTIME.H_WO_HEADER (ID);

prompt
prompt Creating table H_WO_HEADER_EX
prompt =============================
prompt
create table SFCRUNTIME.H_WO_HEADER_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCRUNTIME.PK_H_WO_HEADER_EX on SFCRUNTIME.H_WO_HEADER_EX (ID, SEQ_NO);

prompt
prompt Creating table H_WO_ITEM
prompt ========================
prompt
create table SFCRUNTIME.H_WO_ITEM
(
  id        VARCHAR2(50),
  aufnr     VARCHAR2(20),
  posnr     VARCHAR2(20),
  matnr     VARCHAR2(20),
  parts     VARCHAR2(20),
  kdmat     VARCHAR2(40),
  bdmng     VARCHAR2(20),
  meins     VARCHAR2(40),
  revlv     VARCHAR2(10),
  baugr     VARCHAR2(20),
  repno     VARCHAR2(20),
  reppartno VARCHAR2(20),
  auart     VARCHAR2(10),
  aenam     VARCHAR2(20),
  aedat     VARCHAR2(20),
  maktx     VARCHAR2(200),
  matkl     VARCHAR2(50),
  wgbez     VARCHAR2(50),
  alpos     VARCHAR2(10),
  ablad     VARCHAR2(30),
  mvgr3     VARCHAR2(10),
  rgekz     VARCHAR2(10),
  lgort     VARCHAR2(10),
  enmng     VARCHAR2(20),
  dumps     VARCHAR2(5),
  bismt     VARCHAR2(20),
  xloek     VARCHAR2(5),
  shkzg     VARCHAR2(5),
  charg     VARCHAR2(12),
  rspos     VARCHAR2(20),
  vornr     VARCHAR2(5)
)
;
create index SFCRUNTIME.IDX_H_WO_ITEM0 on SFCRUNTIME.H_WO_ITEM (AUFNR);
create index SFCRUNTIME.IDX_H_WO_ITEM1 on SFCRUNTIME.H_WO_ITEM (POSNR);
create unique index SFCRUNTIME.PK_H_WO_ITEM on SFCRUNTIME.H_WO_ITEM (ID);

prompt
prompt Creating table H_WO_ITEM_EX
prompt ===========================
prompt
create table SFCRUNTIME.H_WO_ITEM_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCRUNTIME.PK_H_WO_ITEM_EX on SFCRUNTIME.H_WO_ITEM_EX (ID, SEQ_NO);

prompt
prompt Creating table H_WO_TEXT
prompt ========================
prompt
create table SFCRUNTIME.H_WO_TEXT
(
  id    VARCHAR2(50),
  aufnr VARCHAR2(20),
  matnr VARCHAR2(20),
  arbpl VARCHAR2(20),
  ltxa1 VARCHAR2(50),
  isavd VARCHAR2(50),
  vornr VARCHAR2(8),
  mgvrg VARCHAR2(20),
  lmnga VARCHAR2(20)
)
;
create index SFCRUNTIME.IDX_H_WO_TEXT0 on SFCRUNTIME.H_WO_TEXT (AUFNR);
create unique index SFCRUNTIME.PK_H_WO_TEXT on SFCRUNTIME.H_WO_TEXT (ID);

prompt
prompt Creating table H_WO_TEXT_EX
prompt ===========================
prompt
create table SFCRUNTIME.H_WO_TEXT_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCRUNTIME.PK_H_WO_TEXT_EX on SFCRUNTIME.H_WO_TEXT_EX (ID, SEQ_NO);

prompt
prompt Creating table MFSYSCOMPONENT
prompt =============================
prompt
create table SFCRUNTIME.MFSYSCOMPONENT
(
  id               VARCHAR2(50) not null,
  shiporderid      VARCHAR2(20) not null,
  sysserialno      VARCHAR2(30),
  partno           VARCHAR2(20),
  version          VARCHAR2(5),
  seqno            NUMBER,
  qty              NUMBER,
  custpartno       VARCHAR2(20),
  replaceno        NUMBER,
  replacetopartno  VARCHAR2(20),
  keypart          VARCHAR2(5),
  installed        VARCHAR2(5),
  installedqty     NUMBER,
  eeecode          VARCHAR2(20),
  cserialno1       VARCHAR2(20),
  cserialno2       VARCHAR2(20),
  cserialno3       VARCHAR2(20),
  cserialno4       VARCHAR2(20),
  categoryname     VARCHAR2(20),
  prodcategoryname VARCHAR2(20),
  prodtype         VARCHAR2(5),
  originalqty      VARCHAR2(10),
  unitcost         NUMBER,
  replacegroup     VARCHAR2(50),
  noreplacepart    VARCHAR2(5),
  lasteditby       VARCHAR2(20),
  lasteditdt       DATE
)
;
create index SFCRUNTIME.IDX_MFSYSCOMPONENT on SFCRUNTIME.MFSYSCOMPONENT (SHIPORDERID);
create unique index SFCRUNTIME.PK_MFSYSCOMPONENT on SFCRUNTIME.MFSYSCOMPONENT (ID);

prompt
prompt Creating table MFSYSCSERIAL
prompt ===========================
prompt
create table SFCRUNTIME.MFSYSCSERIAL
(
  id               VARCHAR2(50) not null,
  shiporderid      VARCHAR2(20) not null,
  sysserialno      VARCHAR2(30),
  cserialno        VARCHAR2(80),
  eventpoint       VARCHAR2(20),
  custpartno       VARCHAR2(30),
  eeecode          VARCHAR2(30),
  partno           VARCHAR2(30),
  seqno            NUMBER,
  categoryname     VARCHAR2(20),
  prodcategoryname VARCHAR2(20),
  prodtype         VARCHAR2(20),
  originalcsn      VARCHAR2(80),
  scanby           VARCHAR2(20),
  scandt           VARCHAR2(30),
  lasteditby       VARCHAR2(20),
  lasteditdt       DATE,
  mdsget           VARCHAR2(20),
  mpn              VARCHAR2(100),
  oldmpn           VARCHAR2(60)
)
;
create index SFCRUNTIME.IDX_MFSYSCSERIAL11 on SFCRUNTIME.MFSYSCSERIAL (SHIPORDERID);
create index SFCRUNTIME.MFSYSCSERIAL02 on SFCRUNTIME.MFSYSCSERIAL (SYSSERIALNO);
create index SFCRUNTIME.MFSYSCSERIAL03 on SFCRUNTIME.MFSYSCSERIAL (CSERIALNO);
create index SFCRUNTIME.MFSYSCSERIAL_01 on SFCRUNTIME.MFSYSCSERIAL (SYSSERIALNO, CSERIALNO, CUSTPARTNO);
create unique index SFCRUNTIME.PK_MFSYSCSERIAL on SFCRUNTIME.MFSYSCSERIAL (ID);

prompt
prompt Creating table MFSYSEVENT
prompt =========================
prompt
create table SFCRUNTIME.MFSYSEVENT
(
  id             VARCHAR2(50) not null,
  shiporderid    VARCHAR2(20) not null,
  sysserialno    VARCHAR2(20),
  eventname      VARCHAR2(30),
  scandatetime   DATE,
  factoryid      VARCHAR2(10),
  productionline VARCHAR2(20),
  shift          VARCHAR2(20),
  scanby         VARCHAR2(20),
  eventpass      VARCHAR2(1),
  eventfail      VARCHAR2(1),
  productstatus  VARCHAR2(20),
  mdsget         VARCHAR2(1),
  skuno          VARCHAR2(20),
  workorderno    VARCHAR2(20)
)
;
create index SFCRUNTIME.IDX_MFSYSEVENT on SFCRUNTIME.MFSYSEVENT (SHIPORDERID);
create unique index SFCRUNTIME.PK_MFSYSEVENT on SFCRUNTIME.MFSYSEVENT (ID);

prompt
prompt Creating table MFSYSPRODUCT
prompt ===========================
prompt
create table SFCRUNTIME.MFSYSPRODUCT
(
  id               VARCHAR2(50) not null,
  shiporderid      VARCHAR2(20) not null,
  sysserialno      VARCHAR2(30),
  seqno            NUMBER,
  factoryid        VARCHAR2(10),
  routeid          VARCHAR2(30),
  customerid       VARCHAR2(20),
  workorderno      VARCHAR2(20),
  skuno            VARCHAR2(30),
  custpartno       VARCHAR2(30),
  eeecode          VARCHAR2(30),
  custssn          DATE,
  firmware         VARCHAR2(400),
  software         VARCHAR2(20),
  servicetag       VARCHAR2(30),
  enetid           VARCHAR2(20),
  prioritycode     VARCHAR2(30),
  productfamily    VARCHAR2(50),
  productlevel     VARCHAR2(30),
  productcolor     VARCHAR2(30),
  productlangulage VARCHAR2(30),
  shipcountry      VARCHAR2(40),
  productdesc      VARCHAR2(100),
  orderno          VARCHAR2(15),
  compcode         VARCHAR2(10),
  shipped          VARCHAR2(5),
  shipdate         DATE,
  location         VARCHAR2(30),
  whid             VARCHAR2(10),
  areaid           VARCHAR2(10),
  workordertype    VARCHAR2(20),
  packageno        NUMBER,
  systemstage      VARCHAR2(20),
  unitcost         NUMBER,
  lineseqno        NUMBER,
  reseatpre        VARCHAR2(10),
  reseat           VARCHAR2(10),
  reseattag        NUMBER,
  lasteditby       VARCHAR2(20),
  lasteditdt       DATE,
  coo              VARCHAR2(20),
  field1           VARCHAR2(20)
)
;
create index SFCRUNTIME.IDX_MFSYSPRODUCT on SFCRUNTIME.MFSYSPRODUCT (SHIPORDERID);
create unique index SFCRUNTIME.PK_MFSYSPRODUCT on SFCRUNTIME.MFSYSPRODUCT (ID);

prompt
prompt Creating table MFWORKORDER
prompt ==========================
prompt
create table SFCRUNTIME.MFWORKORDER
(
  id                VARCHAR2(50) not null,
  shiporderid       VARCHAR2(20) not null,
  workorderno       VARCHAR2(10),
  factoryid         VARCHAR2(10),
  workorderdate     DATE,
  scheduledate      DATE,
  workroutetype     VARCHAR2(20),
  workordertype     VARCHAR2(20),
  productiontype    VARCHAR2(20),
  skuno             VARCHAR2(30),
  skuversion        VARCHAR2(4),
  skuname           VARCHAR2(50),
  skudesc           VARCHAR2(100),
  custpartno        VARCHAR2(30),
  custpartdesc      VARCHAR2(100),
  custmodelno       VARCHAR2(30),
  customerid        VARCHAR2(20),
  shiporder         VARCHAR2(20),
  software          VARCHAR2(20),
  firmware          VARCHAR2(20),
  eeecode           VARCHAR2(20),
  productfamily     VARCHAR2(50),
  productlevel      VARCHAR2(30),
  productcolor      VARCHAR2(30),
  productlangulage  VARCHAR2(30),
  prioritycode      VARCHAR2(30),
  shipcountry       VARCHAR2(30),
  routeid           VARCHAR2(30),
  orderno           VARCHAR2(20),
  custpono          VARCHAR2(20),
  compcode          VARCHAR2(10),
  released          VARCHAR2(1),
  releaseddate      DATE,
  jobstarted        VARCHAR2(1),
  startdate         DATE,
  mrpartial         VARCHAR2(1),
  mrcompleted       VARCHAR2(1),
  cancelled         VARCHAR2(1),
  closed            VARCHAR2(1),
  closedate         DATE,
  workorderqty      NUMBER,
  finishedqty       NUMBER,
  scrapedqty        NUMBER,
  stockinrequestqty NUMBER,
  stockinprocessqty NUMBER,
  batchno           VARCHAR2(10),
  batchdate         DATE,
  batchseqno        NUMBER,
  jobnote1          VARCHAR2(255),
  rmano             VARCHAR2(20),
  rmalineno         VARCHAR2(10),
  reworked          VARCHAR2(1),
  custpartversion   VARCHAR2(20),
  packageno         NUMBER,
  orderlineno       VARCHAR2(10),
  lasteditby        VARCHAR2(20),
  lasteditdt        DATE
)
;
create index SFCRUNTIME.IDX_MFWORKORDER on SFCRUNTIME.MFWORKORDER (SHIPORDERID);
create unique index SFCRUNTIME.PK_MFWORKORDER on SFCRUNTIME.MFWORKORDER (ID);

prompt
prompt Creating table MFWORKSTATUS
prompt ===========================
prompt
create table SFCRUNTIME.MFWORKSTATUS
(
  id             VARCHAR2(50) not null,
  shiporderid    VARCHAR2(20) not null,
  sysserialno    VARCHAR2(20) not null,
  assigndate     DATE,
  workorderno    VARCHAR2(10) not null,
  factoryid      VARCHAR2(10) not null,
  productionline VARCHAR2(20) not null,
  shift          VARCHAR2(20) not null,
  buildno        VARCHAR2(5),
  routeid        VARCHAR2(25),
  started        VARCHAR2(5) not null,
  startdate      DATE,
  packed         VARCHAR2(5) not null,
  packdate       DATE,
  completed      VARCHAR2(5) not null,
  completedate   DATE,
  shipped        VARCHAR2(5) not null,
  shipdate       DATE,
  repairheld     VARCHAR2(5) not null,
  repairdate     DATE,
  currentpdline  VARCHAR2(20),
  currentshift   VARCHAR2(20),
  currentevent   VARCHAR2(30),
  nextevent      VARCHAR2(30),
  stuffingqty    VARCHAR2(5),
  field1         VARCHAR2(20),
  quited         VARCHAR2(5),
  quitdate       DATE,
  lastevent      VARCHAR2(30),
  productstatus  VARCHAR2(30),
  reseatcount    NUMBER(2),
  reseat         VARCHAR2(5),
  lasteditby     VARCHAR2(20),
  lasteditdt     DATE,
  reflow         VARCHAR2(5),
  reflowtime     DATE,
  ort_in_time    DATE,
  ort_out_time   DATE,
  ort_fail_time  DATE,
  ort_count      NUMBER(2) not null,
  ort_flag       VARCHAR2(5) not null,
  ort_outflag    VARCHAR2(5) not null,
  stockintime    DATE,
  stockouttime   DATE,
  stockstatus    VARCHAR2(10)
)
;
create index SFCRUNTIME.IDX_MFWORKSTATUS on SFCRUNTIME.MFWORKSTATUS (SHIPORDERID);
create unique index SFCRUNTIME.PK_MFWORKSTATUS on SFCRUNTIME.MFWORKSTATUS (ID);

prompt
prompt Creating table O_137CARTON_LABEL
prompt ================================
prompt
create table SFCRUNTIME.O_137CARTON_LABEL
(
  id           VARCHAR2(50) not null,
  skuno        VARCHAR2(50) not null,
  specval      VARCHAR2(50),
  partno       VARCHAR2(50),
  qty          VARCHAR2(50),
  descriptions VARCHAR2(50),
  createtime   DATE
)
;
create unique index SFCRUNTIME.PK_O_137CARTON_LABEL on SFCRUNTIME.O_137CARTON_LABEL (ID);

prompt
prompt Creating table O_137_COO_LABEL
prompt ==============================
prompt
create table SFCRUNTIME.O_137_COO_LABEL
(
  id           VARCHAR2(50) not null,
  coovalue     VARCHAR2(50) not null,
  partno       VARCHAR2(50),
  descriptions VARCHAR2(500),
  createtime   DATE
)
;
create unique index SFCRUNTIME.PK_O_137_COO_LABEL on SFCRUNTIME.O_137_COO_LABEL (ID);

prompt
prompt Creating table O_AGILE_ATTR
prompt ===========================
prompt
create table SFCRUNTIME.O_AGILE_ATTR
(
  id                   VARCHAR2(50),
  item_number          VARCHAR2(300),
  rev                  VARCHAR2(40),
  cs_flag              VARCHAR2(2048),
  hidden_bom           VARCHAR2(2048),
  serialization        VARCHAR2(2048),
  user_item_type       VARCHAR2(2048),
  rohs_compliance      VARCHAR2(2048),
  offering_type        VARCHAR2(2048),
  clei_code            VARCHAR2(150),
  cpr_code             VARCHAR2(150),
  eci_bar_code         VARCHAR2(150),
  kcc_cert_number      VARCHAR2(150),
  regulatory_model     VARCHAR2(150),
  upc_code             VARCHAR2(150),
  serial_number_mask   VARCHAR2(4000),
  change_number        VARCHAR2(90),
  effective_date       DATE,
  release_date         DATE,
  plant                VARCHAR2(20),
  created_by           VARCHAR2(50),
  date_created         DATE default sysdate,
  customer_part_number VARCHAR2(150),
  description          VARCHAR2(720),
  actived              VARCHAR2(10)
)
;
create unique index SFCRUNTIME.PK_O_AGILE_ATTR on SFCRUNTIME.O_AGILE_ATTR (ID);

prompt
prompt Creating table O_B2B_ACK
prompt ========================
prompt
create table SFCRUNTIME.O_B2B_ACK
(
  id            VARCHAR2(50) not null,
  f_id          VARCHAR2(50),
  filename      VARCHAR2(100),
  messageid     VARCHAR2(50),
  tranid        VARCHAR2(50),
  f_msg_type    VARCHAR2(20),
  f_doc_no      VARCHAR2(30),
  exceptiontype VARCHAR2(20),
  f_msg         VARCHAR2(200),
  partnerid     VARCHAR2(30),
  f_lastedit    DATE,
  createtime    DATE
)
;
comment on column SFCRUNTIME.O_B2B_ACK.tranid
  is '';
create unique index SFCRUNTIME.PK_O_B2B_ACK on SFCRUNTIME.O_B2B_ACK (ID);

prompt
prompt Creating table O_EXCEPTION_DATA
prompt ===============================
prompt
create table SFCRUNTIME.O_EXCEPTION_DATA
(
  id            VARCHAR2(50),
  upoid         NVARCHAR2(50),
  originalid    NVARCHAR2(50),
  exctype       NVARCHAR2(50),
  exceptioninfo NVARCHAR2(2000),
  excepcode     NVARCHAR2(50),
  status        NVARCHAR2(50),
  mailflag      NVARCHAR2(50),
  createtime    DATE default sysdate,
  createby      NVARCHAR2(50),
  mailid        NVARCHAR2(50),
  edittime      DATE
)
;
create unique index SFCRUNTIME.PK_O_EXCEPTION_DATA on SFCRUNTIME.O_EXCEPTION_DATA (ID);

prompt
prompt Creating table O_I137
prompt =====================
prompt
create table SFCRUNTIME.O_I137
(
  id                      VARCHAR2(50),
  f_id                    NUMBER,
  tranid                  NVARCHAR2(50),
  f_plant                 NVARCHAR2(20),
  filename                NVARCHAR2(70),
  messageid               NVARCHAR2(30),
  headercreationdatetime  DATE,
  senderid                NVARCHAR2(20),
  recipientid             NVARCHAR2(20),
  replenishmentorderid    NVARCHAR2(20),
  shmentordercreationdate DATE,
  pobilltocompany         NVARCHAR2(10),
  billtocompanyname       NVARCHAR2(40),
  soldbyorg               NVARCHAR2(5),
  rmqquotenumber          NVARCHAR2(10),
  rmqponumber             NVARCHAR2(10),
  podoctype               NVARCHAR2(10),
  pochangeindicator       NVARCHAR2(1),
  lastchangedatetime      DATE,
  salesorderreferenceid   NVARCHAR2(10),
  processingtypecode      NVARCHAR2(10),
  completedelivery        NVARCHAR2(10),
  shippmethod             NVARCHAR2(50),
  sofrtcarrier            NVARCHAR2(500),
  splprocind              NVARCHAR2(50),
  shiptoid                NVARCHAR2(20),
  salesordernumber        NVARCHAR2(15),
  headerschedulingstatus  NVARCHAR2(30),
  salesperson             NVARCHAR2(30),
  sodate                  DATE,
  shiptocompany           NVARCHAR2(50),
  shiptocountrycode       NVARCHAR2(50),
  shiptoregioncode        NVARCHAR2(50),
  shiptostreetpostalcode  NVARCHAR2(50),
  shiptocityname          NVARCHAR2(50),
  shiptostreetname        NVARCHAR2(50),
  shiptohouseid           NVARCHAR2(50),
  shiptocontactphone      NVARCHAR2(50),
  shiptodeviatingfullname NVARCHAR2(40),
  shiptoemailuri          NVARCHAR2(20),
  shiptofaxl              NVARCHAR2(25),
  customerponumber        NVARCHAR2(35),
  freightterm             NVARCHAR2(20),
  inco1                   NVARCHAR2(3),
  inco2                   NVARCHAR2(10),
  soldtoid                NVARCHAR2(20),
  soldtocompany           NVARCHAR2(50),
  soldtocountrycode       NVARCHAR2(50),
  soldtoregioncode        NVARCHAR2(50),
  soldtostreetpostalcode  NVARCHAR2(50),
  soldtocityname          NVARCHAR2(50),
  soldtostreetname        NVARCHAR2(50),
  soldtohouseid           NVARCHAR2(50),
  soldtopersonname        NVARCHAR2(50),
  billtoid                NVARCHAR2(100),
  billtocompany           NVARCHAR2(50),
  billtocountrycode       NVARCHAR2(50),
  billtoregioncode        NVARCHAR2(50),
  billtostreetpostalcode  NVARCHAR2(50),
  billtocityname          NVARCHAR2(50),
  billtostreetname        NVARCHAR2(50),
  billtohouseid           NVARCHAR2(50),
  billtopersonname        NVARCHAR2(50),
  buyerpartyid            NVARCHAR2(20),
  buyercountrycode        NVARCHAR2(20),
  buyerregioncode         NVARCHAR2(20),
  buyerstreetpostalcode   NVARCHAR2(20),
  buyercityname           NVARCHAR2(50),
  buyerstreetname         NVARCHAR2(50),
  buyerdeviatingfullname  NVARCHAR2(5),
  buyeremailuri           NVARCHAR2(20),
  sellerpartyid           NVARCHAR2(10),
  eco_fco                 NVARCHAR2(15),
  paymentterm             NVARCHAR2(5),
  actioncode              NVARCHAR2(2),
  item                    NVARCHAR2(5),
  parentitemid            NVARCHAR2(5),
  itemchangeindicator     NVARCHAR2(5),
  blockedindicator        NVARCHAR2(5),
  lineshipmethod          NVARCHAR2(50),
  salesorderlineitem      NVARCHAR2(10),
  soid                    NVARCHAR2(10),
  materialid              NVARCHAR2(40),
  soqty                   NVARCHAR2(5),
  taaindicator            NVARCHAR2(10),
  swtype                  NVARCHAR2(20),
  swversion               NVARCHAR2(30),
  swpartnumber            NVARCHAR2(18),
  jnp_plant               NVARCHAR2(5),
  salesorderhold          NVARCHAR2(25),
  pn                      NVARCHAR2(40),
  custprodid              NVARCHAR2(40),
  productfamily           NVARCHAR2(40),
  packoutlabel            NVARCHAR2(15),
  countryspecificlabel    NVARCHAR2(15),
  cartonlabel1            NVARCHAR2(15),
  cartonlabel2            NVARCHAR2(15),
  customerpn              NVARCHAR2(50),
  materialnumber          NVARCHAR2(40),
  linequantity            NVARCHAR2(20),
  soline                  NVARCHAR2(10),
  rmqcommitdate           NVARCHAR2(50),
  deliverygroup           NVARCHAR2(3),
  classificationcode      NVARCHAR2(5),
  transferlocationname    NVARCHAR2(10),
  currencycode            NVARCHAR2(10),
  netprice                NVARCHAR2(16),
  unitcode                NVARCHAR2(5),
  basequantity            NVARCHAR2(10),
  podeliverydate          DATE,
  changerequesteddate     NVARCHAR2(50),
  custreqshipdate         DATE,
  deliverypriority        NVARCHAR2(2),
  lineschedulingstatus    NVARCHAR2(30),
  quantitycode            NVARCHAR2(15),
  quantity                NVARCHAR2(15),
  componentid             NVARCHAR2(30),
  comcustprodid           NVARCHAR2(50),
  comsalesorderlineitem   NVARCHAR2(10),
  lineuom                 NVARCHAR2(10),
  componentqty            NVARCHAR2(10),
  f_lasteditdt            DATE not null,
  mflag                   VARCHAR2(2),
  createtime              DATE default sysdate,
  edittime                DATE default sysdate,
  shippingnote            CLOB
)
;
create unique index SFCRUNTIME.PK_O_I137 on SFCRUNTIME.O_I137 (ID);

prompt
prompt Creating table O_I137_DETAIL
prompt ============================
prompt
create table SFCRUNTIME.O_I137_DETAIL
(
  id                    VARCHAR2(50),
  f_id                  NUMBER,
  tranid                VARCHAR2(50),
  f_plant               VARCHAR2(20),
  filename              VARCHAR2(70),
  messageid             VARCHAR2(30),
  ponumber              VARCHAR2(20),
  item                  VARCHAR2(5),
  salesorderlineitem    VARCHAR2(10),
  componentid           VARCHAR2(30),
  comcustprodid         VARCHAR2(50),
  comsalesorderlineitem VARCHAR2(10),
  lineuom               VARCHAR2(10),
  componentqty          VARCHAR2(10),
  f_lasteditdt          DATE,
  createtime            DATE default SYSDATE
)
;
create unique index SFCRUNTIME.PK_O_I137_DETAIL on SFCRUNTIME.O_I137_DETAIL (ID);

prompt
prompt Creating table O_I137_DETAIL_H
prompt ==============================
prompt
create table SFCRUNTIME.O_I137_DETAIL_H
(
  id                    VARCHAR2(50),
  f_id                  NUMBER,
  tranid                VARCHAR2(50),
  f_plant               VARCHAR2(20),
  filename              VARCHAR2(70),
  messageid             VARCHAR2(30),
  ponumber              VARCHAR2(20),
  item                  VARCHAR2(5),
  salesorderlineitem    VARCHAR2(10),
  componentid           VARCHAR2(30),
  comcustprodid         VARCHAR2(50),
  comsalesorderlineitem VARCHAR2(10),
  lineuom               VARCHAR2(10),
  componentqty          VARCHAR2(10),
  f_lasteditdt          DATE,
  createtime            DATE default SYSDATE
)
;
create unique index SFCRUNTIME.PK_O_I137_DETAIL_H on SFCRUNTIME.O_I137_DETAIL_H (ID);

prompt
prompt Creating table O_I137_DETAIL_S
prompt ==============================
prompt
create table SFCRUNTIME.O_I137_DETAIL_S
(
  id                    VARCHAR2(50),
  f_id                  NUMBER,
  tranid                VARCHAR2(50),
  f_plant               VARCHAR2(20),
  filename              VARCHAR2(70),
  messageid             VARCHAR2(30),
  ponumber              VARCHAR2(20),
  item                  VARCHAR2(5),
  salesorderlineitem    VARCHAR2(10),
  componentid           VARCHAR2(30),
  comcustprodid         VARCHAR2(50),
  comsalesorderlineitem VARCHAR2(10),
  lineuom               VARCHAR2(10),
  componentqty          VARCHAR2(10),
  f_lasteditdt          DATE,
  createtime            DATE default SYSDATE
)
;

prompt
prompt Creating table O_I137_HEAD
prompt ==========================
prompt
create table SFCRUNTIME.O_I137_HEAD
(
  id                      VARCHAR2(50),
  f_id                    NUMBER,
  tranid                  VARCHAR2(50),
  f_plant                 VARCHAR2(20),
  filename                VARCHAR2(70),
  messageid               VARCHAR2(30),
  headercreationdatetime  DATE,
  senderid                VARCHAR2(20),
  recipientid             VARCHAR2(20),
  ponumber                VARCHAR2(20),
  shmentordercreationdate DATE,
  pobilltocompany         VARCHAR2(10),
  billtocompanyname       VARCHAR2(40),
  soldbyorg               VARCHAR2(5),
  rmqquotenumber          VARCHAR2(10),
  rmqponumber             VARCHAR2(10),
  podoctype               VARCHAR2(10),
  pochangeindicator       VARCHAR2(1),
  lastchangedatetime      DATE,
  vendorid                VARCHAR2(10),
  processingtypecode      VARCHAR2(10),
  completedelivery        VARCHAR2(10),
  shippingnote            VARCHAR2(4000),
  shippmethod             VARCHAR2(50),
  sofrtcarrier            VARCHAR2(500),
  splprocind              VARCHAR2(50),
  shiptoid                VARCHAR2(20),
  salesordernumber        VARCHAR2(15),
  headerschedulingstatus  VARCHAR2(30),
  salesperson             VARCHAR2(30),
  sodate                  DATE,
  shiptocompany           VARCHAR2(50),
  shiptocountrycode       VARCHAR2(50),
  shiptoregioncode        VARCHAR2(50),
  shiptostreetpostalcode  VARCHAR2(50),
  shiptocityname          VARCHAR2(50),
  shiptostreetname        VARCHAR2(50),
  shiptohouseid           VARCHAR2(50),
  shiptocontactphone      VARCHAR2(50),
  shiptodeviatingfullname VARCHAR2(40),
  shiptoemailuri          VARCHAR2(20),
  shiptofaxl              VARCHAR2(25),
  customerponumber        VARCHAR2(35),
  freightterm             VARCHAR2(20),
  inco1                   VARCHAR2(3),
  inco2                   VARCHAR2(10),
  soldtoid                VARCHAR2(20),
  soldtocompany           VARCHAR2(50),
  soldtocountrycode       VARCHAR2(50),
  soldtoregioncode        VARCHAR2(50),
  soldtostreetpostalcode  VARCHAR2(50),
  soldtocityname          VARCHAR2(50),
  soldtostreetname        VARCHAR2(50),
  soldtohouseid           VARCHAR2(50),
  soldtopersonname        VARCHAR2(50),
  billtoid                VARCHAR2(100),
  billtocompany           VARCHAR2(50),
  billtocountrycode       VARCHAR2(50),
  billtoregioncode        VARCHAR2(50),
  billtostreetpostalcode  VARCHAR2(50),
  billtocityname          VARCHAR2(50),
  billtostreetname        VARCHAR2(50),
  billtohouseid           VARCHAR2(50),
  billtopersonname        VARCHAR2(50),
  buyerpartyid            VARCHAR2(20),
  buyercountrycode        VARCHAR2(20),
  buyerregioncode         VARCHAR2(20),
  buyerstreetpostalcode   VARCHAR2(20),
  buyercityname           VARCHAR2(50),
  buyerstreetname         VARCHAR2(50),
  buyerdeviatingfullname  VARCHAR2(5),
  buyeremailuri           VARCHAR2(20),
  sellerpartyid           VARCHAR2(10),
  eco_fco                 VARCHAR2(15),
  paymentterm             VARCHAR2(5),
  f_lasteditdt            DATE,
  mflag                   VARCHAR2(2),
  createtime              DATE default SYSDATE,
  edittime                DATE default SYSDATE,
  version                 VARCHAR2(10)
)
;

prompt
prompt Creating table O_I137_HEAD_H
prompt ============================
prompt
create table SFCRUNTIME.O_I137_HEAD_H
(
  id                      VARCHAR2(50),
  f_id                    NUMBER,
  tranid                  VARCHAR2(50),
  f_plant                 VARCHAR2(20),
  filename                VARCHAR2(70),
  messageid               VARCHAR2(30),
  headercreationdatetime  DATE,
  senderid                VARCHAR2(20),
  recipientid             VARCHAR2(20),
  ponumber                VARCHAR2(20),
  shmentordercreationdate DATE,
  pobilltocompany         VARCHAR2(10),
  billtocompanyname       VARCHAR2(40),
  soldbyorg               VARCHAR2(5),
  rmqquotenumber          VARCHAR2(10),
  rmqponumber             VARCHAR2(10),
  podoctype               VARCHAR2(10),
  pochangeindicator       VARCHAR2(1),
  lastchangedatetime      DATE,
  vendorid                VARCHAR2(10),
  processingtypecode      VARCHAR2(10),
  completedelivery        VARCHAR2(1),
  shippingnote            VARCHAR2(4000),
  shippmethod             VARCHAR2(50),
  sofrtcarrier            VARCHAR2(500),
  splprocind              VARCHAR2(50),
  shiptoid                VARCHAR2(20),
  salesordernumber        VARCHAR2(15),
  headerschedulingstatus  VARCHAR2(30),
  salesperson             VARCHAR2(30),
  sodate                  DATE,
  shiptocompany           VARCHAR2(50),
  shiptocountrycode       VARCHAR2(50),
  shiptoregioncode        VARCHAR2(50),
  shiptostreetpostalcode  VARCHAR2(50),
  shiptocityname          VARCHAR2(50),
  shiptostreetname        VARCHAR2(50),
  shiptohouseid           VARCHAR2(50),
  shiptocontactphone      VARCHAR2(50),
  shiptodeviatingfullname VARCHAR2(40),
  shiptoemailuri          VARCHAR2(20),
  shiptofaxl              VARCHAR2(25),
  customerponumber        VARCHAR2(35),
  freightterm             VARCHAR2(20),
  inco1                   VARCHAR2(3),
  inco2                   VARCHAR2(10),
  soldtoid                VARCHAR2(20),
  soldtocompany           VARCHAR2(50),
  soldtocountrycode       VARCHAR2(50),
  soldtoregioncode        VARCHAR2(50),
  soldtostreetpostalcode  VARCHAR2(50),
  soldtocityname          VARCHAR2(50),
  soldtostreetname        VARCHAR2(50),
  soldtohouseid           VARCHAR2(50),
  soldtopersonname        VARCHAR2(50),
  billtoid                VARCHAR2(100),
  billtocompany           VARCHAR2(50),
  billtocountrycode       VARCHAR2(50),
  billtoregioncode        VARCHAR2(50),
  billtostreetpostalcode  VARCHAR2(50),
  billtocityname          VARCHAR2(50),
  billtostreetname        VARCHAR2(50),
  billtohouseid           VARCHAR2(50),
  billtopersonname        VARCHAR2(50),
  buyerpartyid            VARCHAR2(20),
  buyercountrycode        VARCHAR2(20),
  buyerregioncode         VARCHAR2(20),
  buyerstreetpostalcode   VARCHAR2(20),
  buyercityname           VARCHAR2(50),
  buyerstreetname         VARCHAR2(50),
  buyerdeviatingfullname  VARCHAR2(5),
  buyeremailuri           VARCHAR2(20),
  sellerpartyid           VARCHAR2(10),
  eco_fco                 VARCHAR2(15),
  paymentterm             VARCHAR2(5),
  f_lasteditdt            DATE,
  mflag                   VARCHAR2(2),
  createtime              DATE default SYSDATE,
  edittime                DATE default SYSDATE,
  version                 VARCHAR2(10)
)
;

prompt
prompt Creating table O_I137_HEAD_S
prompt ============================
prompt
create table SFCRUNTIME.O_I137_HEAD_S
(
  id                      VARCHAR2(50),
  f_id                    NUMBER,
  tranid                  VARCHAR2(50),
  f_plant                 VARCHAR2(20),
  filename                VARCHAR2(70),
  messageid               VARCHAR2(30),
  headercreationdatetime  DATE,
  senderid                VARCHAR2(20),
  recipientid             VARCHAR2(20),
  ponumber                VARCHAR2(20),
  shmentordercreationdate DATE,
  pobilltocompany         VARCHAR2(10),
  billtocompanyname       VARCHAR2(40),
  soldbyorg               VARCHAR2(5),
  rmqquotenumber          VARCHAR2(10),
  rmqponumber             VARCHAR2(10),
  podoctype               VARCHAR2(10),
  pochangeindicator       VARCHAR2(1),
  lastchangedatetime      DATE,
  vendorid                VARCHAR2(10),
  processingtypecode      VARCHAR2(10),
  completedelivery        VARCHAR2(1),
  shippingnote            VARCHAR2(4000),
  shippmethod             VARCHAR2(50),
  sofrtcarrier            VARCHAR2(500),
  splprocind              VARCHAR2(50),
  shiptoid                VARCHAR2(20),
  salesordernumber        VARCHAR2(15),
  headerschedulingstatus  VARCHAR2(30),
  salesperson             VARCHAR2(30),
  sodate                  DATE,
  shiptocompany           VARCHAR2(50),
  shiptocountrycode       VARCHAR2(50),
  shiptoregioncode        VARCHAR2(50),
  shiptostreetpostalcode  VARCHAR2(50),
  shiptocityname          VARCHAR2(50),
  shiptostreetname        VARCHAR2(50),
  shiptohouseid           VARCHAR2(50),
  shiptocontactphone      VARCHAR2(50),
  shiptodeviatingfullname VARCHAR2(40),
  shiptoemailuri          VARCHAR2(20),
  shiptofaxl              VARCHAR2(25),
  customerponumber        VARCHAR2(35),
  freightterm             VARCHAR2(20),
  inco1                   VARCHAR2(3),
  inco2                   VARCHAR2(10),
  soldtoid                VARCHAR2(20),
  soldtocompany           VARCHAR2(50),
  soldtocountrycode       VARCHAR2(50),
  soldtoregioncode        VARCHAR2(50),
  soldtostreetpostalcode  VARCHAR2(50),
  soldtocityname          VARCHAR2(50),
  soldtostreetname        VARCHAR2(50),
  soldtohouseid           VARCHAR2(50),
  soldtopersonname        VARCHAR2(50),
  billtoid                VARCHAR2(100),
  billtocompany           VARCHAR2(50),
  billtocountrycode       VARCHAR2(50),
  billtoregioncode        VARCHAR2(50),
  billtostreetpostalcode  VARCHAR2(50),
  billtocityname          VARCHAR2(50),
  billtostreetname        VARCHAR2(50),
  billtohouseid           VARCHAR2(50),
  billtopersonname        VARCHAR2(50),
  buyerpartyid            VARCHAR2(20),
  buyercountrycode        VARCHAR2(20),
  buyerregioncode         VARCHAR2(20),
  buyerstreetpostalcode   VARCHAR2(20),
  buyercityname           VARCHAR2(50),
  buyerstreetname         VARCHAR2(50),
  buyerdeviatingfullname  VARCHAR2(5),
  buyeremailuri           VARCHAR2(20),
  sellerpartyid           VARCHAR2(10),
  eco_fco                 VARCHAR2(15),
  paymentterm             VARCHAR2(5),
  f_lasteditdt            DATE,
  mflag                   VARCHAR2(2),
  createtime              DATE default SYSDATE,
  edittime                DATE default SYSDATE,
  version                 VARCHAR2(10)
)
;
create unique index SFCRUNTIME.PK_O_I137_HEAD_S on SFCRUNTIME.O_I137_HEAD_S (ID);

prompt
prompt Creating table O_I137_ITEM
prompt ==========================
prompt
create table SFCRUNTIME.O_I137_ITEM
(
  id                   VARCHAR2(50),
  f_id                 NUMBER,
  tranid               VARCHAR2(50),
  f_plant              VARCHAR2(20),
  filename             VARCHAR2(70),
  messageid            VARCHAR2(30),
  ponumber             VARCHAR2(20),
  item                 VARCHAR2(5),
  actioncode           VARCHAR2(2),
  parentitemid         VARCHAR2(5),
  itemchangeindicator  VARCHAR2(5),
  lastchangedatetime   DATE,
  blockedindicator     VARCHAR2(5),
  lineshipmethod       VARCHAR2(50),
  salesorderlineitem   VARCHAR2(10),
  soid                 VARCHAR2(50),
  materialid           VARCHAR2(40),
  soqty                VARCHAR2(5),
  taaindicator         VARCHAR2(10),
  swtype               VARCHAR2(20),
  swversion            VARCHAR2(30),
  swpartnumber         VARCHAR2(18),
  jnp_plant            VARCHAR2(5),
  salesorderhold       VARCHAR2(25),
  pn                   VARCHAR2(40),
  custprodid           VARCHAR2(40),
  productfamily        VARCHAR2(40),
  packoutlabel         VARCHAR2(15),
  countryspecificlabel VARCHAR2(15),
  cartonlabel1         VARCHAR2(15),
  cartonlabel2         VARCHAR2(15),
  customerpn           VARCHAR2(50),
  materialnumber       VARCHAR2(40),
  linequantity         VARCHAR2(20),
  soline               VARCHAR2(10),
  rmqcommitdate        VARCHAR2(50),
  deliverygroup        VARCHAR2(3),
  classificationcode   VARCHAR2(5),
  transferlocationname VARCHAR2(10),
  currencycode         VARCHAR2(10),
  netprice             VARCHAR2(16),
  unitcode             VARCHAR2(5),
  basequantity         VARCHAR2(10),
  podeliverydate       DATE,
  changerequesteddate  VARCHAR2(50),
  custreqshipdate      DATE,
  deliverypriority     VARCHAR2(2),
  lineschedulingstatus VARCHAR2(30),
  quantitycode         VARCHAR2(15),
  quantity             VARCHAR2(15),
  f_lasteditdt         DATE,
  createtime           DATE default sysdate,
  version              VARCHAR2(10),
  upoid                VARCHAR2(20),
  mflag                VARCHAR2(20),
  edittime             DATE
)
;
create unique index SFCRUNTIME.PK_O_I137_ITEM on SFCRUNTIME.O_I137_ITEM (ID);

prompt
prompt Creating table O_I137_ITEM_H
prompt ============================
prompt
create table SFCRUNTIME.O_I137_ITEM_H
(
  id                   VARCHAR2(50),
  f_id                 NUMBER,
  tranid               VARCHAR2(50),
  f_plant              VARCHAR2(20),
  filename             VARCHAR2(70),
  messageid            VARCHAR2(30),
  ponumber             VARCHAR2(20),
  item                 VARCHAR2(5),
  actioncode           VARCHAR2(2),
  parentitemid         VARCHAR2(5),
  itemchangeindicator  VARCHAR2(5),
  lastchangedatetime   DATE,
  blockedindicator     VARCHAR2(5),
  lineshipmethod       VARCHAR2(50),
  salesorderlineitem   VARCHAR2(10),
  soid                 VARCHAR2(5),
  materialid           VARCHAR2(40),
  soqty                VARCHAR2(5),
  taaindicator         VARCHAR2(10),
  swtype               VARCHAR2(20),
  swversion            VARCHAR2(30),
  swpartnumber         VARCHAR2(18),
  jnp_plant            VARCHAR2(5),
  salesorderhold       VARCHAR2(25),
  pn                   VARCHAR2(40),
  custprodid           VARCHAR2(40),
  productfamily        VARCHAR2(40),
  packoutlabel         VARCHAR2(15),
  countryspecificlabel VARCHAR2(15),
  cartonlabel1         VARCHAR2(15),
  cartonlabel2         VARCHAR2(15),
  customerpn           VARCHAR2(50),
  materialnumber       VARCHAR2(40),
  linequantity         VARCHAR2(20),
  soline               VARCHAR2(10),
  rmqcommitdate        VARCHAR2(50),
  deliverygroup        VARCHAR2(3),
  classificationcode   VARCHAR2(5),
  transferlocationname VARCHAR2(10),
  currencycode         VARCHAR2(10),
  netprice             VARCHAR2(16),
  unitcode             VARCHAR2(5),
  basequantity         VARCHAR2(10),
  podeliverydate       DATE,
  changerequesteddate  VARCHAR2(50),
  custreqshipdate      DATE,
  deliverypriority     VARCHAR2(2),
  lineschedulingstatus VARCHAR2(30),
  quantitycode         VARCHAR2(15),
  quantity             VARCHAR2(15),
  f_lasteditdt         DATE,
  createtime           DATE default sysdate,
  version              VARCHAR2(10),
  upoid                VARCHAR2(20)
)
;
create unique index SFCRUNTIME.PK_O_I137_ITEM_H on SFCRUNTIME.O_I137_ITEM_H (ID);

prompt
prompt Creating table O_I137_ITEM_S
prompt ============================
prompt
create table SFCRUNTIME.O_I137_ITEM_S
(
  id                   VARCHAR2(50),
  f_id                 NUMBER,
  tranid               VARCHAR2(50),
  f_plant              VARCHAR2(20),
  filename             VARCHAR2(70),
  messageid            VARCHAR2(30),
  ponumber             VARCHAR2(20),
  item                 VARCHAR2(5),
  actioncode           VARCHAR2(2),
  parentitemid         VARCHAR2(5),
  itemchangeindicator  VARCHAR2(5),
  lastchangedatetime   DATE,
  blockedindicator     VARCHAR2(5),
  lineshipmethod       VARCHAR2(50),
  salesorderlineitem   VARCHAR2(10),
  soid                 VARCHAR2(50),
  materialid           VARCHAR2(40),
  soqty                VARCHAR2(5),
  taaindicator         VARCHAR2(10),
  swtype               VARCHAR2(20),
  swversion            VARCHAR2(30),
  swpartnumber         VARCHAR2(18),
  jnp_plant            VARCHAR2(5),
  salesorderhold       VARCHAR2(25),
  pn                   VARCHAR2(40),
  custprodid           VARCHAR2(40),
  productfamily        VARCHAR2(40),
  packoutlabel         VARCHAR2(15),
  countryspecificlabel VARCHAR2(15),
  cartonlabel1         VARCHAR2(15),
  cartonlabel2         VARCHAR2(15),
  customerpn           VARCHAR2(50),
  materialnumber       VARCHAR2(40),
  linequantity         VARCHAR2(20),
  soline               VARCHAR2(10),
  rmqcommitdate        VARCHAR2(50),
  deliverygroup        VARCHAR2(3),
  classificationcode   VARCHAR2(5),
  transferlocationname VARCHAR2(10),
  currencycode         VARCHAR2(10),
  netprice             VARCHAR2(16),
  unitcode             VARCHAR2(5),
  basequantity         VARCHAR2(10),
  podeliverydate       DATE,
  changerequesteddate  VARCHAR2(50),
  custreqshipdate      DATE,
  deliverypriority     VARCHAR2(2),
  lineschedulingstatus VARCHAR2(30),
  quantitycode         VARCHAR2(15),
  quantity             VARCHAR2(15),
  f_lasteditdt         DATE,
  createtime           DATE default sysdate,
  version              VARCHAR2(10),
  upoid                VARCHAR2(20)
)
;

prompt
prompt Creating table O_I138
prompt =====================
prompt
create table SFCRUNTIME.O_I138
(
  id                VARCHAR2(50),
  f_plant           VARCHAR2(50),
  filename          VARCHAR2(60),
  messageid         VARCHAR2(60),
  creationdate      DATE,
  ponumber          VARCHAR2(20) not null,
  pocreationdate    DATE,
  jnp_plant         VARCHAR2(20),
  vendorid          VARCHAR2(20),
  poitemnumber      VARCHAR2(20) not null,
  pn                VARCHAR2(50) not null,
  note              VARCHAR2(20),
  deliverystartdate DATE not null,
  deliveryenddate   DATE not null,
  shippingstartdate DATE not null,
  shippingenddate   DATE not null,
  quantity          VARCHAR2(20) not null,
  tranid            VARCHAR2(50) not null,
  createtime        DATE default sysdate,
  createby          VARCHAR2(50),
  salesordernumber  VARCHAR2(15)
)
;
create unique index SFCRUNTIME.PK_O_I138 on SFCRUNTIME.O_I138 (ID);

prompt
prompt Creating table O_I138_REASON
prompt ============================
prompt
create table SFCRUNTIME.O_I138_REASON
(
  id          VARCHAR2(50) not null,
  reasoncode  VARCHAR2(50),
  description VARCHAR2(500),
  codetype    VARCHAR2(50),
  detail      VARCHAR2(500),
  driver      VARCHAR2(50),
  createtime  DATE
)
;
create unique index SFCRUNTIME.PK_O_I138_REASON on SFCRUNTIME.O_I138_REASON (ID);

prompt
prompt Creating table O_I138_RECORD
prompt ============================
prompt
create table SFCRUNTIME.O_I138_RECORD
(
  id             VARCHAR2(50) not null,
  upoid          VARCHAR2(50),
  i138id         VARCHAR2(50),
  i137id         VARCHAR2(50),
  i138createtime DATE,
  createtime     DATE
)
;
create unique index SFCRUNTIME.PK_O_I138_RECORD on SFCRUNTIME.O_I138_RECORD (ID);

prompt
prompt Creating table O_J_HOLD_C
prompt =========================
prompt
create table SFCRUNTIME.O_J_HOLD_C
(
  id         VARCHAR2(50),
  holdcode   VARCHAR2(50),
  createwo   VARCHAR2(50),
  production VARCHAR2(50),
  preasn     VARCHAR2(50),
  finalasn   VARCHAR2(50),
  i138       VARCHAR2(50),
  createtime DATE default sysdate
)
;
create unique index SFCRUNTIME.PK_O_J_HOLD_C on SFCRUNTIME.O_J_HOLD_C (ID);

prompt
prompt Creating table O_J_WOTYPE
prompt =========================
prompt
create table SFCRUNTIME.O_J_WOTYPE
(
  id         VARCHAR2(50) not null,
  wotype     VARCHAR2(50) not null,
  wopre      VARCHAR2(50),
  createtime DATE
)
;
create unique index SFCRUNTIME.PK_O_J_WOTYPE on SFCRUNTIME.O_J_WOTYPE (ID);

prompt
prompt Creating table O_ORDER_CHANGELOG
prompt ================================
prompt
create table SFCRUNTIME.O_ORDER_CHANGELOG
(
  id             VARCHAR2(50),
  upoid          VARCHAR2(50),
  mainid         VARCHAR2(50),
  changeitemid   VARCHAR2(50),
  sourceitemid   VARCHAR2(50),
  changetype     VARCHAR2(50),
  currentrevsion VARCHAR2(50),
  createtime     DATE default SYSDATE,
  versionlog     VARCHAR2(20)
)
;
create unique index SFCRUNTIME.PK_O_ORDER_CHANGELOG on SFCRUNTIME.O_ORDER_CHANGELOG (ID);

prompt
prompt Creating table O_ORDER_HOLD
prompt ===========================
prompt
create table SFCRUNTIME.O_ORDER_HOLD
(
  id         VARCHAR2(50) not null,
  itemid     VARCHAR2(50) not null,
  upoid      VARCHAR2(50),
  holdflag   VARCHAR2(50) not null,
  holdreason VARCHAR2(50) not null,
  createtime DATE,
  edittime   DATE,
  editby     VARCHAR2(20)
)
;
create unique index SFCRUNTIME.PK_O_ORDER_HOLD on SFCRUNTIME.O_ORDER_HOLD (ID);

prompt
prompt Creating table O_ORDER_MAIN
prompt ===========================
prompt
create table SFCRUNTIME.O_ORDER_MAIN
(
  id             VARCHAR2(50),
  upoid          VARCHAR2(50),
  pono           VARCHAR2(50),
  poline         VARCHAR2(50),
  version        VARCHAR2(5),
  potype         VARCHAR2(50),
  qty            VARCHAR2(50),
  prewo          VARCHAR2(50),
  unitprice      VARCHAR2(50),
  pid            VARCHAR2(50),
  seq            VARCHAR2(8),
  delivery       DATE,
  completed      VARCHAR2(10),
  completime     DATE,
  closed         VARCHAR2(10),
  closetime      DATE,
  cancel         VARCHAR2(10),
  canceltime     DATE,
  customer       VARCHAR2(50),
  createtime     DATE,
  edittime       DATE,
  itemid         VARCHAR2(50),
  originalid     VARCHAR2(50),
  useritemtype   VARCHAR2(50),
  offeringtype   VARCHAR2(50),
  pocreatetime   DATE,
  plant          VARCHAR2(50),
  originalitemid VARCHAR2(50),
  lastchangetime VARCHAR2(50),
  custpid        VARCHAR2(50),
  preasn         VARCHAR2(30),
  preasntime     DATE,
  finalasn       VARCHAR2(30),
  finalasntime   DATE
)
;
create index SFCRUNTIME.IDX_O_ORDER_MAIN on SFCRUNTIME.O_ORDER_MAIN (PONO, POLINE);
create unique index SFCRUNTIME.PK_O_ORDER_MAIN on SFCRUNTIME.O_ORDER_MAIN (ID);

prompt
prompt Creating table O_ORDER_MAIN_H
prompt =============================
prompt
create table SFCRUNTIME.O_ORDER_MAIN_H
(
  id             VARCHAR2(50),
  upoid          VARCHAR2(50),
  pono           VARCHAR2(50),
  poline         VARCHAR2(20),
  version        VARCHAR2(5),
  potype         VARCHAR2(20),
  qty            VARCHAR2(50),
  prewo          VARCHAR2(50),
  unitprice      VARCHAR2(50),
  pid            VARCHAR2(50),
  seq            VARCHAR2(8),
  delivery       DATE,
  completed      VARCHAR2(10),
  completime     DATE,
  closed         VARCHAR2(10),
  closetime      DATE,
  cancel         VARCHAR2(10),
  canceltime     DATE,
  customer       VARCHAR2(50),
  createtime     DATE,
  edittime       DATE,
  itemid         VARCHAR2(50),
  originalid     VARCHAR2(50),
  useritemtype   VARCHAR2(50),
  offeringtype   VARCHAR2(50),
  pocreatetime   DATE,
  plant          VARCHAR2(50),
  originalitemid VARCHAR2(50),
  lastchangetime VARCHAR2(50),
  custpid        VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_O_ORDER_MAIN_H on SFCRUNTIME.O_ORDER_MAIN_H (PONO, POLINE);
create unique index SFCRUNTIME.PK_O_ORDER_MAIN_H on SFCRUNTIME.O_ORDER_MAIN_H (ID);

prompt
prompt Creating table O_ORDER_OPTION
prompt =============================
prompt
create table SFCRUNTIME.O_ORDER_OPTION
(
  id         VARCHAR2(50),
  mainid     VARCHAR2(50),
  partno     VARCHAR2(50),
  qty        NUMBER,
  pitemid    VARCHAR2(50),
  citemid    VARCHAR2(50),
  optiontype VARCHAR2(50),
  createtime DATE,
  foxpn      VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_O_ORDER_OPTION on SFCRUNTIME.O_ORDER_OPTION (MAINID);
create unique index SFCRUNTIME.PK_O_ORDER_OPTION on SFCRUNTIME.O_ORDER_OPTION (ID);

prompt
prompt Creating table O_PO_STATUS
prompt ==========================
prompt
create table SFCRUNTIME.O_PO_STATUS
(
  id         VARCHAR2(50),
  poid       VARCHAR2(50),
  statusid   VARCHAR2(50),
  lev        VARCHAR2(10),
  validflag  VARCHAR2(50),
  createtime DATE,
  createby   VARCHAR2(50),
  edittime   DATE,
  editby     VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_O_PO_STATUS on SFCRUNTIME.O_PO_STATUS (POID);
create unique index SFCRUNTIME.PK_O_PO_STATUS on SFCRUNTIME.O_PO_STATUS (ID);

prompt
prompt Creating table O_PO_STATUS_MAP_J
prompt ================================
prompt
create table SFCRUNTIME.O_PO_STATUS_MAP_J
(
  id          VARCHAR2(50),
  name        VARCHAR2(50),
  description VARCHAR2(50),
  lev         VARCHAR2(10)
)
;
create unique index SFCRUNTIME.PK_O_PO_STATUS_MAP_J on SFCRUNTIME.O_PO_STATUS_MAP_J (ID);

prompt
prompt Creating table O_SKU_CONFIG
prompt ===========================
prompt
create table SFCRUNTIME.O_SKU_CONFIG
(
  id           VARCHAR2(50),
  useritemtype VARCHAR2(50),
  offeringtype VARCHAR2(50),
  bomexplosion VARCHAR2(50),
  producttype  VARCHAR2(50),
  createtime   DATE,
  swotype      VARCHAR2(20),
  nswotype     VARCHAR2(20),
  i054         VARCHAR2(20)
)
;
create unique index SFCRUNTIME.PK_O_SKU_CONFIG on SFCRUNTIME.O_SKU_CONFIG (ID);

prompt
prompt Creating table O_SKU_PACKAGE
prompt ============================
prompt
create table SFCRUNTIME.O_SKU_PACKAGE
(
  id         VARCHAR2(50) not null,
  skuno      VARCHAR2(50) not null,
  scenario   VARCHAR2(50),
  type       VARCHAR2(50),
  usage      VARCHAR2(50),
  fromn      VARCHAR2(50),
  ton        VARCHAR2(50),
  partno     VARCHAR2(50),
  createtime DATE
)
;
create unique index SFCRUNTIME.PK_O_SKU_PACKAGE on SFCRUNTIME.O_SKU_PACKAGE (ID);

prompt
prompt Creating table R_2DXRAY
prompt =======================
prompt
create table SFCRUNTIME.R_2DXRAY
(
  id           VARCHAR2(50),
  sn           VARCHAR2(50),
  skuno        VARCHAR2(50),
  workorderno  VARCHAR2(50),
  bga_location VARCHAR2(20),
  status       VARCHAR2(10),
  misalignment VARCHAR2(10),
  void         VARCHAR2(10),
  isshort      VARCHAR2(10),
  other        VARCHAR2(10),
  remark       VARCHAR2(50),
  remark1      VARCHAR2(50),
  remark2      VARCHAR2(50),
  remark3      VARCHAR2(50),
  customer     VARCHAR2(50),
  linename     VARCHAR2(15),
  edit_emp     VARCHAR2(50),
  edit_time    DATE
)
;
create index SFCRUNTIME.IDX_R_2DXRAY1 on SFCRUNTIME.R_2DXRAY (SKUNO);
create index SFCRUNTIME.IDX_R_2DXRAY2 on SFCRUNTIME.R_2DXRAY (WORKORDERNO);
create index SFCRUNTIME.IDX_R_2DXRAY3 on SFCRUNTIME.R_2DXRAY (SN);
create unique index SFCRUNTIME.PK_R_2DXRAY on SFCRUNTIME.R_2DXRAY (ID);

prompt
prompt Creating table R_AGILE_ATTR
prompt ===========================
prompt
create table SFCRUNTIME.R_AGILE_ATTR
(
  id                 VARCHAR2(50),
  item_number        VARCHAR2(300),
  rev                VARCHAR2(40),
  cs_flag            VARCHAR2(2048),
  hidden_bom         VARCHAR2(2048),
  serialization      VARCHAR2(2048),
  user_item_type     VARCHAR2(2048),
  rohs_compliance    VARCHAR2(2048),
  offering_type      VARCHAR2(2048),
  clei_code          VARCHAR2(150),
  cpr_code           VARCHAR2(150),
  eci_bar_code       VARCHAR2(150),
  kcc_cert_number    VARCHAR2(150),
  regulatory_model   VARCHAR2(150),
  upc_code           VARCHAR2(150),
  serial_number_mask VARCHAR2(4000),
  change_number      VARCHAR2(90),
  effective_date     DATE,
  release_date       DATE,
  created_by         VARCHAR2(50),
  date_created       DATE default sysdate
)
;
create unique index SFCRUNTIME.PK_R_AGILE_ATTR on SFCRUNTIME.R_AGILE_ATTR (ID);

prompt
prompt Creating table R_ARRUBA_SHIPDATE
prompt ================================
prompt
create table SFCRUNTIME.R_ARRUBA_SHIPDATE
(
  id                   VARCHAR2(50),
  dn_no                VARCHAR2(50),
  dn_line              VARCHAR2(50),
  to_no                VARCHAR2(50),
  f_to_trailerno       VARCHAR2(50),
  f_carrier_type       VARCHAR2(50),
  f_carrier_code       VARCHAR2(50),
  f_carrier_tran_type  VARCHAR2(50),
  f_carrier_ref_no     VARCHAR2(50),
  f_carrier_trailer_no VARCHAR2(50),
  f_st_name            VARCHAR2(50),
  f_st_contact         VARCHAR2(50),
  f_st_contact_mail    VARCHAR2(50),
  f_st_customercode    VARCHAR2(50),
  f_st_address         VARCHAR2(50),
  f_st_city            VARCHAR2(50),
  f_st_postcode        VARCHAR2(50),
  f_st_state_code      VARCHAR2(50),
  f_st_country_code    VARCHAR2(50),
  f_po_no              VARCHAR2(50),
  f_po_line_no         VARCHAR2(50),
  f_po_line_qty        VARCHAR2(50),
  f_po_date            VARCHAR2(50),
  create_time          DATE,
  create_emp           VARCHAR2(50),
  edit_time            DATE,
  edit_emp             VARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_R_ARRUBA_SHIPDATE on SFCRUNTIME.R_ARRUBA_SHIPDATE (ID);

prompt
prompt Creating table R_BACKFLUSH_CHECK
prompt ================================
prompt
create table SFCRUNTIME.R_BACKFLUSH_CHECK
(
  workorderno      VARCHAR2(20),
  skuno            VARCHAR2(20),
  sap_station      VARCHAR2(20),
  workorder_qty    NUMBER(10) default 0,
  backflush_qty    NUMBER(10) default 0,
  sfc_qty          NUMBER(10) default 0,
  diff_qty         NUMBER(10) default 0,
  sfc_station      VARCHAR2(20),
  hand_qty         NUMBER(10) default 0,
  last_sfc_qty     NUMBER(10) default 0,
  diff_qty1        NUMBER(10) default 0,
  diff_qty2        NUMBER(10) default 0,
  history_hand_qty NUMBER(10) default 0,
  mrb_qty          NUMBER(10) default 0,
  rec_type         VARCHAR2(10)
)
;

prompt
prompt Creating table R_BACKFLUSH_HISTORY
prompt ==================================
prompt
create table SFCRUNTIME.R_BACKFLUSH_HISTORY
(
  workorderno      VARCHAR2(20),
  skuno            VARCHAR2(20),
  sap_station      VARCHAR2(20),
  workorder_qty    NUMBER(10),
  backflush_qty    NUMBER(10),
  sfc_qty          NUMBER(10),
  diff_qty         NUMBER(10),
  sfc_station      VARCHAR2(20),
  hand_qty         NUMBER(10),
  last_sfc_qty     NUMBER(10),
  diff_qty1        NUMBER(10),
  diff_qty2        NUMBER(10),
  history_hand_qty NUMBER(10),
  mrb_qty          NUMBER(10),
  rec_type         VARCHAR2(50),
  back_date        DATE,
  result           VARCHAR2(1),
  times            NUMBER(10),
  tosap            VARCHAR2(20)
)
;
create index SFCRUNTIME.IX_R_BACKFLUSH_HISTORY0 on SFCRUNTIME.R_BACKFLUSH_HISTORY (WORKORDERNO, SAP_STATION, SFC_STATION);
create index SFCRUNTIME.IX_R_BACKFLUSH_HISTORY1 on SFCRUNTIME.R_BACKFLUSH_HISTORY (WORKORDERNO, TIMES);

prompt
prompt Creating table R_BGA_DETAIL
prompt ===========================
prompt
create table SFCRUNTIME.R_BGA_DETAIL
(
  id           VARCHAR2(50),
  sn           VARCHAR2(50),
  skuno        VARCHAR2(50),
  partno       VARCHAR2(50),
  bga_location VARCHAR2(20),
  station      VARCHAR2(10),
  action       VARCHAR2(15),
  edit_time    DATE,
  location     VARCHAR2(10),
  component_id VARCHAR2(10),
  xrayresult   VARCHAR2(10),
  debugresult  VARCHAR2(10),
  testresult   VARCHAR2(10),
  remark       VARCHAR2(30),
  repair_id    VARCHAR2(10),
  rework_num   VARCHAR2(2) default 1,
  bake_flag    VARCHAR2(1) default 0,
  edit_emp     VARCHAR2(50),
  create_time  DATE,
  bake_start   DATE,
  bake_end     DATE,
  bake_id      VARCHAR2(10),
  bga_type     VARCHAR2(10),
  hours        VARCHAR2(10)
)
;
create index SFCRUNTIME.IDX_R_R_BGA_DETAIL1 on SFCRUNTIME.R_BGA_DETAIL (SKUNO);
create index SFCRUNTIME.IDX_R_R_BGA_DETAIL2 on SFCRUNTIME.R_BGA_DETAIL (PARTNO);
create index SFCRUNTIME.IDX_R_R_BGA_DETAIL3 on SFCRUNTIME.R_BGA_DETAIL (SN);
create unique index SFCRUNTIME.PK_R_BGA_DETAIL on SFCRUNTIME.R_BGA_DETAIL (ID);

prompt
prompt Creating table R_BONEPILE_BASIC
prompt ===============================
prompt
create table SFCRUNTIME.R_BONEPILE_BASIC
(
  id                   VARCHAR2(50),
  tran_type            VARCHAR2(20),
  year                 VARCHAR2(4),
  week_or_month        VARCHAR2(10),
  data_class           VARCHAR2(20),
  brcd                 VARCHAR2(5),
  flh                  VARCHAR2(5),
  normal               VARCHAR2(5),
  rma                  VARCHAR2(5),
  category             VARCHAR2(20),
  status               VARCHAR2(10),
  hardcore             VARCHAR2(10),
  series               VARCHAR2(50),
  sub_series           VARCHAR2(50),
  product_name         VARCHAR2(50),
  bonepile_description VARCHAR2(100),
  aging                VARCHAR2(5),
  avgdays              NUMBER,
  qty                  NUMBER,
  amount               NUMBER,
  lastedit_by          VARCHAR2(50),
  lastedit_date        DATE
)
;
create index SFCRUNTIME.IDX_R_BONEPILE_BASIC on SFCRUNTIME.R_BONEPILE_BASIC (TRAN_TYPE);
create index SFCRUNTIME.IDX_R_BONEPILE_BASIC0 on SFCRUNTIME.R_BONEPILE_BASIC (DATA_CLASS);
create index SFCRUNTIME.IDX_R_BONEPILE_BASIC1 on SFCRUNTIME.R_BONEPILE_BASIC (DATA_CLASS, YEAR, WEEK_OR_MONTH);
create unique index SFCRUNTIME.PK_R_BONEPILE_BASIC on SFCRUNTIME.R_BONEPILE_BASIC (ID);

prompt
prompt Creating table R_BONEPILE_BASIC2
prompt ================================
prompt
create table SFCRUNTIME.R_BONEPILE_BASIC2
(
  id                   VARCHAR2(50),
  tran_type            VARCHAR2(20),
  year                 VARCHAR2(4),
  week_or_month        VARCHAR2(10),
  data_class           VARCHAR2(20),
  brcd                 VARCHAR2(5),
  flh                  VARCHAR2(5),
  normal               VARCHAR2(5),
  rma                  VARCHAR2(5),
  category             VARCHAR2(20),
  status               VARCHAR2(10),
  hardcore             VARCHAR2(10),
  series               VARCHAR2(50),
  sub_series           VARCHAR2(50),
  product_name         VARCHAR2(50),
  bonepile_description VARCHAR2(100),
  a_qty                NUMBER,
  a_amount             NUMBER,
  b_qty                NUMBER,
  b_amount             NUMBER,
  c_qty                NUMBER,
  c_amount             NUMBER,
  d_qty                NUMBER,
  d_amount             NUMBER,
  e_qty                NUMBER,
  e_amount             NUMBER,
  lastedit_by          VARCHAR2(50),
  lastedit_date        DATE
)
;
create index SFCRUNTIME.IDX_R_BONEPILE_BASIC2 on SFCRUNTIME.R_BONEPILE_BASIC2 (TRAN_TYPE);
create index SFCRUNTIME.IDX_R_BONEPILE_BASIC20 on SFCRUNTIME.R_BONEPILE_BASIC2 (DATA_CLASS);
create index SFCRUNTIME.IDX_R_BONEPILE_BASIC21 on SFCRUNTIME.R_BONEPILE_BASIC2 (DATA_CLASS, YEAR, WEEK_OR_MONTH);
create unique index SFCRUNTIME.PK_R_BONEPILE_BASIC2 on SFCRUNTIME.R_BONEPILE_BASIC2 (ID);

prompt
prompt Creating table R_BONEPILE_OVERALL
prompt =================================
prompt
create table SFCRUNTIME.R_BONEPILE_OVERALL
(
  id            VARCHAR2(50),
  tran_type     VARCHAR2(20),
  year          VARCHAR2(4),
  week_or_month VARCHAR2(10),
  data_type     VARCHAR2(20),
  data_class    VARCHAR2(20),
  brcd          VARCHAR2(5),
  flh           VARCHAR2(5),
  new_add_qty   NUMBER,
  closed_qty    NUMBER,
  open_qty      NUMBER,
  open_amount   NUMBER,
  new_a_qty     NUMBER,
  new_b_qty     NUMBER,
  new_c_qty     NUMBER,
  new_d_qty     NUMBER,
  new_e_qty     NUMBER,
  closed_a_qty  NUMBER,
  closed_b_qty  NUMBER,
  closed_c_qty  NUMBER,
  closed_d_qty  NUMBER,
  closed_e_qty  NUMBER,
  open_a_qty    NUMBER,
  open_b_qty    NUMBER,
  open_c_qty    NUMBER,
  open_d_qty    NUMBER,
  open_e_qty    NUMBER,
  open_a_amount NUMBER,
  open_b_amount NUMBER,
  open_c_amount NUMBER,
  open_d_amount NUMBER,
  open_e_amount NUMBER,
  lastedit_by   VARCHAR2(50),
  lastedit_date DATE
)
;
create index SFCRUNTIME.IDX_R_BONEPILE_OVERALL0 on SFCRUNTIME.R_BONEPILE_OVERALL (TRAN_TYPE);
create index SFCRUNTIME.IDX_R_BONEPILE_OVERALL1 on SFCRUNTIME.R_BONEPILE_OVERALL (DATA_CLASS, DATA_TYPE);
create index SFCRUNTIME.IDX_R_BONEPILE_OVERALL2 on SFCRUNTIME.R_BONEPILE_OVERALL (DATA_CLASS, YEAR, WEEK_OR_MONTH);
create unique index SFCRUNTIME.PK_R_BONEPILE_OVERALL on SFCRUNTIME.R_BONEPILE_OVERALL (ID);

prompt
prompt Creating table R_BRCD_EXSN
prompt ==========================
prompt
create table SFCRUNTIME.R_BRCD_EXSN
(
  id         VARCHAR2(50),
  service_no VARCHAR2(50),
  sn         VARCHAR2(50),
  use_flag   VARCHAR2(1),
  edit_time  DATE,
  edit_emp   VARCHAR2(50)
)
;
comment on column SFCRUNTIME.R_BRCD_EXSN.service_no
  is '客戶提供的SERVICE NO';
create unique index SFCRUNTIME.PK_R_BRCD_EXSN on SFCRUNTIME.R_BRCD_EXSN (ID);
grant select, insert, update, delete on SFCRUNTIME.R_BRCD_EXSN to TEST;

prompt
prompt Creating table R_BRCM_ASBUILT_DATA
prompt ==================================
prompt
create table SFCRUNTIME.R_BRCM_ASBUILT_DATA
(
  id                   VARCHAR2(50) not null,
  record_type          VARCHAR2(10),
  record_creation_date VARCHAR2(14),
  cm_code              VARCHAR2(16),
  shipment_number      VARCHAR2(20),
  t_part_num           VARCHAR2(30),
  t_ser_num            VARCHAR2(30),
  p_part_num           VARCHAR2(30),
  p_ser_num            VARCHAR2(30),
  c_part_num           VARCHAR2(30),
  c_ser_num            VARCHAR2(30),
  ab_date              VARCHAR2(14),
  status               VARCHAR2(10),
  reserved1            VARCHAR2(20),
  reserved2            VARCHAR2(20),
  reserved3            VARCHAR2(20),
  reserved4            VARCHAR2(20),
  reserved5            VARCHAR2(20),
  reserved6            VARCHAR2(20),
  reserved7            VARCHAR2(20),
  reserved8            VARCHAR2(20),
  createtime           DATE,
  filename             VARCHAR2(50)
)
;
alter table SFCRUNTIME.R_BRCM_ASBUILT_DATA
  add constraint PK_R_BRCM_AS_DATA primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_BRCM_ASBUILT_DATA to TEST;

prompt
prompt Creating table R_BRCM_DATA_HEAD
prompt ===============================
prompt
create table SFCRUNTIME.R_BRCM_DATA_HEAD
(
  id             VARCHAR2(50) not null,
  dnno           VARCHAR2(15),
  sono           VARCHAR2(10),
  solineno       VARCHAR2(10),
  filename       VARCHAR2(70),
  filetype       VARCHAR2(10),
  createtime     DATE,
  flag           VARCHAR2(2),
  createfiletime DATE,
  sendtime       DATE
)
;
alter table SFCRUNTIME.R_BRCM_DATA_HEAD
  add constraint PK_R_BRCM_DATA_HEAD primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_BRCM_DATA_HEAD to TEST;

prompt
prompt Creating table R_BRCM_ONHB_DATA
prompt ===============================
prompt
create table SFCRUNTIME.R_BRCM_ONHB_DATA
(
  id                     VARCHAR2(50) not null,
  record_type            VARCHAR2(10),
  cm_code                VARCHAR2(40),
  record_creation_date   VARCHAR2(14),
  item                   VARCHAR2(20),
  department             VARCHAR2(20),
  uom                    VARCHAR2(10),
  cut_off_date           VARCHAR2(14),
  quantity               VARCHAR2(10),
  on_hold_flag           VARCHAR2(1),
  comments               VARCHAR2(10),
  reserved_column1       VARCHAR2(240),
  transaction_type       VARCHAR2(4),
  lot                    VARCHAR2(18),
  waybill_airbill_number VARCHAR2(20),
  firm_flag              VARCHAR2(240),
  location               VARCHAR2(240),
  reserved_column2       VARCHAR2(240),
  wafer_part_number      VARCHAR2(20),
  wafer_quantity_gdpw    VARCHAR2(20),
  job_name               VARCHAR2(240),
  yield                  VARCHAR2(10),
  reserved_column3       VARCHAR2(240),
  rma_so_po_number       VARCHAR2(20),
  rma_so_po_line_number  VARCHAR2(10),
  reserved_column4       VARCHAR2(240),
  reserved_column5       NVARCHAR2(10),
  creattime              DATE,
  filename               NVARCHAR2(50)
)
;
alter table SFCRUNTIME.R_BRCM_ONHB_DATA
  add constraint PK_R_BRCM_ONHB_DATA primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_BRCM_ONHB_DATA to TEST;

prompt
prompt Creating table R_BRCM_PICK2SHIP_DATA
prompt ====================================
prompt
create table SFCRUNTIME.R_BRCM_PICK2SHIP_DATA
(
  id                      VARCHAR2(50) not null,
  record_type             VARCHAR2(10),
  cm_code                 VARCHAR2(40),
  delivery_name           VARCHAR2(30),
  sales_order_number      VARCHAR2(40),
  sales_order_line_number VARCHAR2(40),
  ship_method             VARCHAR2(30),
  incoterm                VARCHAR2(20),
  shipment_date           VARCHAR2(20),
  waybill_number          VARCHAR2(30),
  shipping_lpn            VARCHAR2(40),
  box_code                VARCHAR2(30),
  box_weight              VARCHAR2(10),
  item                    VARCHAR2(40),
  lot_number              VARCHAR2(18),
  shipped_quantity        VARCHAR2(10),
  lot_lpn                 VARCHAR2(40),
  serial_number           VARCHAR2(40),
  customer_serial_number  VARCHAR2(40),
  department_code         VARCHAR2(20),
  comment1                VARCHAR2(40),
  reserved_columns1       VARCHAR2(240),
  reserved_columns2       VARCHAR2(240),
  reserved_columns3       VARCHAR2(240),
  reserved_columns4       VARCHAR2(240),
  reserved_columns5       VARCHAR2(240),
  reserved_columns6       VARCHAR2(240),
  reserved_columns7       VARCHAR2(240),
  reserved_columns8       VARCHAR2(240),
  reserved_columns9       VARCHAR2(240),
  reserved_columns10      VARCHAR2(240),
  reserved_columns11      VARCHAR2(240),
  reserved_columns12      VARCHAR2(240),
  reserved_columns13      VARCHAR2(240),
  reserved_columns14      VARCHAR2(240),
  reserved_columns15      VARCHAR2(240),
  reserved_columns16      VARCHAR2(240),
  reserved_columns17      VARCHAR2(240),
  reserved_columns18      VARCHAR2(240),
  reserved_columns19      VARCHAR2(240),
  reserved_columns20      VARCHAR2(240),
  createtime              DATE,
  filename                VARCHAR2(70)
)
;
alter table SFCRUNTIME.R_BRCM_PICK2SHIP_DATA
  add constraint PK_R_BRCM_PICK2SHIP_DATA primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_BRCM_PICK2SHIP_DATA to TEST;

prompt
prompt Creating table R_BRCM_SHIP_DATA
prompt ===============================
prompt
create table SFCRUNTIME.R_BRCM_SHIP_DATA
(
  id                     VARCHAR2(50) not null,
  record_type            VARCHAR2(10),
  cm_code                VARCHAR2(40),
  record_creation_date   VARCHAR2(14),
  transaction_type       VARCHAR2(40),
  shipment_id            VARCHAR2(25),
  item                   VARCHAR2(20),
  uom                    VARCHAR2(10),
  department_code        VARCHAR2(20),
  completion_date        VARCHAR2(14),
  shipment_date          VARCHAR2(14),
  shipment_number        VARCHAR2(25),
  delivery_date          VARCHAR2(14),
  delivery_note_number   VARCHAR2(80),
  ship_to_address_code   VARCHAR2(80),
  ship_method            VARCHAR2(80),
  order_number           VARCHAR2(40),
  line_number            VARCHAR2(40),
  po_number              VARCHAR2(40),
  po_line_number         VARCHAR2(40),
  po_shipment_number     VARCHAR2(40),
  po_release_number      VARCHAR2(20),
  quantity_completed     INTEGER,
  quantity_shipped       INTEGER,
  waybill_number         VARCHAR2(80),
  packing_slip_number    VARCHAR2(25),
  bill_of_lading         VARCHAR2(80),
  lot_number             VARCHAR2(18),
  lot_quantity           INTEGER,
  coo                    VARCHAR2(2),
  lpn                    VARCHAR2(30),
  manufacture_date       VARCHAR2(14),
  cat                    VARCHAR2(40),
  bin                    VARCHAR2(40),
  custom_pn              VARCHAR2(40),
  rev                    VARCHAR2(40),
  vendor                 VARCHAR2(40),
  comment1               VARCHAR2(200),
  test_program_revision  VARCHAR2(40),
  number_of_wipc_records INTEGER,
  reserved_columns       VARCHAR2(240),
  shiptosite             VARCHAR2(40),
  shiptodept             VARCHAR2(20),
  vendor_part_number     VARCHAR2(40),
  vendor_lot_number      VARCHAR2(40),
  nc_reason_code         VARCHAR2(40),
  batch_note             VARCHAR2(40),
  substrate_id           VARCHAR2(40),
  seal_date              DATE,
  good_die_qty           INTEGER,
  die_part_number        VARCHAR2(20),
  date_code              VARCHAR2(4),
  lpn_lot_attributes     VARCHAR2(240),
  outer_lpn_number       VARCHAR2(30),
  outer_lpn_flag         VARCHAR2(1),
  wafer_batch_number     VARCHAR2(18),
  country_of_diffusion   VARCHAR2(2),
  createtime             DATE,
  filename               VARCHAR2(50)
)
;
alter table SFCRUNTIME.R_BRCM_SHIP_DATA
  add constraint PK_R_BRCM_SHIP_DATA primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_BRCM_SHIP_DATA to TEST;

prompt
prompt Creating table R_CARRIER_LINK
prompt =============================
prompt
create table SFCRUNTIME.R_CARRIER_LINK
(
  id        VARCHAR2(50),
  sn        VARCHAR2(50),
  carrierno VARCHAR2(50),
  edittime  DATE,
  editby    VARCHAR2(30)
)
;
create index SFCRUNTIME.IDX_R_CARRIER_LINK0 on SFCRUNTIME.R_CARRIER_LINK (ID, SN, CARRIERNO);
create unique index SFCRUNTIME.PK_R_CARRIER_LINK on SFCRUNTIME.R_CARRIER_LINK (ID);

prompt
prompt Creating table R_CARRIER_SKUNO_LINK
prompt ===================================
prompt
create table SFCRUNTIME.R_CARRIER_SKUNO_LINK
(
  id            VARCHAR2(50),
  carrier_skuno VARCHAR2(50),
  skuno         VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_CARRIER_SKUNO_LINK0 on SFCRUNTIME.R_CARRIER_SKUNO_LINK (ID, CARRIER_SKUNO, SKUNO);
create unique index SFCRUNTIME.PK_R_CARRIER_SKUNO_LINK on SFCRUNTIME.R_CARRIER_SKUNO_LINK (ID);

prompt
prompt Creating table R_CMCHOST
prompt ========================
prompt
create table SFCRUNTIME.R_CMCHOST
(
  id          VARCHAR2(50) not null,
  host_name   VARCHAR2(50),
  ip          VARCHAR2(50),
  description VARCHAR2(50),
  edit_time   DATE,
  edit_emp    VARCHAR2(50)
)
;
alter table SFCRUNTIME.R_CMCHOST
  add constraint PK_R_CMCHOST primary key (ID);

prompt
prompt Creating table R_CONTROLRUN
prompt ===========================
prompt
create table SFCRUNTIME.R_CONTROLRUN
(
  id         VARCHAR2(50),
  type       VARCHAR2(50),
  cus_dev    VARCHAR2(50),
  revision   VARCHAR2(50),
  starttime  DATE,
  endtime    DATE,
  status     VARCHAR2(10),
  reason     VARCHAR2(1000),
  comments   VARCHAR2(1000),
  valid_flag VARCHAR2(10),
  edittime   DATE,
  editby     VARCHAR2(30)
)
;
create index SFCRUNTIME.IDX_R_CONTROLRUN0 on SFCRUNTIME.R_CONTROLRUN (VALID_FLAG);
create unique index SFCRUNTIME.PK_R_CONTROLRUN on SFCRUNTIME.R_CONTROLRUN (ID);
grant select, insert, update, delete on SFCRUNTIME.R_CONTROLRUN to TEST;

prompt
prompt Creating table R_CONTROLRUN_DETAIL
prompt ==================================
prompt
create table SFCRUNTIME.R_CONTROLRUN_DETAIL
(
  id         VARCHAR2(50),
  controlid  VARCHAR2(50),
  data       VARCHAR2(50),
  valid_flag VARCHAR2(50),
  edittime   DATE,
  editby     VARCHAR2(30)
)
;
create index SFCRUNTIME.IDX_R_CONTROLRUN_DETAIL0 on SFCRUNTIME.R_CONTROLRUN_DETAIL (ID, CONTROLID, VALID_FLAG);
create unique index SFCRUNTIME.PK_R_CONTROLRUN_DETAIL on SFCRUNTIME.R_CONTROLRUN_DETAIL (ID);
grant select, insert, update, delete on SFCRUNTIME.R_CONTROLRUN_DETAIL to TEST;

prompt
prompt Creating table R_CONTROLRUN_STATION
prompt ===================================
prompt
create table SFCRUNTIME.R_CONTROLRUN_STATION
(
  id           VARCHAR2(50),
  controlid    VARCHAR2(50),
  station_name VARCHAR2(50),
  valid_flag   VARCHAR2(50),
  edittime     DATE,
  editby       VARCHAR2(30),
  seqno        NUMBER
)
;
create index SFCRUNTIME.IDX_R_CONTROLRUN_STATION0 on SFCRUNTIME.R_CONTROLRUN_STATION (ID, CONTROLID, VALID_FLAG);
create unique index SFCRUNTIME.PK_R_CONTROLRUN_STATION on SFCRUNTIME.R_CONTROLRUN_STATION (ID);
grant select, insert, update, delete on SFCRUNTIME.R_CONTROLRUN_STATION to TEST;

prompt
prompt Creating table R_COO_MAP
prompt ========================
prompt
create table SFCRUNTIME.R_COO_MAP
(
  id         VARCHAR2(50),
  code       VARCHAR2(50),
  country    VARCHAR2(50),
  createtime DATE default SYSDATE
)
;
create unique index SFCRUNTIME.PK_R_COO_MAP on SFCRUNTIME.R_COO_MAP (ID);

prompt
prompt Creating table R_CRITICAL_BONEPILE
prompt ==================================
prompt
create table SFCRUNTIME.R_CRITICAL_BONEPILE
(
  id                     VARCHAR2(50),
  sn                     VARCHAR2(50),
  brc_start_date         DATE,
  flh_start_date         DATE,
  first_load_date        DATE,
  cto_sn_old             VARCHAR2(50),
  vanilla_sn_old         VARCHAR2(50),
  pcba_sn_old            VARCHAR2(50),
  cto_sn_new             VARCHAR2(50),
  vanilla_sn_new         VARCHAR2(50),
  pcba_sn_new            VARCHAR2(50),
  workorderno            VARCHAR2(50),
  skuno                  VARCHAR2(50),
  product_name           VARCHAR2(50),
  sub_series             VARCHAR2(50),
  product_series         VARCHAR2(50),
  fail_station           VARCHAR2(50),
  failure_symptom        VARCHAR2(100),
  bonepile_description   VARCHAR2(300),
  bonepile_station       VARCHAR2(50),
  bonepile_category      VARCHAR2(10),
  owner                  VARCHAR2(50),
  brc_remark             VARCHAR2(50),
  flh_remark             VARCHAR2(50),
  rma_flag               VARCHAR2(1),
  critical_bonepile_flag VARCHAR2(1),
  hardcore_board         VARCHAR2(10),
  price                  NUMBER,
  current_station        VARCHAR2(50),
  current_status         VARCHAR2(50),
  scrapped_flag          VARCHAR2(1),
  shipped_flag           VARCHAR2(1),
  closed_flag            VARCHAR2(1),
  closed_reason          VARCHAR2(100),
  closed_by              VARCHAR2(50),
  closed_date            DATE,
  upload_by              VARCHAR2(50),
  upload_date            DATE,
  uploadlh_by            VARCHAR2(50),
  uploadlh_date          DATE,
  lastedit_by            VARCHAR2(50),
  lastedit_date          DATE
)
;
create index SFCRUNTIME.IDX_R_CRITICAL_BONEPILE on SFCRUNTIME.R_CRITICAL_BONEPILE (SN);
create index SFCRUNTIME.IDX_R_CRITICAL_BONEPILE_S on SFCRUNTIME.R_CRITICAL_BONEPILE (SKUNO);
create unique index SFCRUNTIME.PK_R_CRITICAL_BONEPILE on SFCRUNTIME.R_CRITICAL_BONEPILE (ID);

prompt
prompt Creating table R_CUSTPN_MAP
prompt ===========================
prompt
create table SFCRUNTIME.R_CUSTPN_MAP
(
  id         VARCHAR2(50) not null,
  custpn     VARCHAR2(50) not null,
  partno     VARCHAR2(50),
  descitions VARCHAR2(50),
  rev        VARCHAR2(50),
  plant      VARCHAR2(50),
  createtime DATE
)
;
create unique index SFCRUNTIME.PK_R_CUSTPN_MAP on SFCRUNTIME.R_CUSTPN_MAP (ID);

prompt
prompt Creating table R_CUST_PO
prompt ========================
prompt
create table SFCRUNTIME.R_CUST_PO
(
  id           VARCHAR2(50) not null,
  cust_po_no   VARCHAR2(50),
  c_cust_id    VARCHAR2(50),
  bill_to_code VARCHAR2(50),
  status       VARCHAR2(50),
  po_file_type VARCHAR2(50),
  po_file_desc VARCHAR2(50),
  po_file_id   VARCHAR2(50),
  edit_date    DATE,
  edit_emp     VARCHAR2(50)
)
;
alter table SFCRUNTIME.R_CUST_PO
  add constraint PK_R_CUST_PO primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_CUST_PO to TEST;

prompt
prompt Creating table R_CUST_PO_DETAIL
prompt ===============================
prompt
create table SFCRUNTIME.R_CUST_PO_DETAIL
(
  id               VARCHAR2(50) not null,
  r_cust_po_id     VARCHAR2(50),
  cust_po_no       VARCHAR2(50),
  line_no          VARCHAR2(10),
  cust_skuno       VARCHAR2(50),
  skuno            VARCHAR2(50),
  qty              NUMBER,
  dn_qty           NUMBER,
  shiped_qty       NUMBER,
  enable_date_from DATE,
  enable_date_to   DATE,
  need_by_date     DATE,
  status           VARCHAR2(10),
  ext_key1         VARCHAR2(20),
  ext_value1       VARCHAR2(50),
  ext_key2         VARCHAR2(20),
  ext_value2       VARCHAR2(50),
  ext_key3         VARCHAR2(20),
  ext_value3       VARCHAR2(50),
  edit_date        DATE,
  edit_emp         VARCHAR2(20),
  po_file_type     VARCHAR2(50),
  po_file_desc     VARCHAR2(50),
  po_file_id       VARCHAR2(50)
)
;
create index SFCRUNTIME.KEY1_R_CUST_PO_DETAIL on SFCRUNTIME.R_CUST_PO_DETAIL (R_CUST_PO_ID);
alter table SFCRUNTIME.R_CUST_PO_DETAIL
  add constraint PK_R_CUST_PO_DETAIL primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_CUST_PO_DETAIL to TEST;

prompt
prompt Creating table R_DN_CUST_PO
prompt ===========================
prompt
create table SFCRUNTIME.R_DN_CUST_PO
(
  id              VARCHAR2(50) not null,
  cust_po_no      VARCHAR2(50),
  cust_po_line_no VARCHAR2(10),
  cust_skuno      VARCHAR2(50),
  po_qty          NUMBER not null,
  dn_no           VARCHAR2(50),
  dn_line_no      VARCHAR2(50),
  dn_skuno        VARCHAR2(50),
  dn_qty          NUMBER,
  ext_key1        VARCHAR2(20),
  ext_value1      VARCHAR2(50),
  ext_key2        VARCHAR2(20),
  ext_value2      VARCHAR2(50),
  edit_date       DATE,
  edit_emp        VARCHAR2(20)
)
;
alter table SFCRUNTIME.R_DN_CUST_PO
  add constraint PK_R_DN_CUST_PO primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_DN_CUST_PO to TEST;

prompt
prompt Creating table R_DN_SO
prompt ======================
prompt
create table SFCRUNTIME.R_DN_SO
(
  id          VARCHAR2(50) not null,
  dn_no       VARCHAR2(50),
  dn_line     VARCHAR2(10),
  dn_skuno    VARCHAR2(50),
  dn_qty      NUMBER,
  so_no       VARCHAR2(50),
  so_line_seq VARCHAR2(10),
  so_line_qty NUMBER,
  edit_date   DATE,
  edit_emp    VARCHAR2(20)
)
;
alter table SFCRUNTIME.R_DN_SO
  add constraint PK_R_DN_SO primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_DN_SO to TEST;

prompt
prompt Creating table R_DN_STATUS
prompt ==========================
prompt
create table SFCRUNTIME.R_DN_STATUS
(
  dn_no      VARCHAR2(20),
  dn_line    VARCHAR2(10),
  po_no      VARCHAR2(20),
  po_line    VARCHAR2(10),
  so_no      VARCHAR2(20),
  skuno      VARCHAR2(50),
  qty        NUMBER(10),
  gttype     VARCHAR2(50),
  gt_flag    VARCHAR2(10) default 0,
  gtdate     DATE,
  dn_flag    VARCHAR2(10) default 0,
  dn_plant   VARCHAR2(10),
  createtime DATE,
  edittime   DATE,
  gtevent    VARCHAR2(10),
  id         VARCHAR2(50) not null,
  real_qty   NUMBER
)
;

prompt
prompt Creating table R_FAI
prompt ====================
prompt
create table SFCRUNTIME.R_FAI
(
  id          NVARCHAR2(50),
  faitype     NVARCHAR2(50),
  skuno       NVARCHAR2(50),
  sku_ver     NVARCHAR2(50),
  line        NVARCHAR2(50),
  econo       NVARCHAR2(50),
  workorderno NVARCHAR2(50),
  remark      NVARCHAR2(50),
  status      NVARCHAR2(50),
  producttype NVARCHAR2(50),
  createtime  DATE,
  createby    NVARCHAR2(50),
  edittime    DATE,
  editby      NVARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_FAI_ECO on SFCRUNTIME.R_FAI (ECONO);
create index SFCRUNTIME.IDX_R_FAI_SKU on SFCRUNTIME.R_FAI (SKUNO, SKU_VER);
create index SFCRUNTIME.IDX_R_FAI_STATUS on SFCRUNTIME.R_FAI (STATUS);
create index SFCRUNTIME.IDX_R_FAI_WO on SFCRUNTIME.R_FAI (WORKORDERNO);
create unique index SFCRUNTIME.PK_R_FAI on SFCRUNTIME.R_FAI (ID);
grant select, insert, update, delete on SFCRUNTIME.R_FAI to TEST;

prompt
prompt Creating table R_FAI_DETAIL
prompt ===========================
prompt
create table SFCRUNTIME.R_FAI_DETAIL
(
  id           NVARCHAR2(50),
  sn           NVARCHAR2(50),
  seqno        NVARCHAR2(50),
  faistationid NVARCHAR2(50),
  item         NVARCHAR2(50),
  status       NVARCHAR2(50),
  filename     NVARCHAR2(50),
  faitime      DATE,
  faiby        NVARCHAR2(50),
  createtime   DATE,
  createby     NVARCHAR2(50),
  edittime     DATE,
  editby       NVARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_FAI_DETAIL_SN on SFCRUNTIME.R_FAI_DETAIL (SN, FAISTATIONID, STATUS);
create unique index SFCRUNTIME.PK_R_FAI_DETAIL on SFCRUNTIME.R_FAI_DETAIL (ID);
grant select, insert, update, delete on SFCRUNTIME.R_FAI_DETAIL to TEST;

prompt
prompt Creating table R_FAI_STATION
prompt ============================
prompt
create table SFCRUNTIME.R_FAI_STATION
(
  id           NVARCHAR2(50),
  faiid        NVARCHAR2(50),
  faistation   NVARCHAR2(50),
  createtime   DATE,
  createby     NVARCHAR2(50),
  startstation NVARCHAR2(50),
  checktime    NVARCHAR2(10)
)
;
create index SFCRUNTIME.IDX_R_FAI_STATION on SFCRUNTIME.R_FAI_STATION (FAIID, FAISTATION);
create unique index SFCRUNTIME.PK_R_FAI_STATION on SFCRUNTIME.R_FAI_STATION (ID);
grant select, insert, update, delete on SFCRUNTIME.R_FAI_STATION to TEST;

prompt
prompt Creating table R_FIFO_FGI
prompt =========================
prompt
create table SFCRUNTIME.R_FIFO_FGI
(
  id         VARCHAR2(50) not null,
  palletno   VARCHAR2(50),
  reason     VARCHAR2(150),
  createtime DATE,
  createby   VARCHAR2(10)
)
;
create index SFCRUNTIME.IDX_R_FIFO_FGI0 on SFCRUNTIME.R_FIFO_FGI (PALLETNO);
alter table SFCRUNTIME.R_FIFO_FGI
  add constraint PK_R_FIFO_FGI primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_FIFO_FGI to TEST;

prompt
prompt Creating table R_FILE
prompt =====================
prompt
create table SFCRUNTIME.R_FILE
(
  id        VARCHAR2(50) not null,
  name      VARCHAR2(50),
  filename  VARCHAR2(255),
  md5       VARCHAR2(50),
  usetype   VARCHAR2(10),
  valid     NUMBER,
  state     VARCHAR2(50),
  clob_file CLOB,
  edit_time DATE,
  edit_emp  VARCHAR2(20),
  blob_file BLOB
)
;
create index SFCRUNTIME.IDX_R_FILE_NAME on SFCRUNTIME.R_FILE (NAME);
alter table SFCRUNTIME.R_FILE
  add constraint PK_R_FILE_ID primary key (ID);

prompt
prompt Creating table R_FUNCTION_CONTROL
prompt =================================
prompt
create table SFCRUNTIME.R_FUNCTION_CONTROL
(
  id           VARCHAR2(50),
  functionname VARCHAR2(50),
  category     VARCHAR2(50),
  functiondec  VARCHAR2(300),
  categorydec  VARCHAR2(300),
  value        VARCHAR2(50),
  extval       VARCHAR2(50),
  controlflag  VARCHAR2(10),
  createtime   DATE,
  createby     VARCHAR2(30),
  edittime     DATE,
  editby       VARCHAR2(30),
  functiontype VARCHAR2(10),
  usercontrol  VARCHAR2(10)
)
;
comment on column SFCRUNTIME.R_FUNCTION_CONTROL.controlflag
  is '是否生效(Y/N)';
comment on column SFCRUNTIME.R_FUNCTION_CONTROL.functiontype
  is '是否系統數據(SYSTEM/NOSYSTEM)';
comment on column SFCRUNTIME.R_FUNCTION_CONTROL.usercontrol
  is '是否開放用戶編輯(Y/N)';
create index SFCRUNTIME.IDX_R_FUNCTION_CONTROL0 on SFCRUNTIME.R_FUNCTION_CONTROL (FUNCTIONNAME, CATEGORY, CONTROLFLAG);
create unique index SFCRUNTIME.PK_R_FUNCTION_CONTROL on SFCRUNTIME.R_FUNCTION_CONTROL (ID);

prompt
prompt Creating table R_FUNCTION_CONTROL_EX
prompt ====================================
prompt
create table SFCRUNTIME.R_FUNCTION_CONTROL_EX
(
  id        VARCHAR2(50),
  seq_no    NUMBER,
  name      VARCHAR2(50),
  value     VARCHAR2(200),
  detail_id VARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_R_FUNCTION_CONTROL_EX on SFCRUNTIME.R_FUNCTION_CONTROL_EX (ID, DETAIL_ID);

prompt
prompt Creating table R_GT
prompt ===================
prompt
create table SFCRUNTIME.R_GT
(
  id               VARCHAR2(50),
  workorderno      VARCHAR2(50),
  sap_station_code VARCHAR2(50),
  from_storage     VARCHAR2(50),
  to_storage       VARCHAR2(50),
  qty              NUMBER,
  confirmed_flag   VARCHAR2(1),
  zcpp_flag        VARCHAR2(1),
  sap_flag         VARCHAR2(1),
  skuno            VARCHAR2(50),
  sap_message      VARCHAR2(100),
  edit_emp         VARCHAR2(50),
  edit_time        DATE
)
;
create index SFCRUNTIME.IDX_R_GT0 on SFCRUNTIME.R_GT (WORKORDERNO, SAP_STATION_CODE);
create unique index SFCRUNTIME.PK_R_GT on SFCRUNTIME.R_GT (ID);

prompt
prompt Creating table R_I054
prompt =====================
prompt
create table SFCRUNTIME.R_I054
(
  id                   VARCHAR2(50),
  f_plant              VARCHAR2(5),
  filename             VARCHAR2(60),
  messageid            VARCHAR2(60),
  creationdatetime     DATE,
  createdby            VARCHAR2(20),
  logicalsystem        VARCHAR2(10),
  sender               VARCHAR2(20),
  salesordernumber     VARCHAR2(20),
  salesorderlinenumber VARCHAR2(10),
  parentmodel          VARCHAR2(30) not null,
  pntype               VARCHAR2(20) not null,
  parentsn             VARCHAR2(40) not null,
  childmaterial        VARCHAR2(30),
  sn                   VARCHAR2(30),
  revision             VARCHAR2(20),
  qty                  VARCHAR2(10),
  coo                  VARCHAR2(20),
  cleicode             VARCHAR2(200),
  macaddress           VARCHAR2(200),
  builtsite            VARCHAR2(200),
  builddate            DATE,
  softwareversion      VARCHAR2(20),
  subassemblynumber    VARCHAR2(150),
  subassemblyrevision  VARCHAR2(20),
  ibmserialnumber      VARCHAR2(120),
  future1              VARCHAR2(150),
  future2              VARCHAR2(150),
  future3              VARCHAR2(150),
  future4              VARCHAR2(150),
  future5              VARCHAR2(150),
  tranid               VARCHAR2(50) not null,
  createtime           DATE default SYSDATE
)
;
create unique index SFCRUNTIME.PK_R_I054 on SFCRUNTIME.R_I054 (ID);

prompt
prompt Creating table R_I054_ACK
prompt =========================
prompt
create table SFCRUNTIME.R_I054_ACK
(
  id                   VARCHAR2(50),
  f_id                 VARCHAR2(50),
  filename             VARCHAR2(100),
  messageid            VARCHAR2(50),
  salesordernumber     VARCHAR2(50),
  salesorderlinenumber VARCHAR2(50),
  serialnumber         VARCHAR2(50),
  modelnumber          VARCHAR2(50),
  responsecode         VARCHAR2(50),
  responsemessage      VARCHAR2(100),
  tranid               VARCHAR2(100),
  f_lastedit           DATE,
  createtime           DATE default sysdate
)
;
create unique index SFCRUNTIME.PK_R_I054_ACK on SFCRUNTIME.R_I054_ACK (ID);

prompt
prompt Creating table R_I137
prompt =====================
prompt
create table SFCRUNTIME.R_I137
(
  id                      VARCHAR2(50),
  f_id                    NUMBER,
  tranid                  NVARCHAR2(50),
  f_plant                 NVARCHAR2(20),
  filename                NVARCHAR2(70),
  messageid               NVARCHAR2(30),
  headercreationdatetime  DATE,
  senderid                NVARCHAR2(20),
  recipientid             NVARCHAR2(20),
  replenishmentorderid    NVARCHAR2(20),
  shmentordercreationdate DATE,
  pobilltocompany         NVARCHAR2(10),
  billtocompanyname       NVARCHAR2(40),
  soldbyorg               NVARCHAR2(5),
  rmqquotenumber          NVARCHAR2(10),
  rmqponumber             NVARCHAR2(10),
  podoctype               NVARCHAR2(10),
  pochangeindicator       NVARCHAR2(1),
  lastchangedatetime      DATE,
  salesorderreferenceid   NVARCHAR2(10),
  processingtypecode      NVARCHAR2(10),
  completedelivery        NVARCHAR2(1),
  shippingnote            NVARCHAR2(2000),
  shippmethod             NVARCHAR2(50),
  sofrtcarrier            NVARCHAR2(500),
  splprocind              NVARCHAR2(50),
  shiptoid                NVARCHAR2(20),
  salesordernumber        NVARCHAR2(15),
  headerschedulingstatus  NVARCHAR2(30),
  salesperson             NVARCHAR2(30),
  sodate                  DATE,
  shiptocompany           NVARCHAR2(50),
  shiptocountrycode       NVARCHAR2(50),
  shiptoregioncode        NVARCHAR2(50),
  shiptostreetpostalcode  NVARCHAR2(50),
  shiptocityname          NVARCHAR2(50),
  shiptostreetname        NVARCHAR2(50),
  shiptohouseid           NVARCHAR2(50),
  shiptocontactphone      NVARCHAR2(50),
  shiptodeviatingfullname NVARCHAR2(40),
  shiptoemailuri          NVARCHAR2(20),
  shiptofaxl              NVARCHAR2(25),
  customerponumber        NVARCHAR2(35),
  freightterm             NVARCHAR2(20),
  inco1                   NVARCHAR2(3),
  inco2                   NVARCHAR2(10),
  soldtoid                NVARCHAR2(20),
  soldtocompany           NVARCHAR2(50),
  soldtocountrycode       NVARCHAR2(50),
  soldtoregioncode        NVARCHAR2(50),
  soldtostreetpostalcode  NVARCHAR2(50),
  soldtocityname          NVARCHAR2(50),
  soldtostreetname        NVARCHAR2(50),
  soldtohouseid           NVARCHAR2(50),
  soldtopersonname        NVARCHAR2(50),
  billtoid                NVARCHAR2(100),
  billtocompany           NVARCHAR2(50),
  billtocountrycode       NVARCHAR2(50),
  billtoregioncode        NVARCHAR2(50),
  billtostreetpostalcode  NVARCHAR2(50),
  billtocityname          NVARCHAR2(50),
  billtostreetname        NVARCHAR2(50),
  billtohouseid           NVARCHAR2(50),
  billtopersonname        NVARCHAR2(50),
  buyerpartyid            NVARCHAR2(20),
  buyercountrycode        NVARCHAR2(20),
  buyerregioncode         NVARCHAR2(20),
  buyerstreetpostalcode   NVARCHAR2(20),
  buyercityname           NVARCHAR2(50),
  buyerstreetname         NVARCHAR2(50),
  buyerdeviatingfullname  NVARCHAR2(5),
  buyeremailuri           NVARCHAR2(20),
  sellerpartyid           NVARCHAR2(10),
  eco_fco                 NVARCHAR2(15),
  paymentterm             NVARCHAR2(5),
  actioncode              NVARCHAR2(2),
  item                    NVARCHAR2(5),
  parentitemid            NVARCHAR2(5),
  itemchangeindicator     NVARCHAR2(5),
  blockedindicator        NVARCHAR2(5),
  lineshipmethod          NVARCHAR2(50),
  salesorderlineitem      NVARCHAR2(10),
  soid                    NVARCHAR2(10),
  materialid              NVARCHAR2(40),
  soqty                   NVARCHAR2(5),
  taaindicator            NVARCHAR2(10),
  swtype                  NVARCHAR2(20),
  swversion               NVARCHAR2(30),
  swpartnumber            NVARCHAR2(18),
  jnp_plant               NVARCHAR2(5),
  salesorderhold          NVARCHAR2(25),
  pn                      NVARCHAR2(40),
  custprodid              NVARCHAR2(40),
  productfamily           NVARCHAR2(40),
  packoutlabel            NVARCHAR2(15),
  countryspecificlabel    NVARCHAR2(15),
  cartonlabel1            NVARCHAR2(15),
  cartonlabel2            NVARCHAR2(15),
  customerpn              NVARCHAR2(50),
  materialnumber          NVARCHAR2(40),
  linequantity            NVARCHAR2(20),
  soline                  NVARCHAR2(10),
  rmqcommitdate           NVARCHAR2(50),
  deliverygroup           NVARCHAR2(3),
  classificationcode      NVARCHAR2(5),
  transferlocationname    NVARCHAR2(10),
  currencycode            NVARCHAR2(10),
  netprice                NVARCHAR2(16),
  unitcode                NVARCHAR2(5),
  basequantity            NVARCHAR2(10),
  podeliverydate          DATE,
  changerequesteddate     NVARCHAR2(50),
  custreqshipdate         DATE,
  deliverypriority        NVARCHAR2(2),
  lineschedulingstatus    NVARCHAR2(30),
  quantitycode            NVARCHAR2(15),
  quantity                NVARCHAR2(15),
  componentid             NVARCHAR2(30),
  comcustprodid           NVARCHAR2(50),
  comsalesorderlineitem   NVARCHAR2(10),
  lineuom                 NVARCHAR2(10),
  componentqty            NVARCHAR2(10),
  f_lasteditdt            DATE not null,
  mflag                   VARCHAR2(2),
  createtime              DATE default sysdate,
  edittime                DATE default sysdate
)
;
create unique index SFCRUNTIME.PK_R_I137 on SFCRUNTIME.R_I137 (ID);

prompt
prompt Creating table R_I137_DETAIL
prompt ============================
prompt
create table SFCRUNTIME.R_I137_DETAIL
(
  id                    VARCHAR2(50),
  f_id                  NUMBER not null,
  tranid                VARCHAR2(50),
  f_plant               VARCHAR2(20),
  filename              VARCHAR2(70),
  messageid             VARCHAR2(30),
  ponumber              VARCHAR2(20),
  item                  VARCHAR2(5),
  componentid           VARCHAR2(15),
  comcustprodid         VARCHAR2(50),
  comsalesorderlineitem VARCHAR2(10),
  componentqty          VARCHAR2(10),
  f_lasteditdt          DATE not null,
  createtime            DATE default SYSDATE
)
;
create unique index SFCRUNTIME.PK_R_I137_DETAIL on SFCRUNTIME.R_I137_DETAIL (ID);

prompt
prompt Creating table R_I137_HEAD
prompt ==========================
prompt
create table SFCRUNTIME.R_I137_HEAD
(
  id                        VARCHAR2(50),
  f_id                      NUMBER,
  tranid                    VARCHAR2(50),
  f_plant                   VARCHAR2(20),
  filename                  VARCHAR2(70),
  messageid                 VARCHAR2(30),
  headercreationdate        DATE,
  senderid                  VARCHAR2(20),
  recipientid               VARCHAR2(20),
  ponumber                  VARCHAR2(20),
  shmentordercreationdate   DATE,
  billtocompany             VARCHAR2(10),
  billtocompanyname         VARCHAR2(40),
  soldbyorg                 VARCHAR2(5),
  rmqquotenumber            VARCHAR2(10),
  rmqponumber               VARCHAR2(10),
  podoctype                 VARCHAR2(10),
  pochangeindicator         VARCHAR2(1),
  lastchangedate            DATE,
  vendorid                  VARCHAR2(10),
  processingtypecode        VARCHAR2(10),
  sodelcompl                VARCHAR2(1),
  shippingnote              VARCHAR2(4000),
  shippmethod               VARCHAR2(50),
  sofrtcarrier              VARCHAR2(500),
  splprocind                VARCHAR2(50),
  shiptoid                  VARCHAR2(20),
  salesordernumber          VARCHAR2(15),
  headerschedulingstatus    VARCHAR2(30),
  salesperson               VARCHAR2(30),
  sodate                    DATE,
  shiptoaddress             VARCHAR2(50),
  shiptocountrycode         VARCHAR2(50),
  shiptoregioncode          VARCHAR2(50),
  shiptostreetpostalcode    VARCHAR2(50),
  shiptocityname            VARCHAR2(50),
  shiptostreetname          VARCHAR2(50),
  shiptohouseid             VARCHAR2(50),
  shiptocontactphone        VARCHAR2(50),
  shiptodeviatingfullname   VARCHAR2(40),
  shiptoemailuri            VARCHAR2(20),
  shiptouridefaultindicator VARCHAR2(10),
  shiptofaxl                VARCHAR2(25),
  customerponumber          VARCHAR2(35),
  freightterm               VARCHAR2(20),
  inco1                     VARCHAR2(3),
  inco2                     VARCHAR2(10),
  soldtoid                  VARCHAR2(20),
  soldtoaddress             VARCHAR2(50),
  soldtocountrycode         VARCHAR2(50),
  soldtoregioncode          VARCHAR2(50),
  soldtostreetpostalcode    VARCHAR2(50),
  soldtocityname            VARCHAR2(50),
  soldtostreetname          VARCHAR2(50),
  soldtohouseid             VARCHAR2(50),
  soldtopersonname          VARCHAR2(50),
  billtoid                  VARCHAR2(100),
  billtoaddress             VARCHAR2(50),
  billtocountrycode         VARCHAR2(50),
  billtoregioncode          VARCHAR2(50),
  billtostreetpostalcode    VARCHAR2(50),
  billtocityname            VARCHAR2(50),
  billtostreetname          VARCHAR2(50),
  billtohouseid             VARCHAR2(50),
  billtopersonname          VARCHAR2(50),
  buyerpartyagencyid        VARCHAR2(15),
  buyerpartyid              VARCHAR2(20),
  buyercountrycode          VARCHAR2(20),
  buyerregioncode           VARCHAR2(20),
  buyerstreetpostalcode     VARCHAR2(20),
  buyercityname             VARCHAR2(50),
  buyerstreetname           VARCHAR2(50),
  buyerdeviatingfullname    VARCHAR2(5),
  buyeremailuri             VARCHAR2(20),
  buyeruridefaultindicator  VARCHAR2(20),
  sellerpartyagencyid       VARCHAR2(15),
  sellerpartyid             VARCHAR2(10),
  buyerreferencenote        VARCHAR2(15),
  descri                    VARCHAR2(5),
  f_lasteditdt              DATE,
  mflag                     VARCHAR2(2),
  createtime                DATE default sysdate,
  edittime                  DATE default sysdate,
  version                   VARCHAR2(2)
)
;

prompt
prompt Creating table R_I137_ITEM
prompt ==========================
prompt
create table SFCRUNTIME.R_I137_ITEM
(
  id                       VARCHAR2(50),
  f_id                     NUMBER not null,
  tranid                   VARCHAR2(50),
  f_plant                  VARCHAR2(20),
  filename                 VARCHAR2(70),
  messageid                VARCHAR2(30),
  ponumber                 VARCHAR2(20),
  item                     VARCHAR2(5),
  parentitemid             VARCHAR2(5),
  typecode                 VARCHAR2(5),
  itemchangeindicator      VARCHAR2(5),
  lastchangedate           DATE,
  blockedindicator         VARCHAR2(5),
  lineshipmethod           VARCHAR2(50),
  salesorderlineitem       VARCHAR2(10),
  soid                     VARCHAR2(5),
  materialid               VARCHAR2(40),
  soqty                    VARCHAR2(5),
  taaindicator             VARCHAR2(10),
  swtype                   VARCHAR2(20),
  swversion                VARCHAR2(30),
  swpartnumber             VARCHAR2(18),
  itemagencyid             VARCHAR2(15),
  jnp_plant                VARCHAR2(5),
  salesorderhold           VARCHAR2(25),
  pn                       VARCHAR2(40),
  custprodid               VARCHAR2(40),
  productfamily            VARCHAR2(40),
  packoutlabel             VARCHAR2(15),
  countryspecificlabel     VARCHAR2(15),
  cartonlabel1             VARCHAR2(15),
  cartonlabel2             VARCHAR2(15),
  customerpn               VARCHAR2(50),
  materialnumber           VARCHAR2(40),
  linequantity             VARCHAR2(20),
  soline                   VARCHAR2(10),
  rmqcommitdate            VARCHAR2(50),
  deliverygroup            VARCHAR2(3),
  classificationcode       VARCHAR2(5),
  transferlocationname     VARCHAR2(10),
  netprice                 VARCHAR2(16),
  unitcode                 VARCHAR2(5),
  basequantity             VARCHAR2(10),
  deliverystartdate        DATE,
  changerequesteddate      VARCHAR2(50),
  custreqshipdate          DATE,
  deliverypriority         VARCHAR2(2),
  deliveryschedulingstatus VARCHAR2(30),
  schedulingstatus         VARCHAR2(5),
  quantitycode             VARCHAR2(15),
  quantity                 VARCHAR2(15),
  f_lasteditdt             DATE not null,
  createtime               DATE default sysdate
)
;
create unique index SFCRUNTIME.PK_R_I137_ITEM on SFCRUNTIME.R_I137_ITEM (ID);

prompt
prompt Creating table R_I138
prompt =====================
prompt
create table SFCRUNTIME.R_I138
(
  id                VARCHAR2(50),
  f_plant           VARCHAR2(5),
  filename          VARCHAR2(60),
  messageid         VARCHAR2(60),
  creationdate      DATE,
  ponumber          VARCHAR2(20) not null,
  pocreationdate    DATE,
  jnp_plant         VARCHAR2(10),
  vendorid          VARCHAR2(10),
  poitemnumber      VARCHAR2(10) not null,
  pn                VARCHAR2(50) not null,
  note              VARCHAR2(20),
  deliverystartdate DATE not null,
  deliveryenddate   DATE not null,
  shippingstartdate DATE not null,
  shippingenddate   DATE not null,
  quantity          VARCHAR2(10) not null,
  tranid            VARCHAR2(50) not null,
  createtime        DATE default sysdate
)
;
create unique index SFCRUNTIME.PK_R_I138 on SFCRUNTIME.R_I138 (ID);

prompt
prompt Creating table R_I139
prompt =====================
prompt
create table SFCRUNTIME.R_I139
(
  id                   VARCHAR2(50),
  f_id                 NUMBER,
  f_plant              VARCHAR2(5),
  filename             VARCHAR2(60),
  messageid            VARCHAR2(60),
  creationdate         DATE,
  recipientid          VARCHAR2(20) not null,
  deliverycode         VARCHAR2(5),
  asnnumber            VARCHAR2(30) not null,
  asncreationtime      DATE not null,
  vendorid             VARCHAR2(20) not null,
  shiptoid             VARCHAR2(20) not null,
  grossweight          VARCHAR2(10) not null,
  grosscode            VARCHAR2(10),
  netweight            VARCHAR2(10) not null,
  netcode              VARCHAR2(10),
  volumeweight         VARCHAR2(10),
  volumecode           VARCHAR2(10),
  arrivaldate          DATE,
  issuedate            DATE,
  trackingid           VARCHAR2(40),
  waybillid            VARCHAR2(10),
  freightinvoiceid     VARCHAR2(10) not null,
  classificationcode   VARCHAR2(10),
  transferlocationname VARCHAR2(10),
  line                 VARCHAR2(10) not null,
  ponumber             VARCHAR2(20) not null,
  item                 VARCHAR2(10) not null,
  pn                   VARCHAR2(20) not null,
  specialrequest       VARCHAR2(50),
  coo                  VARCHAR2(20),
  serialid             VARCHAR2(20),
  shippedquantity      VARCHAR2(10) not null,
  quantity             VARCHAR2(10) not null,
  tranid               VARCHAR2(50) not null,
  createtime           DATE default SYSDATE
)
;
create unique index SFCRUNTIME.PK_R_I139 on SFCRUNTIME.R_I139 (ID);

prompt
prompt Creating table R_I139_TEMP
prompt ==========================
prompt
create table SFCRUNTIME.R_I139_TEMP
(
  id                   VARCHAR2(50),
  f_id                 NUMBER,
  f_plant              VARCHAR2(5),
  filename             VARCHAR2(60),
  messageid            VARCHAR2(60),
  creationdate         DATE,
  recipientid          VARCHAR2(20) not null,
  deliverycode         VARCHAR2(5),
  asnnumber            VARCHAR2(30) not null,
  asncreationtime      DATE not null,
  vendorid             VARCHAR2(20) not null,
  shiptoid             VARCHAR2(20) not null,
  grossweight          VARCHAR2(10) not null,
  grosscode            VARCHAR2(10),
  netweight            VARCHAR2(10) not null,
  netcode              VARCHAR2(10),
  volumeweight         VARCHAR2(10),
  volumecode           VARCHAR2(10),
  arrivaldate          DATE,
  issuedate            DATE,
  trackingid           VARCHAR2(40),
  waybillid            VARCHAR2(10),
  freightinvoiceid     VARCHAR2(10) not null,
  classificationcode   VARCHAR2(10),
  transferlocationname VARCHAR2(10),
  line                 VARCHAR2(10) not null,
  ponumber             VARCHAR2(20) not null,
  item                 VARCHAR2(10) not null,
  pn                   VARCHAR2(20) not null,
  specialrequest       VARCHAR2(50),
  coo                  VARCHAR2(20),
  serialid             VARCHAR2(20) not null,
  shippedquantity      VARCHAR2(10) not null,
  quantity             VARCHAR2(10) not null,
  tranid               VARCHAR2(50) not null,
  createtime           DATE default SYSDATE
)
;
create unique index SFCRUNTIME.PK_R_I139_TEMP on SFCRUNTIME.R_I139_TEMP (ID);

prompt
prompt Creating table R_I140
prompt =====================
prompt
create table SFCRUNTIME.R_I140
(
  id               VARCHAR2(50),
  f_id             VARCHAR2(50),
  tranid           VARCHAR2(50),
  f_plant          VARCHAR2(5),
  filename         VARCHAR2(100),
  messageid        VARCHAR2(50),
  creationdatetime DATE,
  vendorcode       VARCHAR2(50),
  pn               VARCHAR2(30),
  startdatetime    DATE,
  enddatetime      DATE,
  quantity         VARCHAR2(15),
  f_lasteditdt     DATE,
  mflag            VARCHAR2(2),
  createtime       DATE
)
;

prompt
prompt Creating table R_I140_MAIN
prompt ==========================
prompt
create table SFCRUNTIME.R_I140_MAIN
(
  id         VARCHAR2(50) not null,
  tranid     VARCHAR2(50),
  weekno     VARCHAR2(50),
  yearno     VARCHAR2(50),
  complete   VARCHAR2(50),
  partnum    VARCHAR2(50),
  itemnum    VARCHAR2(50),
  createtime DATE,
  edittime   DATE,
  plant      VARCHAR2(20)
)
;
alter table SFCRUNTIME.R_I140_MAIN
  add constraint R_I140_MAIN_PK primary key (ID);

prompt
prompt Creating table R_I140_MAIN_D
prompt ============================
prompt
create table SFCRUNTIME.R_I140_MAIN_D
(
  id         VARCHAR2(50),
  tranid     VARCHAR2(50),
  commitday  VARCHAR2(50),
  complete   VARCHAR2(50),
  commitid   VARCHAR2(50),
  createtime DATE,
  edittime   DATE,
  editemp    VARCHAR2(50),
  vendorcode VARCHAR2(50),
  commitdate VARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_R_I140_MAIN_D on SFCRUNTIME.R_I140_MAIN_D (ID);

prompt
prompt Creating table R_I244
prompt =====================
prompt
create table SFCRUNTIME.R_I244
(
  id                   VARCHAR2(50) not null,
  f_id                 NUMBER,
  f_plant              VARCHAR2(5),
  filename             VARCHAR2(60),
  messageid            VARCHAR2(60),
  creationdatetime     DATE,
  createdby            VARCHAR2(20),
  logicalsystem        VARCHAR2(10),
  sender               VARCHAR2(20),
  salesordernumber     VARCHAR2(20),
  salesorderlinenumber VARCHAR2(10),
  parentmodel          VARCHAR2(30) not null,
  pntype               VARCHAR2(20) not null,
  parentsn             VARCHAR2(40) not null,
  childmaterial        VARCHAR2(30),
  sn                   VARCHAR2(30),
  revision             VARCHAR2(20),
  qty                  VARCHAR2(10),
  coo                  VARCHAR2(20),
  cleicode             VARCHAR2(200),
  macaddress           VARCHAR2(200),
  builtsite            VARCHAR2(200),
  builddate            DATE,
  softwareversion      VARCHAR2(20),
  subassemblynumber    VARCHAR2(150),
  subassemblyrevision  VARCHAR2(20),
  ibmserialnumber      VARCHAR2(120),
  future1              VARCHAR2(150),
  future2              VARCHAR2(150),
  future3              VARCHAR2(150),
  future4              VARCHAR2(150),
  future5              VARCHAR2(150),
  tranid               VARCHAR2(50) not null,
  f_lasteditdt         DATE not null,
  createtime           DATE,
  mflag                VARCHAR2(20)
)
;
create unique index SFCRUNTIME.PK_R_I244 on SFCRUNTIME.R_I244 (ID);

prompt
prompt Creating table R_I282
prompt =====================
prompt
create table SFCRUNTIME.R_I282
(
  id                  VARCHAR2(50) not null,
  f_id                NUMBER not null,
  tranid              VARCHAR2(50),
  f_plant             VARCHAR2(50),
  filename            VARCHAR2(100),
  messageid           VARCHAR2(60),
  creationdatetime    DATE,
  asnnumber           VARCHAR2(50),
  vendorid            VARCHAR2(50),
  deliverynumber      VARCHAR2(50),
  shiptopartyname     VARCHAR2(50),
  shiptopartyaddress2 VARCHAR2(50),
  shiptopartycity     VARCHAR2(50),
  shiptopartycountry  VARCHAR2(50),
  shiptopartyzipcode  VARCHAR2(50),
  itemid              VARCHAR2(50),
  productcode         VARCHAR2(50),
  errorcode           VARCHAR2(50),
  errordescription    VARCHAR2(200),
  f_lasteditdt        DATE not null,
  createtime          DATE,
  mflag               VARCHAR2(20)
)
;
create unique index SFCRUNTIME.PK_R_I282 on SFCRUNTIME.R_I282 (ID);

prompt
prompt Creating table R_I285
prompt =====================
prompt
create table SFCRUNTIME.R_I285
(
  id           VARCHAR2(50),
  f_plant      VARCHAR2(5),
  filename     VARCHAR2(50),
  messageid    VARCHAR2(60),
  creationdate DATE,
  senderid     VARCHAR2(10),
  pn           VARCHAR2(20),
  quantity     VARCHAR2(10),
  startdate    DATE,
  enddate      DATE,
  tranid       VARCHAR2(50) not null,
  f_lasteditdt DATE not null,
  createtime   DATE default SYSDATE
)
;
create unique index SFCRUNTIME.PK_R_I285 on SFCRUNTIME.R_I285 (ID);

prompt
prompt Creating table R_INPUT_ACTION
prompt =============================
prompt
create table SFCRUNTIME.R_INPUT_ACTION
(
  id                  VARCHAR2(50),
  input_id            VARCHAR2(50),
  c_station_action_id VARCHAR2(50),
  seq_no              NUMBER(38),
  config_type         VARCHAR2(20),
  config_value        VARCHAR2(50),
  add_flag            NUMBER(38),
  edit_time           DATE,
  edit_emp            VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_INPUT_ACTION0 on SFCRUNTIME.R_INPUT_ACTION (INPUT_ID);
create index SFCRUNTIME.IDX_R_INPUT_ACTION1 on SFCRUNTIME.R_INPUT_ACTION (CONFIG_TYPE, CONFIG_VALUE);
create unique index SFCRUNTIME.PK_R_INPUT_ACTION on SFCRUNTIME.R_INPUT_ACTION (ID);

prompt
prompt Creating table R_IO_HEAD
prompt ========================
prompt
create table SFCRUNTIME.R_IO_HEAD
(
  id        VARCHAR2(50),
  sn        VARCHAR2(50),
  iotype    VARCHAR2(50),
  iostatus  VARCHAR2(50),
  data1     VARCHAR2(50),
  data2     VARCHAR2(50),
  data3     VARCHAR2(50),
  data4     VARCHAR2(50),
  data5     VARCHAR2(50),
  data6     VARCHAR2(50),
  data7     VARCHAR2(50),
  edit_emp  VARCHAR2(50),
  edit_time DATE
)
;
create index SFCRUNTIME.INDEX_R_ID_HEAD_SN on SFCRUNTIME.R_IO_HEAD (SN);
create unique index SFCRUNTIME.PK_R_IO_HEAD_ID on SFCRUNTIME.R_IO_HEAD (ID);
grant select, insert, update, delete on SFCRUNTIME.R_IO_HEAD to TEST;

prompt
prompt Creating table R_JSON
prompt =====================
prompt
create table SFCRUNTIME.R_JSON
(
  id        VARCHAR2(50) not null,
  name      VARCHAR2(150),
  type      VARCHAR2(50),
  blobdata  BLOB,
  edit_emp  VARCHAR2(50),
  edit_time DATE,
  index1    VARCHAR2(50),
  index2    VARCHAR2(50),
  index3    VARCHAR2(50),
  index4    VARCHAR2(50)
)
;
create index SFCUSER.I1_R_JSON on SFCRUNTIME.R_JSON (INDEX1);
create index SFCUSER.I2_R_JSON on SFCRUNTIME.R_JSON (INDEX2);
alter table SFCRUNTIME.R_JSON
  add constraint PK_R_JSON primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_JSON to TEST;

prompt
prompt Creating table R_JUNIPER_SW
prompt ===========================
prompt
create table SFCRUNTIME.R_JUNIPER_SW
(
  id         VARCHAR2(50),
  parentpn   VARCHAR2(50),
  modelpn    VARCHAR2(50),
  swtype     VARCHAR2(50),
  swversion  VARCHAR2(50),
  swpn       VARCHAR2(50),
  createtime DATE default SYSDATE
)
;
create unique index SFCRUNTIME.PK_R_JUNIPER_SW on SFCRUNTIME.R_JUNIPER_SW (ID);

prompt
prompt Creating table R_LABEL
prompt ======================
prompt
create table SFCRUNTIME.R_LABEL
(
  id          VARCHAR2(50) not null,
  r_file_name VARCHAR2(50),
  labelname   VARCHAR2(50),
  printtype   VARCHAR2(50),
  edit_time   DATE,
  edit_emp    VARCHAR2(20),
  arrylength  NUMBER default 0
)
;
alter table SFCRUNTIME.R_LABEL
  add constraint PK_R_LABEL_ID primary key (ID);

prompt
prompt Creating table R_LINK_CONTROL
prompt =============================
prompt
create table SFCRUNTIME.R_LINK_CONTROL
(
  id           VARCHAR2(50) not null,
  control_type VARCHAR2(50),
  main_item    VARCHAR2(50),
  sub_item     VARCHAR2(50),
  edittime     DATE,
  editby       VARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_R_LINK_CONTROL_ID on SFCRUNTIME.R_LINK_CONTROL (ID);
grant select, insert, update, delete on SFCRUNTIME.R_LINK_CONTROL to TEST;

prompt
prompt Creating table R_LOG
prompt ====================
prompt
create table SFCRUNTIME.R_LOG
(
  id            VARCHAR2(50),
  class_name    VARCHAR2(50),
  function_name VARCHAR2(100),
  input         VARCHAR2(100),
  output        VARCHAR2(100),
  ip            VARCHAR2(128),
  edit_time     DATE,
  edit_emp      VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_LOG_CN on SFCRUNTIME.R_LOG (CLASS_NAME);
create index SFCRUNTIME.IDX_R_LOG_ET on SFCRUNTIME.R_LOG (EDIT_TIME);
create index SFCRUNTIME.IDX_R_LOG_FN on SFCRUNTIME.R_LOG (FUNCTION_NAME);
create unique index SFCRUNTIME.PK_R_LOG_ID on SFCRUNTIME.R_LOG (ID);

prompt
prompt Creating table R_LOG_EX
prompt =======================
prompt
create table SFCRUNTIME.R_LOG_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCRUNTIME.PK_R_LOG_EX on SFCRUNTIME.R_LOG_EX (ID, SEQ_NO);

prompt
prompt Creating table R_LOT_CARTON
prompt ===========================
prompt
create table SFCRUNTIME.R_LOT_CARTON
(
  id        VARCHAR2(50),
  lot_id    VARCHAR2(50),
  tray_no   VARCHAR2(50),
  carton_no VARCHAR2(50),
  pallet_no VARCHAR2(50),
  edit_emp  VARCHAR2(50),
  edit_time DATE
)
;
create index SFCRUNTIME.IDX_R_LOT_CARTON0 on SFCRUNTIME.R_LOT_CARTON (LOT_ID);
create unique index SFCRUNTIME.PK_R_LOT_CARTON on SFCRUNTIME.R_LOT_CARTON (ID);

prompt
prompt Creating table R_LOT_DETAIL
prompt ===========================
prompt
create table SFCRUNTIME.R_LOT_DETAIL
(
  id            VARCHAR2(50),
  lot_id        VARCHAR2(50),
  sn            VARCHAR2(50),
  workorderno   VARCHAR2(50),
  create_date   DATE,
  sampling      VARCHAR2(1),
  status        VARCHAR2(1),
  fail_code     VARCHAR2(50),
  fail_location VARCHAR2(100),
  description   VARCHAR2(100),
  carton_no     VARCHAR2(50),
  pallet_no     VARCHAR2(50),
  edit_emp      VARCHAR2(50),
  edit_time     DATE,
  seq_no        NUMBER
)
;
comment on column SFCRUNTIME.R_LOT_DETAIL.seq_no
  is '排序';
create index SFCRUNTIME.IDX_R_LOT_DETAIL0 on SFCRUNTIME.R_LOT_DETAIL (LOT_ID, SN, WORKORDERNO);
create index SFCRUNTIME.IDX_R_LOT_DETAIL_SN on SFCRUNTIME.R_LOT_DETAIL (SN);
create unique index SFCRUNTIME.PK_R_LOT_DETAIL on SFCRUNTIME.R_LOT_DETAIL (ID);

prompt
prompt Creating table R_LOT_PACK
prompt =========================
prompt
create table SFCRUNTIME.R_LOT_PACK
(
  id        VARCHAR2(50) not null,
  lotno     VARCHAR2(50),
  packno    VARCHAR2(50),
  edit_time DATE,
  edit_emp  VARCHAR2(20)
)
;
create index SFCRUNTIME.IDX_R_LOT_PACK_LOTNO on SFCRUNTIME.R_LOT_PACK (LOTNO);
alter table SFCRUNTIME.R_LOT_PACK
  add constraint PK_R_LOT_PACK_ID primary key (ID);

prompt
prompt Creating table R_LOT_STATUS
prompt ===========================
prompt
create table SFCRUNTIME.R_LOT_STATUS
(
  id              VARCHAR2(50),
  lot_no          VARCHAR2(50),
  skuno           VARCHAR2(50),
  aql_type        VARCHAR2(50),
  lot_qty         NUMBER,
  reject_qty      NUMBER,
  sample_qty      NUMBER,
  pass_qty        NUMBER,
  fail_qty        NUMBER,
  closed_flag     VARCHAR2(1),
  lot_status_flag VARCHAR2(1),
  sample_station  VARCHAR2(50),
  line            VARCHAR2(50),
  edit_emp        VARCHAR2(50),
  edit_time       DATE,
  aql_level       VARCHAR2(10)
)
;
create index SFCRUNTIME.IDX_R_LOT_STATUS0 on SFCRUNTIME.R_LOT_STATUS (LOT_NO);
create index SFCRUNTIME.IDX_R_LOT_STATUS1 on SFCRUNTIME.R_LOT_STATUS (SKUNO);
create unique index SFCRUNTIME.PK_R_LOT_STATUS on SFCRUNTIME.R_LOT_STATUS (ID);
create unique index SFCRUNTIME.UNQ_R_LOT_STATUS on SFCRUNTIME.R_LOT_STATUS (LOT_NO, SKUNO);

prompt
prompt Creating table R_MAILFUNC_USER
prompt ==============================
prompt
create table SFCRUNTIME.R_MAILFUNC_USER
(
  id           VARCHAR2(50),
  functionname VARCHAR2(50),
  empno        VARCHAR2(50),
  groupname    VARCHAR2(50),
  utype        VARCHAR2(50),
  enableflag   VARCHAR2(10),
  createtime   DATE default sysdate
)
;
create unique index SFCRUNTIME.PK_R_MAILFUNC_USER on SFCRUNTIME.R_MAILFUNC_USER (ID);

prompt
prompt Creating table R_MAIL_DATA
prompt ==========================
prompt
create table SFCRUNTIME.R_MAIL_DATA
(
  id           VARCHAR2(50),
  functionname VARCHAR2(50),
  title        VARCHAR2(1000),
  contents     NVARCHAR2(2000),
  mailto       VARCHAR2(1000),
  attrfileid   VARCHAR2(50),
  sendtime     DATE,
  mflag        VARCHAR2(10),
  createtime   DATE default sysdate
)
;
create unique index SFCRUNTIME.PK_R_MAIL_DATA on SFCRUNTIME.R_MAIL_DATA (ID);

prompt
prompt Creating table R_MATERIAL_STAGE_CONFIRM
prompt =======================================
prompt
create table SFCRUNTIME.R_MATERIAL_STAGE_CONFIRM
(
  id          NVARCHAR2(50),
  skuno       NVARCHAR2(50),
  version     NVARCHAR2(50),
  workorderno NVARCHAR2(50),
  station     NVARCHAR2(50),
  route       NVARCHAR2(50),
  filename    NVARCHAR2(50),
  description NVARCHAR2(50),
  totalnum    NVARCHAR2(50),
  usednum     NVARCHAR2(50),
  remainnum   NVARCHAR2(50),
  uploadby    NVARCHAR2(50),
  uploadtime  DATE,
  editby      NVARCHAR2(50),
  edittime    DATE,
  flag        NVARCHAR2(10),
  reason      NVARCHAR2(50),
  signby      NVARCHAR2(50),
  signtime    DATE
)
;
create index SFCRUNTIME.IDX_R_MATERIAL_S_C_ALL on SFCRUNTIME.R_MATERIAL_STAGE_CONFIRM (SKUNO, VERSION, STATION, FLAG);
create unique index SFCRUNTIME.PK_R_MATERIAL_S_C on SFCRUNTIME.R_MATERIAL_STAGE_CONFIRM (ID);
grant select, insert, update, delete on SFCRUNTIME.R_MATERIAL_STAGE_CONFIRM to TEST;

prompt
prompt Creating table R_MATERIAL_STAGE_DETAIL
prompt ======================================
prompt
create table SFCRUNTIME.R_MATERIAL_STAGE_DETAIL
(
  id         NVARCHAR2(50),
  skuno      NVARCHAR2(50),
  version    NVARCHAR2(50),
  eventpoint NVARCHAR2(50),
  custpartno NVARCHAR2(50),
  custpndesc NVARCHAR2(200),
  qty        NUMBER,
  soppage    NVARCHAR2(50),
  sopeventpn NVARCHAR2(50),
  note       NVARCHAR2(100),
  totalqty   NVARCHAR2(50),
  editby     NVARCHAR2(50),
  edittime   DATE,
  vaild      NVARCHAR2(10)
)
;
create index SFCRUNTIME.IDX_R_M_S_DETAIL_ALL on SFCRUNTIME.R_MATERIAL_STAGE_DETAIL (SKUNO, VERSION, EVENTPOINT, CUSTPARTNO);
create unique index SFCRUNTIME.PK_R_MATERIAL_STAGE_DETAIL on SFCRUNTIME.R_MATERIAL_STAGE_DETAIL (ID);
grant select, insert, update, delete on SFCRUNTIME.R_MATERIAL_STAGE_DETAIL to TEST;

prompt
prompt Creating table R_MATERIAL_STAGE_HEAD
prompt ====================================
prompt
create table SFCRUNTIME.R_MATERIAL_STAGE_HEAD
(
  id         NVARCHAR2(50),
  skuno      NVARCHAR2(50),
  groupname  NVARCHAR2(50),
  eventname  NVARCHAR2(50),
  ismaterial NVARCHAR2(50),
  seqno      NVARCHAR2(50),
  editby     NVARCHAR2(50),
  edittime   DATE
)
;
create index SFCRUNTIME.IDX_R_MATERIAL_STAGE_HEAD_SKU on SFCRUNTIME.R_MATERIAL_STAGE_HEAD (SKUNO, EVENTNAME);
create unique index SFCRUNTIME.PK_R_MATERIAL_STAGE_HEAD on SFCRUNTIME.R_MATERIAL_STAGE_HEAD (ID);
grant select, insert, update, delete on SFCRUNTIME.R_MATERIAL_STAGE_HEAD to TEST;

prompt
prompt Creating table R_MDS_HEAD
prompt =========================
prompt
create table SFCRUNTIME.R_MDS_HEAD
(
  id         VARCHAR2(50) not null,
  mdskey     VARCHAR2(50) not null,
  mdstype    VARCHAR2(15) not null,
  mdsfile    VARCHAR2(100),
  cqa        VARCHAR2(10) default 0,
  converted  VARCHAR2(10) default 0,
  send       VARCHAR2(10) default 0,
  createtime DATE default sysdate,
  edittime   DATE default sysdate
)
;
comment on column SFCRUNTIME.R_MDS_HEAD.cqa
  is '0:wait,';
comment on column SFCRUNTIME.R_MDS_HEAD.converted
  is '0:wait';
comment on column SFCRUNTIME.R_MDS_HEAD.send
  is '0:wait';
create unique index SFCRUNTIME.PK_R_MDS_HEAD on SFCRUNTIME.R_MDS_HEAD (ID);
grant select on SFCRUNTIME.R_MDS_HEAD to TEST;

prompt
prompt Creating table R_MDS_IQC
prompt ========================
prompt
create table SFCRUNTIME.R_MDS_IQC
(
  id                   VARCHAR2(50) not null,
  datapoint            VARCHAR2(50) not null,
  record_creation_date VARCHAR2(50) not null,
  cm_code              VARCHAR2(50) not null,
  inspection_date      VARCHAR2(50) not null,
  rejectcode           VARCHAR2(50),
  partno               VARCHAR2(50),
  mpn                  VARCHAR2(50),
  manufacturer         VARCHAR2(50),
  lotno                VARCHAR2(50),
  datecode             VARCHAR2(50),
  lotcode              VARCHAR2(50),
  receiveqty           VARCHAR2(50),
  samplesize           VARCHAR2(50),
  acceptqty            VARCHAR2(50),
  rejectqty            VARCHAR2(50),
  avlstatus            VARCHAR2(50),
  firstincoming        VARCHAR2(50),
  inspector            VARCHAR2(50),
  rmano                VARCHAR2(50),
  actio                VARCHAR2(50),
  temp1                VARCHAR2(50),
  temp2                VARCHAR2(50),
  temp3                VARCHAR2(50),
  temp4                VARCHAR2(50),
  temp5                VARCHAR2(50),
  createtime           DATE,
  headid               VARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_R_MDS_IQC on SFCRUNTIME.R_MDS_IQC (ID);
grant select, insert, update, delete on SFCRUNTIME.R_MDS_IQC to TEST;

prompt
prompt Creating table R_MDS_IQC_AP
prompt ===========================
prompt
create table SFCRUNTIME.R_MDS_IQC_AP
(
  id            VARCHAR2(50),
  mdsdate       DATE,
  datapoint     VARCHAR2(3),
  rejectcode    VARCHAR2(10),
  partno        VARCHAR2(30),
  mpn           VARCHAR2(50),
  manufacturer  VARCHAR2(50),
  lotno         VARCHAR2(80),
  datecode      VARCHAR2(50),
  lotcode       VARCHAR2(50),
  receiveqty    NUMBER,
  samplesize    NUMBER,
  acceptqty     NUMBER,
  rejectqty     NUMBER,
  avlstatus     VARCHAR2(25),
  firstincoming VARCHAR2(50),
  inspector     VARCHAR2(20),
  rmano         VARCHAR2(10),
  raction       VARCHAR2(20),
  temp1         VARCHAR2(50),
  temp2         VARCHAR2(50),
  temp3         VARCHAR2(50),
  temp4         VARCHAR2(50),
  temp5         VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_MDS_IQC_AP on SFCRUNTIME.R_MDS_IQC_AP (ID);
grant select, insert, update, delete on SFCRUNTIME.R_MDS_IQC_AP to TEST;

prompt
prompt Creating table R_MDS_STR
prompt ========================
prompt
create table SFCRUNTIME.R_MDS_STR
(
  id                   VARCHAR2(50) not null,
  datapoint            VARCHAR2(50) not null,
  record_creation_date VARCHAR2(50) not null,
  cm_code              VARCHAR2(50) not null,
  skuno                VARCHAR2(50),
  sysserialno          VARCHAR2(50),
  partno               VARCHAR2(50),
  cserialno            VARCHAR2(50),
  vendorid             VARCHAR2(50),
  vendorname           VARCHAR2(50),
  struc_date           VARCHAR2(50),
  correcttype          VARCHAR2(50),
  workorderno          VARCHAR2(50),
  workordertype        VARCHAR2(50),
  attribute1           VARCHAR2(50),
  attribute2           VARCHAR2(50),
  attribute3           VARCHAR2(50),
  attribute4           VARCHAR2(50),
  createtime           DATE,
  headid               VARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_R_MDS_STR on SFCRUNTIME.R_MDS_STR (ID);
grant select on SFCRUNTIME.R_MDS_STR to TEST;

prompt
prompt Creating table R_MDS_YIELD
prompt ==========================
prompt
create table SFCRUNTIME.R_MDS_YIELD
(
  id                   VARCHAR2(50) not null,
  datapoint            VARCHAR2(50) not null,
  record_creation_date VARCHAR2(50) not null,
  cm_code              VARCHAR2(50),
  skuno                VARCHAR2(50),
  sysserialno          VARCHAR2(50),
  eventpoint           VARCHAR2(50),
  yield_date           VARCHAR2(50),
  workorderno          VARCHAR2(50),
  recordtype           VARCHAR2(50),
  workordertype        VARCHAR2(50),
  scanby               VARCHAR2(50),
  failcode             VARCHAR2(50),
  comments             VARCHAR2(50),
  faillocation         VARCHAR2(50),
  failpartno           VARCHAR2(50),
  failserialno         VARCHAR2(50),
  replacserialno       VARCHAR2(50),
  correnttype          VARCHAR2(50),
  routeid              VARCHAR2(50),
  routerev             VARCHAR2(50),
  attribute1           VARCHAR2(50),
  attribute2           VARCHAR2(50),
  attribute3           VARCHAR2(50),
  attribute4           VARCHAR2(50),
  fault_confirmed_flag VARCHAR2(50),
  firmware_version     VARCHAR2(50),
  uptime               VARCHAR2(50),
  fru_serial_number    VARCHAR2(50),
  hold_flag            VARCHAR2(50),
  fa_required_flag     VARCHAR2(50),
  cust_tag             VARCHAR2(50),
  chg_part_num         VARCHAR2(50),
  ref1                 VARCHAR2(50),
  ref2                 VARCHAR2(50),
  ref3                 VARCHAR2(50),
  ref4                 VARCHAR2(50),
  ref5                 VARCHAR2(50),
  createtime           DATE,
  headid               VARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_R_MDS_YIELD on SFCRUNTIME.R_MDS_YIELD (ID);
grant select on SFCRUNTIME.R_MDS_YIELD to TEST;

prompt
prompt Creating table R_MES_EXT
prompt ========================
prompt
create table SFCRUNTIME.R_MES_EXT
(
  id         VARCHAR2(50) not null,
  data1      VARCHAR2(50),
  data2      VARCHAR2(50),
  data3      VARCHAR2(50),
  data4      VARCHAR2(50),
  data5      VARCHAR2(50),
  data6      VARCHAR2(50),
  data7      VARCHAR2(50),
  data8      VARCHAR2(150),
  data9      VARCHAR2(150),
  data10     VARCHAR2(150),
  data11     VARCHAR2(150),
  data12     VARCHAR2(150),
  data13     VARCHAR2(150),
  createtime DATE,
  editemp    VARCHAR2(50),
  edittime   DATE
)
;
create unique index SFCRUNTIME.DATA1_R_MES_EXT on SFCRUNTIME.R_MES_EXT (DATA1);
alter table SFCRUNTIME.R_MES_EXT
  add constraint PK_R_MES_EXT primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_MES_EXT to TEST;

prompt
prompt Creating table R_MES_LOG
prompt ========================
prompt
create table SFCRUNTIME.R_MES_LOG
(
  id            VARCHAR2(50) not null,
  program_name  VARCHAR2(50),
  class_name    VARCHAR2(100),
  function_name VARCHAR2(50),
  log_message   VARCHAR2(500),
  log_sql       VARCHAR2(1000),
  edit_emp      VARCHAR2(50),
  edit_time     DATE,
  data1         VARCHAR2(50),
  data2         VARCHAR2(50),
  data3         VARCHAR2(50),
  mailflag      VARCHAR2(2),
  data4         VARCHAR2(200)
)
;
comment on column SFCRUNTIME.R_MES_LOG.id
  is ' ID �� ';
comment on column SFCRUNTIME.R_MES_LOG.program_name
  is ' �{���W�� ';
comment on column SFCRUNTIME.R_MES_LOG.class_name
  is '�{�������W';
comment on column SFCRUNTIME.R_MES_LOG.function_name
  is 'function�W��';
comment on column SFCRUNTIME.R_MES_LOG.log_message
  is ' ���`�H�� ';
comment on column SFCRUNTIME.R_MES_LOG.log_sql
  is ' ���`SQL ';
comment on column SFCRUNTIME.R_MES_LOG.edit_emp
  is ' �����s���H ';
comment on column SFCRUNTIME.R_MES_LOG.edit_time
  is ' �����s������ ';
comment on column SFCRUNTIME.R_MES_LOG.data1
  is 'KEY1';
comment on column SFCRUNTIME.R_MES_LOG.data2
  is '備份字段';
comment on column SFCRUNTIME.R_MES_LOG.data3
  is '備份字段';
comment on column SFCRUNTIME.R_MES_LOG.mailflag
  is 'MAILFLAG';
comment on column SFCRUNTIME.R_MES_LOG.data4
  is '備份字段';
create index SFCRUNTIME.IDX_R_MES_LOG0 on SFCRUNTIME.R_MES_LOG (PROGRAM_NAME);
create index SFCRUNTIME.IDX_R_MES_LOG1 on SFCRUNTIME.R_MES_LOG (FUNCTION_NAME);
alter table SFCRUNTIME.R_MES_LOG
  add constraint PK_R_MES_LOG primary key (ID);

prompt
prompt Creating table R_MODELSUBPN_MAP
prompt ===============================
prompt
create table SFCRUNTIME.R_MODELSUBPN_MAP
(
  id         VARCHAR2(50),
  custpn     VARCHAR2(50),
  partno     VARCHAR2(50),
  subpartno  VARCHAR2(50),
  subpnrev   VARCHAR2(50),
  createtime DATE default SYSDATE
)
;
create unique index SFCRUNTIME.PK_R_MODELSUBPN_MAP on SFCRUNTIME.R_MODELSUBPN_MAP (ID);

prompt
prompt Creating table R_MOVE_LIST
prompt ==========================
prompt
create table SFCRUNTIME.R_MOVE_LIST
(
  id            VARCHAR2(50) not null,
  move_id       VARCHAR2(50),
  from_location VARCHAR2(50),
  to_location   VARCHAR2(50),
  pack_type     VARCHAR2(50),
  move_emp      VARCHAR2(50),
  move_date     DATE
)
;
create index SFCRUNTIME.IDX_R_MOVE_LIST_F_LOC on SFCRUNTIME.R_MOVE_LIST (FROM_LOCATION);
create index SFCRUNTIME.IDX_R_MOVE_LIST_MOVE on SFCRUNTIME.R_MOVE_LIST (MOVE_ID);
create index SFCRUNTIME.IDX_R_MOVE_LIST_T_LOC on SFCRUNTIME.R_MOVE_LIST (TO_LOCATION);
alter table SFCRUNTIME.R_MOVE_LIST
  add constraint PK_R_MOVE_LIST_ID primary key (ID);

prompt
prompt Creating table R_MRB
prompt ====================
prompt
create table SFCRUNTIME.R_MRB
(
  id           VARCHAR2(50),
  sn           VARCHAR2(50),
  workorderno  VARCHAR2(50),
  next_station VARCHAR2(50),
  skuno        VARCHAR2(50),
  from_storage VARCHAR2(50),
  to_storage   VARCHAR2(50),
  rework_wo    VARCHAR2(50),
  create_emp   VARCHAR2(50),
  create_time  DATE,
  mrb_flag     VARCHAR2(1),
  sap_flag     VARCHAR2(1),
  edit_emp     VARCHAR2(50),
  edit_time    DATE
)
;
create unique index SFCRUNTIME.PK_R_MRB on SFCRUNTIME.R_MRB (ID);
create unique index SFCRUNTIME.UNQ_R_MRB on SFCRUNTIME.R_MRB (SN, CREATE_TIME);

prompt
prompt Creating table R_MRB_GT
prompt =======================
prompt
create table SFCRUNTIME.R_MRB_GT
(
  id               VARCHAR2(50),
  workorderno      VARCHAR2(50),
  sap_station_code VARCHAR2(50),
  from_storage     VARCHAR2(50),
  to_storage       VARCHAR2(50),
  total_qty        NUMBER,
  confirmed_flag   VARCHAR2(1),
  zcpp_flag        VARCHAR2(1),
  sap_flag         VARCHAR2(1),
  skuno            VARCHAR2(50),
  sap_message      VARCHAR2(200),
  edit_emp         VARCHAR2(50),
  edit_time        DATE
)
;
create index SFCRUNTIME.IDX_R_MRB_GT0 on SFCRUNTIME.R_MRB_GT (WORKORDERNO);
create unique index SFCRUNTIME.PK_R_MRB_GT on SFCRUNTIME.R_MRB_GT (ID);

prompt
prompt Creating table R_NETGEAR_PTM_CTL
prompt ================================
prompt
create table SFCRUNTIME.R_NETGEAR_PTM_CTL
(
  id          VARCHAR2(50) not null,
  shiporderid VARCHAR2(50) not null,
  dn          VARCHAR2(15) not null,
  tono        VARCHAR2(15) not null,
  po          VARCHAR2(50) not null,
  shiptopart  VARCHAR2(20) not null,
  orgcode     VARCHAR2(10) not null,
  shipqty     NUMBER not null,
  ptmfile     VARCHAR2(50),
  cqa         VARCHAR2(10) not null,
  converted   VARCHAR2(10) not null,
  sent        VARCHAR2(10) not null,
  edittime    DATE not null,
  editby      VARCHAR2(20) not null
)
;
create index SFCRUNTIME.IDX_R_NETGEAR_PTM_CTL_0 on SFCRUNTIME.R_NETGEAR_PTM_CTL (SHIPORDERID);
create unique index SFCRUNTIME.PK_R_NETGEAR_PTM_CTL on SFCRUNTIME.R_NETGEAR_PTM_CTL (ID);

prompt
prompt Creating table R_NETGEAR_PTM_DATA
prompt =================================
prompt
create table SFCRUNTIME.R_NETGEAR_PTM_DATA
(
  id                      VARCHAR2(50) not null,
  shiporderid             VARCHAR2(50),
  packageno               NUMBER,
  orderlineno             VARCHAR2(10),
  seqno                   NUMBER,
  pallet_id               VARCHAR2(20),
  master_carton_id        VARCHAR2(20),
  item_number             VARCHAR2(20),
  serial_number           VARCHAR2(30),
  top_serial_number       VARCHAR2(30),
  mac_id                  VARCHAR2(20),
  asn_number              VARCHAR2(20),
  invoice_number          VARCHAR2(20),
  packing_slip_number     VARCHAR2(20),
  container_number        VARCHAR2(20),
  po_number               VARCHAR2(50),
  po_line_number          VARCHAR2(10),
  xfactory_date           VARCHAR2(20),
  manufacturer_name       VARCHAR2(20),
  as_date_of_manufacture  VARCHAR2(20),
  country_of_origin       VARCHAR2(20),
  org_code                VARCHAR2(10),
  imei_number             VARCHAR2(10),
  masterlock_number       VARCHAR2(20) default '',
  networklock_number      VARCHAR2(20) default '',
  servicelock_number      VARCHAR2(20) default '',
  fa_number_level_rev     VARCHAR2(20) default '',
  fa_number               VARCHAR2(20) default '',
  item_number_level_rev   VARCHAR2(20),
  wep_key                 VARCHAR2(20) default '',
  wifi_id                 VARCHAR2(20) default '',
  access_code             VARCHAR2(20) default '',
  primary_ssid            VARCHAR2(20) default '',
  wpa_key                 VARCHAR2(20) default '',
  mac_id_cable            VARCHAR2(20) default '',
  mac_id_emta             VARCHAR2(20) default '',
  hardware_version        VARCHAR2(20) default '',
  firmware_version        VARCHAR2(20) default '',
  ean_code                VARCHAR2(20) default '',
  software_version        VARCHAR2(20) default '',
  srm_password            VARCHAR2(20) default '',
  rf_mac_id               VARCHAR2(20) default '',
  macid_in_mta            VARCHAR2(20) default '',
  mta_man_router_mac      VARCHAR2(20) default '',
  mtadata_mac             VARCHAR2(20) default '',
  ethernet_mac            VARCHAR2(20) default '',
  usb_mac                 VARCHAR2(20) default '',
  primaryssid_passphrase  VARCHAR2(20) default '',
  cmci_mac                VARCHAR2(20) default '',
  lan_mac                 VARCHAR2(20) default '',
  wan_mac                 VARCHAR2(20) default '',
  device_mac              VARCHAR2(20) default '',
  wireless_mac            VARCHAR2(20) default '',
  wifi_mac_ssid1          VARCHAR2(20) default '',
  ssid1                   VARCHAR2(20) default '',
  ssid1_passphrase        VARCHAR2(20) default '',
  wpa_passphrase          VARCHAR2(20) default '',
  wps_pin_code            VARCHAR2(20) default '',
  pppoa_username          VARCHAR2(20) default '',
  pppoa_passphrase        VARCHAR2(20) default '',
  tr069_unique_key_64_bit VARCHAR2(20) default '',
  fon_key                 VARCHAR2(20) default '',
  ta                      VARCHAR2(20) default '',
  pa_sn                   VARCHAR2(30),
  pa_item_number          VARCHAR2(20),
  lasteditby              VARCHAR2(20),
  lasteditdt              DATE
)
;
create index SFCRUNTIME.IDX_R_NETGEAR_PTM_DATA_0 on SFCRUNTIME.R_NETGEAR_PTM_DATA (SHIPORDERID);
create unique index SFCRUNTIME.PK_R_NETGEAR_PTM_DATA on SFCRUNTIME.R_NETGEAR_PTM_DATA (ID);
grant select, insert, update, delete on SFCRUNTIME.R_NETGEAR_PTM_DATA to TEST;

prompt
prompt Creating table R_NORMAL_BONEPILE
prompt ================================
prompt
create table SFCRUNTIME.R_NORMAL_BONEPILE
(
  id                     VARCHAR2(50),
  sn                     VARCHAR2(50),
  first_load_date        DATE,
  cto_sn_old             VARCHAR2(50),
  vanilla_sn_old         VARCHAR2(50),
  pcba_sn_old            VARCHAR2(50),
  cto_sn_new             VARCHAR2(50),
  vanilla_sn_new         VARCHAR2(50),
  pcba_sn_new            VARCHAR2(50),
  workorderno            VARCHAR2(50),
  skuno                  VARCHAR2(50),
  product_name           VARCHAR2(50),
  sub_series             VARCHAR2(50),
  product_series         VARCHAR2(50),
  fail_station           VARCHAR2(50),
  fail_date              DATE,
  failure_symptom        VARCHAR2(100),
  defect_description     VARCHAR2(100),
  repair_action          VARCHAR2(50),
  repair_date            DATE,
  remark                 VARCHAR2(50),
  bonepile_category      VARCHAR2(16),
  rma_flag               VARCHAR2(1),
  critical_bonepile_flag VARCHAR2(1),
  hardcore_board         VARCHAR2(10),
  price                  NUMBER,
  current_wo             VARCHAR2(50),
  current_station        VARCHAR2(50),
  current_status         VARCHAR2(50),
  scrapped_flag          VARCHAR2(1),
  shipped_flag           VARCHAR2(1),
  closed_flag            VARCHAR2(1),
  closed_reason          VARCHAR2(100),
  closed_by              VARCHAR2(50),
  closed_date            DATE,
  lastedit_by            VARCHAR2(50),
  lastedit_date          DATE
)
;
create index SFCRUNTIME.IDX_R_NORMAL_BONEPILE on SFCRUNTIME.R_NORMAL_BONEPILE (SN);
create index SFCRUNTIME.IDX_R_NORMAL_BONEPILE0 on SFCRUNTIME.R_NORMAL_BONEPILE (SKUNO);
create unique index SFCRUNTIME.PK_R_NORMAL_BONEPILE on SFCRUNTIME.R_NORMAL_BONEPILE (ID);

prompt
prompt Creating table R_ONLINECAR
prompt ==========================
prompt
create table SFCRUNTIME.R_ONLINECAR
(
  id                VARCHAR2(50) not null,
  carno             VARCHAR2(12) not null,
  cartype           VARCHAR2(2) not null,
  cartitle          VARCHAR2(200),
  buname            VARCHAR2(10),
  skuname           VARCHAR2(100) not null,
  skuno             VARCHAR2(20) not null,
  workorderno       VARCHAR2(20),
  productionline    VARCHAR2(20) not null,
  station           VARCHAR2(50) not null,
  findtime          DATE not null,
  totime            DATE,
  skuqty            NUMBER not null,
  failqty           NUMBER not null,
  failtext          VARCHAR2(800),
  attachfile1       VARCHAR2(200),
  failpname         VARCHAR2(50) not null,
  issuedate         DATE,
  oktorelease       NUMBER not null,
  faildepart        VARCHAR2(20),
  confirmname       VARCHAR2(50),
  confirmdate       DATE,
  rootdepart        VARCHAR2(60),
  roottext          VARCHAR2(1800),
  patext            VARCHAR2(1200),
  attachfile2       VARCHAR2(200),
  rootpname         VARCHAR2(50),
  iscancel          VARCHAR2(2),
  fadate            DATE,
  auditdepart1      VARCHAR2(50),
  auditdepart2      VARCHAR2(50),
  auditdepart3      VARCHAR2(50),
  auditdepart4      VARCHAR2(50),
  auditdepart5      VARCHAR2(50),
  modipart1         VARCHAR2(500),
  modipart2         VARCHAR2(500),
  modipart3         VARCHAR2(500),
  modipart4         VARCHAR2(500),
  modipart5         VARCHAR2(500),
  ycompleteddate1   DATE,
  ycompleteddate2   DATE,
  ycompleteddate3   DATE,
  ycompleteddate4   DATE,
  ycompleteddate5   DATE,
  completeddate1    DATE,
  completedate2     DATE,
  completedate3     DATE,
  completedate4     DATE,
  completedate5     DATE,
  auditname1        VARCHAR2(50),
  auditname2        VARCHAR2(50),
  auditname3        VARCHAR2(50),
  auditname4        VARCHAR2(50),
  auditname5        VARCHAR2(50),
  lasteditdt        DATE,
  returnreason      VARCHAR2(100),
  qcfailprodprocess VARCHAR2(800),
  attachfile3       VARCHAR2(200),
  qcpreparedby      VARCHAR2(50),
  qcprepareddate    DATE,
  promit            VARCHAR2(2),
  promitdate        DATE,
  remark            VARCHAR2(500),
  qamanager         VARCHAR2(50),
  estatus           NUMBER,
  createtime        DATE,
  createby          VARCHAR2(50),
  edittime          DATE,
  editby            VARCHAR2(50),
  currentdep        VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_ONLINECAR on SFCRUNTIME.R_ONLINECAR (CARNO);
create unique index SFCRUNTIME.PK_R_ONLINECAR on SFCRUNTIME.R_ONLINECAR (ID);

prompt
prompt Creating table R_ORDER_SN
prompt =========================
prompt
create table SFCRUNTIME.R_ORDER_SN
(
  id           VARCHAR2(50),
  dnid         VARCHAR2(50),
  grouptype    VARCHAR2(50),
  sn           VARCHAR2(50),
  orderno      VARCHAR2(50),
  skuno        VARCHAR2(50),
  printflag    VARCHAR2(10),
  overpacktime DATE,
  lasteditby   VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_ORDER_SN0 on SFCRUNTIME.R_ORDER_SN (DNID);
create unique index SFCRUNTIME.PK_R_ORDER_SN on SFCRUNTIME.R_ORDER_SN (ID);
grant select, insert, update, delete on SFCRUNTIME.R_ORDER_SN to TEST;

prompt
prompt Creating table R_ORDER_WO
prompt =========================
prompt
create table SFCRUNTIME.R_ORDER_WO
(
  id         VARCHAR2(50),
  wo         VARCHAR2(50),
  upoid      VARCHAR2(50),
  originalid VARCHAR2(50),
  dismantle  VARCHAR2(10),
  valid      VARCHAR2(5),
  createtime DATE,
  edittime   DATE
)
;
create index SFCRUNTIME.IDX_R_ORDER_WO on SFCRUNTIME.R_ORDER_WO (UPOID, WO);
create unique index SFCRUNTIME.PK_R_ORDER_WO on SFCRUNTIME.R_ORDER_WO (ID);

prompt
prompt Creating table R_ORT
prompt ====================
prompt
create table SFCRUNTIME.R_ORT
(
  id          VARCHAR2(50),
  sn          VARCHAR2(50),
  snid        VARCHAR2(50),
  ortevent    VARCHAR2(15),
  workorderno VARCHAR2(20),
  skuno       VARCHAR2(20),
  version     VARCHAR2(4),
  reasoncode  VARCHAR2(20),
  counter     NUMBER,
  sendflag    VARCHAR2(2),
  mdstime     DATE,
  worktime    DATE
)
;
create index SFCRUNTIME.IDX_R_ORT on SFCRUNTIME.R_ORT (SNID);
create unique index SFCRUNTIME.PK_R_ORT on SFCRUNTIME.R_ORT (ID);

prompt
prompt Creating table R_ORT_ALERT
prompt ==========================
prompt
create table SFCRUNTIME.R_ORT_ALERT
(
  id         VARCHAR2(50),
  skuno      VARCHAR2(20),
  sn         VARCHAR2(50),
  snid       VARCHAR2(50),
  skuno_ort  VARCHAR2(20),
  sn_ort     VARCHAR2(20),
  scanreason VARCHAR2(50),
  alert_flag NUMBER,
  controlby  VARCHAR2(50),
  controldt  DATE,
  scanby     VARCHAR2(20),
  scandt     DATE
)
;
create index SFCRUNTIME.IDX_R_ORT_ALERT on SFCRUNTIME.R_ORT_ALERT (SNID);
create unique index SFCRUNTIME.PK_R_ORT_ALERT on SFCRUNTIME.R_ORT_ALERT (ID);

prompt
prompt Creating table R_OUTLINE_TEST
prompt =============================
prompt
create table SFCRUNTIME.R_OUTLINE_TEST
(
  id            VARCHAR2(50),
  sn            VARCHAR2(50),
  workorderno   VARCHAR2(50),
  skuno         VARCHAR2(50),
  station       VARCHAR2(50),
  line          VARCHAR2(50),
  status        VARCHAR2(10),
  fail_desc     VARCHAR2(300),
  valid_flag    NUMBER,
  creat_date    DATE,
  creat_emp     VARCHAR2(50),
  lastedit_date DATE,
  lastedit_by   VARCHAR2(50),
  data_type     VARCHAR2(20)
)
;
create index SFCRUNTIME.IDX_R_OUTLINE_TEST on SFCRUNTIME.R_OUTLINE_TEST (SN);
create unique index SFCRUNTIME.PK_R_OUTLINE_TEST on SFCRUNTIME.R_OUTLINE_TEST (ID);

prompt
prompt Creating table R_PACKING
prompt ========================
prompt
create table SFCRUNTIME.R_PACKING
(
  id             VARCHAR2(50),
  pack_no        VARCHAR2(50),
  pack_type      VARCHAR2(50),
  parent_pack_id VARCHAR2(50),
  skuno          VARCHAR2(50),
  max_qty        NUMBER,
  qty            NUMBER,
  closed_flag    VARCHAR2(2),
  create_time    DATE,
  edit_time      DATE,
  edit_emp       VARCHAR2(50),
  line           VARCHAR2(20),
  station        VARCHAR2(20),
  ip             VARCHAR2(20)
)
;
comment on column SFCRUNTIME.R_PACKING.id
  is ' ID ';
comment on column SFCRUNTIME.R_PACKING.pack_no
  is ' 包裝編號 ';
comment on column SFCRUNTIME.R_PACKING.pack_type
  is ' 包裝類型 ';
comment on column SFCRUNTIME.R_PACKING.parent_pack_id
  is ' 父級包裝ID ';
comment on column SFCRUNTIME.R_PACKING.skuno
  is ' 機種 ';
comment on column SFCRUNTIME.R_PACKING.max_qty
  is ' 包規數量 ';
comment on column SFCRUNTIME.R_PACKING.qty
  is ' 實際掃描數量 ';
comment on column SFCRUNTIME.R_PACKING.closed_flag
  is ' 關閉標記 0：未關閉  1：已關閉 ';
comment on column SFCRUNTIME.R_PACKING.create_time
  is ' 創建時間 ';
comment on column SFCRUNTIME.R_PACKING.edit_time
  is ' 編輯時間 ';
comment on column SFCRUNTIME.R_PACKING.edit_emp
  is ' 編輯人 ';
comment on column SFCRUNTIME.R_PACKING.line
  is '生成的線別';
comment on column SFCRUNTIME.R_PACKING.station
  is '生成的工站名';
comment on column SFCRUNTIME.R_PACKING.ip
  is '工站的IP';
create index SFCRUNTIME.IDX_R_PACKING_PR on SFCRUNTIME.R_PACKING (PARENT_PACK_ID, 0);
create unique index SFCRUNTIME.PK_R_PACKING on SFCRUNTIME.R_PACKING (ID);
create unique index SFCRUNTIME.UNQ_R_PACKING on SFCRUNTIME.R_PACKING (PACK_NO);

prompt
prompt Creating table R_PACKING_BAK0414
prompt ================================
prompt
create table SFCRUNTIME.R_PACKING_BAK0414
(
  id             VARCHAR2(50),
  pack_no        VARCHAR2(50),
  pack_type      VARCHAR2(50),
  parent_pack_id VARCHAR2(50),
  skuno          VARCHAR2(50),
  max_qty        NUMBER,
  qty            NUMBER,
  closed_flag    VARCHAR2(2),
  create_time    DATE,
  edit_time      DATE,
  edit_emp       VARCHAR2(50),
  line           VARCHAR2(20),
  station        VARCHAR2(20),
  ip             VARCHAR2(20)
)
;
comment on column SFCRUNTIME.R_PACKING_BAK0414.id
  is ' ID ';
comment on column SFCRUNTIME.R_PACKING_BAK0414.pack_no
  is ' 包裝編號 ';
comment on column SFCRUNTIME.R_PACKING_BAK0414.pack_type
  is ' 包裝類型 ';
comment on column SFCRUNTIME.R_PACKING_BAK0414.parent_pack_id
  is ' 父級包裝ID ';
comment on column SFCRUNTIME.R_PACKING_BAK0414.skuno
  is ' 機種 ';
comment on column SFCRUNTIME.R_PACKING_BAK0414.max_qty
  is ' 包規數量 ';
comment on column SFCRUNTIME.R_PACKING_BAK0414.qty
  is ' 實際掃描數量 ';
comment on column SFCRUNTIME.R_PACKING_BAK0414.closed_flag
  is ' 關閉標記 0：未關閉  1：已關閉 ';
comment on column SFCRUNTIME.R_PACKING_BAK0414.create_time
  is ' 創建時間 ';
comment on column SFCRUNTIME.R_PACKING_BAK0414.edit_time
  is ' 編輯時間 ';
comment on column SFCRUNTIME.R_PACKING_BAK0414.edit_emp
  is ' 編輯人 ';
comment on column SFCRUNTIME.R_PACKING_BAK0414.line
  is '生成的線別';
comment on column SFCRUNTIME.R_PACKING_BAK0414.station
  is '生成的工站名';
comment on column SFCRUNTIME.R_PACKING_BAK0414.ip
  is '工站的IP';

prompt
prompt Creating table R_PANEL_SN
prompt =========================
prompt
create table SFCRUNTIME.R_PANEL_SN
(
  id          VARCHAR2(50),
  sn          VARCHAR2(50),
  panel       VARCHAR2(50),
  workorderno VARCHAR2(50),
  seq_no      NUMBER,
  edit_emp    VARCHAR2(50),
  edit_time   DATE
)
;
create index SFCRUNTIME.IDX_R_PANEL_SN0 on SFCRUNTIME.R_PANEL_SN (WORKORDERNO);
create index SFCRUNTIME.IDX_R_PANEL_SN1 on SFCRUNTIME.R_PANEL_SN (SN);
create index SFCRUNTIME.IDX_R_PANEL_SN2 on SFCRUNTIME.R_PANEL_SN (PANEL);
create unique index SFCRUNTIME.PK_R_PANEL_SN on SFCRUNTIME.R_PANEL_SN (ID);
create unique index SFCRUNTIME.UNQ_R_PANEL_SN on SFCRUNTIME.R_PANEL_SN (PANEL, SN);

prompt
prompt Creating table R_PN_HB_MAP
prompt ==========================
prompt
create table SFCRUNTIME.R_PN_HB_MAP
(
  id         VARCHAR2(50) not null,
  custpn     VARCHAR2(50) not null,
  hbpn       VARCHAR2(50),
  createtime DATE
)
;
create unique index SFCRUNTIME.PK_R_PN_HB_MAP on SFCRUNTIME.R_PN_HB_MAP (ID);

prompt
prompt Creating table R_PN_MASTER_DATA
prompt ===============================
prompt
create table SFCRUNTIME.R_PN_MASTER_DATA
(
  id                 VARCHAR2(50),
  plant              VARCHAR2(30),
  pn                 VARCHAR2(50),
  version            VARCHAR2(50),
  description        VARCHAR2(300),
  cpudt              DATE,
  selling_price      NUMBER,
  price_unit         NUMBER,
  currency           VARCHAR2(10),
  condition_unit     VARCHAR2(100),
  net_weight         NUMBER,
  weight_unit        VARCHAR2(100),
  net_weight_by_unit NUMBER,
  enabled            VARCHAR2(2),
  standard_value     NUMBER,
  unit               VARCHAR2(4),
  price              NUMBER,
  price1             NUMBER,
  price2             NUMBER,
  price3             NUMBER,
  sap_weight         NUMBER,
  weight1            NUMBER,
  weight2            NUMBER,
  chinese_desc       VARCHAR2(300),
  import_date_time   DATE,
  import_user        VARCHAR2(30),
  last_edit_dt       DATE,
  last_edit_by       VARCHAR2(30)
)
;
create index SFCRUNTIME.IDX_R_PN_MASTER_DATA_PN on SFCRUNTIME.R_PN_MASTER_DATA (PN);
create unique index SFCRUNTIME.PK_R_PN_MASTER_DATA on SFCRUNTIME.R_PN_MASTER_DATA (ID);
grant select, insert, update, delete on SFCRUNTIME.R_PN_MASTER_DATA to TEST;

prompt
prompt Creating table R_PRE_WO_DETAIL
prompt ==============================
prompt
create table SFCRUNTIME.R_PRE_WO_DETAIL
(
  id          VARCHAR2(50) not null,
  wo          VARCHAR2(20) not null,
  partno      VARCHAR2(50),
  requestqty  VARCHAR2(10),
  unitprice   VARCHAR2(50),
  unitweight  VARCHAR2(30),
  packageflag VARCHAR2(20),
  partnotype  VARCHAR2(15),
  createtime  DATE default SYSDATE
)
;
create unique index SFCRUNTIME.PK_R_PRE_WO_DETAIL on SFCRUNTIME.R_PRE_WO_DETAIL (ID);
alter table SFCRUNTIME.R_PRE_WO_DETAIL
  add constraint R_PRE_WO_DETAIL_PK primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_PRE_WO_DETAIL to TEST;

prompt
prompt Creating table R_PRE_WO_HEAD
prompt ============================
prompt
create table SFCRUNTIME.R_PRE_WO_HEAD
(
  id           VARCHAR2(50) not null,
  wo           VARCHAR2(50) not null,
  groupid      VARCHAR2(50),
  woqty        VARCHAR2(50),
  pono         VARCHAR2(50) not null,
  poline       VARCHAR2(50) not null,
  pid          VARCHAR2(50),
  totunitprice VARCHAR2(50),
  sapflag      VARCHAR2(2),
  description  VARCHAR2(100),
  mainid       VARCHAR2(50) not null,
  createtime   DATE default SYSDATE not null
)
;
create unique index SFCRUNTIME.PK_R_PRE_WO_HEAD on SFCRUNTIME.R_PRE_WO_HEAD (ID);
alter table SFCRUNTIME.R_PRE_WO_HEAD
  add constraint R_PRE_WO_HEAD_PK primary key (ID);
grant select, insert, update, delete, alter on SFCRUNTIME.R_PRE_WO_HEAD to TEST;

prompt
prompt Creating table R_PROCCESS_EVENT
prompt ===============================
prompt
create table SFCRUNTIME.R_PROCCESS_EVENT
(
  id            VARCHAR2(50) not null,
  proccess_name VARCHAR2(50),
  event_type    VARCHAR2(20),
  message       VARCHAR2(500),
  event_lv      NUMBER,
  runtime_id    VARCHAR2(20),
  ip            VARCHAR2(20),
  state         VARCHAR2(10),
  edit_emp      VARCHAR2(20),
  edit_date     DATE
)
;
create index SFCUSER.I1_R_PROCCESS_EVENT on SFCRUNTIME.R_PROCCESS_EVENT (PROCCESS_NAME);
alter table SFCRUNTIME.R_PROCCESS_EVENT
  add constraint PK_R_PROCCESS_EVENT primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_PROCCESS_EVENT to TEST;

prompt
prompt Creating table R_PROFILE
prompt ========================
prompt
create table SFCRUNTIME.R_PROFILE
(
  id              VARCHAR2(50),
  profilename     VARCHAR2(100),
  profilecategory VARCHAR2(50),
  profiletype     VARCHAR2(50),
  profilevalue    VARCHAR2(255),
  profiledesc     VARCHAR2(255),
  profilesort     NUMBER,
  profilelevel    NUMBER,
  note1           VARCHAR2(255),
  note2           VARCHAR2(255),
  note3           VARCHAR2(255),
  note4           VARCHAR2(255),
  note5           VARCHAR2(255),
  edit_emp        VARCHAR2(50),
  edit_time       DATE
)
;
create unique index SFCRUNTIME.INDEX_R_PROFILE on SFCRUNTIME.R_PROFILE (PROFILENAME, PROFILECATEGORY, PROFILETYPE);
create unique index SFCRUNTIME.PK_R_PROFILE on SFCRUNTIME.R_PROFILE (ID);

prompt
prompt Creating table R_PTM_TACONFIG
prompt =============================
prompt
create table SFCRUNTIME.R_PTM_TACONFIG
(
  id        VARCHAR2(50),
  wo        VARCHAR2(50),
  skuno     VARCHAR2(50),
  prexid    VARCHAR2(50),
  ta_number VARCHAR2(50),
  value1    VARCHAR2(50),
  edittime  DATE,
  editby    VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_PTM_TACONFIG on SFCRUNTIME.R_PTM_TACONFIG (WO);
create unique index SFCRUNTIME.PK_R_PTM_TACONFIG on SFCRUNTIME.R_PTM_TACONFIG (ID);

prompt
prompt Creating table R_REPAIR_ACTION
prompt ==============================
prompt
create table SFCRUNTIME.R_REPAIR_ACTION
(
  id                   VARCHAR2(50),
  repair_failcode_id   VARCHAR2(50),
  sn                   VARCHAR2(50),
  action_code          VARCHAR2(50),
  section_id           VARCHAR2(50),
  process              VARCHAR2(50),
  items_id             VARCHAR2(50),
  items_son_id         VARCHAR2(50),
  reason_code          VARCHAR2(50),
  description          VARCHAR2(200),
  fail_location        VARCHAR2(50),
  fail_code            VARCHAR2(50),
  keypart_sn           VARCHAR2(50),
  new_keypart_sn       VARCHAR2(50),
  kp_no                VARCHAR2(50),
  tr_sn                VARCHAR2(50),
  mfr_code             VARCHAR2(50),
  mfr_name             VARCHAR2(100),
  date_code            VARCHAR2(50),
  lot_code             VARCHAR2(50),
  new_kp_no            VARCHAR2(50),
  new_tr_sn            VARCHAR2(50),
  new_mfr_code         VARCHAR2(50),
  new_mfr_name         VARCHAR2(100),
  new_date_code        VARCHAR2(50),
  new_lot_code         VARCHAR2(50),
  repair_emp           VARCHAR2(50),
  repair_time          DATE,
  edit_time            DATE,
  edit_emp             VARCHAR2(50),
  fail_time            DATE,
  repair_start_time    DATE,
  repair_complete_time DATE,
  fixed_flag           VARCHAR2(1),
  replaced_flag        VARCHAR2(1),
  solution             VARCHAR2(50),
  solder               VARCHAR2(50),
  package_type         VARCHAR2(50),
  part_desc            VARCHAR2(50),
  compomentid          VARCHAR2(20),
  mpn                  VARCHAR2(50),
  new_mpn              VARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_R_REPAIR_ACTION on SFCRUNTIME.R_REPAIR_ACTION (ID);

prompt
prompt Creating table R_REPAIR_AGINGREPORT
prompt ===================================
prompt
create table SFCRUNTIME.R_REPAIR_AGINGREPORT
(
  id          VARCHAR2(50),
  report_date VARCHAR2(15),
  bu          VARCHAR2(10),
  series      VARCHAR2(25),
  p_no        VARCHAR2(30),
  day1within  INTEGER default 0,
  days1_3     INTEGER default 0,
  days4_7     INTEGER default 0,
  days8_14    INTEGER default 0,
  days15_30   INTEGER default 0,
  over30days  INTEGER default 0,
  send_flag   INTEGER default 0,
  send_date   DATE,
  lasteditby  VARCHAR2(15),
  lasteditdt  DATE default SYSDATE
)
;
grant select, insert, update on SFCRUNTIME.R_REPAIR_AGINGREPORT to TEST;

prompt
prompt Creating table R_REPAIR_DAILYREPORT
prompt ===================================
prompt
create table SFCRUNTIME.R_REPAIR_DAILYREPORT
(
  id               VARCHAR2(50),
  report_date      VARCHAR2(15),
  bu               VARCHAR2(10),
  series           VARCHAR2(25),
  p_no             VARCHAR2(30),
  balance_qty      INTEGER default 0,
  checkin_qty      INTEGER default 0,
  checkout_qty     INTEGER default 0,
  overtime4h_qty   INTEGER default 0,
  overtime8h_qty   INTEGER default 0,
  send_flag        INTEGER default 0,
  send_date        DATE,
  lasteditby       VARCHAR2(15),
  lasteditdt       DATE default SYSDATE,
  last_balance_qty INTEGER default 0
)
;
grant select, insert, update on SFCRUNTIME.R_REPAIR_DAILYREPORT to TEST;

prompt
prompt Creating table R_REPAIR_DAILYREPORT_SN
prompt ======================================
prompt
create table SFCRUNTIME.R_REPAIR_DAILYREPORT_SN
(
  id             VARCHAR2(50),
  report_date    VARCHAR2(15),
  bu             VARCHAR2(10),
  series         VARCHAR2(25),
  sn             VARCHAR2(30),
  sn_type        VARCHAR2(15),
  checkin_date   DATE,
  checkout_date  DATE,
  failtime       DATE,
  first_failtime DATE,
  sn_agile       FLOAT,
  editdt         DATE default SYSDATE,
  p_no           VARCHAR2(20),
  final_status   VARCHAR2(10)
)
;
grant select, insert, update on SFCRUNTIME.R_REPAIR_DAILYREPORT_SN to TEST;

prompt
prompt Creating table R_REPAIR_FAILCODE
prompt ================================
prompt
create table SFCRUNTIME.R_REPAIR_FAILCODE
(
  id             VARCHAR2(50),
  repair_main_id VARCHAR2(50),
  sn             VARCHAR2(50),
  fail_code      VARCHAR2(50),
  fail_location  VARCHAR2(50),
  fail_category  VARCHAR2(50),
  fail_process   VARCHAR2(50),
  fail_time      DATE,
  fail_emp       VARCHAR2(50),
  description    VARCHAR2(500),
  create_time    DATE,
  repair_flag    VARCHAR2(2),
  edit_time      DATE,
  edit_emp       VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_REPAIR_FAILCODE0 on SFCRUNTIME.R_REPAIR_FAILCODE (SN, FAIL_TIME, FAIL_CATEGORY);
create unique index SFCRUNTIME.PK_R_REPAIR_FAILCODE on SFCRUNTIME.R_REPAIR_FAILCODE (ID);

prompt
prompt Creating table R_REPAIR_MAIN
prompt ============================
prompt
create table SFCRUNTIME.R_REPAIR_MAIN
(
  id                VARCHAR2(50),
  sn                VARCHAR2(50),
  workorderno       VARCHAR2(20),
  skuno             VARCHAR2(50),
  fail_line         VARCHAR2(50),
  fail_station      VARCHAR2(50),
  fail_device       VARCHAR2(50),
  fail_emp          VARCHAR2(50),
  fail_time         DATE,
  distribution_emp  VARCHAR2(50),
  distribution_time DATE,
  create_time       DATE,
  closed_flag       VARCHAR2(2),
  edit_time         DATE,
  edit_emp          VARCHAR2(50),
  repairing_flag    VARCHAR2(1) default 0
)
;
create index SFCRUNTIME.IDX_R_REPAIR_MAIN0 on SFCRUNTIME.R_REPAIR_MAIN (ID, SN);
create index SFCRUNTIME.IDX_R_REPAIR_MAIN1 on SFCRUNTIME.R_REPAIR_MAIN (SN, CREATE_TIME);
create unique index SFCRUNTIME.PK_R_REPAIR_MAIN on SFCRUNTIME.R_REPAIR_MAIN (ID);

prompt
prompt Creating table R_REPAIR_TRANSFER
prompt ================================
prompt
create table SFCRUNTIME.R_REPAIR_TRANSFER
(
  id              VARCHAR2(50),
  repair_main_id  VARCHAR2(50),
  sn              VARCHAR2(50),
  line_name       VARCHAR2(50),
  station_name    VARCHAR2(50),
  skuno           VARCHAR2(50),
  workorderno     VARCHAR2(50),
  in_time         DATE,
  in_send_emp     VARCHAR2(50),
  in_receive_emp  VARCHAR2(50),
  out_time        DATE,
  out_send_emp    VARCHAR2(50),
  out_receive_emp VARCHAR2(50),
  description     VARCHAR2(200),
  closed_flag     VARCHAR2(2),
  create_time     DATE,
  edit_time       DATE,
  edit_emp        VARCHAR2(50),
  department      VARCHAR2(10)
)
;
comment on column SFCRUNTIME.R_REPAIR_TRANSFER.department
  is '部門信息';
create index SFCRUNTIME.IDX_R_REPAIR_TRANSFER0 on SFCRUNTIME.R_REPAIR_TRANSFER (ID, SN);
create unique index SFCRUNTIME.PK_R_REPAIR_TRANSFER on SFCRUNTIME.R_REPAIR_TRANSFER (ID);

prompt
prompt Creating table R_REPLACE_SN
prompt ===========================
prompt
create table SFCRUNTIME.R_REPLACE_SN
(
  id        VARCHAR2(50),
  old_sn_id VARCHAR2(50),
  old_sn    VARCHAR2(50),
  new_sn    VARCHAR2(50),
  edit_emp  VARCHAR2(50),
  edit_time DATE
)
;
create index SFCRUNTIME.IDX_R_REPLACE_SN0 on SFCRUNTIME.R_REPLACE_SN (OLD_SN_ID);
create unique index SFCRUNTIME.PK_R_REPLACE_SN on SFCRUNTIME.R_REPLACE_SN (ID);

prompt
prompt Creating table R_RMA_BONEPILE
prompt =============================
prompt
create table SFCRUNTIME.R_RMA_BONEPILE
(
  id              VARCHAR2(50),
  lot_no          VARCHAR2(50),
  skuno           VARCHAR2(50),
  sn              VARCHAR2(50),
  received_date   DATE,
  lastpack_date   DATE,
  fail_station    VARCHAR2(50),
  failure_symptom VARCHAR2(50),
  failure_types   VARCHAR2(50),
  owner           VARCHAR2(50),
  remark          VARCHAR2(50),
  valuable        VARCHAR2(2),
  rma_times       NUMBER,
  function_times  NUMBER,
  cosmetic_times  NUMBER,
  closed_flag     VARCHAR2(2),
  closed_date     DATE,
  edit_emp        VARCHAR2(50),
  edit_time       DATE,
  upload_emp      VARCHAR2(50),
  upload_time     DATE default sysdate
)
;
comment on column SFCRUNTIME.R_RMA_BONEPILE.failure_types
  is ' Cosmetic或者Function ';
comment on column SFCRUNTIME.R_RMA_BONEPILE.owner
  is ' FNN或者Vertiv ';
comment on column SFCRUNTIME.R_RMA_BONEPILE.valuable
  is ' Y代表RMA產品有PO,N代表RMA產品無PO ';
comment on column SFCRUNTIME.R_RMA_BONEPILE.rma_times
  is ' 該SN上傳RMA系統的次數 ';
comment on column SFCRUNTIME.R_RMA_BONEPILE.function_times
  is ' 該SN上傳到系統中,Failure Types為Function的次數 ';
comment on column SFCRUNTIME.R_RMA_BONEPILE.cosmetic_times
  is ' 該SN上傳到系統中,Failure Types為Cosmetic的次數 ';
comment on column SFCRUNTIME.R_RMA_BONEPILE.closed_flag
  is ' RMA重工後過CBS後則1:closed,未過CBS則0:open ';
create index SFCRUNTIME.IDX_R_RMA_BONEPILE1 on SFCRUNTIME.R_RMA_BONEPILE (LOT_NO);
create index SFCRUNTIME.IDX_R_RMA_BONEPILE2 on SFCRUNTIME.R_RMA_BONEPILE (SKUNO);
create index SFCRUNTIME.IDX_R_RMA_BONEPILE3 on SFCRUNTIME.R_RMA_BONEPILE (SN);
create unique index SFCRUNTIME.PK_R_RMA_BONEPILE on SFCRUNTIME.R_RMA_BONEPILE (ID);

prompt
prompt Creating table R_SAP_AS_BOM
prompt ===========================
prompt
create table SFCRUNTIME.R_SAP_AS_BOM
(
  id           VARCHAR2(50),
  wo           NVARCHAR2(50),
  pn           NVARCHAR2(50),
  usage        NVARCHAR2(50),
  parentpn     NVARCHAR2(50),
  custpn       NVARCHAR2(50),
  custparentpn NVARCHAR2(50),
  clei1        NVARCHAR2(50),
  clei2        NVARCHAR2(50),
  spartdesc    NVARCHAR2(50),
  ppartdesc    NVARCHAR2(50),
  createtime   DATE default sysdate,
  wastage      NVARCHAR2(50),
  pnrev        NVARCHAR2(50),
  parentrev    NVARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_R_SAP_AS_BOM on SFCRUNTIME.R_SAP_AS_BOM (ID);

prompt
prompt Creating table R_SAP_HB
prompt =======================
prompt
create table SFCRUNTIME.R_SAP_HB
(
  id           VARCHAR2(50),
  wo           NVARCHAR2(50),
  pn           NVARCHAR2(50),
  usage        NVARCHAR2(50),
  parentpn     NVARCHAR2(50),
  custpn       NVARCHAR2(50),
  custparentpn NVARCHAR2(50),
  clei1        NVARCHAR2(50),
  clei2        NVARCHAR2(50),
  spartdesc    NVARCHAR2(50),
  ppartdesc    NVARCHAR2(50),
  createtime   DATE default sysdate,
  pnrev        NVARCHAR2(50),
  wastage      NVARCHAR2(50),
  hbrev        NVARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_R_SAP_HB on SFCRUNTIME.R_SAP_HB (ID);

prompt
prompt Creating table R_SAP_PODETAIL
prompt =============================
prompt
create table SFCRUNTIME.R_SAP_PODETAIL
(
  id         VARCHAR2(50),
  wo         NVARCHAR2(50),
  plant      NVARCHAR2(50),
  pn         NVARCHAR2(50),
  orderqty   NVARCHAR2(50),
  pnrev      NVARCHAR2(50),
  pid        NVARCHAR2(50),
  pidrev     NVARCHAR2(50),
  spartdesc  NVARCHAR2(50),
  ppartdesc  NVARCHAR2(50),
  createtime DATE default sysdate
)
;
create unique index SFCRUNTIME.PK_R_SAP_PODETAIL on SFCRUNTIME.R_SAP_PODETAIL (ID);

prompt
prompt Creating table R_SERVICE_ALARM_CONFIG
prompt =====================================
prompt
create table SFCRUNTIME.R_SERVICE_ALARM_CONFIG
(
  id              VARCHAR2(50),
  servicename     VARCHAR2(50),
  timespan        NUMBER,
  runstatus       VARCHAR2(50),
  runtype         VARCHAR2(50),
  runtypedesc     VARCHAR2(250),
  controltype     VARCHAR2(50),
  controlcode     VARCHAR2(50),
  controltypedesc VARCHAR2(50),
  controllevel    VARCHAR2(50),
  controlflag     VARCHAR2(50),
  triggerfunction VARCHAR2(4000),
  searchfunction  VARCHAR2(4000),
  runfunction     VARCHAR2(4000),
  alarmtitle      VARCHAR2(4000),
  alarmcontent    VARCHAR2(4000),
  alarmip         VARCHAR2(50),
  remark          VARCHAR2(250),
  configlevel     VARCHAR2(50),
  data1           VARCHAR2(50),
  data2           VARCHAR2(50),
  data3           VARCHAR2(50),
  data4           VARCHAR2(50),
  data5           VARCHAR2(50),
  createtime      DATE,
  createemp       VARCHAR2(50),
  edittime        DATE,
  editemp         VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_SERVICE_ALARM_CONFIG on SFCRUNTIME.R_SERVICE_ALARM_CONFIG (SERVICENAME);
create unique index SFCRUNTIME.PK_R_SERVICE_ALARM_CONFIG on SFCRUNTIME.R_SERVICE_ALARM_CONFIG (ID);

prompt
prompt Creating table R_SERVICE_LOG
prompt ============================
prompt
create table SFCRUNTIME.R_SERVICE_LOG
(
  id              VARCHAR2(50),
  functiontype    VARCHAR2(50),
  lastedittime    DATE,
  currentedittime DATE,
  nextedittime    DATE,
  sourcecode      VARCHAR2(250),
  data1           VARCHAR2(50),
  data2           VARCHAR2(50),
  data3           VARCHAR2(50),
  data4           VARCHAR2(50),
  data5           VARCHAR2(50),
  data6           VARCHAR2(50),
  data7           VARCHAR2(50),
  data8           VARCHAR2(250),
  data9           VARCHAR2(250),
  data10          VARCHAR2(250),
  data11          VARCHAR2(250),
  data12          VARCHAR2(250),
  data13          VARCHAR2(250),
  data14          VARCHAR2(250),
  data15          VARCHAR2(250),
  mailflag        VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_SERVICE_LOG on SFCRUNTIME.R_SERVICE_LOG (FUNCTIONTYPE);
create index SFCRUNTIME.IDX_R_SERVICE_LOG1 on SFCRUNTIME.R_SERVICE_LOG (MAILFLAG, CURRENTEDITTIME, SOURCECODE);
create unique index SFCRUNTIME.PK_R_SERVICE_LOG on SFCRUNTIME.R_SERVICE_LOG (ID);

prompt
prompt Creating table R_SHIP_DETAIL
prompt ============================
prompt
create table SFCRUNTIME.R_SHIP_DETAIL
(
  id          VARCHAR2(50),
  sn          VARCHAR2(50),
  skuno       VARCHAR2(50),
  dn_no       VARCHAR2(20),
  dn_line     VARCHAR2(20),
  shipdate    DATE,
  createby    VARCHAR2(20),
  shiporderid VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_SHIP_DETAIL_SN on SFCRUNTIME.R_SHIP_DETAIL (SN);
create unique index SFCRUNTIME.PK_R_SHIP_DETAIL_ID on SFCRUNTIME.R_SHIP_DETAIL (ID);

prompt
prompt Creating table R_SKU_PLANT
prompt ==========================
prompt
create table SFCRUNTIME.R_SKU_PLANT
(
  id         VARCHAR2(50),
  juniper    VARCHAR2(50),
  foxconn    VARCHAR2(50),
  plantcode  VARCHAR2(50),
  createtime DATE
)
;
create unique index SFCRUNTIME.PK_R_SKU_PLANT on SFCRUNTIME.R_SKU_PLANT (ID);

prompt
prompt Creating table R_SKU_ROUTE
prompt ==========================
prompt
create table SFCRUNTIME.R_SKU_ROUTE
(
  id           VARCHAR2(50),
  route_id     VARCHAR2(50),
  sku_id       VARCHAR2(50),
  default_flag VARCHAR2(1),
  edit_time    DATE,
  edit_emp     VARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_R_SKU_ROUTE on SFCRUNTIME.R_SKU_ROUTE (ID);

prompt
prompt Creating table R_SKU_ROUTE_EX
prompt =============================
prompt
create table SFCRUNTIME.R_SKU_ROUTE_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCRUNTIME.PK_R_SKU_ROUTE_EX on SFCRUNTIME.R_SKU_ROUTE_EX (ID, SEQ_NO);

prompt
prompt Creating table R_SN
prompt ===================
prompt
create table SFCRUNTIME.R_SN
(
  id                 VARCHAR2(50),
  sn                 VARCHAR2(50),
  skuno              VARCHAR2(50),
  workorderno        VARCHAR2(50),
  plant              VARCHAR2(50),
  route_id           VARCHAR2(50),
  started_flag       VARCHAR2(1) default 0,
  start_time         DATE,
  packed_flag        VARCHAR2(1) default 0,
  packdate           DATE,
  completed_flag     VARCHAR2(1) default 0,
  completed_time     DATE,
  shipped_flag       VARCHAR2(1) default 0,
  shipdate           DATE,
  repair_failed_flag VARCHAR2(1) default 0,
  current_station    VARCHAR2(50),
  next_station       VARCHAR2(50),
  kp_list_id         VARCHAR2(50),
  po_no              VARCHAR2(50),
  cust_order_no      VARCHAR2(50),
  cust_pn            VARCHAR2(50),
  boxsn              VARCHAR2(50),
  scraped_flag       VARCHAR2(2) default 0,
  scraped_time       DATE,
  product_status     VARCHAR2(20),
  rework_count       NUMBER,
  valid_flag         VARCHAR2(1) default 1,
  stock_status       VARCHAR2(1) default 0,
  stock_in_time      DATE,
  edit_emp           VARCHAR2(50),
  edit_time          DATE
)
;
create index SFCRUNTIME.IDX_R_SN1 on SFCRUNTIME.R_SN (SKUNO);
create index SFCRUNTIME.IDX_R_SN2 on SFCRUNTIME.R_SN (WORKORDERNO);
create index SFCRUNTIME.IDX_R_SN3 on SFCRUNTIME.R_SN (SN);
create index SFCRUNTIME.IDX_R_SN4 on SFCRUNTIME.R_SN (BOXSN);
create index SFCRUNTIME.IDX_R_SN5 on SFCRUNTIME.R_SN (VALID_FLAG);
create unique index SFCRUNTIME.PK_R_SN on SFCRUNTIME.R_SN (ID);

prompt
prompt Creating table R_SN_EX
prompt ======================
prompt
create table SFCRUNTIME.R_SN_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCRUNTIME.PK_R_SN_EX on SFCRUNTIME.R_SN_EX (ID, SEQ_NO);

prompt
prompt Creating table R_SN_KEYPART_DETAIL
prompt ==================================
prompt
create table SFCRUNTIME.R_SN_KEYPART_DETAIL
(
  id            VARCHAR2(50),
  r_sn_id       VARCHAR2(50),
  sn            VARCHAR2(50),
  keypart_sn    VARCHAR2(50),
  station_name  VARCHAR2(50),
  part_no       VARCHAR2(50),
  seq_no        NUMBER,
  category_name VARCHAR2(50),
  category      VARCHAR2(50),
  original_csn  VARCHAR2(50),
  mpn           VARCHAR2(50),
  old_mpn       VARCHAR2(50),
  mfr_name      VARCHAR2(50),
  old_mfr_name  VARCHAR2(50),
  valid         VARCHAR2(2),
  create_emp    VARCHAR2(50),
  create_time   DATE,
  edit_emp      VARCHAR2(50),
  edit_time     DATE
)
;
create index SFCRUNTIME.IDX_R_SN_KEYPART_DETAIL0 on SFCRUNTIME.R_SN_KEYPART_DETAIL (PART_NO, STATION_NAME, SN, KEYPART_SN);
create index SFCRUNTIME.IDX_R_SN_KEYPART_DETAIL1 on SFCRUNTIME.R_SN_KEYPART_DETAIL (KEYPART_SN);
create unique index SFCRUNTIME.PK_R_SN_KEYPART_DETAIL on SFCRUNTIME.R_SN_KEYPART_DETAIL (ID);

prompt
prompt Creating table R_SN_KEYPART_DETAIL_EX
prompt =====================================
prompt
create table SFCRUNTIME.R_SN_KEYPART_DETAIL_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCRUNTIME.PK_R_SN_KEYPART_DETAIL_EX on SFCRUNTIME.R_SN_KEYPART_DETAIL_EX (ID, SEQ_NO);

prompt
prompt Creating table R_SN_KP
prompt ======================
prompt
create table SFCRUNTIME.R_SN_KP
(
  id         VARCHAR2(50),
  r_sn_id    VARCHAR2(50),
  sn         VARCHAR2(50),
  value      VARCHAR2(100),
  partno     VARCHAR2(50),
  kp_name    VARCHAR2(20),
  mpn        VARCHAR2(50),
  scantype   VARCHAR2(50),
  itemseq    NUMBER,
  scanseq    NUMBER,
  detailseq  NUMBER,
  station    VARCHAR2(10),
  regex      VARCHAR2(200),
  valid_flag NUMBER,
  exkey1     VARCHAR2(10),
  exvalue1   VARCHAR2(50),
  exkey2     VARCHAR2(10),
  exvalue2   VARCHAR2(50),
  edit_time  DATE,
  edit_emp   VARCHAR2(20),
  location   VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_SN_KP_ID on SFCRUNTIME.R_SN_KP (ID);
create index SFCRUNTIME.IDX_R_SN_KP_SN on SFCRUNTIME.R_SN_KP (SN);
create index SFCRUNTIME.IDX_R_SN_KP_SN_ID on SFCRUNTIME.R_SN_KP (R_SN_ID);
create index SFCRUNTIME.IDX_R_SN_KP_VALUE on SFCRUNTIME.R_SN_KP (VALUE);
create index SFCRUNTIME.IDX_SCANTYPE on SFCRUNTIME.R_SN_KP (SCANTYPE);
create index SFCRUNTIME.IDX_STATION on SFCRUNTIME.R_SN_KP (STATION);
create index SFCRUNTIME.IDX_VALID_FLAG on SFCRUNTIME.R_SN_KP (VALID_FLAG);
create index SFCRUNTIME.R_SN_KP_ET on SFCRUNTIME.R_SN_KP (EDIT_TIME);
create index SFCRUNTIME.R_SN_KP_SVR on SFCRUNTIME.R_SN_KP (STATION, VALID_FLAG, R_SN_ID);
grant select, insert, update, delete on SFCRUNTIME.R_SN_KP to TEST;

prompt
prompt Creating table R_SN_LINK
prompt ========================
prompt
create table SFCRUNTIME.R_SN_LINK
(
  id         NVARCHAR2(50),
  linktype   NVARCHAR2(20),
  model      NVARCHAR2(20),
  sn         NVARCHAR2(50),
  csn        NVARCHAR2(50),
  validflag  NVARCHAR2(10),
  createtime DATE,
  createby   NVARCHAR2(20),
  edittime   DATE,
  editby     NVARCHAR2(20)
)
;
create index SFCRUNTIME.IDX_R_SN_LINK on SFCRUNTIME.R_SN_LINK (SN, CSN, VALIDFLAG, LINKTYPE);
create unique index SFCRUNTIME.PK_R_SN_LINK on SFCRUNTIME.R_SN_LINK (ID);
grant select, insert, update, delete on SFCRUNTIME.R_SN_LINK to TEST;

prompt
prompt Creating table R_SN_LOCK
prompt ========================
prompt
create table SFCRUNTIME.R_SN_LOCK
(
  id            VARCHAR2(50),
  lock_lot      VARCHAR2(50),
  sn            VARCHAR2(50),
  type          VARCHAR2(50),
  workorderno   VARCHAR2(50),
  lock_station  VARCHAR2(50),
  lock_status   VARCHAR2(1),
  lock_reason   VARCHAR2(300),
  unlock_reason VARCHAR2(300),
  lock_emp      VARCHAR2(50),
  lock_time     DATE,
  unlock_emp    VARCHAR2(50),
  unlock_time   DATE
)
;
create index SFCRUNTIME.IDX_R_SN_LOCK0 on SFCRUNTIME.R_SN_LOCK (LOCK_LOT);
create index SFCRUNTIME.IDX_R_SN_LOCK1 on SFCRUNTIME.R_SN_LOCK (LOCK_STATUS);
create index SFCRUNTIME.IDX_R_SN_LOCK2 on SFCRUNTIME.R_SN_LOCK (SN, LOCK_STATUS);
create unique index SFCRUNTIME.PK_R_SN_LOCK on SFCRUNTIME.R_SN_LOCK (ID);
create unique index SFCRUNTIME.UNQ_R_SN_LOCK on SFCRUNTIME.R_SN_LOCK (TYPE, SN, LOCK_TIME, WORKORDERNO);

prompt
prompt Creating table R_SN_LOG
prompt =======================
prompt
create table SFCRUNTIME.R_SN_LOG
(
  id         VARCHAR2(50),
  snid       VARCHAR2(50),
  sn         VARCHAR2(50),
  logtype    VARCHAR2(50),
  data1      VARCHAR2(50),
  data2      VARCHAR2(50),
  data3      VARCHAR2(50),
  data4      VARCHAR2(50),
  data5      VARCHAR2(50),
  data6      VARCHAR2(50),
  data7      VARCHAR2(500),
  data8      VARCHAR2(500),
  data9      VARCHAR2(500),
  flag       VARCHAR2(2),
  createtime DATE,
  createby   VARCHAR2(15)
)
;
create index SFCRUNTIME.IDX_R_SN_LOG0 on SFCRUNTIME.R_SN_LOG (SN);
create index SFCRUNTIME.IDX_R_SN_LOG1 on SFCRUNTIME.R_SN_LOG (LOGTYPE);
create index SFCRUNTIME.IDX_R_SN_LOG2 on SFCRUNTIME.R_SN_LOG (SNID);
create unique index SFCRUNTIME.PK_R_SN_LOG on SFCRUNTIME.R_SN_LOG (ID);
grant select, insert, update, delete on SFCRUNTIME.R_SN_LOG to TEST;

prompt
prompt Creating table R_SN_OVERPACK
prompt ============================
prompt
create table SFCRUNTIME.R_SN_OVERPACK
(
  id         VARCHAR2(50) not null,
  dn_no      VARCHAR2(20),
  dn_line    VARCHAR2(10),
  pack_no    NUMBER,
  sn         VARCHAR2(50),
  sn_id      VARCHAR2(50),
  valid_flag NUMBER,
  edit_emp   VARCHAR2(20),
  edit_time  DATE,
  ext_key1   VARCHAR2(50),
  ext_value1 VARCHAR2(50),
  ext_key2   VARCHAR2(50),
  ext_value2 VARCHAR2(50)
)
;
create index SFCRUNTIME.K1_R_SN_OVERPACK on SFCRUNTIME.R_SN_OVERPACK (DN_NO);
create index SFCRUNTIME.K2_R_SN_OVERPACK on SFCRUNTIME.R_SN_OVERPACK (SN);
alter table SFCRUNTIME.R_SN_OVERPACK
  add constraint PK_R_SN_OVERPACK primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_SN_OVERPACK to TEST;

prompt
prompt Creating table R_SN_PACKING
prompt ===========================
prompt
create table SFCRUNTIME.R_SN_PACKING
(
  id        VARCHAR2(50),
  sn_id     VARCHAR2(50),
  pack_id   VARCHAR2(50),
  edit_time DATE,
  edit_emp  VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_SN_PACKING1 on SFCRUNTIME.R_SN_PACKING (SN_ID, PACK_ID);
create index SFCRUNTIME.IDX_R_SN_PACKING2 on SFCRUNTIME.R_SN_PACKING (SN_ID);
create index SFCRUNTIME.IDX_R_SN_PACKING3 on SFCRUNTIME.R_SN_PACKING (PACK_ID);
create unique index SFCRUNTIME.PK_R_SN_PACKING on SFCRUNTIME.R_SN_PACKING (ID);

prompt
prompt Creating table R_SN_PASS
prompt ========================
prompt
create table SFCRUNTIME.R_SN_PASS
(
  id            VARCHAR2(50),
  lotno         VARCHAR2(50),
  sn            VARCHAR2(50),
  type          VARCHAR2(50),
  workorderno   VARCHAR2(50),
  pass_station  VARCHAR2(50),
  status        VARCHAR2(1),
  reason        VARCHAR2(300),
  cancel_reason VARCHAR2(300),
  create_emp    VARCHAR2(50),
  create_time   DATE,
  cancel_emp    VARCHAR2(50),
  cancel_time   DATE
)
;
create index SFCRUNTIME.IDX_R_SN_PASS0 on SFCRUNTIME.R_SN_PASS (LOTNO);
create index SFCRUNTIME.IDX_R_SN_PASS2 on SFCRUNTIME.R_SN_PASS (SN, STATUS);
create unique index SFCRUNTIME.PK_R_SN_PASS on SFCRUNTIME.R_SN_PASS (ID);
create unique index SFCRUNTIME.UNQ_R_SN_PASS on SFCRUNTIME.R_SN_PASS (TYPE, SN, CREATE_TIME, WORKORDERNO);

prompt
prompt Creating table R_SN_REPLACE
prompt ===========================
prompt
create table SFCRUNTIME.R_SN_REPLACE
(
  id         NVARCHAR2(50),
  linktype   NVARCHAR2(20),
  newsn      NVARCHAR2(50),
  oldsn      NVARCHAR2(50),
  boxsn      NVARCHAR2(50),
  station    NVARCHAR2(20),
  remark     NVARCHAR2(100),
  flag       NVARCHAR2(10),
  createtime DATE,
  createby   NVARCHAR2(20),
  edittime   DATE,
  editby     NVARCHAR2(20)
)
;
create index SFCRUNTIME.IDX_R_SN_REPLACE on SFCRUNTIME.R_SN_REPLACE (NEWSN, OLDSN, LINKTYPE);
create unique index SFCRUNTIME.PK_R_SN_REPLACE on SFCRUNTIME.R_SN_REPLACE (ID);
grant select, insert, update, delete on SFCRUNTIME.R_SN_REPLACE to TEST;

prompt
prompt Creating table R_SN_STATION_DETAIL
prompt ==================================
prompt
create table SFCRUNTIME.R_SN_STATION_DETAIL
(
  id                 VARCHAR2(50),
  r_sn_id            VARCHAR2(50),
  sn                 VARCHAR2(50),
  skuno              VARCHAR2(50),
  workorderno        VARCHAR2(50),
  plant              VARCHAR2(50),
  class_name         VARCHAR2(50),
  route_id           VARCHAR2(50),
  line               VARCHAR2(50),
  started_flag       VARCHAR2(1) default 0,
  start_time         DATE,
  packed_flag        VARCHAR2(1) default 0,
  packed_time        DATE,
  completed_flag     VARCHAR2(1) default 0,
  completed_time     DATE,
  shipped_flag       VARCHAR2(1) default 0,
  shipdate           DATE,
  repair_failed_flag VARCHAR2(1) default 0,
  current_station    VARCHAR2(50),
  next_station       VARCHAR2(50),
  kp_list_id         VARCHAR2(50),
  po_no              VARCHAR2(50),
  cust_order_no      VARCHAR2(50),
  cust_pn            VARCHAR2(50),
  boxsn              VARCHAR2(50),
  device_name        VARCHAR2(50),
  station_name       VARCHAR2(50),
  scraped_flag       VARCHAR2(2) default 0,
  scraped_time       DATE,
  product_status     VARCHAR2(50),
  rework_count       NUMBER,
  valid_flag         VARCHAR2(1) default 1,
  edit_emp           VARCHAR2(50),
  edit_time          DATE
)
;
create index SFCRUNTIME.IDX_R_SN_STATION_DETAIL1 on SFCRUNTIME.R_SN_STATION_DETAIL (SN);
create index SFCRUNTIME.IDX_R_SN_STATION_DETAIL2 on SFCRUNTIME.R_SN_STATION_DETAIL (SKUNO);
create index SFCRUNTIME.IDX_R_SN_STATION_DETAIL3 on SFCRUNTIME.R_SN_STATION_DETAIL (WORKORDERNO);
create index SFCRUNTIME.IDX_R_SN_STATION_DETAIL4 on SFCRUNTIME.R_SN_STATION_DETAIL (EDIT_TIME, CURRENT_STATION);
create index SFCRUNTIME.IDX_R_SN_STATION_DETAIL5 on SFCRUNTIME.R_SN_STATION_DETAIL (STATION_NAME);
create index SFCRUNTIME.IDX_R_SN_STATION_DETAIL6 on SFCRUNTIME.R_SN_STATION_DETAIL (NVL(R_SN_ID,'0'));
create index SFCRUNTIME.IDX_R_SN_STATION_DETAIL7 on SFCRUNTIME.R_SN_STATION_DETAIL (NVL(R_SN_ID,'0'), STATION_NAME);
create unique index SFCRUNTIME.PK_R_SN_STATION_DETAIL on SFCRUNTIME.R_SN_STATION_DETAIL (ID);

prompt
prompt Creating table R_SO
prompt ===================
prompt
create table SFCRUNTIME.R_SO
(
  id               VARCHAR2(50) not null,
  so_no            VARCHAR2(50),
  bill_to_code     VARCHAR2(10),
  status           VARCHAR2(10),
  enable_date_from DATE,
  enable_date_to   DATE,
  ext_key1         VARCHAR2(20),
  ext_value1       VARCHAR2(50),
  ext_key2         VARCHAR2(20),
  ext_value2       VARCHAR2(50),
  ext_key3         VARCHAR2(20),
  ext_value3       VARCHAR2(50),
  edit_date        DATE,
  edit_emp         VARCHAR2(20)
)
;
alter table SFCRUNTIME.R_SO
  add constraint PK_R_SO primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_SO to TEST;

prompt
prompt Creating table R_SO_DETAIL
prompt ==========================
prompt
create table SFCRUNTIME.R_SO_DETAIL
(
  id         VARCHAR2(50) not null,
  r_so_id    VARCHAR2(50),
  so_no      VARCHAR2(50),
  line_seq   VARCHAR2(10),
  skuno      VARCHAR2(50),
  qty        NUMBER,
  dn_qty     NUMBER,
  ext_key1   VARCHAR2(20),
  ext_value1 VARCHAR2(50),
  ext_key2   VARCHAR2(20),
  ext_value2 VARCHAR2(50),
  edit_date  DATE,
  edit_emp   VARCHAR2(20)
)
;
alter table SFCRUNTIME.R_SO_DETAIL
  add constraint PK_R_SO_DETAIL primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_SO_DETAIL to TEST;

prompt
prompt Creating table R_SO_FILE
prompt ========================
prompt
create table SFCRUNTIME.R_SO_FILE
(
  id        VARCHAR2(50) not null,
  vbeln     VARCHAR2(50),
  posnr     VARCHAR2(50),
  matnr     VARCHAR2(50),
  bstnk     VARCHAR2(50),
  kwmeng    VARCHAR2(50),
  cmpre     VARCHAR2(50),
  kunnr     VARCHAR2(50),
  kunnv     VARCHAR2(50),
  arktx     VARCHAR2(500),
  name      VARCHAR2(500),
  land1     VARCHAR2(50),
  netpr     VARCHAR2(50),
  status    VARCHAR2(20),
  edit_emp  VARCHAR2(20),
  edit_date DATE
)
;
comment on column SFCRUNTIME.R_SO_FILE.vbeln
  is 'SO_NO';
comment on column SFCRUNTIME.R_SO_FILE.posnr
  is 'SO_LINE_SEQ';
comment on column SFCRUNTIME.R_SO_FILE.matnr
  is 'SKUNO';
comment on column SFCRUNTIME.R_SO_FILE.kwmeng
  is 'QTY';
comment on column SFCRUNTIME.R_SO_FILE.kunnr
  is 'CUST_NO';
comment on column SFCRUNTIME.R_SO_FILE.kunnv
  is 'SHIP_CUST_NO';
comment on column SFCRUNTIME.R_SO_FILE.arktx
  is 'DESC';
comment on column SFCRUNTIME.R_SO_FILE.name
  is 'CUST_NAME';
comment on column SFCRUNTIME.R_SO_FILE.land1
  is 'BILLTOCODE';
create index SFCRUNTIME.KEY1_R_SO_FILE on SFCRUNTIME.R_SO_FILE (VBELN);
alter table SFCRUNTIME.R_SO_FILE
  add constraint PK_R_SO_FILE primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_SO_FILE to TEST;

prompt
prompt Creating table R_STATION
prompt ========================
prompt
create table SFCRUNTIME.R_STATION
(
  id                   VARCHAR2(50),
  display_station_name VARCHAR2(50),
  station_name         VARCHAR2(50),
  fail_station_id      VARCHAR2(50),
  fail_station_flag    NUMBER(38),
  edit_time            DATE,
  edit_emp             VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_STATION0 on SFCRUNTIME.R_STATION (DISPLAY_STATION_NAME, STATION_NAME, FAIL_STATION_ID, FAIL_STATION_FLAG);
create unique index SFCRUNTIME.PK_R_STATION on SFCRUNTIME.R_STATION (ID);

prompt
prompt Creating table R_STATION_ACTION
prompt ===============================
prompt
create table SFCRUNTIME.R_STATION_ACTION
(
  id                  VARCHAR2(50),
  r_station_input_id  VARCHAR2(50),
  c_station_action_id VARCHAR2(50),
  seq_no              NUMBER(38),
  config_type         VARCHAR2(20),
  config_value        VARCHAR2(50),
  add_flag            NUMBER(38),
  edit_time           DATE,
  edit_emp            VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_STATION_ACTION0 on SFCRUNTIME.R_STATION_ACTION (R_STATION_INPUT_ID);
create index SFCRUNTIME.IDX_R_STATION_ACTION1 on SFCRUNTIME.R_STATION_ACTION (CONFIG_TYPE, CONFIG_VALUE);
create unique index SFCRUNTIME.PK_R_STATION_ACTION on SFCRUNTIME.R_STATION_ACTION (ID);

prompt
prompt Creating table R_STATION_ACTION_PARA
prompt ====================================
prompt
create table SFCRUNTIME.R_STATION_ACTION_PARA
(
  id                  VARCHAR2(50),
  r_station_action_id VARCHAR2(50),
  r_input_action_id   VARCHAR2(50),
  seq_no              NUMBER(38),
  session_type        VARCHAR2(50),
  session_key         VARCHAR2(50),
  value               VARCHAR2(50),
  edit_time           DATE,
  edit_emp            VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_STATION_ACTION_PARA0 on SFCRUNTIME.R_STATION_ACTION_PARA (R_STATION_ACTION_ID, R_INPUT_ACTION_ID);
create unique index SFCRUNTIME.PK_R_STATION_ACTION_PARA on SFCRUNTIME.R_STATION_ACTION_PARA (ID);

prompt
prompt Creating table R_STATION_AUTOSCAN
prompt =================================
prompt
create table SFCRUNTIME.R_STATION_AUTOSCAN
(
  id           VARCHAR2(50),
  skuno        VARCHAR2(50),
  routeid      VARCHAR2(50),
  pack_type    VARCHAR2(20),
  label_type   VARCHAR2(20),
  currentpoint VARCHAR2(50),
  nextpoint    VARCHAR2(50),
  palletqty    VARCHAR2(50),
  productname  VARCHAR2(50),
  field1       VARCHAR2(50),
  ppid_flag    VARCHAR2(10),
  label_flag   VARCHAR2(10),
  edit_time    DATE,
  edit_emp     VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_R_STATION_AUTOSCAN0 on SFCRUNTIME.R_STATION_AUTOSCAN (SKUNO);
create unique index SFCRUNTIME.PK_R_STATION_AUTOSCAN on SFCRUNTIME.R_STATION_AUTOSCAN (ID);
grant select, insert, update, delete on SFCRUNTIME.R_STATION_AUTOSCAN to TEST;

prompt
prompt Creating table R_STATION_INPUT
prompt ==============================
prompt
create table SFCRUNTIME.R_STATION_INPUT
(
  id                  VARCHAR2(50),
  station_id          VARCHAR2(50),
  input_id            VARCHAR2(50),
  seq_no              NUMBER(38),
  scan_flag           NUMBER(38),
  display_name        VARCHAR2(50),
  remember_last_input VARCHAR2(200),
  edit_time           DATE,
  edit_emp            VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_STATION_INPUT0 on SFCRUNTIME.R_STATION_INPUT (STATION_ID);
create unique index SFCRUNTIME.PK_R_STATION_INPUT on SFCRUNTIME.R_STATION_INPUT (ID);

prompt
prompt Creating table R_STATION_OUTPUT
prompt ===============================
prompt
create table SFCRUNTIME.R_STATION_OUTPUT
(
  id           VARCHAR2(50),
  r_station_id VARCHAR2(50),
  name         VARCHAR2(50),
  seq_no       NUMBER(38),
  display_type VARCHAR2(20),
  session_type VARCHAR2(50),
  session_key  VARCHAR2(50),
  edit_time    DATE,
  edit_emp     VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_STATION_OUTPUT0 on SFCRUNTIME.R_STATION_OUTPUT (R_STATION_ID);
create unique index SFCRUNTIME.PK_R_STATION_OUTPUT on SFCRUNTIME.R_STATION_OUTPUT (ID);

prompt
prompt Creating table R_STATION_SCAN_LOG
prompt =================================
prompt
create table SFCRUNTIME.R_STATION_SCAN_LOG
(
  scankey    VARCHAR2(50),
  errmsg     VARCHAR2(150),
  station    VARCHAR2(20),
  line       VARCHAR2(10),
  ip         VARCHAR2(15),
  empno      VARCHAR2(10),
  actionname VARCHAR2(50),
  classname  VARCHAR2(100),
  createtime DATE,
  createby   VARCHAR2(10)
)
;
create index SFCRUNTIME.IDX_R_STATION_SCAN_LOG0 on SFCRUNTIME.R_STATION_SCAN_LOG (SCANKEY);
create index SFCRUNTIME.IDX_R_STATION_SCAN_LOG1 on SFCRUNTIME.R_STATION_SCAN_LOG (STATION);
create index SFCRUNTIME.IDX_R_STATION_SCAN_LOG2 on SFCRUNTIME.R_STATION_SCAN_LOG (CREATETIME);
create index SFCRUNTIME.IDX_R_STATION_SCAN_LOG3 on SFCRUNTIME.R_STATION_SCAN_LOG (LINE, IP);
grant select, insert, update, delete on SFCRUNTIME.R_STATION_SCAN_LOG to TEST;

prompt
prompt Creating table R_STOCK
prompt ======================
prompt
create table SFCRUNTIME.R_STOCK
(
  id             VARCHAR2(50),
  sn             VARCHAR2(50),
  workorderno    VARCHAR2(50),
  skuno          VARCHAR2(50),
  next_station   VARCHAR2(50),
  from_storage   VARCHAR2(50),
  to_storage     VARCHAR2(50),
  confirmed_flag VARCHAR2(1),
  sap_flag       VARCHAR2(1),
  edit_emp       VARCHAR2(50),
  edit_time      DATE,
  backflush_time DATE,
  gt_id          VARCHAR2(50),
  stock_type     VARCHAR2(1)
)
;
comment on column SFCRUNTIME.R_STOCK.id
  is 'ID號';
comment on column SFCRUNTIME.R_STOCK.sn
  is '產品SN';
comment on column SFCRUNTIME.R_STOCK.workorderno
  is '工單號';
comment on column SFCRUNTIME.R_STOCK.skuno
  is '機種料號';
comment on column SFCRUNTIME.R_STOCK.next_station
  is '下一站';
comment on column SFCRUNTIME.R_STOCK.from_storage
  is '起始倉碼 ';
comment on column SFCRUNTIME.R_STOCK.to_storage
  is '目的倉碼';
comment on column SFCRUNTIME.R_STOCK.confirmed_flag
  is '拋帳類型(0 代表既拋帳又轉倉，1只轉倉)';
comment on column SFCRUNTIME.R_STOCK.sap_flag
  is '拋帳返回標誌(0,未拋賬;1,拋帳OK;其它拋帳Fail)';
comment on column SFCRUNTIME.R_STOCK.edit_emp
  is '編輯人';
comment on column SFCRUNTIME.R_STOCK.edit_time
  is '編輯時間';
comment on column SFCRUNTIME.R_STOCK.backflush_time
  is '拋賬時間';
comment on column SFCRUNTIME.R_STOCK.gt_id
  is '拋賬ID號';
comment on column SFCRUNTIME.R_STOCK.stock_type
  is '操作類型(0從半成品倉轉到成品倉,其餘字符標誌待定)';
create index SFCRUNTIME.IDX_R_STOCK_GT_ID on SFCRUNTIME.R_STOCK (GT_ID);
create index SFCRUNTIME.IDX_R_STOCK_SN on SFCRUNTIME.R_STOCK (SN);
create index SFCRUNTIME.IDX_R_STOCK_WO on SFCRUNTIME.R_STOCK (WORKORDERNO);
create unique index SFCRUNTIME.PK_R_STOCK_ID on SFCRUNTIME.R_STOCK (ID);

prompt
prompt Creating table R_STOCK_GT
prompt =========================
prompt
create table SFCRUNTIME.R_STOCK_GT
(
  id               VARCHAR2(50),
  skuno            VARCHAR2(50),
  workorderno      VARCHAR2(50),
  total_qty        NUMBER,
  from_storage     VARCHAR2(50),
  to_storage       VARCHAR2(50),
  confirmed_flag   VARCHAR2(1),
  sap_flag         VARCHAR2(1),
  sap_message      VARCHAR2(200),
  edit_emp         VARCHAR2(50),
  edit_time        DATE,
  backflush_time   DATE,
  sap_station_code VARCHAR2(50),
  stock_type       VARCHAR2(1)
)
;
comment on column SFCRUNTIME.R_STOCK_GT.id
  is 'ID號';
comment on column SFCRUNTIME.R_STOCK_GT.skuno
  is '機種料號';
comment on column SFCRUNTIME.R_STOCK_GT.workorderno
  is '工單號';
comment on column SFCRUNTIME.R_STOCK_GT.total_qty
  is '拋帳數量';
comment on column SFCRUNTIME.R_STOCK_GT.from_storage
  is '起始倉碼 ';
comment on column SFCRUNTIME.R_STOCK_GT.to_storage
  is '目的倉碼 ';
comment on column SFCRUNTIME.R_STOCK_GT.confirmed_flag
  is '拋帳類型(0 代表既拋帳又轉倉，1只轉倉)';
comment on column SFCRUNTIME.R_STOCK_GT.sap_flag
  is '拋帳返回標誌(0,未拋賬;1,拋帳OK;其它拋帳Fail)';
comment on column SFCRUNTIME.R_STOCK_GT.sap_message
  is 'SAP返回信息';
comment on column SFCRUNTIME.R_STOCK_GT.edit_emp
  is '編輯人';
comment on column SFCRUNTIME.R_STOCK_GT.edit_time
  is '編輯時間';
comment on column SFCRUNTIME.R_STOCK_GT.backflush_time
  is '拋賬時間';
comment on column SFCRUNTIME.R_STOCK_GT.sap_station_code
  is '拋賬Code';
comment on column SFCRUNTIME.R_STOCK_GT.stock_type
  is '操作類型(0從半成品倉轉到成品倉,其餘字符標誌待定)';
create index SFCRUNTIME.IDX_R_STOCK_GT_WO on SFCRUNTIME.R_STOCK_GT (WORKORDERNO);
create unique index SFCRUNTIME.PK_R_STOCK_GT_ID on SFCRUNTIME.R_STOCK_GT (ID);

prompt
prompt Creating table R_SYNC_LOCK
prompt ==========================
prompt
create table SFCRUNTIME.R_SYNC_LOCK
(
  id             VARCHAR2(50),
  lock_name      VARCHAR2(50),
  lock_key       VARCHAR2(50),
  lock_time_long NUMBER,
  lock_time      DATE,
  edit_emp       VARCHAR2(50),
  lock_ip        VARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_R_SYNC_LOCK on SFCRUNTIME.R_SYNC_LOCK (ID);

prompt
prompt Creating table R_TEST_BRCD
prompt ==========================
prompt
create table SFCRUNTIME.R_TEST_BRCD
(
  id               VARCHAR2(50) not null,
  sysserialno      VARCHAR2(50),
  testdate         DATE,
  eventname        VARCHAR2(30),
  status           VARCHAR2(20),
  partno           VARCHAR2(20),
  sfpmpn           VARCHAR2(20),
  location         VARCHAR2(100),
  symptom          VARCHAR2(100),
  pcbasn           VARCHAR2(20),
  pcbapn           VARCHAR2(20),
  vsn              VARCHAR2(20),
  vpn              VARCHAR2(20),
  csn              VARCHAR2(20),
  cpn              VARCHAR2(20),
  frupcbasn        VARCHAR2(20),
  testreportname   VARCHAR2(200),
  lasteditdt       DATE,
  lasteditby       VARCHAR2(20),
  failurecode      VARCHAR2(20),
  tray_sn          VARCHAR2(20),
  testerno         VARCHAR2(80),
  temp4            NUMBER,
  temp5            NUMBER,
  tatime           DATE,
  bk1_key          VARCHAR2(20),
  bk1_value        VARCHAR2(50),
  bk2_key          VARCHAR2(20),
  bk2_value        VARCHAR2(50),
  bk3_key          VARCHAR2(20),
  bk3_value        VARCHAR2(50),
  bk4_key          VARCHAR2(20),
  bk4_value        VARCHAR2(50),
  r_test_record_id VARCHAR2(50)
)
;
create index SFCRUNTIME.I_R_TEST_BRCD1 on SFCRUNTIME.R_TEST_BRCD (SYSSERIALNO);
alter table SFCRUNTIME.R_TEST_BRCD
  add constraint PK_R_TEST_BRCD primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_TEST_BRCD to TEST;

prompt
prompt Creating table R_TEST_DETAIL_VERTIV
prompt ===================================
prompt
create table SFCRUNTIME.R_TEST_DETAIL_VERTIV
(
  id               VARCHAR2(50),
  r_test_record_id VARCHAR2(50),
  sn               VARCHAR2(50),
  skuno            VARCHAR2(20),
  createtime       DATE,
  state            VARCHAR2(5),
  station          VARCHAR2(10),
  cell             VARCHAR2(5),
  operator         VARCHAR2(10),
  error_code       VARCHAR2(120),
  edit_time        DATE,
  edit_emp         VARCHAR2(50),
  burnin_time      VARCHAR2(10),
  line             VARCHAR2(20)
)
;
create index SFCRUNTIME.IDX_RTD_CREATETIME on SFCRUNTIME.R_TEST_DETAIL_VERTIV (CREATETIME);
create index SFCRUNTIME.IDX_TEST_VERTIV_RECORD_ID on SFCRUNTIME.R_TEST_DETAIL_VERTIV (R_TEST_RECORD_ID);
create index SFCRUNTIME.IDX_TEST_VERTIV_SKUNO on SFCRUNTIME.R_TEST_DETAIL_VERTIV (SKUNO, STATION);
create index SFCRUNTIME.IDX_TEST_VERTIV_SN on SFCRUNTIME.R_TEST_DETAIL_VERTIV (SN);
grant select, insert, update, delete on SFCRUNTIME.R_TEST_DETAIL_VERTIV to TEST;

prompt
prompt Creating table R_TEST_JUNIPER
prompt =============================
prompt
create table SFCRUNTIME.R_TEST_JUNIPER
(
  id                   VARCHAR2(50) not null,
  sysserialno          VARCHAR2(50),
  testdate             DATE,
  eventname            VARCHAR2(30),
  status               VARCHAR2(20),
  part_number          VARCHAR2(50),
  cm_odm_partnumber    VARCHAR2(50),
  serial_number        VARCHAR2(50),
  phase                VARCHAR2(50),
  part_number_revision VARCHAR2(50),
  unique_test_id       VARCHAR2(50),
  test_start_timestamp DATE,
  test_step            VARCHAR2(50),
  test_cycle_test_loop VARCHAR2(50),
  capture_time         DATE,
  test_result          VARCHAR2(50),
  failcode             VARCHAR2(50),
  test_station_number  VARCHAR2(50),
  test_station_name    VARCHAR2(50),
  load_date            DATE,
  file_name            VARCHAR2(250),
  lasteditdt           DATE,
  lasteditby           VARCHAR2(20),
  testerno             VARCHAR2(80),
  tatime               DATE,
  r_test_record_id     VARCHAR2(50)
)
;
create index SFCRUNTIME.R_TEST_JUNIPER_IDX1 on SFCRUNTIME.R_TEST_JUNIPER (SYSSERIALNO);
alter table SFCRUNTIME.R_TEST_JUNIPER
  add constraint PK_R_TEST_JUNIPER primary key (ID);
grant select, insert, update, delete on SFCRUNTIME.R_TEST_JUNIPER to TEST;

prompt
prompt Creating table R_TEST_RECORD
prompt ============================
prompt
create table SFCRUNTIME.R_TEST_RECORD
(
  id          VARCHAR2(50),
  r_sn_id     VARCHAR2(50),
  sn          VARCHAR2(50),
  state       VARCHAR2(10),
  tegroup     VARCHAR2(10),
  testation   VARCHAR2(20),
  messtation  VARCHAR2(20),
  device      VARCHAR2(50),
  starttime   DATE,
  endtime     DATE,
  detailtable VARCHAR2(50),
  edit_time   DATE,
  edit_emp    VARCHAR2(50),
  testinfo    VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_RTR_ID on SFCRUNTIME.R_TEST_RECORD (ID);
create index SFCRUNTIME.IDX_R_TEST_RECORD_MESSTATION on SFCRUNTIME.R_TEST_RECORD (MESSTATION);
create index SFCRUNTIME.IDX_R_TEST_RECORD_SN on SFCRUNTIME.R_TEST_RECORD (SN);
create index SFCRUNTIME.IDX_R_TEST_RECORD_SN_ID on SFCRUNTIME.R_TEST_RECORD (R_SN_ID);
create index SFCRUNTIME.IDX_R_TEST_RECORD_STATE on SFCRUNTIME.R_TEST_RECORD (STATE);
grant select, insert, update, delete on SFCRUNTIME.R_TEST_RECORD to TEST;

prompt
prompt Creating table R_UPH_DETAIL
prompt ===========================
prompt
create table SFCRUNTIME.R_UPH_DETAIL
(
  id                     VARCHAR2(50),
  work_date              DATE,
  work_time              VARCHAR2(50),
  production_line        VARCHAR2(50),
  class_name             VARCHAR2(50),
  station_name           VARCHAR2(50),
  workorderno            VARCHAR2(50),
  skuno                  VARCHAR2(50),
  sku_name               VARCHAR2(50),
  sku_series             VARCHAR2(50),
  total_fresh_build_qty  NUMBER,
  total_fresh_pass_qty   NUMBER,
  total_fresh_fail_qty   NUMBER,
  total_rework_build_qty NUMBER,
  total_rework_pass_qty  NUMBER,
  total_rework_fail_qty  NUMBER,
  edit_emp               VARCHAR2(50),
  edit_time              DATE
)
;
create unique index SFCRUNTIME.PK_R_UPH_DETAIL on SFCRUNTIME.R_UPH_DETAIL (ID);
create unique index SFCRUNTIME.UNQ_R_UPH_DETAIL on SFCRUNTIME.R_UPH_DETAIL (WORK_DATE, WORK_TIME, PRODUCTION_LINE, CLASS_NAME, STATION_NAME, WORKORDERNO);

prompt
prompt Creating table R_WEIGHT
prompt =======================
prompt
create table SFCRUNTIME.R_WEIGHT
(
  id         VARCHAR2(50),
  snid       VARCHAR2(50),
  station    VARCHAR2(20),
  weight     VARCHAR2(20),
  createtime DATE,
  createby   VARCHAR2(20)
)
;
create index SFCRUNTIME.IDX_R_WEIGHT_1 on SFCRUNTIME.R_WEIGHT (SNID);
create unique index SFCRUNTIME.PK_R_WEIGHT_0 on SFCRUNTIME.R_WEIGHT (ID);
grant select, insert, update, delete on SFCRUNTIME.R_WEIGHT to TEST;

prompt
prompt Creating table R_WO_AGEING
prompt ==========================
prompt
create table SFCRUNTIME.R_WO_AGEING
(
  id               VARCHAR2(50),
  wo               VARCHAR2(50),
  sku              VARCHAR2(50),
  ageing_area_code VARCHAR2(5),
  ageing_type      VARCHAR2(20),
  max_ageing_time  VARCHAR2(3),
  max_time_qty     VARCHAR2(5),
  min_ageing_time  VARCHAR2(3),
  min_time_qty     VARCHAR2(5),
  edit_emp         VARCHAR2(50),
  edit_time        DATE
)
;
create unique index SFCRUNTIME.PK_R_WO_AGEING_ID on SFCRUNTIME.R_WO_AGEING (ID);
grant select, insert, update, delete on SFCRUNTIME.R_WO_AGEING to TEST;

prompt
prompt Creating table R_WO_BASE
prompt ========================
prompt
create table SFCRUNTIME.R_WO_BASE
(
  id              VARCHAR2(50),
  workorderno     VARCHAR2(50),
  plant           VARCHAR2(50),
  release_date    DATE,
  download_date   DATE,
  production_type VARCHAR2(50),
  wo_type         VARCHAR2(50),
  skuno           VARCHAR2(50),
  sku_ver         VARCHAR2(8),
  sku_series      VARCHAR2(50),
  sku_name        VARCHAR2(50),
  sku_desc        VARCHAR2(200),
  cust_pn         VARCHAR2(50),
  cust_pn_ver     VARCHAR2(50),
  customer_name   VARCHAR2(50),
  route_id        VARCHAR2(50),
  start_station   VARCHAR2(50),
  kp_list_id      VARCHAR2(50),
  closed_flag     VARCHAR2(1),
  close_date      DATE,
  workorder_qty   NUMBER,
  input_qty       NUMBER,
  finished_qty    NUMBER,
  scraped_qty     NUMBER,
  stock_location  VARCHAR2(50),
  po_no           VARCHAR2(50),
  cust_order_no   VARCHAR2(50),
  rohs            VARCHAR2(50),
  edit_emp        VARCHAR2(50),
  edit_time       DATE
)
;
create index SFCRUNTIME.IDX_R_WO_BASE0 on SFCRUNTIME.R_WO_BASE (WORKORDERNO);
create index SFCRUNTIME.IDX_R_WO_BASE1 on SFCRUNTIME.R_WO_BASE (SKUNO);
create unique index SFCRUNTIME.PK_R_WO_BASE on SFCRUNTIME.R_WO_BASE (ID);

prompt
prompt Creating table R_WO_BASE_EX
prompt ===========================
prompt
create table SFCRUNTIME.R_WO_BASE_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCRUNTIME.PK_R_WO_BASE_EX on SFCRUNTIME.R_WO_BASE_EX (ID, SEQ_NO);

prompt
prompt Creating table R_WO_COLUMN_MAPPING
prompt ==================================
prompt
create table SFCRUNTIME.R_WO_COLUMN_MAPPING
(
  id          VARCHAR2(50),
  table_from  VARCHAR2(50),
  table_to    VARCHAR2(50),
  column_from VARCHAR2(50),
  column_to   VARCHAR2(50),
  edit_emp    VARCHAR2(50),
  edit_time   DATE
)
;
create unique index SFCRUNTIME.PK_R_WO_COLUMN_MAPPING on SFCRUNTIME.R_WO_COLUMN_MAPPING (ID);
create index SFCRUNTIME.R_WO_COLUMN_MAPPING0 on SFCRUNTIME.R_WO_COLUMN_MAPPING (TABLE_FROM);
create index SFCRUNTIME.R_WO_COLUMN_MAPPING1 on SFCRUNTIME.R_WO_COLUMN_MAPPING (TABLE_TO);

prompt
prompt Creating table R_WO_COLUMN_MAPPING_EX
prompt =====================================
prompt
create table SFCRUNTIME.R_WO_COLUMN_MAPPING_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCRUNTIME.PK_R_WO_COLUMN_MAPPING_EX on SFCRUNTIME.R_WO_COLUMN_MAPPING_EX (ID, SEQ_NO);

prompt
prompt Creating table R_WO_DOWNLOAD
prompt ============================
prompt
create table SFCRUNTIME.R_WO_DOWNLOAD
(
  id             VARCHAR2(50),
  plant          VARCHAR2(35),
  wo             VARCHAR2(35),
  skuno          VARCHAR2(50),
  sku_version    VARCHAR2(50),
  sap_wo_type    VARCHAR2(10),
  wo_qty         NUMBER(22),
  create_time    DATE,
  release_time   DATE,
  rohs           VARCHAR2(20),
  task_order     VARCHAR2(200),
  stokin_storage VARCHAR2(20),
  ecn_no         VARCHAR2(35),
  edit_time      DATE,
  edit_emp       VARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_R_WO_DOWNLOAD on SFCRUNTIME.R_WO_DOWNLOAD (ID);

prompt
prompt Creating table R_WO_DOWNLOAD_EX
prompt ===============================
prompt
create table SFCRUNTIME.R_WO_DOWNLOAD_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCRUNTIME.PK_R_WO_DOWNLOAD_EX on SFCRUNTIME.R_WO_DOWNLOAD_EX (ID, SEQ_NO);

prompt
prompt Creating table R_WO_GROUPID
prompt ===========================
prompt
create table SFCRUNTIME.R_WO_GROUPID
(
  id         VARCHAR2(50),
  wo         VARCHAR2(50),
  groupid    VARCHAR2(50),
  rutype     VARCHAR2(10),
  unitprice  VARCHAR2(70) not null,
  unitweight VARCHAR2(30),
  dwflag     VARCHAR2(30),
  trantime   VARCHAR2(15),
  dw_id      VARCHAR2(15),
  type_iu    VARCHAR2(15),
  skuno      VARCHAR2(15),
  createtime DATE,
  edittime   DATE
)
;
create unique index SFCRUNTIME.PK_R_WO_GROUPID on SFCRUNTIME.R_WO_GROUPID (ID);
grant select, insert, update, delete on SFCRUNTIME.R_WO_GROUPID to TEST;

prompt
prompt Creating table R_WO_HEADER
prompt ==========================
prompt
create table SFCRUNTIME.R_WO_HEADER
(
  id         VARCHAR2(50),
  aufnr      VARCHAR2(50),
  werks      VARCHAR2(50),
  auart      VARCHAR2(50),
  matnr      VARCHAR2(50),
  revlv      VARCHAR2(50),
  kdauf      VARCHAR2(50),
  gstrs      VARCHAR2(50),
  gamng      VARCHAR2(50),
  kdmat      VARCHAR2(50),
  aedat      VARCHAR2(50),
  aenam      VARCHAR2(50),
  matkl      VARCHAR2(50),
  maktx      VARCHAR2(200),
  erdat      VARCHAR2(50),
  gsups      VARCHAR2(50),
  erfzeit    VARCHAR2(50),
  gltrs      VARCHAR2(50),
  glups      VARCHAR2(50),
  lgort      VARCHAR2(50),
  ablad      VARCHAR2(50),
  rohs_value VARCHAR2(50),
  ftrmi      VARCHAR2(50),
  mvgr3      VARCHAR2(50),
  wemng      VARCHAR2(50),
  bismt      VARCHAR2(50),
  charg      VARCHAR2(50),
  saenr      VARCHAR2(50),
  aetxt      VARCHAR2(50),
  gltrp      VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_WO_HEADER0 on SFCRUNTIME.R_WO_HEADER (AUFNR, REVLV);
create unique index SFCRUNTIME.PK_R_WO_HEADER on SFCRUNTIME.R_WO_HEADER (ID);

prompt
prompt Creating table R_WO_HEADER_EX
prompt =============================
prompt
create table SFCRUNTIME.R_WO_HEADER_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCRUNTIME.PK_R_WO_HEADER_EX on SFCRUNTIME.R_WO_HEADER_EX (ID, SEQ_NO);

prompt
prompt Creating table R_WO_ITEM
prompt ========================
prompt
create table SFCRUNTIME.R_WO_ITEM
(
  id        VARCHAR2(50),
  aufnr     VARCHAR2(20),
  posnr     VARCHAR2(20),
  matnr     VARCHAR2(20),
  parts     VARCHAR2(20),
  kdmat     VARCHAR2(40),
  bdmng     VARCHAR2(20),
  meins     VARCHAR2(40),
  revlv     VARCHAR2(10),
  baugr     VARCHAR2(20),
  repno     VARCHAR2(20),
  reppartno VARCHAR2(20),
  auart     VARCHAR2(10),
  aenam     VARCHAR2(20),
  aedat     VARCHAR2(50),
  maktx     VARCHAR2(200),
  matkl     VARCHAR2(50),
  wgbez     VARCHAR2(50),
  alpos     VARCHAR2(10),
  ablad     VARCHAR2(30),
  mvgr3     VARCHAR2(10),
  rgekz     VARCHAR2(10),
  lgort     VARCHAR2(10),
  enmng     VARCHAR2(20),
  dumps     VARCHAR2(5),
  bismt     VARCHAR2(20),
  xloek     VARCHAR2(5),
  shkzg     VARCHAR2(5),
  charg     VARCHAR2(12),
  rspos     VARCHAR2(20),
  vornr     VARCHAR2(5)
)
;
create index SFCRUNTIME.IDX_R_WO_ITEM0 on SFCRUNTIME.R_WO_ITEM (AUFNR);
create index SFCRUNTIME.IDX_R_WO_ITEM1 on SFCRUNTIME.R_WO_ITEM (POSNR);
create unique index SFCRUNTIME.PK_R_WO_ITEM on SFCRUNTIME.R_WO_ITEM (ID);

prompt
prompt Creating table R_WO_ITEM_EX
prompt ===========================
prompt
create table SFCRUNTIME.R_WO_ITEM_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCRUNTIME.PK_R_WO_ITEM_EX on SFCRUNTIME.R_WO_ITEM_EX (ID, SEQ_NO);

prompt
prompt Creating table R_WO_KP_REPALCE
prompt ==============================
prompt
create table SFCRUNTIME.R_WO_KP_REPALCE
(
  id            VARCHAR2(50),
  wo            VARCHAR2(50),
  partno        VARCHAR2(50),
  repalcepartno VARCHAR2(50),
  edit_time     DATE,
  edit_emp      VARCHAR2(20)
)
;
create index SFCRUNTIME.IDX_R_WO_KP_REPALCE_WO on SFCRUNTIME.R_WO_KP_REPALCE (WO);
grant select, insert, update, delete on SFCRUNTIME.R_WO_KP_REPALCE to TEST;

prompt
prompt Creating table R_WO_LINK
prompt ========================
prompt
create table SFCRUNTIME.R_WO_LINK
(
  id         NVARCHAR2(50),
  linktype   NVARCHAR2(50),
  wo         NVARCHAR2(50),
  linkwo     NVARCHAR2(50),
  createtime DATE,
  createby   NVARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_R_WO_LINK on SFCRUNTIME.R_WO_LINK (ID);
grant select, insert, update, delete on SFCRUNTIME.R_WO_LINK to TEST;

prompt
prompt Creating table R_WO_LOG
prompt =======================
prompt
create table SFCRUNTIME.R_WO_LOG
(
  id           VARCHAR2(50),
  functionname VARCHAR2(50),
  skuno        VARCHAR2(50),
  version      VARCHAR2(50),
  workorderno  VARCHAR2(50),
  reason       VARCHAR2(50),
  flag         VARCHAR2(50),
  data1        VARCHAR2(50),
  edittime     DATE,
  editby       VARCHAR2(50)
)
;
create unique index SFCRUNTIME.PK_R_WO_LOG_ID on SFCRUNTIME.R_WO_LOG (ID);

prompt
prompt Creating table R_WO_REGION
prompt ==========================
prompt
create table SFCRUNTIME.R_WO_REGION
(
  id          VARCHAR2(50),
  workorderno VARCHAR2(50),
  skuno       VARCHAR2(50),
  qty         NUMBER,
  min_sn      VARCHAR2(50),
  max_sn      VARCHAR2(50),
  edit_emp    VARCHAR2(20),
  edit_time   DATE
)
;
create index SFCRUNTIME.IDX_R_WO_REGION0 on SFCRUNTIME.R_WO_REGION (WORKORDERNO, QTY);
create index SFCRUNTIME.IDX_R_WO_REGION1 on SFCRUNTIME.R_WO_REGION (SKUNO);
create unique index SFCRUNTIME.PK_R_WO_REGION on SFCRUNTIME.R_WO_REGION (ID);

prompt
prompt Creating table R_WO_REGION_EX
prompt =============================
prompt
create table SFCRUNTIME.R_WO_REGION_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCRUNTIME.PK_R_WO_REGION_EX on SFCRUNTIME.R_WO_REGION_EX (ID, SEQ_NO);

prompt
prompt Creating table R_WO_STATUS_EX
prompt =============================
prompt
create table SFCRUNTIME.R_WO_STATUS_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCRUNTIME.PK_R_WO_STATUS_EX on SFCRUNTIME.R_WO_STATUS_EX (ID, SEQ_NO);

prompt
prompt Creating table R_WO_TEXT
prompt ========================
prompt
create table SFCRUNTIME.R_WO_TEXT
(
  id    VARCHAR2(50),
  aufnr VARCHAR2(20),
  matnr VARCHAR2(20),
  arbpl VARCHAR2(20),
  ltxa1 VARCHAR2(50),
  isavd VARCHAR2(50),
  vornr VARCHAR2(8),
  mgvrg VARCHAR2(20),
  lmnga VARCHAR2(20)
)
;
create index SFCRUNTIME.IDX_R_WO_TEXT0 on SFCRUNTIME.R_WO_TEXT (AUFNR);
create unique index SFCRUNTIME.PK_R_WO_TEXT on SFCRUNTIME.R_WO_TEXT (ID);

prompt
prompt Creating table R_WO_TEXT_EX
prompt ===========================
prompt
create table SFCRUNTIME.R_WO_TEXT_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCRUNTIME.PK_R_WO_TEXT_EX on SFCRUNTIME.R_WO_TEXT_EX (ID, SEQ_NO);

prompt
prompt Creating table R_WO_TYPE
prompt ========================
prompt
create table SFCRUNTIME.R_WO_TYPE
(
  id             VARCHAR2(50),
  workorder_type VARCHAR2(20),
  category       VARCHAR2(12),
  prefix         VARCHAR2(12),
  order_type     VARCHAR2(30),
  product_type   VARCHAR2(30),
  description    VARCHAR2(200),
  edit_emp       VARCHAR2(50),
  edit_time      DATE
)
;
create index SFCRUNTIME.IDX_R_WO_TYPE0 on SFCRUNTIME.R_WO_TYPE (WORKORDER_TYPE);
create unique index SFCRUNTIME.PK_R_WO_TYPE on SFCRUNTIME.R_WO_TYPE (ID);

prompt
prompt Creating table R_XRAY_HEAD_HWD
prompt ==============================
prompt
create table SFCRUNTIME.R_XRAY_HEAD_HWD
(
  id        VARCHAR2(50),
  result    VARCHAR2(50),
  remark    VARCHAR2(50),
  edit_time DATE,
  edit_emp  VARCHAR2(50)
)
;
create index SFCRUNTIME.IDX_R_XRAY_HEAD_HWD0 on SFCRUNTIME.R_XRAY_HEAD_HWD (RESULT);
create unique index SFCRUNTIME.PK_R_XRAY_HEAD_HWD on SFCRUNTIME.R_XRAY_HEAD_HWD (ID);
grant select, insert, update, delete on SFCRUNTIME.R_XRAY_HEAD_HWD to TEST;

prompt
prompt Creating table R_YIELD_RATE_DETAIL
prompt ==================================
prompt
create table SFCRUNTIME.R_YIELD_RATE_DETAIL
(
  id                     VARCHAR2(50),
  work_date              DATE,
  work_time              VARCHAR2(50),
  production_line        VARCHAR2(50),
  class_name             VARCHAR2(50),
  station_name           VARCHAR2(50),
  workorderno            VARCHAR2(50),
  skuno                  VARCHAR2(50),
  sku_name               VARCHAR2(50),
  sku_series             VARCHAR2(50),
  total_fresh_build_qty  NUMBER,
  total_fresh_pass_qty   NUMBER,
  total_fresh_fail_qty   NUMBER,
  total_rework_build_qty NUMBER,
  total_rework_pass_qty  NUMBER,
  total_rework_fail_qty  NUMBER,
  edit_emp               VARCHAR2(50),
  edit_time              DATE
)
;
create unique index SFCRUNTIME.PK_R_YIELD_RATE_DETAIL on SFCRUNTIME.R_YIELD_RATE_DETAIL (ID);
create unique index SFCRUNTIME.UNQ_R_YIELD_RATE_DETAIL on SFCRUNTIME.R_YIELD_RATE_DETAIL (WORK_DATE, WORK_TIME, PRODUCTION_LINE, CLASS_NAME, STATION_NAME, WORKORDERNO);

prompt
prompt Creating table SMT_CONFIG
prompt =========================
prompt
create table SFCRUNTIME.SMT_CONFIG
(
  item            VARCHAR2(50),
  lang            VARCHAR2(50),
  campus          VARCHAR2(50),
  building        VARCHAR2(50),
  floor           VARCHAR2(50),
  bg              VARCHAR2(50),
  bu              VARCHAR2(50),
  bgcode          VARCHAR2(50),
  roup            VARCHAR2(50),
  generation_by   VARCHAR2(50),
  transmission_by VARCHAR2(50)
)
;

prompt
prompt Creating table WWN_DATASHARING
prompt ==============================
prompt
create table SFCRUNTIME.WWN_DATASHARING
(
  id             VARCHAR2(50),
  wsn            VARCHAR2(50),
  sku            VARCHAR2(20),
  vssn           VARCHAR2(50),
  vsku           VARCHAR2(20),
  cssn           VARCHAR2(50),
  csku           VARCHAR2(20),
  mac            VARCHAR2(12),
  wwn            VARCHAR2(16),
  mac_block_size NUMBER,
  wwn_block_size NUMBER,
  lasteditby     VARCHAR2(20),
  lasteditdt     DATE,
  mactb0         VARCHAR2(20),
  mactb1         VARCHAR2(20),
  mactb2         VARCHAR2(20),
  mactb3         VARCHAR2(20),
  mactb4         VARCHAR2(20),
  wwntb0         VARCHAR2(20),
  wwntb1         VARCHAR2(20),
  wwntb2         VARCHAR2(20),
  wwntb3         VARCHAR2(20),
  wwntb4         VARCHAR2(20)
)
;
create index SFCRUNTIME.IDX_WWN_DATASHARING_CSN on SFCRUNTIME.WWN_DATASHARING (CSSN);
create index SFCRUNTIME.IDX_WWN_DATASHARING_MAC on SFCRUNTIME.WWN_DATASHARING (MAC);
create index SFCRUNTIME.IDX_WWN_DATASHARING_VSN on SFCRUNTIME.WWN_DATASHARING (VSSN);
create index SFCRUNTIME.IDX_WWN_DATASHARING_WSN on SFCRUNTIME.WWN_DATASHARING (WSN);
create unique index SFCRUNTIME.PK_WWN_DATASHARING on SFCRUNTIME.WWN_DATASHARING (ID);
grant select, insert, update, delete on SFCRUNTIME.WWN_DATASHARING to TEST;


spool off
