﻿-------------------------------------------------
-- Export file for user SFCBASE@JNPTEST        --
-- Created by HuongHV on 8/1/2022, 11:07:23 AM --
-------------------------------------------------

set define off
spool SFCBASE.log

prompt
prompt Creating table C_2DXRAYLINE
prompt ===========================
prompt
create table SFCBASE.C_2DXRAYLINE
(
  id        VARCHAR2(50),
  customer  VARCHAR2(50),
  building  VARCHAR2(50),
  linename  VARCHAR2(100),
  edit_time DATE,
  edit_emp  VARCHAR2(50)
)
;
create unique index SFCBASE.C_2DXRAYLINE on SFCBASE.C_2DXRAYLINE (ID);

prompt
prompt Creating table C_ACTION_CODE
prompt ============================
prompt
create table SFCBASE.C_ACTION_CODE
(
  id                  VARCHAR2(50),
  action_code         VARCHAR2(50),
  english_description VARCHAR2(500),
  chinese_description VARCHAR2(500),
  edit_time           DATE,
  edit_emp            VARCHAR2(50),
  code_name           VARCHAR2(50)
)
;
comment on column SFCBASE.C_ACTION_CODE.code_name
  is '代碼名稱';
create unique index SFCBASE.PK_C_ACTION_CODE on SFCBASE.C_ACTION_CODE (ID);
create unique index SFCBASE.UNQ_C_ACTION_CODE on SFCBASE.C_ACTION_CODE (ACTION_CODE);

prompt
prompt Creating table C_ACTION_PARA
prompt ============================
prompt
create table SFCBASE.C_ACTION_PARA
(
  id                  VARCHAR2(50),
  c_station_action_id VARCHAR2(50),
  seq_no              NUMBER(38),
  name                VARCHAR2(50),
  description         VARCHAR2(200),
  edit_emp            VARCHAR2(50),
  edit_time           DATE
)
;
create index SFCBASE.IDX_C_ACTION_PARA0 on SFCBASE.C_ACTION_PARA (C_STATION_ACTION_ID);
create unique index SFCBASE.PK_C_ACTION_PARA on SFCBASE.C_ACTION_PARA (ID);

prompt
prompt Creating table C_AGEING_TYPE
prompt ============================
prompt
create table SFCBASE.C_AGEING_TYPE
(
  id                    VARCHAR2(50) not null,
  ageing_type           VARCHAR2(20),
  ageing_area_code      VARCHAR2(5),
  max_ageing_time       VARCHAR2(3),
  max_ageing_percentage VARCHAR2(5),
  min_ageing_time       VARCHAR2(3),
  min_time_percentage   VARCHAR2(5),
  edit_emp              VARCHAR2(50),
  edit_time             DATE
)
;
create unique index SFCBASE.PK_C_AGEING_TYPE_ID on SFCBASE.C_AGEING_TYPE (ID);
grant select, insert, update, delete on SFCBASE.C_AGEING_TYPE to TEST;

prompt
prompt Creating table C_AQLTYPE
prompt ========================
prompt
create table SFCBASE.C_AQLTYPE
(
  id         VARCHAR2(50),
  aql_type   VARCHAR2(50),
  lot_qty    NUMBER,
  gl_level   VARCHAR2(10),
  sample_qty NUMBER,
  accept_qty NUMBER,
  reject_qty NUMBER,
  edit_emp   VARCHAR2(50),
  edit_time  DATE
)
;
create index SFCBASE.IDX_C_AQLTYPE0 on SFCBASE.C_AQLTYPE (AQL_TYPE);
create unique index SFCBASE.PK_C_AQLTYPE on SFCBASE.C_AQLTYPE (ID);

prompt
prompt Creating table C_BACKFLUSH_MAPPING
prompt ==================================
prompt
create table SFCBASE.C_BACKFLUSH_MAPPING
(
  id               VARCHAR2(50),
  skuno            VARCHAR2(50),
  station_name     VARCHAR2(50),
  sap_station_name VARCHAR2(50),
  edit_time        DATE,
  edit_emp         VARCHAR2(50),
  wo_type          VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_BACKFLUSH_MAPPING on SFCBASE.C_BACKFLUSH_MAPPING (ID);

prompt
prompt Creating table C_BGA_SET
prompt ========================
prompt
create table SFCBASE.C_BGA_SET
(
  id        VARCHAR2(50),
  skuno     VARCHAR2(50),
  partno    VARCHAR2(50),
  loc_times VARCHAR2(10),
  times     VARCHAR2(10),
  edit_time DATE,
  edit_emp  VARCHAR2(50)
)
;
create unique index SFCBASE.C_BGA_SET on SFCBASE.C_BGA_SET (ID);
grant select, insert, update, delete on SFCBASE.C_BGA_SET to TEST;

prompt
prompt Creating table C_BU
prompt ===================
prompt
create table SFCBASE.C_BU
(
  id VARCHAR2(50),
  bu VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_BU on SFCBASE.C_BU (BU);
grant select, insert, update on SFCBASE.C_BU to TEST;

prompt
prompt Creating table C_BU_EX
prompt ======================
prompt
create table SFCBASE.C_BU_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_BU_EX on SFCBASE.C_BU_EX (ID, SEQ_NO);

prompt
prompt Creating table C_CATEGORY
prompt =========================
prompt
create table SFCBASE.C_CATEGORY
(
  id            VARCHAR2(50),
  category      VARCHAR2(50),
  category_name VARCHAR2(50),
  kp_method     VARCHAR2(50),
  kp_station    VARCHAR2(50),
  description   VARCHAR2(300),
  edit_emp      VARCHAR2(50),
  edit_time     DATE
)
;
create unique index SFCBASE.PK_C_CATEGORY on SFCBASE.C_CATEGORY (ID);
create unique index SFCBASE.UNQ_C_CATEGORY on SFCBASE.C_CATEGORY (CATEGORY);

prompt
prompt Creating table C_CODE_MAPPING
prompt =============================
prompt
create table SFCBASE.C_CODE_MAPPING
(
  id        VARCHAR2(50) not null,
  codetype  VARCHAR2(20),
  value     VARCHAR2(20),
  codevalue VARCHAR2(20),
  edit_time DATE,
  edit_emp  VARCHAR2(20),
  seq       NUMBER
)
;
create index SFCBASE.IDX_C_CODE_MAPPING_CODETYPE on SFCBASE.C_CODE_MAPPING (CODETYPE);
alter table SFCBASE.C_CODE_MAPPING
  add constraint PK_C_CODE_MAPPING_ID primary key (ID);

prompt
prompt Creating table C_CONTROL
prompt ========================
prompt
create table SFCBASE.C_CONTROL
(
  id            VARCHAR2(50),
  control_name  VARCHAR2(30),
  control_value VARCHAR2(100),
  control_type  VARCHAR2(30),
  control_level VARCHAR2(30),
  control_desc  VARCHAR2(300),
  edit_emp      VARCHAR2(30),
  edit_time     DATE
)
;
create index SFCBASE.IDX_C_CONTROL0 on SFCBASE.C_CONTROL (CONTROL_NAME, CONTROL_VALUE);
create unique index SFCBASE.PK_C_CONTROL on SFCBASE.C_CONTROL (ID);

prompt
prompt Creating table C_CUSTOMER
prompt =========================
prompt
create table SFCBASE.C_CUSTOMER
(
  id            VARCHAR2(50),
  bu            VARCHAR2(50),
  customer_name VARCHAR2(100),
  description   VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_CUSTOMER on SFCBASE.C_CUSTOMER (ID);

prompt
prompt Creating table C_CUSTOMER_DETAIL
prompt ================================
prompt
create table SFCBASE.C_CUSTOMER_DETAIL
(
  id           VARCHAR2(50),
  customer_id  VARCHAR2(50),
  part_no      VARCHAR2(100),
  part_version VARCHAR2(30),
  skuno        VARCHAR2(100),
  sku_version  VARCHAR2(30),
  edit_time    DATE,
  edit_emp     VARCHAR2(50)
)
;
create index SFCBASE.IDX_C_CUSTOMER_DETAIL0 on SFCBASE.C_CUSTOMER_DETAIL (CUSTOMER_ID);
create index SFCBASE.IDX_C_CUSTOMER_DETAIL1 on SFCBASE.C_CUSTOMER_DETAIL (PART_NO, PART_VERSION);
create index SFCBASE.IDX_C_CUSTOMER_DETAIL2 on SFCBASE.C_CUSTOMER_DETAIL (SKUNO, SKU_VERSION);
create unique index SFCBASE.PK_C_CUSTOMER_DETAIL on SFCBASE.C_CUSTOMER_DETAIL (ID);

prompt
prompt Creating table C_CUSTOMER_DETAIL_EX
prompt ===================================
prompt
create table SFCBASE.C_CUSTOMER_DETAIL_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_CUSTOMER_DETAIL_EX on SFCBASE.C_CUSTOMER_DETAIL_EX (ID, SEQ_NO);

prompt
prompt Creating table C_CUSTOMER_EX
prompt ============================
prompt
create table SFCBASE.C_CUSTOMER_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_CUSTOMER_EX on SFCBASE.C_CUSTOMER_EX (ID, SEQ_NO);

prompt
prompt Creating table C_DEPARTMENT
prompt ===========================
prompt
create table SFCBASE.C_DEPARTMENT
(
  id              VARCHAR2(50),
  department_name VARCHAR2(50),
  description     VARCHAR2(100),
  seq_no          NUMBER,
  edit_time       DATE,
  edit_emp        VARCHAR2(10)
)
;
create unique index SFCBASE.PK_C_DEPARTMENT on SFCBASE.C_DEPARTMENT (ID);

prompt
prompt Creating table C_DUTY
prompt =====================
prompt
create table SFCBASE.C_DUTY
(
  id        VARCHAR2(50),
  duty      VARCHAR2(50),
  seq_no    NUMBER,
  edit_emp  VARCHAR2(50),
  edit_time DATE
)
;
create index SFCBASE.IDX_C_DUTY0 on SFCBASE.C_DUTY (DUTY);
create unique index SFCBASE.PK_C_DUTY on SFCBASE.C_DUTY (ID);

prompt
prompt Creating table C_ERROR_CODE
prompt ===========================
prompt
create table SFCBASE.C_ERROR_CODE
(
  id                  VARCHAR2(50),
  error_code          VARCHAR2(50),
  english_description VARCHAR2(500),
  chinese_description VARCHAR2(500),
  edit_time           DATE,
  edit_emp            VARCHAR2(50),
  error_category      VARCHAR2(50),
  cisco_code          VARCHAR2(50),
  sendmail_flag       VARCHAR2(1)
)
;
comment on column SFCBASE.C_ERROR_CODE.id
  is '行唯一標識';
comment on column SFCBASE.C_ERROR_CODE.error_code
  is '錯誤代碼';
comment on column SFCBASE.C_ERROR_CODE.english_description
  is '英文描述';
comment on column SFCBASE.C_ERROR_CODE.chinese_description
  is '中文描述';
comment on column SFCBASE.C_ERROR_CODE.edit_time
  is '編輯時間';
comment on column SFCBASE.C_ERROR_CODE.edit_emp
  is '編輯人';
comment on column SFCBASE.C_ERROR_CODE.error_category
  is '不良種類';
comment on column SFCBASE.C_ERROR_CODE.cisco_code
  is '思科代碼';
comment on column SFCBASE.C_ERROR_CODE.sendmail_flag
  is '標籤';
create unique index SFCBASE.PK_C_ERROR_CODE on SFCBASE.C_ERROR_CODE (ID);
create unique index SFCBASE.UNQ_C_ERROR_CODE on SFCBASE.C_ERROR_CODE (ERROR_CODE);

prompt
prompt Creating table C_FACTORY
prompt ========================
prompt
create table SFCBASE.C_FACTORY
(
  id              VARCHAR2(50),
  factory_code    VARCHAR2(50),
  factory_name    VARCHAR2(100),
  factory_address VARCHAR2(200),
  description     VARCHAR2(200),
  edit_time       DATE,
  edit_emp        VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_FACTORY on SFCBASE.C_FACTORY (ID);

prompt
prompt Creating table C_IDS
prompt ====================
prompt
create table SFCBASE.C_IDS
(
  id         VARCHAR2(100),
  convert_id VARCHAR2(100)
)
;
create index SFCBASE.IDX_C_IDS0 on SFCBASE.C_IDS (ID);
create unique index SFCBASE.UNQ_C_IDS on SFCBASE.C_IDS (CONVERT_ID);

prompt
prompt Creating table C_INPUT
prompt ======================
prompt
create table SFCBASE.C_INPUT
(
  id                   VARCHAR2(50),
  input_name           VARCHAR2(20),
  display_type         VARCHAR2(20),
  data_source_api      VARCHAR2(200),
  data_source_api_para VARCHAR2(500),
  refresh_type         VARCHAR2(20),
  description          VARCHAR2(500),
  edit_time            DATE,
  edit_emp             VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_INPUT on SFCBASE.C_INPUT (ID);

prompt
prompt Creating table C_INPUT_RULE
prompt ===========================
prompt
create table SFCBASE.C_INPUT_RULE
(
  id          VARCHAR2(50),
  system_name VARCHAR2(30),
  page_name   VARCHAR2(50),
  input_name  VARCHAR2(50),
  expression  VARCHAR2(200),
  description VARCHAR2(200),
  edit_time   DATE,
  edit_emp    VARCHAR2(50)
)
;
create index SFCBASE.IDX_C_INPUT_RULE0 on SFCBASE.C_INPUT_RULE (PAGE_NAME);
create unique index SFCBASE.PK_C_INPUT_RULE on SFCBASE.C_INPUT_RULE (ID);

prompt
prompt Creating table C_INTERFACE
prompt ==========================
prompt
create table SFCBASE.C_INTERFACE
(
  id            VARCHAR2(50),
  program_name  VARCHAR2(50),
  item_name     VARCHAR2(50),
  class_name    VARCHAR2(100),
  function_name VARCHAR2(50),
  seq_no        VARCHAR2(50),
  item_status   VARCHAR2(1),
  last_run_date DATE,
  next_run_date DATE,
  run_type      VARCHAR2(1),
  run_time      VARCHAR2(50),
  description   VARCHAR2(200),
  edit_emp      VARCHAR2(50),
  edit_time     DATE
)
;
create index SFCBASE.IDX_C_INTERFACE0 on SFCBASE.C_INTERFACE (PROGRAM_NAME);
create index SFCBASE.IDX_C_INTERFACE1 on SFCBASE.C_INTERFACE (ITEM_NAME);
create unique index SFCBASE.PK_C_INTERFACE on SFCBASE.C_INTERFACE (ID);

prompt
prompt Creating table C_KEYPART
prompt ========================
prompt
create table SFCBASE.C_KEYPART
(
  id            VARCHAR2(50),
  keypart_id    VARCHAR2(50),
  seq_no        NUMBER,
  part_no       VARCHAR2(50),
  part_no_ver   VARCHAR2(50),
  qty           NUMBER,
  station_name  VARCHAR2(50),
  category      VARCHAR2(50),
  category_name VARCHAR2(50),
  skuno         VARCHAR2(50),
  skuno_ver     VARCHAR2(50),
  edit_emp      VARCHAR2(50),
  edit_time     DATE,
  valid_flag    VARCHAR2(1)
)
;
comment on column SFCBASE.C_KEYPART.valid_flag
  is '是否有效標籤';
create index SFCBASE.IDX_C_KEYPART0 on SFCBASE.C_KEYPART (KEYPART_ID, PART_NO_VER, PART_NO);
create unique index SFCBASE.PK_C_KEYPART on SFCBASE.C_KEYPART (ID);

prompt
prompt Creating table C_KP_CHECK
prompt =========================
prompt
create table SFCBASE.C_KP_CHECK
(
  id        VARCHAR2(50),
  typename  VARCHAR2(50),
  dll       VARCHAR2(50),
  class     VARCHAR2(50),
  function  VARCHAR2(50),
  edit_time DATE,
  edit_emp  VARCHAR2(20)
)
;
create index SFCBASE.IDX_C_KP_CHECK_TYPENAME on SFCBASE.C_KP_CHECK (TYPENAME);
grant select, insert, update, delete on SFCBASE.C_KP_CHECK to TEST;

prompt
prompt Creating table C_KP_LIST
prompt ========================
prompt
create table SFCBASE.C_KP_LIST
(
  id          VARCHAR2(50),
  listname    VARCHAR2(50),
  skuno       VARCHAR2(50),
  edit_time   DATE,
  edit_emp    VARCHAR2(20),
  flag        VARCHAR2(10),
  custversion VARCHAR2(20)
)
;
create index SFCBASE.IDX_C_KP_LIST_SKUNO on SFCBASE.C_KP_LIST (SKUNO);
grant select, insert, update, delete on SFCBASE.C_KP_LIST to TEST;

prompt
prompt Creating table C_KP_LIST_ITEM
prompt =============================
prompt
create table SFCBASE.C_KP_LIST_ITEM
(
  id        VARCHAR2(50),
  list_id   VARCHAR2(50),
  kp_name   VARCHAR2(20),
  kp_partno VARCHAR2(50),
  station   VARCHAR2(20),
  qty       NUMBER,
  seq       NUMBER,
  edit_time DATE,
  edit_emp  VARCHAR2(20)
)
;
create index SFCBASE.IDX_C_KP_LIST_ITEM_LIST_ID on SFCBASE.C_KP_LIST_ITEM (LIST_ID);
grant select, insert, update, delete on SFCBASE.C_KP_LIST_ITEM to TEST;

prompt
prompt Creating table C_KP_LIST_ITEM_DETAIL
prompt ====================================
prompt
create table SFCBASE.C_KP_LIST_ITEM_DETAIL
(
  id        VARCHAR2(50),
  item_id   VARCHAR2(50),
  scantype  VARCHAR2(50),
  seq       NUMBER,
  edit_time DATE,
  edit_emp  VARCHAR2(20),
  location  VARCHAR2(1000)
)
;
create index SFCBASE.IDX_KP_ITEM_DETAIL_ITEM_ID on SFCBASE.C_KP_LIST_ITEM_DETAIL (ITEM_ID);
grant select, insert, update, delete on SFCBASE.C_KP_LIST_ITEM_DETAIL to TEST;

prompt
prompt Creating table C_KP_REPLACE
prompt ===========================
prompt
create table SFCBASE.C_KP_REPLACE
(
  id            VARCHAR2(50),
  skuno         VARCHAR2(50),
  partno        VARCHAR2(50),
  replacepartno VARCHAR2(50),
  edit_time     DATE,
  edit_emp      VARCHAR2(20)
)
;
create index SFCBASE.IDX_C_KP_REPLACE_PARTNO on SFCBASE.C_KP_REPLACE (PARTNO);
create index SFCBASE.IDX_C_KP_REPLACE_SKUNO on SFCBASE.C_KP_REPLACE (SKUNO);
create index SFCBASE.IDX_C_KP_REPLACE_SKUPARTNO on SFCBASE.C_KP_REPLACE (SKUNO, PARTNO);
grant select, insert, update, delete on SFCBASE.C_KP_REPLACE to TEST;

prompt
prompt Creating table C_KP_RULE
prompt ========================
prompt
create table SFCBASE.C_KP_RULE
(
  id        VARCHAR2(50),
  partno    VARCHAR2(50),
  mpn       VARCHAR2(50),
  scantype  VARCHAR2(50),
  regex     VARCHAR2(200),
  edit_time DATE,
  edit_emp  VARCHAR2(20)
)
;
create index SFCBASE.IDX_C_KP_RULE_PARTNO on SFCBASE.C_KP_RULE (PARTNO);
grant select, insert, update, delete on SFCBASE.C_KP_RULE to TEST;

prompt
prompt Creating table C_KP_SCANTYPE
prompt ============================
prompt
create table SFCBASE.C_KP_SCANTYPE
(
  id          VARCHAR2(50),
  typename    VARCHAR2(50),
  partno      VARCHAR2(50),
  description VARCHAR2(50),
  edit_time   DATE,
  edit_emp    VARCHAR2(20)
)
;
create index SFCBASE.IDX_C_KP_SCANTYPE_PARTNO on SFCBASE.C_KP_SCANTYPE (PARTNO);
create index SFCBASE.IDX_C_KP_SCANTYPE_TYPENAME on SFCBASE.C_KP_SCANTYPE (TYPENAME);
grant select, insert, update, delete on SFCBASE.C_KP_SCANTYPE to TEST;

prompt
prompt Creating table C_LABEL
prompt ======================
prompt
create table SFCBASE.C_LABEL
(
  id            VARCHAR2(50),
  skuno         VARCHAR2(20),
  print_station VARCHAR2(15),
  label_type    VARCHAR2(50),
  label_path    VARCHAR2(50),
  edit_time     DATE,
  edit_emp      VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_LABEL on SFCBASE.C_LABEL (ID);

prompt
prompt Creating table C_LABEL_EX
prompt =========================
prompt
create table SFCBASE.C_LABEL_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_LABEL_EX on SFCBASE.C_LABEL_EX (ID, SEQ_NO);

prompt
prompt Creating table C_LABEL_TYPE
prompt ===========================
prompt
create table SFCBASE.C_LABEL_TYPE
(
  id        VARCHAR2(50) not null,
  name      VARCHAR2(50),
  dll       VARCHAR2(250),
  class     VARCHAR2(250),
  edit_time DATE,
  edit_emp  VARCHAR2(20)
)
;
create index SFCBASE.IDX_C_LABEL_TYPE_NAME on SFCBASE.C_LABEL_TYPE (NAME);
alter table SFCBASE.C_LABEL_TYPE
  add constraint PK_C_LABEL_TYPE_ID primary key (ID);

prompt
prompt Creating table C_LANGUAGE
prompt =========================
prompt
create table SFCBASE.C_LANGUAGE
(
  id             VARCHAR2(50),
  language_name  VARCHAR2(50),
  language_value VARCHAR2(50),
  sort           NUMBER(22),
  edit_emp       VARCHAR2(50),
  edit_time      DATE
)
;
create unique index SFCBASE.PK_C_LANGUAGE on SFCBASE.C_LANGUAGE (ID);

prompt
prompt Creating table C_LANGUAGE_EX
prompt ============================
prompt
create table SFCBASE.C_LANGUAGE_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_LANGUAGE_EX on SFCBASE.C_LANGUAGE_EX (ID, SEQ_NO);

prompt
prompt Creating table C_LANGUAGE_PAGE
prompt ==============================
prompt
create table SFCBASE.C_LANGUAGE_PAGE
(
  id          VARCHAR2(50),
  system_name VARCHAR2(30),
  page_name   VARCHAR2(50),
  label_name  VARCHAR2(50),
  chinese     VARCHAR2(100),
  chinese_tw  VARCHAR2(100),
  english     VARCHAR2(100),
  edit_time   DATE,
  edit_emp    VARCHAR2(10)
)
;
create unique index SFCBASE.PK_C_LANGUAGE_PAGE on SFCBASE.C_LANGUAGE_PAGE (ID);

prompt
prompt Creating table C_LANGUAGE_PAGE_EX
prompt =================================
prompt
create table SFCBASE.C_LANGUAGE_PAGE_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_LANGUAGE_PAGE_EX on SFCBASE.C_LANGUAGE_PAGE_EX (ID, SEQ_NO);

prompt
prompt Creating table C_LINE
prompt =====================
prompt
create table SFCBASE.C_LINE
(
  id          VARCHAR2(50),
  line_name   VARCHAR2(50),
  section_id  VARCHAR2(50),
  line_code   VARCHAR2(50),
  line_pcas   VARCHAR2(50),
  description VARCHAR2(200),
  edit_time   DATE,
  edit_emp    VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_LINE on SFCBASE.C_LINE (ID);

prompt
prompt Creating table C_LINE_EX
prompt ========================
prompt
create table SFCBASE.C_LINE_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_LINE_EX on SFCBASE.C_LINE_EX (ID, SEQ_NO);

prompt
prompt Creating table C_MANUFACTURER
prompt =============================
prompt
create table SFCBASE.C_MANUFACTURER
(
  id        VARCHAR2(50),
  part_no   VARCHAR2(50),
  mfr_code  VARCHAR2(50),
  mpn       VARCHAR2(50),
  mfr_name  VARCHAR2(50),
  edit_emp  VARCHAR2(50),
  edit_time DATE
)
;
create index SFCBASE.IDX_C_MANUFACTURER0 on SFCBASE.C_MANUFACTURER (PART_NO);
create unique index SFCBASE.PK_C_MANUFACTURER on SFCBASE.C_MANUFACTURER (ID);

prompt
prompt Creating table C_MENU
prompt =====================
prompt
create table SFCBASE.C_MENU
(
  id          VARCHAR2(50),
  system_name VARCHAR2(30),
  menu_name   VARCHAR2(50),
  page_path   VARCHAR2(200),
  parent_code VARCHAR2(50),
  sort        NUMBER(22),
  style_name  VARCHAR2(50),
  class_name  VARCHAR2(50),
  language_id VARCHAR2(50),
  menu_desc   VARCHAR2(100),
  edit_time   DATE,
  edit_emp    VARCHAR2(50)
)
;

prompt
prompt Creating table C_MENU_EX
prompt ========================
prompt
create table SFCBASE.C_MENU_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_MENU_EX on SFCBASE.C_MENU_EX (ID, SEQ_NO);

prompt
prompt Creating table C_MES_MESSAGE
prompt ============================
prompt
create table SFCBASE.C_MES_MESSAGE
(
  id           VARCHAR2(50),
  message_code VARCHAR2(50),
  chinese      VARCHAR2(200),
  chinese_tw   VARCHAR2(200),
  english      VARCHAR2(200),
  edit_time    DATE,
  edit_emp     VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_MES_MESSAGE on SFCBASE.C_MES_MESSAGE (ID);

prompt
prompt Creating table C_MES_MESSAGE_EX
prompt ===============================
prompt
create table SFCBASE.C_MES_MESSAGE_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_MES_MESSAGE_EX on SFCBASE.C_MES_MESSAGE_EX (ID, SEQ_NO);

prompt
prompt Creating table C_OBA_EX
prompt =======================
prompt
create table SFCBASE.C_OBA_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_OBA_EX on SFCBASE.C_OBA_EX (ID, SEQ_NO);

prompt
prompt Creating table C_PACKING
prompt ========================
prompt
create table SFCBASE.C_PACKING
(
  id               VARCHAR2(50),
  skuno            VARCHAR2(50),
  pack_type        VARCHAR2(50),
  transport_type   VARCHAR2(50),
  inside_pack_type VARCHAR2(50),
  max_qty          NUMBER,
  description      VARCHAR2(200),
  edit_time        DATE,
  edit_emp         VARCHAR2(50),
  sn_rule          VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_PACKING on SFCBASE.C_PACKING (ID);

prompt
prompt Creating table C_PACKING_SIZE
prompt =============================
prompt
create table SFCBASE.C_PACKING_SIZE
(
  id          VARCHAR2(50),
  skuno       VARCHAR2(50),
  pallet_size VARCHAR2(50),
  carton_size VARCHAR2(50),
  box_size    VARCHAR2(50),
  edit_time   DATE,
  edit_emp    VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_PACKING_SIZE on SFCBASE.C_PACKING_SIZE (ID);

prompt
prompt Creating table C_PACKING_TYPE
prompt =============================
prompt
create table SFCBASE.C_PACKING_TYPE
(
  id        VARCHAR2(50),
  pack_type VARCHAR2(50),
  edit_time DATE,
  edit_emp  VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_PACKING_TYPE on SFCBASE.C_PACKING_TYPE (ID);

prompt
prompt Creating table C_PACKOUT_WEIGHT
prompt ===============================
prompt
create table SFCBASE.C_PACKOUT_WEIGHT
(
  id          VARCHAR2(50),
  bu          VARCHAR2(10),
  description VARCHAR2(150),
  pn          VARCHAR2(50),
  box_nt      VARCHAR2(50),
  box_gw      VARCHAR2(10),
  pcs_nt      VARCHAR2(10),
  pcs_gw      VARCHAR2(10),
  p_nullwg    VARCHAR2(20),
  p_gw        VARCHAR2(10),
  pcs_b       VARCHAR2(20),
  pcs_p       VARCHAR2(20),
  box_p       VARCHAR2(20),
  lasteditdt  DATE
)
;
grant select, insert, update, delete on SFCBASE.C_PACKOUT_WEIGHT to TEST;

prompt
prompt Creating table C_PARAMETER
prompt ==========================
prompt
create table SFCBASE.C_PARAMETER
(
  id              VARCHAR2(50),
  function_name   VARCHAR2(50),
  parameter_name  VARCHAR2(50),
  parameter_value VARCHAR2(50),
  seq_no          NUMBER,
  description     VARCHAR2(50),
  edit_emp        VARCHAR2(20),
  edit_time       DATE
)
;
create index SFCBASE.IDX_C_PARAMETER0 on SFCBASE.C_PARAMETER (FUNCTION_NAME);
create unique index SFCBASE.PK_C_PARAMETER on SFCBASE.C_PARAMETER (ID);

prompt
prompt Creating table C_PRIVILEGE
prompt ==========================
prompt
create table SFCBASE.C_PRIVILEGE
(
  id              VARCHAR2(50),
  system_name     VARCHAR2(30),
  menu_id         VARCHAR2(50),
  privilege_name  VARCHAR2(50),
  privilege_desc  VARCHAR2(200),
  edit_time       DATE,
  edit_emp        VARCHAR2(50),
  baseconfig_flag VARCHAR2(2)
)
;
create unique index SFCBASE.PK_C_PRIVILEGE on SFCBASE.C_PRIVILEGE (ID);

prompt
prompt Creating table C_PRIVILEGE_EX
prompt =============================
prompt
create table SFCBASE.C_PRIVILEGE_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_PRIVILEGE_EX on SFCBASE.C_PRIVILEGE_EX (ID, SEQ_NO);

prompt
prompt Creating table C_PROCCESS_ALERT
prompt ===============================
prompt
create table SFCBASE.C_PROCCESS_ALERT
(
  id            VARCHAR2(50) not null,
  proccess_name VARCHAR2(50),
  lv1_sms       VARCHAR2(500),
  lv1_mail      VARCHAR2(500),
  lv2_sms       VARCHAR2(500),
  lv2_mail      VARCHAR2(500),
  lv3_sms       VARCHAR2(500),
  lv3_mail      VARCHAR2(500),
  monitor_name  VARCHAR2(50),
  edit_date     DATE,
  edit_emp      VARCHAR2(50)
)
;
alter table SFCBASE.C_PROCCESS_ALERT
  add constraint PK_C_PROCCESS_ALERT primary key (ID);
grant select, insert, update, delete on SFCBASE.C_PROCCESS_ALERT to TEST;

prompt
prompt Creating table C_PROCCESS_CHECK
prompt ===============================
prompt
create table SFCBASE.C_PROCCESS_CHECK
(
  id            VARCHAR2(50) not null,
  proccess_name VARCHAR2(50),
  check_type    VARCHAR2(50),
  config        VARCHAR2(2000),
  alert_state   VARCHAR2(10),
  run_time_data VARCHAR2(2000),
  edit_date     DATE,
  edit_emp      VARCHAR2(20)
)
;
alter table SFCBASE.C_PROCCESS_CHECK
  add constraint PK_C_PROCCESS_CHECK primary key (ID);
grant select, insert, update, delete on SFCBASE.C_PROCCESS_CHECK to TEST;

prompt
prompt Creating table C_PROCESS
prompt ========================
prompt
create table SFCBASE.C_PROCESS
(
  id        VARCHAR2(50),
  process   VARCHAR2(50),
  seq_no    NUMBER,
  edit_emp  VARCHAR2(50),
  edit_time DATE
)
;
create index SFCBASE.IDX_C_PROCESS0 on SFCBASE.C_PROCESS (PROCESS);
create unique index SFCBASE.PK_C_PROCESS on SFCBASE.C_PROCESS (ID);

prompt
prompt Creating table C_PROGRAM_SERVER
prompt ===============================
prompt
create table SFCBASE.C_PROGRAM_SERVER
(
  id           VARCHAR2(50),
  program_name VARCHAR2(50),
  server_ip    VARCHAR2(50),
  port         VARCHAR2(50),
  service_name VARCHAR2(50),
  edit_emp     VARCHAR2(50),
  edit_time    DATE
)
;
create index SFCBASE.IDX_C_PROGRAM_SERVER0 on SFCBASE.C_PROGRAM_SERVER (PROGRAM_NAME);
create unique index SFCBASE.PK_C_PROGRAM_SERVER on SFCBASE.C_PROGRAM_SERVER (ID);

prompt
prompt Creating table C_REASON_CODE
prompt ============================
prompt
create table SFCBASE.C_REASON_CODE
(
  id                  VARCHAR2(50),
  reason_code         VARCHAR2(50),
  english_description VARCHAR2(500),
  chinese_description VARCHAR2(500),
  edit_time           DATE,
  edit_emp            VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_REASON_CODE on SFCBASE.C_REASON_CODE (ID);
create unique index SFCBASE.UNQ_C_REASON_CODE on SFCBASE.C_REASON_CODE (REASON_CODE);

prompt
prompt Creating table C_REPAIR_CHECK_STATION
prompt =====================================
prompt
create table SFCBASE.C_REPAIR_CHECK_STATION
(
  id            VARCHAR2(50),
  sn            VARCHAR2(50),
  fail_time     DATE,
  check_station VARCHAR2(50),
  edit_time     DATE,
  edit_emp      VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_REPAIR_CHECK_STATION on SFCBASE.C_REPAIR_CHECK_STATION (ID);

prompt
prompt Creating table C_REPAIR_DAY
prompt ===========================
prompt
create table SFCBASE.C_REPAIR_DAY
(
  id               VARCHAR2(50),
  skuno            VARCHAR2(50),
  version          VARCHAR2(50),
  repair_day_count NUMBER,
  repair_count     NUMBER,
  station_count    NUMBER,
  edit_time        DATE,
  edit_emp         VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_REPAIR_DAY on SFCBASE.C_REPAIR_DAY (ID);

prompt
prompt Creating table C_REPAIR_ITEMS
prompt =============================
prompt
create table SFCBASE.C_REPAIR_ITEMS
(
  id        VARCHAR2(50),
  item_name VARCHAR2(200),
  edit_time DATE,
  edit_emp  VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_REPAIR_ITEMS on SFCBASE.C_REPAIR_ITEMS (ID);
create unique index SFCBASE.UNQ_C_REPAIR_ITEMS on SFCBASE.C_REPAIR_ITEMS (ITEM_NAME);

prompt
prompt Creating table C_REPAIR_ITEMS_SON
prompt =================================
prompt
create table SFCBASE.C_REPAIR_ITEMS_SON
(
  id        VARCHAR2(50),
  items_id  VARCHAR2(50),
  items_son VARCHAR2(200),
  edit_time DATE,
  edit_emp  VARCHAR2(50)
)
;
create index SFCBASE.IDX_C_REPAIR_ITEMS_SON0 on SFCBASE.C_REPAIR_ITEMS_SON (ITEMS_ID);
create unique index SFCBASE.PK_C_REPAIR_ITEMS_SON on SFCBASE.C_REPAIR_ITEMS_SON (ID);
create unique index SFCBASE.UNQ_C_REPAIR_ITEMS_SON on SFCBASE.C_REPAIR_ITEMS_SON (ITEMS_ID, ITEMS_SON);

prompt
prompt Creating table C_REPAIR_LOCATION
prompt ================================
prompt
create table SFCBASE.C_REPAIR_LOCATION
(
  id           VARCHAR2(50),
  skuno        NUMBER,
  version      VARCHAR2(50),
  location     VARCHAR2(50),
  repair_count NUMBER,
  edit_time    DATE,
  edit_emp     VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_REPAIR_LOCATION on SFCBASE.C_REPAIR_LOCATION (ID);

prompt
prompt Creating table C_REPAIR_RETURE_STATION
prompt ======================================
prompt
create table SFCBASE.C_REPAIR_RETURE_STATION
(
  id             VARCHAR2(50),
  skuno          VARCHAR2(50),
  action_code    VARCHAR2(50),
  return_station VARCHAR2(50),
  edit_time      DATE,
  edit_emp       VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_REPAIR_RETURE_STATION on SFCBASE.C_REPAIR_RETURE_STATION (ID);

prompt
prompt Creating table C_ROLE
prompt =====================
prompt
create table SFCBASE.C_ROLE
(
  id          VARCHAR2(50),
  system_name VARCHAR2(30),
  role_name   VARCHAR2(50),
  role_desc   VARCHAR2(200),
  edit_time   DATE,
  edit_emp    VARCHAR2(50),
  role_type   VARCHAR2(50)
)
;

prompt
prompt Creating table C_ROLE_EX
prompt ========================
prompt
create table SFCBASE.C_ROLE_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_ROLE_EX on SFCBASE.C_ROLE_EX (ID, SEQ_NO);

prompt
prompt Creating table C_ROLE_PRIVILEGE
prompt ===============================
prompt
create table SFCBASE.C_ROLE_PRIVILEGE
(
  id           VARCHAR2(50),
  system_name  VARCHAR2(30),
  role_id      VARCHAR2(50),
  privilege_id VARCHAR2(50),
  edit_time    DATE,
  edit_emp     VARCHAR2(50)
)
;

prompt
prompt Creating table C_ROLE_PRIVILEGE_EX
prompt ==================================
prompt
create table SFCBASE.C_ROLE_PRIVILEGE_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_ROLE_PRIVILEGE_EX on SFCBASE.C_ROLE_PRIVILEGE_EX (ID, SEQ_NO);

prompt
prompt Creating table C_ROUTE
prompt ======================
prompt
create table SFCBASE.C_ROUTE
(
  id            VARCHAR2(50),
  route_name    VARCHAR2(100),
  default_skuno VARCHAR2(50),
  route_type    VARCHAR2(50),
  edit_time     DATE,
  edit_emp      VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_ROUTE on SFCBASE.C_ROUTE (ID);

prompt
prompt Creating table C_ROUTE_DETAIL
prompt =============================
prompt
create table SFCBASE.C_ROUTE_DETAIL
(
  id           VARCHAR2(50),
  seq_no       NUMBER(22),
  route_id     VARCHAR2(50),
  station_name VARCHAR2(50),
  station_type VARCHAR2(50),
  return_flag  VARCHAR2(1)
)
;
create unique index SFCBASE.PK_C_ROUTE_DETAIL on SFCBASE.C_ROUTE_DETAIL (ID, SEQ_NO);

prompt
prompt Creating table C_ROUTE_DETAIL_DIRECTLINK
prompt ========================================
prompt
create table SFCBASE.C_ROUTE_DETAIL_DIRECTLINK
(
  id                         VARCHAR2(50),
  c_route_detail_id          VARCHAR2(50),
  directlink_route_detail_id VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_ROUTE_DETAIL_DIRECTLINK on SFCBASE.C_ROUTE_DETAIL_DIRECTLINK (ID);

prompt
prompt Creating table C_ROUTE_DETAIL_EX
prompt ================================
prompt
create table SFCBASE.C_ROUTE_DETAIL_EX
(
  id        VARCHAR2(50),
  seq_no    NUMBER,
  name      VARCHAR2(50),
  value     VARCHAR2(200),
  detail_id VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_ROUTE_DETAIL_EX on SFCBASE.C_ROUTE_DETAIL_EX (ID, SEQ_NO);

prompt
prompt Creating table C_ROUTE_DETAIL_RETURN
prompt ====================================
prompt
create table SFCBASE.C_ROUTE_DETAIL_RETURN
(
  id                     VARCHAR2(50),
  route_detail_id        VARCHAR2(50),
  return_route_detail_id VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_ROUTE_DETAIL_RETURN on SFCBASE.C_ROUTE_DETAIL_RETURN (ID);

prompt
prompt Creating table C_ROUTE_DETAIL_RETURN_EX
prompt =======================================
prompt
create table SFCBASE.C_ROUTE_DETAIL_RETURN_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_ROUTE_DETAIL_RETURN_EX on SFCBASE.C_ROUTE_DETAIL_RETURN_EX (ID, SEQ_NO);

prompt
prompt Creating table C_ROUTE_EX
prompt =========================
prompt
create table SFCBASE.C_ROUTE_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_ROUTE_EX on SFCBASE.C_ROUTE_EX (ID, SEQ_NO);

prompt
prompt Creating table C_SAMPLE_STATION
prompt ===============================
prompt
create table SFCBASE.C_SAMPLE_STATION
(
  id             VARCHAR2(50),
  sample_rule_id VARCHAR2(50),
  skuno          VARCHAR2(20),
  sample_station VARCHAR2(10),
  sample_type    VARCHAR2(10),
  create_by      VARCHAR2(50),
  create_date    DATE,
  edit_emp       VARCHAR2(50),
  edit_time      DATE
)
;
create unique index SFCBASE.PK_C_SAMPLE_STATION on SFCBASE.C_SAMPLE_STATION (ID);

prompt
prompt Creating table C_SAP_STATION_MAP
prompt ================================
prompt
create table SFCBASE.C_SAP_STATION_MAP
(
  id               VARCHAR2(50),
  skuno            VARCHAR2(50),
  station_name     VARCHAR2(50),
  sap_station_code VARCHAR2(50),
  workorder_type   VARCHAR2(50),
  edit_emp         VARCHAR2(50),
  edit_time        DATE
)
;
create index SFCBASE.IDX_C_SAP_STATION_MAP0 on SFCBASE.C_SAP_STATION_MAP (SKUNO);
create unique index SFCBASE.PK_C_SAP_STATION_MAP on SFCBASE.C_SAP_STATION_MAP (ID);
create unique index SFCBASE.UNQ_C_SAP_STATION_MAP on SFCBASE.C_SAP_STATION_MAP (SKUNO, STATION_NAME, WORKORDER_TYPE);

prompt
prompt Creating table C_SECTION
prompt ========================
prompt
create table SFCBASE.C_SECTION
(
  id           VARCHAR2(50),
  section_name VARCHAR2(50),
  description  VARCHAR2(100)
)
;
create index SFCBASE.IDX_C_SECTION0 on SFCBASE.C_SECTION (SECTION_NAME);
create unique index SFCBASE.PK_C_SECTION on SFCBASE.C_SECTION (ID);

prompt
prompt Creating table C_SECTION_EX
prompt ===========================
prompt
create table SFCBASE.C_SECTION_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_SECTION_EX on SFCBASE.C_SECTION_EX (ID, SEQ_NO);

prompt
prompt Creating table C_SEQNO
prompt ======================
prompt
create table SFCBASE.C_SEQNO
(
  id          VARCHAR2(50),
  seq_name    VARCHAR2(50),
  seq_no      VARCHAR2(50),
  digits      NUMBER,
  base_code   VARCHAR2(50),
  minimum     VARCHAR2(50),
  maximum     VARCHAR2(50),
  prefix      VARCHAR2(50),
  fixed       VARCHAR2(50),
  seq_form    VARCHAR2(50),
  reset       VARCHAR2(50),
  use_time    DATE,
  edit_emp    VARCHAR2(50),
  edit_time   DATE,
  description VARCHAR2(60)
)
;
comment on column SFCBASE.C_SEQNO.description
  is '描述';
create index SFCBASE.IDX_C_SEQNO0 on SFCBASE.C_SEQNO (SEQ_NAME);
create unique index SFCBASE.PK_C_SEQNO on SFCBASE.C_SEQNO (ID);

prompt
prompt Creating table C_SEQUENCE_EXTEND_DEFINE
prompt =======================================
prompt
create table SFCBASE.C_SEQUENCE_EXTEND_DEFINE
(
  owner_name    VARCHAR2(30),
  sequence_name VARCHAR2(50),
  edit_time     DATE
)
;
create unique index SFCBASE.PK_C_SEQUENCE_EXTEND_DEFINE on SFCBASE.C_SEQUENCE_EXTEND_DEFINE (OWNER_NAME, SEQUENCE_NAME);

prompt
prompt Creating table C_SEQUENCE_EXTEND_DEFINE_EX
prompt ==========================================
prompt
create table SFCBASE.C_SEQUENCE_EXTEND_DEFINE_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_SEQUENCE_EXTEND_DEFINE_EX on SFCBASE.C_SEQUENCE_EXTEND_DEFINE_EX (ID, SEQ_NO);

prompt
prompt Creating table C_SERIES
prompt =======================
prompt
create table SFCBASE.C_SERIES
(
  id          VARCHAR2(50),
  customer_id VARCHAR2(50),
  series_name VARCHAR2(50),
  description VARCHAR2(100),
  edit_time   DATE,
  edit_emp    VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_SERIES on SFCBASE.C_SERIES (ID);

prompt
prompt Creating table C_SERIES_EX
prompt ==========================
prompt
create table SFCBASE.C_SERIES_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_SERIES_EX on SFCBASE.C_SERIES_EX (ID, SEQ_NO);

prompt
prompt Creating table C_SERVICE_CONTROL
prompt ================================
prompt
create table SFCBASE.C_SERVICE_CONTROL
(
  id             VARCHAR2(50),
  servername     VARCHAR2(50),
  timespan       VARCHAR2(50),
  runstatus      VARCHAR2(50),
  serverfunction VARCHAR2(50),
  functionname   VARCHAR2(250),
  classname      VARCHAR2(250),
  descriptions   VARCHAR2(250),
  currentip      VARCHAR2(50),
  runtime        DATE,
  data1          VARCHAR2(250),
  data2          VARCHAR2(250),
  data3          VARCHAR2(250),
  data4          VARCHAR2(250),
  data5          VARCHAR2(250)
)
;
create unique index SFCBASE.PK_C_SERVICE_CONTROL on SFCBASE.C_SERVICE_CONTROL (ID);

prompt
prompt Creating table C_SHIPPING_ADDRESS
prompt =================================
prompt
create table SFCBASE.C_SHIPPING_ADDRESS
(
  id               NVARCHAR2(50),
  area_code        NVARCHAR2(5),
  shipping_area    NVARCHAR2(10),
  shipping_address NVARCHAR2(50),
  edit_time        DATE,
  edit_emp         NVARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_SHIPPING_ADDRESS_ID on SFCBASE.C_SHIPPING_ADDRESS (ID);
grant select, insert, update, delete on SFCBASE.C_SHIPPING_ADDRESS to TEST;

prompt
prompt Creating table C_SHIPPING_ROUTE
prompt ===============================
prompt
create table SFCBASE.C_SHIPPING_ROUTE
(
  routename   VARCHAR2(50),
  description VARCHAR2(250),
  id          VARCHAR2(50) not null
)
;
alter table SFCBASE.C_SHIPPING_ROUTE
  add constraint PK_C_SHIPOING_ROUTE_ID primary key (ID);

prompt
prompt Creating table C_SHIPPING_ROUTE_DETAIL
prompt ======================================
prompt
create table SFCBASE.C_SHIPPING_ROUTE_DETAIL
(
  routename  VARCHAR2(50),
  seq        VARCHAR2(10),
  actionname VARCHAR2(50),
  from_stock VARCHAR2(10),
  to_stock   VARCHAR2(10),
  actiontype VARCHAR2(10),
  from_plant VARCHAR2(10),
  to_plant   VARCHAR2(10),
  rfc_name   VARCHAR2(50),
  id         VARCHAR2(50) not null
)
;
alter table SFCBASE.C_SHIPPING_ROUTE_DETAIL
  add constraint PK_C_SHIPPING_ROUTE_DETAIL primary key (ID);

prompt
prompt Creating table C_SHIP_CUSTOMER
prompt ==============================
prompt
create table SFCBASE.C_SHIP_CUSTOMER
(
  customername   VARCHAR2(20),
  billtolocation VARCHAR2(10),
  billtoaddr1    VARCHAR2(20),
  billtocountry  VARCHAR2(10),
  currencycode   VARCHAR2(20),
  billtocode     VARCHAR2(50),
  routename      VARCHAR2(50),
  id             VARCHAR2(50) not null
)
;
alter table SFCBASE.C_SHIP_CUSTOMER
  add constraint PK_C_SHIP_CUSTOMER_ID primary key (ID);

prompt
prompt Creating table C_SKU
prompt ====================
prompt
create table SFCBASE.C_SKU
(
  id            VARCHAR2(50),
  bu            VARCHAR2(50),
  skuno         VARCHAR2(50),
  version       VARCHAR2(50),
  sku_name      VARCHAR2(50),
  c_series_id   VARCHAR2(50),
  cust_partno   VARCHAR2(50),
  cust_sku_code VARCHAR2(50),
  sn_rule       VARCHAR2(50),
  panel_rule    VARCHAR2(50),
  description   VARCHAR2(100),
  edit_emp      VARCHAR2(50),
  edit_time     DATE,
  sku_type      VARCHAR2(50),
  aqltype       VARCHAR2(50)
)
;
create index SFCBASE.IDX_C_SKU0 on SFCBASE.C_SKU (SKUNO, VERSION);
create unique index SFCBASE.PK_C_SKU on SFCBASE.C_SKU (ID);

prompt
prompt Creating table C_SKU_AQL
prompt ========================
prompt
create table SFCBASE.C_SKU_AQL
(
  id          VARCHAR2(50),
  aqltype     VARCHAR2(50),
  skuno       VARCHAR2(50),
  edit_emp    VARCHAR2(50),
  edit_time   DATE,
  defaullevel VARCHAR2(10)
)
;
create index SFCBASE.IDX_C_SKU_AQL_SKUNO on SFCBASE.C_SKU_AQL (SKUNO);

prompt
prompt Creating table C_SKU_DETAIL
prompt ===========================
prompt
create table SFCBASE.C_SKU_DETAIL
(
  id            VARCHAR2(50),
  skuno         VARCHAR2(30),
  category      VARCHAR2(30),
  category_name VARCHAR2(30),
  value         VARCHAR2(200),
  extend        VARCHAR2(50),
  version       VARCHAR2(20),
  basetemplate  VARCHAR2(100),
  snlength      NUMBER,
  station_name  VARCHAR2(100),
  seq_no        VARCHAR2(100),
  edit_emp      VARCHAR2(30),
  edit_time     DATE
)
;
comment on column SFCBASE.C_SKU_DETAIL.id
  is 'ID 號';
comment on column SFCBASE.C_SKU_DETAIL.skuno
  is '料號';
comment on column SFCBASE.C_SKU_DETAIL.category
  is '管控類型';
comment on column SFCBASE.C_SKU_DETAIL.category_name
  is '管控類型名稱';
comment on column SFCBASE.C_SKU_DETAIL.value
  is '管控類型信息';
comment on column SFCBASE.C_SKU_DETAIL.extend
  is '拓展信息';
comment on column SFCBASE.C_SKU_DETAIL.version
  is '版本';
comment on column SFCBASE.C_SKU_DETAIL.basetemplate
  is 'SN規則';
comment on column SFCBASE.C_SKU_DETAIL.station_name
  is '工站名稱';
comment on column SFCBASE.C_SKU_DETAIL.seq_no
  is '不知道什麼鬼,SEQ_NO竟然不用序列!';
comment on column SFCBASE.C_SKU_DETAIL.edit_emp
  is '最後編輯人';
comment on column SFCBASE.C_SKU_DETAIL.edit_time
  is '最後編輯時間';
create index SFCBASE.IDX_C_SKU_DETAIL0 on SFCBASE.C_SKU_DETAIL (CATEGORY_NAME, CATEGORY, SKUNO);
create unique index SFCBASE.PK_C_SKU_DETAIL on SFCBASE.C_SKU_DETAIL (ID);

prompt
prompt Creating table C_SKU_EX
prompt =======================
prompt
create table SFCBASE.C_SKU_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_SKU_EX on SFCBASE.C_SKU_EX (ID, SEQ_NO);

prompt
prompt Creating table C_SKU_LABEL
prompt ==========================
prompt
create table SFCBASE.C_SKU_LABEL
(
  id        VARCHAR2(50) not null,
  skuno     VARCHAR2(50),
  station   VARCHAR2(50),
  seq       NUMBER,
  qty       NUMBER,
  labelname VARCHAR2(50),
  labeltype VARCHAR2(50),
  edit_time DATE,
  edit_emp  VARCHAR2(20)
)
;
create index SFCBASE.IDX_C_SKU_LABEL_LABELNAME on SFCBASE.C_SKU_LABEL (LABELNAME);
create index SFCBASE.IDX_C_SKU_LABEL_SKUNO on SFCBASE.C_SKU_LABEL (SKUNO);
alter table SFCBASE.C_SKU_LABEL
  add constraint PK_C_SKU_LABEL_ID primary key (ID);

prompt
prompt Creating table C_SKU_MPN
prompt ========================
prompt
create table SFCBASE.C_SKU_MPN
(
  id        VARCHAR2(50),
  skuno     VARCHAR2(50),
  partno    VARCHAR2(50),
  mpn       VARCHAR2(50),
  mfrcode   VARCHAR2(50),
  edit_time DATE,
  edit_emp  VARCHAR2(20)
)
;
create index SFCBASE.IDX_C_SKU_MPN_PARTNO on SFCBASE.C_SKU_MPN (PARTNO);
create index SFCBASE.IDX_C_SKU_MPN_SKUNO on SFCBASE.C_SKU_MPN (SKUNO);
grant select, insert, update, delete on SFCBASE.C_SKU_MPN to TEST;

prompt
prompt Creating table C_SKU_SAMPLE
prompt ===========================
prompt
create table SFCBASE.C_SKU_SAMPLE
(
  id           VARCHAR2(50),
  skuno        VARCHAR2(50),
  station_name VARCHAR2(50),
  aql_type     VARCHAR2(50),
  edit_emp     VARCHAR2(50),
  edit_time    DATE
)
;
create index SFCBASE.IDX_C_SKU_SAMPLE0 on SFCBASE.C_SKU_SAMPLE (SKUNO, STATION_NAME);
create unique index SFCBASE.PK_C_SKU_SAMPLE on SFCBASE.C_SKU_SAMPLE (ID);

prompt
prompt Creating table C_SKU_VER_MAPPING
prompt ================================
prompt
create table SFCBASE.C_SKU_VER_MAPPING
(
  id               VARCHAR2(50) not null,
  fox_skuno        VARCHAR2(50),
  customer_skuno   VARCHAR2(50),
  fox_version1     VARCHAR2(10),
  fox_version2     VARCHAR2(10),
  customer_version VARCHAR2(10),
  edit_emp         VARCHAR2(20),
  edit_time        DATE
)
;
comment on column SFCBASE.C_SKU_VER_MAPPING.id
  is '唯一行標識ID';
comment on column SFCBASE.C_SKU_VER_MAPPING.fox_skuno
  is 'Foxconn 機種料號';
comment on column SFCBASE.C_SKU_VER_MAPPING.customer_skuno
  is '客戶機種料號';
comment on column SFCBASE.C_SKU_VER_MAPPING.fox_version1
  is 'Foxconn 2位數版本號';
comment on column SFCBASE.C_SKU_VER_MAPPING.fox_version2
  is 'Foxconn 3位數版本號';
comment on column SFCBASE.C_SKU_VER_MAPPING.customer_version
  is '客戶3位數版本號';
comment on column SFCBASE.C_SKU_VER_MAPPING.edit_emp
  is '編輯人';
comment on column SFCBASE.C_SKU_VER_MAPPING.edit_time
  is '編輯時間';
create index SFCBASE.IDX_C_SKU_VER_MAP_C_SKU on SFCBASE.C_SKU_VER_MAPPING (CUSTOMER_SKUNO);
create index SFCBASE.IDX_C_SKU_VER_MAP_F_SKU on SFCBASE.C_SKU_VER_MAPPING (FOX_SKUNO);
alter table SFCBASE.C_SKU_VER_MAPPING
  add constraint PK_C_SKU_VER_MAPPING_ID primary key (ID);

prompt
prompt Creating table C_SN_RULE
prompt ========================
prompt
create table SFCBASE.C_SN_RULE
(
  id        VARCHAR2(50) not null,
  name      VARCHAR2(50),
  curvalue  VARCHAR2(50),
  edit_time DATE,
  edit_emp  VARCHAR2(20)
)
;
create index SFCBASE.IDX_C_SN_RULE_NAME on SFCBASE.C_SN_RULE (NAME);
alter table SFCBASE.C_SN_RULE
  add constraint PK_ID primary key (ID);

prompt
prompt Creating table C_SN_RULE_DETAIL
prompt ===============================
prompt
create table SFCBASE.C_SN_RULE_DETAIL
(
  id           VARCHAR2(50) not null,
  c_sn_rule_id VARCHAR2(50),
  seq          NUMBER,
  inputtype    VARCHAR2(20),
  codetype     VARCHAR2(20),
  curvalue     VARCHAR2(20),
  resetsn_flag NUMBER,
  resetvalue   VARCHAR2(20),
  check_flag   NUMBER,
  edit_time    DATE,
  edit_emp     VARCHAR2(20),
  value10      VARCHAR2(20)
)
;
create index SFCBASE.IDX_C_SN_RULE_DETAIL_SN_ID on SFCBASE.C_SN_RULE_DETAIL (C_SN_RULE_ID);
alter table SFCBASE.C_SN_RULE_DETAIL
  add constraint PK_C_SN_RULE_DETAIL_ID primary key (ID);

prompt
prompt Creating table C_STATION
prompt ========================
prompt
create table SFCBASE.C_STATION
(
  id           VARCHAR2(50),
  station_name VARCHAR2(50),
  type         VARCHAR2(30)
)
;
create unique index SFCBASE.PK_C_STATION on SFCBASE.C_STATION (ID);

prompt
prompt Creating table C_STATION_ACTION
prompt ===============================
prompt
create table SFCBASE.C_STATION_ACTION
(
  id            VARCHAR2(50),
  action_type   VARCHAR2(50),
  action_name   VARCHAR2(100),
  dll_name      VARCHAR2(255),
  class_name    VARCHAR2(255),
  function_name VARCHAR2(255),
  description   VARCHAR2(500),
  bu            VARCHAR2(50),
  sorting       VARCHAR2(50),
  use_station   VARCHAR2(50),
  edit_time     DATE,
  edit_emp      VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_STATION_ACTION on SFCBASE.C_STATION_ACTION (ID);

prompt
prompt Creating table C_STATION_EX
prompt ===========================
prompt
create table SFCBASE.C_STATION_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_STATION_EX on SFCBASE.C_STATION_EX (ID, SEQ_NO);

prompt
prompt Creating table C_STATION_SECTION
prompt ================================
prompt
create table SFCBASE.C_STATION_SECTION
(
  id          VARCHAR2(50),
  section_id  VARCHAR2(50),
  station_id  VARCHAR2(50),
  description VARCHAR2(200),
  edit_time   DATE,
  edit_emp    VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_STATION_SECTION on SFCBASE.C_STATION_SECTION (ID);

prompt
prompt Creating table C_STATION_SECTION_EX
prompt ===================================
prompt
create table SFCBASE.C_STATION_SECTION_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_STATION_SECTION_EX on SFCBASE.C_STATION_SECTION_EX (ID, SEQ_NO);

prompt
prompt Creating table C_STORAGE_CODE
prompt =============================
prompt
create table SFCBASE.C_STORAGE_CODE
(
  id           VARCHAR2(50),
  plant        VARCHAR2(50),
  storage_code VARCHAR2(50),
  description  VARCHAR2(200),
  edit_time    DATE,
  edit_emp     VARCHAR2(50)
)
;
create index SFCBASE.IDX_C_STORAGE_CODE0 on SFCBASE.C_STORAGE_CODE (STORAGE_CODE);
create unique index SFCBASE.PK_C_STORAGE_CODE on SFCBASE.C_STORAGE_CODE (ID);

prompt
prompt Creating table C_STORAGE_ITEM
prompt =============================
prompt
create table SFCBASE.C_STORAGE_ITEM
(
  id           VARCHAR2(50),
  item_name    VARCHAR2(50),
  item_son     VARCHAR2(50),
  storage_code VARCHAR2(50),
  edit_time    DATE,
  edit_emp     VARCHAR2(50)
)
;
create index SFCBASE.IDX_C_STORAGE_ITEM0 on SFCBASE.C_STORAGE_ITEM (ITEM_SON, STORAGE_CODE);
create unique index SFCBASE.PK_C_STORAGE_ITEM on SFCBASE.C_STORAGE_ITEM (ID);

prompt
prompt Creating table C_TABLE_EXTEND_DEFINE
prompt ====================================
prompt
create table SFCBASE.C_TABLE_EXTEND_DEFINE
(
  owner_name   VARCHAR2(10),
  table_name   VARCHAR2(50),
  column_name  VARCHAR2(50),
  column_value VARCHAR2(50),
  column_desc  VARCHAR2(200),
  edit_time    DATE,
  edit_emp     VARCHAR2(50)
)
;

prompt
prompt Creating table C_TABLE_EXTEND_DEFINE_EX
prompt =======================================
prompt
create table SFCBASE.C_TABLE_EXTEND_DEFINE_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_TABLE_EXTEND_DEFINE_EX on SFCBASE.C_TABLE_EXTEND_DEFINE_EX (ID, SEQ_NO);

prompt
prompt Creating table C_TAB_COLUMN_MAP
prompt ===============================
prompt
create table SFCBASE.C_TAB_COLUMN_MAP
(
  id          VARCHAR2(50),
  tab_name    VARCHAR2(50),
  tab_column  VARCHAR2(200),
  description VARCHAR2(100),
  edit_emp    VARCHAR2(50),
  edit_time   DATE
)
;
create index SFCBASE.IDX_C_TAB_COLUMN_MAP0 on SFCBASE.C_TAB_COLUMN_MAP (TAB_NAME);
create unique index SFCBASE.PK_C_TAB_COLUMN_MAP on SFCBASE.C_TAB_COLUMN_MAP (ID);

prompt
prompt Creating table C_TEMES_STATION_MAPPING
prompt ======================================
prompt
create table SFCBASE.C_TEMES_STATION_MAPPING
(
  id          VARCHAR2(50),
  tegroup     VARCHAR2(10),
  te_station  VARCHAR2(30),
  mes_station VARCHAR2(30)
)
;
create index SFCBASE.IDX_C_TEMES_MAPPING_GROUP on SFCBASE.C_TEMES_STATION_MAPPING (TEGROUP);
grant select, insert, update, delete on SFCBASE.C_TEMES_STATION_MAPPING to TEST;

prompt
prompt Creating table C_TRANSPORT_TYPE
prompt ===============================
prompt
create table SFCBASE.C_TRANSPORT_TYPE
(
  id             VARCHAR2(50),
  transport_type VARCHAR2(50),
  edit_time      DATE,
  edit_emp       VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_TRANSPORT_TYPE on SFCBASE.C_TRANSPORT_TYPE (ID);

prompt
prompt Creating table C_USER
prompt =====================
prompt
create table SFCBASE.C_USER
(
  id                   VARCHAR2(50),
  factory              VARCHAR2(30),
  bu_name              VARCHAR2(30),
  emp_no               VARCHAR2(50),
  emp_password         VARCHAR2(50),
  emp_name             VARCHAR2(100),
  emp_level            VARCHAR2(10),
  dpt_name             VARCHAR2(50),
  position_name        VARCHAR2(50),
  mail_address         VARCHAR2(50),
  phone_number         VARCHAR2(30),
  location             VARCHAR2(50),
  lock_flag            VARCHAR2(2),
  agent_emp_no         VARCHAR2(50),
  change_password_time DATE,
  emp_desc             VARCHAR2(100),
  edit_time            DATE,
  edit_emp             VARCHAR2(50),
  emp_en_name          VARCHAR2(50),
  emp_id_card          VARCHAR2(20),
  director_mail        VARCHAR2(50)
)
;
comment on column SFCBASE.C_USER.emp_id_card
  is '身份證';
comment on column SFCBASE.C_USER.director_mail
  is '主管郵箱';
create index SFCBASE.IDX_C_USER0 on SFCBASE.C_USER (EMP_NO, EMP_PASSWORD);
create unique index SFCBASE.PK_C_USER on SFCBASE.C_USER (ID);
create unique index SFCBASE.UNQ_C_USER on SFCBASE.C_USER (EMP_NO);

prompt
prompt Creating table C_USER_EX
prompt ========================
prompt
create table SFCBASE.C_USER_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_USER_EX on SFCBASE.C_USER_EX (ID, SEQ_NO);

prompt
prompt Creating table C_USER_PRIVILEGE
prompt ===============================
prompt
create table SFCBASE.C_USER_PRIVILEGE
(
  id           VARCHAR2(50),
  system_name  VARCHAR2(30),
  user_id      VARCHAR2(50),
  privilege_id VARCHAR2(50),
  edit_time    DATE,
  edit_emp     VARCHAR2(50)
)
;
create unique index SFCBASE.PK_C_USER_PRIVILEGE on SFCBASE.C_USER_PRIVILEGE (ID);

prompt
prompt Creating table C_USER_PRIVILEGE_EX
prompt ==================================
prompt
create table SFCBASE.C_USER_PRIVILEGE_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_USER_PRIVILEGE_EX on SFCBASE.C_USER_PRIVILEGE_EX (ID, SEQ_NO);

prompt
prompt Creating table C_USER_ROLE
prompt ==========================
prompt
create table SFCBASE.C_USER_ROLE
(
  id           VARCHAR2(50),
  system_name  VARCHAR2(30),
  user_id      VARCHAR2(50),
  role_id      VARCHAR2(50),
  operate_flag VARCHAR2(2),
  edit_time    DATE,
  edit_emp     VARCHAR2(10)
)
;
create unique index SFCBASE.PK_C_USER_ROLE on SFCBASE.C_USER_ROLE (ID);

prompt
prompt Creating table C_USER_ROLE_EX
prompt =============================
prompt
create table SFCBASE.C_USER_ROLE_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_USER_ROLE_EX on SFCBASE.C_USER_ROLE_EX (ID, SEQ_NO);

prompt
prompt Creating table C_WEIGHT
prompt =======================
prompt
create table SFCBASE.C_WEIGHT
(
  id         VARCHAR2(50),
  type       VARCHAR2(10),
  skuno      VARCHAR2(50),
  partno     VARCHAR2(50),
  mpn        VARCHAR2(50),
  maxweight  VARCHAR2(10),
  avgweight  VARCHAR2(10),
  minweight  VARCHAR2(10),
  station    VARCHAR2(20),
  enableflag VARCHAR2(10),
  createtime DATE,
  createby   VARCHAR2(20),
  edittime   DATE,
  editby     VARCHAR2(20)
)
;
create unique index SFCBASE.PK_C_WEIGHT_I on SFCBASE.C_WEIGHT (ID);
grant select, insert, update, delete on SFCBASE.C_WEIGHT to TEST;

prompt
prompt Creating table C_WORK_CLASS
prompt ===========================
prompt
create table SFCBASE.C_WORK_CLASS
(
  id         VARCHAR2(50),
  name       VARCHAR2(50),
  start_time VARCHAR2(8),
  end_time   VARCHAR2(8)
)
;
create unique index SFCBASE.PK_C_WORK_CLASS on SFCBASE.C_WORK_CLASS (ID);

prompt
prompt Creating table C_WORK_CLASS_EX
prompt ==============================
prompt
create table SFCBASE.C_WORK_CLASS_EX
(
  id     VARCHAR2(50),
  seq_no NUMBER,
  name   VARCHAR2(50),
  value  VARCHAR2(200)
)
;
create unique index SFCBASE.PK_C_WORK_CLASS_EX on SFCBASE.C_WORK_CLASS_EX (ID, SEQ_NO);

prompt
prompt Creating table R_CMCHOST_DETAIL
prompt ===============================
prompt
create table SFCBASE.R_CMCHOST_DETAIL
(
  id           VARCHAR2(50) not null,
  host_id      VARCHAR2(50),
  line         VARCHAR2(50),
  station_name VARCHAR2(50),
  ip           VARCHAR2(50),
  cmctype      VARCHAR2(50),
  edit_time    DATE,
  edit_emp     VARCHAR2(50)
)
;
alter table SFCBASE.R_CMCHOST_DETAIL
  add constraint PK_R_CMCHOST_DETAIL primary key (ID);

prompt
prompt Creating table R_DN_STATUS
prompt ==========================
prompt
create table SFCBASE.R_DN_STATUS
(
  dn_no      VARCHAR2(20) not null,
  dn_line    VARCHAR2(10),
  po_no      VARCHAR2(20),
  po_line    VARCHAR2(10),
  so_no      VARCHAR2(20),
  skuno      VARCHAR2(50),
  qty        NUMBER(10),
  gttype     VARCHAR2(50),
  gt_flag    VARCHAR2(10) default 0,
  gtdate     DATE,
  dn_flag    VARCHAR2(10) default 0,
  dn_plant   VARCHAR2(10),
  createtime DATE,
  edittime   DATE,
  gtevent    VARCHAR2(10),
  id         VARCHAR2(50) not null
)
;
comment on column SFCBASE.R_DN_STATUS.gt_flag
  is '0:WAIT GT;1:GT FINISH;2:LOCKGT;';
comment on column SFCBASE.R_DN_STATUS.dn_flag
  is '0:WAIT SHIP;1:WAIT CQA;2:WAIT GT;3:GTFINISH;';
alter table SFCBASE.R_DN_STATUS
  add constraint PK_R_DN_STATUS_ID primary key (ID);

prompt
prompt Creating table R_TO_DETAIL
prompt ==========================
prompt
create table SFCBASE.R_TO_DETAIL
(
  to_no       VARCHAR2(50),
  to_item_no  VARCHAR2(10),
  dn_no       VARCHAR2(20),
  dn_customer VARCHAR2(20),
  createtime  DATE,
  id          VARCHAR2(50) not null
)
;
alter table SFCBASE.R_TO_DETAIL
  add constraint PK_R_TO_DETAIL_ID primary key (ID);

prompt
prompt Creating table R_TO_HEAD
prompt ========================
prompt
create table SFCBASE.R_TO_HEAD
(
  to_no         VARCHAR2(50),
  plan_startime DATE,
  plan_endtime  DATE,
  to_createtime VARCHAR2(20),
  container_no  VARCHAR2(50),
  vehicle_no    VARCHAR2(50),
  external_no   VARCHAR2(10),
  drop_flag     VARCHAR2(10),
  createtime    DATE,
  id            VARCHAR2(50) not null
)
;
alter table SFCBASE.R_TO_HEAD
  add constraint PK_R_TO_HEAD_ID primary key (ID);

prompt
prompt Creating table SD_CUSTMER_PO
prompt ============================
prompt
create table SFCBASE.SD_CUSTMER_PO
(
  vbeln VARCHAR2(250),
  erdat VARCHAR2(250),
  kunnr VARCHAR2(250),
  name1 VARCHAR2(250),
  bstnk VARCHAR2(250),
  auart VARCHAR2(250),
  bstdk VARCHAR2(250)
)
;

prompt
prompt Creating table SD_CUSTOMER_PO_ITEM
prompt ==================================
prompt
create table SFCBASE.SD_CUSTOMER_PO_ITEM
(
  vbeln  VARCHAR2(250),
  posnr  VARCHAR2(250),
  matnr  VARCHAR2(250),
  arktx  VARCHAR2(250),
  kwmeng VARCHAR2(250),
  netpr  VARCHAR2(250),
  posex  VARCHAR2(250)
)
;

prompt
prompt Creating table SD_CUSTOMER_SO
prompt =============================
prompt
create table SFCBASE.SD_CUSTOMER_SO
(
  vbeln   VARCHAR2(250),
  posnr   VARCHAR2(250),
  bstkd   VARCHAR2(250),
  posex   VARCHAR2(250),
  bstkd_e VARCHAR2(250),
  posex_e VARCHAR2(250),
  name1   VARCHAR2(250),
  ihrez_e VARCHAR2(250)
)
;

prompt
prompt Creating table SD_DN_DETAIL
prompt ===========================
prompt
create table SFCBASE.SD_DN_DETAIL
(
  vbeln VARCHAR2(250),
  posnr VARCHAR2(250),
  bstkd VARCHAR2(250),
  matnr VARCHAR2(250),
  arktx VARCHAR2(250),
  ntgew VARCHAR2(250),
  brgew VARCHAR2(250),
  volum VARCHAR2(250),
  kbetr VARCHAR2(250),
  lfimg VARCHAR2(250),
  vgbel VARCHAR2(250),
  vgpos VARCHAR2(250),
  erdat VARCHAR2(250),
  gewei VARCHAR2(250),
  mtart VARCHAR2(250),
  matkl VARCHAR2(250),
  lgort VARCHAR2(250),
  kdmat VARCHAR2(250),
  sdabw VARCHAR2(250),
  kunnr VARCHAR2(250),
  land1 VARCHAR2(250),
  ort01 VARCHAR2(250),
  netpr VARCHAR2(250)
)
;

prompt
prompt Creating table SD_REPORT_DETAIL
prompt ===============================
prompt
create table SFCBASE.SD_REPORT_DETAIL
(
  vbeln      VARCHAR2(250),
  tknum      VARCHAR2(250),
  tpnum      VARCHAR2(250),
  name1      VARCHAR2(250),
  floor      VARCHAR2(250),
  roomnum    VARCHAR2(250),
  street     VARCHAR2(250),
  building   VARCHAR2(250),
  city1      VARCHAR2(250),
  natio      VARCHAR2(250),
  bezei      VARCHAR2(250),
  ort01      VARCHAR2(250),
  city2      VARCHAR2(250),
  gewei      VARCHAR2(250),
  inco1      VARCHAR2(250),
  inco2      VARCHAR2(250),
  name2      VARCHAR2(250),
  name3      VARCHAR2(250),
  name4      VARCHAR2(250),
  str_suppl1 VARCHAR2(250),
  str_suppl2 VARCHAR2(250),
  str_suppl3 VARCHAR2(250),
  location   VARCHAR2(250)
)
;

prompt
prompt Creating table SD_TO_DETAIL
prompt ===========================
prompt
create table SFCBASE.SD_TO_DETAIL
(
  vbeln VARCHAR2(250),
  tknum VARCHAR2(250),
  tpnum VARCHAR2(250),
  kunnr VARCHAR2(250),
  lfart VARCHAR2(250),
  land1 VARCHAR2(250),
  ort01 VARCHAR2(250)
)
;

prompt
prompt Creating table SD_TO_HEAD
prompt =========================
prompt
create table SFCBASE.SD_TO_HEAD
(
  tknum  VARCHAR2(250),
  dpreg  VARCHAR2(250),
  upreg  VARCHAR2(250),
  dpabf  VARCHAR2(250),
  upabf  VARCHAR2(250),
  erdat  VARCHAR2(250),
  aedat  VARCHAR2(250),
  aezet  VARCHAR2(250),
  signi  VARCHAR2(250),
  exti2  VARCHAR2(250),
  exti1  VARCHAR2(250),
  kunag  VARCHAR2(250),
  werks  VARCHAR2(250),
  shtyp  VARCHAR2(250),
  shipto VARCHAR2(250),
  tpbez  VARCHAR2(250),
  erzet  VARCHAR2(250)
)
;

prompt
prompt Creating table TABLEDESC
prompt ========================
prompt
create table SFCBASE.TABLEDESC
(
  tablename        VARCHAR2(100),
  descripition     VARCHAR2(300),
  sortno           NUMBER,
  efoxtable_old    VARCHAR2(300),
  linktable_column VARCHAR2(300),
  trueorfalse      VARCHAR2(20),
  xw_table_old     VARCHAR2(300)
)
;

prompt
prompt Creating table TB_POST
prompt ======================
prompt
create table SFCBASE.TB_POST
(
  id          NUMBER(12),
  title       VARCHAR2(255),
  content     CLOB,
  authorid    NUMBER(6),
  authorname  VARCHAR2(50),
  createdat   DATE,
  publishedat DATE,
  isdeleted   CHAR(1),
  allowshow   CHAR(1),
  viewcount   NUMBER(10)
)
;


spool off
