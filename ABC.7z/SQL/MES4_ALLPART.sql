﻿-------------------------------------------------
-- Export file for user MES4@DCNAPDB           --
-- Created by HuongHV on 8/1/2022, 11:17:30 AM --
-------------------------------------------------

set define off
spool MES4_ALLPART.log

prompt
prompt Creating table AGILE_ECN
prompt ========================
prompt
create table MES4.AGILE_ECN
(
  change_number     VARCHAR2(90),
  customer_item     VARCHAR2(150),
  item_number       VARCHAR2(300),
  part_rev          VARCHAR2(40),
  ecn_transfer_mode VARCHAR2(2048),
  customer_ecn      VARCHAR2(150),
  effective_date    DATE,
  release_date      DATE,
  travel_no         VARCHAR2(30),
  feeder_setup_no   VARCHAR2(30),
  unable            VARCHAR2(2) default 0,
  dcc_checked       VARCHAR2(2) default 0,
  wo_used           VARCHAR2(2) default 0,
  is_dccinsert      VARCHAR2(2),
  bu                VARCHAR2(2048)
)
;
grant select, insert, update, delete on MES4.AGILE_ECN to MES1;

prompt
prompt Creating table AGILE_ECN_QC_FAI
prompt ===============================
prompt
create table MES4.AGILE_ECN_QC_FAI
(
  wo          VARCHAR2(20),
  fai         VARCHAR2(50),
  update_time DATE,
  type        VARCHAR2(50),
  is_closed   VARCHAR2(2) default 0,
  workorder   VARCHAR2(50),
  user_name   VARCHAR2(20),
  ecn_desc    VARCHAR2(500)
)
;
grant select, insert, update, delete on MES4.AGILE_ECN_QC_FAI to MES1;

prompt
prompt Creating table AGILE_PROJECT_REPORT
prompt ===================================
prompt
create table MES4.AGILE_PROJECT_REPORT
(
  wo                VARCHAR2(20),
  workorderno       VARCHAR2(20),
  pn                VARCHAR2(20),
  customer_per_dscp VARCHAR2(1000),
  check_per_dscp    VARCHAR2(1000),
  update_soft       VARCHAR2(50),
  update_soft_dscp  VARCHAR2(1000),
  back_soft         VARCHAR2(50),
  back_soft_dscp    VARCHAR2(1000),
  other_soft        VARCHAR2(50),
  other_soft_dscp   VARCHAR2(1000),
  pe_conform        VARCHAR2(1),
  last_edit_date    DATE,
  update_soft_ecn   VARCHAR2(20),
  back_soft_ecn     VARCHAR2(20),
  other_soft_ecn    VARCHAR2(20),
  remark            VARCHAR2(1000)
)
;
grant select, insert, update, delete on MES4.AGILE_PROJECT_REPORT to MES1;

prompt
prompt Creating table AGILE_PROJECT_WO
prompt ===============================
prompt
create table MES4.AGILE_PROJECT_WO
(
  wo             VARCHAR2(20),
  is_started     VARCHAR2(1) default 0,
  is_confirm     VARCHAR2(1) default 0,
  sendmail_count VARCHAR2(5) default 0
)
;
grant select, insert, update, delete on MES4.AGILE_PROJECT_WO to MES1;

prompt
prompt Creating table AGILE_REDLINE_SOFTWARE
prompt =====================================
prompt
create table MES4.AGILE_REDLINE_SOFTWARE
(
  change_number  VARCHAR2(90),
  affected_item  VARCHAR2(150),
  redline_item   VARCHAR2(300),
  item_longdesc  VARCHAR2(4000),
  effective_date DATE,
  release_date   DATE
)
;
grant select, insert, update, delete on MES4.AGILE_REDLINE_SOFTWARE to MES1;

prompt
prompt Creating table AGILE_SAP_COMPARE
prompt ================================
prompt
create table MES4.AGILE_SAP_COMPARE
(
  wo                   VARCHAR2(20),
  pn_sap               VARCHAR2(20),
  pn_per_sap           VARCHAR2(10),
  virtual_pn_sap       VARCHAR2(20),
  virtual_pn_per_sap   VARCHAR2(10),
  pn_agile             VARCHAR2(20),
  pn_per_agile         VARCHAR2(10),
  virtual_pn_agile     VARCHAR2(20),
  virtual_pn_per_agile VARCHAR2(10),
  is_closed            VARCHAR2(10) default 0,
  ecn_no               VARCHAR2(20),
  virtual_ecn_no       VARCHAR2(20),
  pn_cust              VARCHAR2(15),
  virtual_pn_cust      VARCHAR2(10),
  pe_response          VARCHAR2(100),
  pc_response          VARCHAR2(100),
  smt_response         VARCHAR2(100),
  last_edit_time       DATE,
  pc_close             VARCHAR2(200),
  model                VARCHAR2(100),
  is_started           VARCHAR2(10) default 0,
  assy_response        VARCHAR2(100)
)
;
grant select, insert, update, delete on MES4.AGILE_SAP_COMPARE to MES1;

prompt
prompt Creating table AGILE_SPECIFIC_DOC
prompt =================================
prompt
create table MES4.AGILE_SPECIFIC_DOC
(
  change_number  VARCHAR2(90),
  item_number    VARCHAR2(300),
  part_rev       VARCHAR2(40),
  description    VARCHAR2(2046),
  effective_date DATE,
  release_date   DATE
)
;
grant select, insert, update, delete on MES4.AGILE_SPECIFIC_DOC to MES1;

prompt
prompt Creating table AMS_AP
prompt =====================
prompt
create table MES4.AMS_AP
(
  ap_name     VARCHAR2(50) not null,
  ap_version  VARCHAR2(50) not null,
  ap_path     VARCHAR2(50) not null,
  ap_desc     VARCHAR2(200),
  ap_type     VARCHAR2(5) not null,
  file_name   VARCHAR2(60) not null,
  update_time DATE default Sysdate not null,
  ap_group    VARCHAR2(20) not null
)
;

prompt
prompt Creating table AMS_AP_DEVICES
prompt =============================
prompt
create table MES4.AMS_AP_DEVICES
(
  ap_name    VARCHAR2(50) not null,
  device_key VARCHAR2(50) not null,
  key_type   VARCHAR2(50) not null,
  valid      VARCHAR2(1),
  ip         VARCHAR2(30),
  edit_time  DATE default SYSDATE not null,
  edit_emp   VARCHAR2(20) not null
)
;
create index MES4.IDX_AMS_AP_DEVICES on MES4.AMS_AP_DEVICES (AP_NAME, DEVICE_KEY, VALID)
  nologging;
create index MES4.IDX_AMS_AP_DEVICES2 on MES4.AMS_AP_DEVICES (AP_NAME, KEY_TYPE, VALID)
  nologging;
grant select, insert, update, delete on MES4.AMS_AP_DEVICES to MES1;

prompt
prompt Creating table AMS_AP_GROUP
prompt ===========================
prompt
create table MES4.AMS_AP_GROUP
(
  ap_group VARCHAR2(20) not null
)
;

prompt
prompt Creating table AMS_PRIVILEGE
prompt ============================
prompt
create table MES4.AMS_PRIVILEGE
(
  emp_no      VARCHAR2(20) not null,
  ap_name     VARCHAR2(50) not null,
  permit_time DATE default Sysdate not null,
  favorite    VARCHAR2(2)
)
;

prompt
prompt Creating table AMS_PRIV_GROUP
prompt =============================
prompt
create table MES4.AMS_PRIV_GROUP
(
  priv_group VARCHAR2(20) not null
)
;

prompt
prompt Creating table AMS_SERVER
prompt =========================
prompt
create table MES4.AMS_SERVER
(
  server_alias  VARCHAR2(20) not null,
  server_ip     VARCHAR2(20) not null,
  server_dir    VARCHAR2(50) not null,
  server_status VARCHAR2(10)
)
;

prompt
prompt Creating table APP_LOGIN_LOG
prompt ============================
prompt
create table MES4.APP_LOGIN_LOG
(
  app_name    VARCHAR2(50) not null,
  app_page    VARCHAR2(80),
  emp_no      VARCHAR2(20),
  create_time DATE,
  data1       VARCHAR2(50),
  data2       VARCHAR2(50)
)
;

prompt
prompt Creating table BACKUP_SP
prompt ========================
prompt
create table MES4.BACKUP_SP
(
  owner       VARCHAR2(50),
  name        VARCHAR2(50),
  type        VARCHAR2(50),
  line        NUMBER,
  text        VARCHAR2(4000),
  backup_time DATE default SYSDATE
)
;
create index MES4.BACKUP_SP_BACKUP_TIME on MES4.BACKUP_SP (BACKUP_TIME);
create index MES4.BACKUP_SP_NAME on MES4.BACKUP_SP (NAME);
create index MES4.BACKUP_SP_OWNER on MES4.BACKUP_SP (OWNER);
grant select, insert, update, delete on MES4.BACKUP_SP to MES1;

prompt
prompt Creating table CMC_SHELL_LOG
prompt ============================
prompt
create table MES4.CMC_SHELL_LOG
(
  actiontype VARCHAR2(50),
  division   VARCHAR2(50),
  program    VARCHAR2(50),
  path       VARCHAR2(50),
  filename   VARCHAR2(50),
  client     VARCHAR2(50),
  editdt     DATE,
  pcname     VARCHAR2(50)
)
;
grant select, insert, update, delete, references, alter, index on MES4.CMC_SHELL_LOG to MES1;

prompt
prompt Creating table DOC_CREATE
prompt =========================
prompt
create table MES4.DOC_CREATE
(
  doc         VARCHAR2(20) not null,
  actionid    NUMBER(10) not null,
  doctime     DATE not null,
  confirmuser VARCHAR2(20) not null
)
;
grant select, insert, update, delete on MES4.DOC_CREATE to MES1;

prompt
prompt Creating table EMS_RESELL_INFO
prompt ==============================
prompt
create table MES4.EMS_RESELL_INFO
(
  trans_head_id   NUMBER,
  trans_line_id   NUMBER,
  trans_detail_id NUMBER,
  trans_source_id NUMBER,
  trans_action_id NUMBER,
  bar_code        VARCHAR2(60),
  sn_no           VARCHAR2(80),
  comments        VARCHAR2(255),
  created_date    DATE,
  created_by      NUMBER,
  updated_date    DATE,
  updated_by      NUMBER,
  segment1        VARCHAR2(360),
  segment2        VARCHAR2(360),
  segment3        VARCHAR2(360),
  segment4        VARCHAR2(360),
  segment5        VARCHAR2(360),
  segment6        NUMBER,
  segment7        NUMBER,
  segment8        VARCHAR2(20),
  segment9        DATE,
  segment10       DATE,
  vendor_name     VARCHAR2(360)
)
;
create index MES4.IDX_EMS_RESELL_INFO_BC on MES4.EMS_RESELL_INFO (BAR_CODE)
  nologging;
create index MES4.IDX_EMS_RESELL_INFO_SN on MES4.EMS_RESELL_INFO (SN_NO)
  nologging;
create index MES4.INDEX_SEGMENT7 on MES4.EMS_RESELL_INFO (SEGMENT7)
  nologging;
create index MES4.INDEX_TRANSACTION_HEADER on MES4.EMS_RESELL_INFO (TRANS_HEAD_ID)
  nologging;
grant select, insert, update, delete, alter on MES4.EMS_RESELL_INFO to MES1;

prompt
prompt Creating table H_ALARM_MAIL
prompt ===========================
prompt
create table MES4.H_ALARM_MAIL
(
  alarm_tr_sn     VARCHAR2(13) not null,
  mail_subject    VARCHAR2(180),
  mail_info       VARCHAR2(1000),
  mail_attac      BLOB,
  mail_attac_name VARCHAR2(50)
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_ALARM_MAIL to MES1;

prompt
prompt Creating table H_ALARM_SEND_TASK
prompt ================================
prompt
create table MES4.H_ALARM_SEND_TASK
(
  alarm_tr_sn VARCHAR2(13) not null,
  alarm_type  VARCHAR2(3) not null,
  alarm_code  VARCHAR2(6) not null,
  send_type   VARCHAR2(1) default '0' not null,
  send_orig   VARCHAR2(50),
  remark      VARCHAR2(400) not null,
  work_flag   VARCHAR2(1) default '0' not null,
  work_time   DATE not null
)
;
grant select, insert, update, delete on MES4.H_ALARM_SEND_TASK to MES1;

prompt
prompt Creating table H_ALARM_TASK_HISTORY
prompt ===================================
prompt
create table MES4.H_ALARM_TASK_HISTORY
(
  alarm_tr_sn VARCHAR2(13) not null,
  send_dest   VARCHAR2(500) not null,
  send_cc     VARCHAR2(500),
  send_bcc    VARCHAR2(500),
  send_status VARCHAR2(1) not null,
  work_time   DATE not null
)
;
grant select, insert on MES4.H_ALARM_TASK_HISTORY to MES1;

prompt
prompt Creating table H_DOC_NO
prompt =======================
prompt
create table MES4.H_DOC_NO
(
  doc_no     VARCHAR2(15) not null,
  whs_doc_no VARCHAR2(15) not null,
  work_time  DATE not null
)
;
create index MES4.H_DOC_NO on MES4.H_DOC_NO (DOC_NO)
  nologging;
create index MES4.H_WHS_DOC_NO on MES4.H_DOC_NO (WHS_DOC_NO)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.H_DOC_NO to MES1;

prompt
prompt Creating table H_DOMI_ERROR
prompt ===========================
prompt
create table MES4.H_DOMI_ERROR
(
  p_sn          VARCHAR2(25) not null,
  test_date     DATE not null,
  p_no          VARCHAR2(20) not null,
  error_type    VARCHAR2(1) not null,
  error_data    VARCHAR2(100),
  handle_flag   VARCHAR2(1) default '0' not null,
  efox_emp_name VARCHAR2(30) not null,
  edit_time     DATE not null
)
;
grant select, insert on MES4.H_DOMI_ERROR to MES1;

prompt
prompt Creating table H_DOMI_HISTORY
prompt =============================
prompt
create table MES4.H_DOMI_HISTORY
(
  p_sn          VARCHAR2(25) not null,
  test_date     DATE not null,
  efox_station  VARCHAR2(20) not null,
  p_no          VARCHAR2(20) not null,
  efox_emp_name VARCHAR2(30) not null,
  edit_time     DATE not null
)
;
create index MES4.H_DOMI_HISTORY_PNO on MES4.H_DOMI_HISTORY (P_NO)
  nologging;
create index MES4.H_DOMI_HISTORY_PSN on MES4.H_DOMI_HISTORY (P_SN)
  nologging;
grant select, insert on MES4.H_DOMI_HISTORY to MES1;

prompt
prompt Creating table H_ECN_BASE
prompt =========================
prompt
create table MES4.H_ECN_BASE
(
  sheet_no            VARCHAR2(15) not null,
  create_time         DATE not null,
  plant               VARCHAR2(10),
  customer            VARCHAR2(20),
  vendor              VARCHAR2(20),
  change_desc         VARCHAR2(300),
  change_type         VARCHAR2(50),
  affected_mfg_kp_no  VARCHAR2(500),
  affected_cust_kp_no VARCHAR2(500),
  issued_time         DATE,
  effected_date       DATE,
  attac_no            VARCHAR2(15),
  prepare_email_no    VARCHAR2(15),
  prepare_emp         VARCHAR2(10) not null,
  prepare_time        DATE not null,
  approve_email_no    VARCHAR2(15),
  approve_emp         VARCHAR2(10),
  approve_time        DATE,
  ecn_status          VARCHAR2(1) default '0' not null,
  close_time          DATE,
  delete_emp          VARCHAR2(10),
  delete_time         DATE
)
;
grant select, insert, update, delete on MES4.H_ECN_BASE to MES1;

prompt
prompt Creating table H_ECN_CE_CONFIRM
prompt ===============================
prompt
create table MES4.H_ECN_CE_CONFIRM
(
  sheet_no         VARCHAR2(15) not null,
  inspect_comment  VARCHAR2(500) not null,
  run_flag         VARCHAR2(300) default '0' not null,
  prepare_email_no VARCHAR2(15),
  prepare_emp      VARCHAR2(10) not null,
  prepare_time     DATE not null,
  approve_email_no VARCHAR2(15),
  approve_emp      VARCHAR2(10),
  approve_time     DATE
)
;
grant select, insert, update, delete on MES4.H_ECN_CE_CONFIRM to MES1;

prompt
prompt Creating table H_ECN_INSPECT
prompt ============================
prompt
create table MES4.H_ECN_INSPECT
(
  sheet_no         VARCHAR2(15) not null,
  po_no            VARCHAR2(15) not null,
  inspect_time     DATE not null,
  inspect_qty      NUMBER(10) not null,
  prepare_email_no VARCHAR2(15),
  prepare_emp      VARCHAR2(10) not null,
  prepare_time     DATE not null,
  approve_email_no VARCHAR2(15),
  approve_emp      VARCHAR2(10),
  approve_time     DATE
)
;
grant select, insert, update, delete on MES4.H_ECN_INSPECT to MES1;

prompt
prompt Creating table H_ECN_PQE_CONFIRM
prompt ================================
prompt
create table MES4.H_ECN_PQE_CONFIRM
(
  sheet_no         VARCHAR2(15) not null,
  run_qty          NUMBER(5) not null,
  date_code        VARCHAR2(20),
  lot_code         VARCHAR2(20),
  failed_qty       NUMBER(5) not null,
  evaluation       VARCHAR2(100),
  run_result       VARCHAR2(1) default '0' not null,
  prepare_email_no VARCHAR2(15),
  prepare_emp      VARCHAR2(10) not null,
  prepare_time     DATE not null,
  approve_email_no VARCHAR2(15),
  approve_emp      VARCHAR2(10),
  approve_time     DATE
)
;
grant select, insert, update, delete on MES4.H_ECN_PQE_CONFIRM to MES1;

prompt
prompt Creating table H_ECN_SQE_ACTION
prompt ===============================
prompt
create table MES4.H_ECN_SQE_ACTION
(
  sheet_no         VARCHAR2(15) not null,
  action_result    VARCHAR2(1) default '0' not null,
  attac_no         VARCHAR2(15) not null,
  prepare_email_no VARCHAR2(15),
  prepare_emp      VARCHAR2(10) not null,
  prepare_time     DATE not null,
  approve_email_no VARCHAR2(15),
  approve_emp      VARCHAR2(10),
  approve_time     DATE
)
;
grant select, insert, update, delete on MES4.H_ECN_SQE_ACTION to MES1;

prompt
prompt Creating table H_FAR_BASE
prompt =========================
prompt
create table MES4.H_FAR_BASE
(
  sheet_no         VARCHAR2(15) not null,
  create_time      DATE not null,
  plant            VARCHAR2(10),
  model            VARCHAR2(20),
  customer         VARCHAR2(20),
  bu               VARCHAR2(20),
  cust_kp_no       VARCHAR2(20),
  material_code    VARCHAR2(10),
  vendor           VARCHAR2(20),
  vendor_kp_no     VARCHAR2(20),
  defect_qty       NUMBER(6),
  suspect_qty      NUMBER(10),
  failure_rate     VARCHAR2(15),
  po_no            VARCHAR2(15),
  initiator        VARCHAR2(25),
  defect_desc      VARCHAR2(200),
  attac_no         VARCHAR2(15),
  sample_qty       NUMBER(5),
  sample_send_time DATE,
  tracking_no      VARCHAR2(15),
  far_expec        VARCHAR2(500),
  email_no         VARCHAR2(15),
  prepare_emp      VARCHAR2(10) not null,
  prepare_time     DATE not null,
  far_status       VARCHAR2(1) default '0' not null,
  close_time       DATE,
  delete_emp       VARCHAR2(10),
  delete_time      DATE
)
;
grant select, insert, update, delete on MES4.H_FAR_BASE to MES1;

prompt
prompt Creating table H_FAR_CONFIRM
prompt ============================
prompt
create table MES4.H_FAR_CONFIRM
(
  sheet_no       VARCHAR2(15) not null,
  sqm_group      VARCHAR2(5) not null,
  work_flag      VARCHAR2(1) default '0' not null,
  confirm_remark VARCHAR2(500),
  email_no       VARCHAR2(15),
  confirm_emp    VARCHAR2(10) not null,
  confirm_time   DATE not null
)
;
grant select, insert, update, delete on MES4.H_FAR_CONFIRM to MES1;

prompt
prompt Creating table H_FAR_DL
prompt =======================
prompt
create table MES4.H_FAR_DL
(
  sheet_no   VARCHAR2(15) not null,
  cust_kp_no VARCHAR2(20) not null,
  date_code  VARCHAR2(20),
  lot_code   VARCHAR2(20)
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_FAR_DL to MES1;

prompt
prompt Creating table H_FAR_LOCATION
prompt =============================
prompt
create table MES4.H_FAR_LOCATION
(
  sheet_no      VARCHAR2(15) not null,
  location_code VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_FAR_LOCATION to MES1;

prompt
prompt Creating table H_FAR_RESPONSE
prompt =============================
prompt
create table MES4.H_FAR_RESPONSE
(
  sheet_no      VARCHAR2(15) not null,
  response_type VARCHAR2(1) not null,
  attac_no      VARCHAR2(15) not null,
  replied_time  DATE not null,
  attac_emp     VARCHAR2(10) not null,
  attac_time    DATE not null
)
;
grant select, insert, update, delete on MES4.H_FAR_RESPONSE to MES1;

prompt
prompt Creating table H_FB_ALARM
prompt =========================
prompt
create table MES4.H_FB_ALARM
(
  alarm_no      VARCHAR2(10) not null,
  alarm_code    VARCHAR2(6) not null,
  alarm_type    VARCHAR2(1) default '1' not null,
  alarm_cond    VARCHAR2(3) not null,
  p_no          VARCHAR2(20) not null,
  p_version     VARCHAR2(4) not null,
  alarm_time    DATE not null,
  aoi_station   VARCHAR2(10) not null,
  alarm_station VARCHAR2(10) not null,
  alarm_status  VARCHAR2(1) default '0' not null,
  alarm_message VARCHAR2(200) not null,
  remove_emp    VARCHAR2(10),
  remove_time   DATE
)
;
grant select, insert, update, delete on MES4.H_FB_ALARM to MES1;

prompt
prompt Creating table H_FB_ALARM_CAR
prompt =============================
prompt
create table MES4.H_FB_ALARM_CAR
(
  alarm_no    VARCHAR2(10) not null,
  handle_desc VARCHAR2(100),
  handle_emp  VARCHAR2(10),
  handle_time DATE
)
;
grant select, insert, update, delete on MES4.H_FB_ALARM_CAR to MES1;

prompt
prompt Creating table H_FB_ALARM_DEFECT
prompt ================================
prompt
create table MES4.H_FB_ALARM_DEFECT
(
  alarm_no  VARCHAR2(10) not null,
  file_name VARCHAR2(30) not null,
  defect_no NUMBER(6) not null
)
;
grant select, insert, update, delete on MES4.H_FB_ALARM_DEFECT to MES1;

prompt
prompt Creating table H_FB_DEFECT
prompt ==========================
prompt
create table MES4.H_FB_DEFECT
(
  file_name    VARCHAR2(30) not null,
  inspect_time DATE not null,
  station_name VARCHAR2(10) not null,
  defect_no    NUMBER(6) not null,
  p_no         VARCHAR2(20) not null,
  p_version    VARCHAR2(4) not null,
  process_flag VARCHAR2(1) not null,
  comp_name    VARCHAR2(15) not null,
  comp_type    VARCHAR2(15) not null,
  defect_name  VARCHAR2(15) not null
)
;
grant select, insert, update, delete on MES4.H_FB_DEFECT to MES1;

prompt
prompt Creating table H_FB_INSPECT
prompt ===========================
prompt
create table MES4.H_FB_INSPECT
(
  file_name       VARCHAR2(30) not null,
  station_name    VARCHAR2(10) not null,
  inspect_time    DATE not null,
  multiboard_no   VARCHAR2(2) not null,
  program_name    VARCHAR2(15) not null,
  p_sn            VARCHAR2(30) not null,
  work_flag       VARCHAR2(1) default '0' not null,
  comp_qty        NUMBER(6) not null,
  defect_qty      NUMBER(6) not null,
  collection_time DATE not null,
  alarm_flag      VARCHAR2(1) default '0' not null
)
;
grant select, insert, update, delete on MES4.H_FB_INSPECT to MES1;

prompt
prompt Creating table H_FB_STOP_CAR
prompt ============================
prompt
create table MES4.H_FB_STOP_CAR
(
  alarm_no          VARCHAR2(10) not null,
  notice_no         VARCHAR2(25) not null,
  issue_date        DATE not null,
  shift             VARCHAR2(10),
  cust_code         VARCHAR2(15) not null,
  line_name         VARCHAR2(8) not null,
  initiator         VARCHAR2(25) not null,
  stop_reason       VARCHAR2(500) not null,
  handle_desc       VARCHAR2(500),
  handle_emp        VARCHAR2(10),
  handle_time       DATE,
  work_flag         VARCHAR2(1) default '0',
  temp_strategy     VARCHAR2(500),
  affected_lot      VARCHAR2(100),
  duty_confirm      VARCHAR2(10),
  duty_confirm_time DATE,
  smt_confirm       VARCHAR2(10),
  smt_confirm_time  DATE,
  qc_confirm        VARCHAR2(10),
  qc_confirm_time   DATE,
  send_flag         VARCHAR2(1) default '0' not null
)
;
grant select, insert, update, delete on MES4.H_FB_STOP_CAR to MES1;

prompt
prompt Creating table H_FEEDER_DETAIL
prompt ==============================
prompt
create table MES4.H_FEEDER_DETAIL
(
  feeder_no     VARCHAR2(20) not null,
  feeder_sn     VARCHAR2(20) not null,
  feeder_type   VARCHAR2(40) not null,
  feederno_rule VARCHAR2(10) not null,
  work_flag     VARCHAR2(1) not null,
  use_times     NUMBER(10) not null,
  mfr_emp       VARCHAR2(10),
  work_time     DATE default SYSDATE not null,
  emp_no        VARCHAR2(10) not null
)
;
create index MES4.H_FEEDER_DETAILFEEDER_NO on MES4.H_FEEDER_DETAIL (FEEDER_NO);
grant select, insert, update, delete, references, alter, index on MES4.H_FEEDER_DETAIL to MES1;

prompt
prompt Creating table H_FEEDER_LB_REPLACE
prompt ==================================
prompt
create table MES4.H_FEEDER_LB_REPLACE
(
  feederno_code VARCHAR2(15) not null,
  feeder_sn     VARCHAR2(15) not null,
  feeder_no     VARCHAR2(15),
  feeder_type   VARCHAR2(40) not null,
  feederno_rule VARCHAR2(10) not null,
  status        VARCHAR2(1) not null,
  work_time     DATE default SYSDATE not null,
  emp_no        VARCHAR2(10) not null
)
;
create index MES4.H_FEEDER_LB_REPLACEFEEDER_NO on MES4.H_FEEDER_LB_REPLACE (FEEDER_NO)
  nologging;
create index MES4.H_FEEDER_LB_REPLACE_CODE on MES4.H_FEEDER_LB_REPLACE (FEEDERNO_CODE)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.H_FEEDER_LB_REPLACE to MES1;

prompt
prompt Creating table H_FEEDER_REPAIR
prompt ==============================
prompt
create table MES4.H_FEEDER_REPAIR
(
  feeder_no     VARCHAR2(15) not null,
  work_flag     VARCHAR2(1) not null,
  repair_status VARCHAR2(1) not null,
  error_desc    VARCHAR2(120) not null,
  adjust_reason VARCHAR2(150),
  repair_remark VARCHAR2(120),
  work_time     DATE not null,
  start_time    DATE,
  end_time      DATE,
  emp_no        VARCHAR2(10) not null
)
;
create index MES4.H_FEEDER_REPAIRFEEDER_NO on MES4.H_FEEDER_REPAIR (FEEDER_NO)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.H_FEEDER_REPAIR to MES1;

prompt
prompt Creating table H_HOLD_SETUP
prompt ===========================
prompt
create table MES4.H_HOLD_SETUP
(
  cust_kp_no  VARCHAR2(20) not null,
  mfr_kp_no   VARCHAR2(100),
  mfr_no      VARCHAR2(10),
  date_code   VARCHAR2(20),
  lot_code    VARCHAR2(20),
  qty         NUMBER(7) not null,
  ext_qty     NUMBER(7) not null,
  sn_qty      NUMBER(7) not null,
  work_flag   VARCHAR2(1) not null,
  start_time  DATE not null,
  end_time    DATE,
  hold_emp_no VARCHAR2(10) not null,
  open_emp_no VARCHAR2(10)
)
;
create index MES4.H_HOLD_SETUPCUST_KP_NO on MES4.H_HOLD_SETUP (CUST_KP_NO)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.H_HOLD_SETUP to MES1;

prompt
prompt Creating table H_KITTING_SCAN_DETAIL
prompt ====================================
prompt
create table MES4.H_KITTING_SCAN_DETAIL
(
  tr_sn         VARCHAR2(12) not null,
  cust_kp_no    VARCHAR2(20) not null,
  qty           NUMBER(7) not null,
  from_location VARCHAR2(12) not null,
  to_location   VARCHAR2(12) not null,
  move_type     VARCHAR2(1) not null,
  move_reason   VARCHAR2(20),
  move_emp      VARCHAR2(10) not null,
  move_time     DATE not null,
  process_flag  VARCHAR2(25),
  data1         VARCHAR2(25),
  data2         VARCHAR2(25),
  data3         VARCHAR2(25)
)
;
create index MES4.H_KITTING_SCAN_DETAIL_TRSN on MES4.H_KITTING_SCAN_DETAIL (TR_SN)
  nologging;

prompt
prompt Creating table H_KITTING_WASTAGE
prompt ================================
prompt
create table MES4.H_KITTING_WASTAGE
(
  specialnumber VARCHAR2(20) not null,
  datetime      DATE,
  workorder     VARCHAR2(12),
  skuno         VARCHAR2(30),
  floor         VARCHAR2(5),
  lineid        VARCHAR2(5),
  qty           NUMBER,
  singleprice   NUMBER,
  totalvalue    NUMBER,
  username      VARCHAR2(10),
  reason        VARCHAR2(100),
  snum_flag     VARCHAR2(10),
  return_date   DATE,
  uploadresult  VARCHAR2(1),
  description   VARCHAR2(200),
  uploadtime    DATE,
  m_remark      VARCHAR2(100)
)
;

prompt
prompt Creating table H_KP_LIST
prompt ========================
prompt
create table MES4.H_KP_LIST
(
  tr_sn             VARCHAR2(12) not null,
  wo                VARCHAR2(12) not null,
  kp_no             VARCHAR2(20) not null,
  mfr_kp_no         VARCHAR2(100) not null,
  mfr_code          VARCHAR2(15) not null,
  date_code         VARCHAR2(20),
  lot_code          VARCHAR2(20),
  add_qty           NUMBER(7) not null,
  ext_qty           NUMBER(7) default 0 not null,
  start_time        DATE not null,
  end_time          DATE,
  station           VARCHAR2(10) not null,
  emp_no            VARCHAR2(10) not null,
  check_emp         VARCHAR2(10),
  ipqc_check_emp    VARCHAR2(50),
  ipqc_check_time   DATE,
  ipqc_check_result VARCHAR2(100),
  memo              VARCHAR2(100),
  data1             VARCHAR2(50),
  data2             VARCHAR2(50),
  data3             VARCHAR2(50)
)
;
create index MES4.H_KP_LISTKP_NO on MES4.H_KP_LIST (KP_NO)
  nologging;
create index MES4.H_KP_LISTTR_SN on MES4.H_KP_LIST (TR_SN)
  nologging;
create index MES4.H_KP_LIST_WO on MES4.H_KP_LIST (WO)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.H_KP_LIST to MES1;

prompt
prompt Creating table H_KP_REPLACE
prompt ===========================
prompt
create table MES4.H_KP_REPLACE
(
  replace_sn     VARCHAR2(8),
  p_sn           VARCHAR2(50) not null,
  wo             VARCHAR2(12) not null,
  kp_no          VARCHAR2(30) not null,
  date_code      VARCHAR2(50),
  lot_code       VARCHAR2(50),
  mfr_kp_no      VARCHAR2(100) not null,
  mfr_code       VARCHAR2(15) not null,
  error_station  VARCHAR2(20) not null,
  error_location VARCHAR2(10) not null,
  replace_tr_sn  VARCHAR2(12) not null,
  work_time      DATE not null,
  work_flag      VARCHAR2(1) default '0' not null,
  replace_flag   VARCHAR2(1) default '0' not null,
  old_kp_sn      VARCHAR2(20),
  new_kp_sn      VARCHAR2(20),
  emp_no         VARCHAR2(10) not null,
  p_no           VARCHAR2(30),
  fail_symptom   VARCHAR2(50),
  fail_id        VARCHAR2(20),
  new_tr_sn      VARCHAR2(12),
  old_kp_no      VARCHAR2(50),
  old_date_code  VARCHAR2(50),
  old_lot_code   VARCHAR2(50),
  old_mfr_code   VARCHAR2(50),
  old_mfr_kp_no  VARCHAR2(50),
  error_code     VARCHAR2(30),
  vanilla_pn     VARCHAR2(50),
  vanilla_sn     VARCHAR2(50)
)
;
create index MES4.H014_DATE_CODE on MES4.H_KP_REPLACE (DATE_CODE);
create index MES4.H014_KP_LOT_CODE on MES4.H_KP_REPLACE (LOT_CODE);
create index MES4.H014_KP_NO on MES4.H_KP_REPLACE (KP_NO);
create index MES4.H014_P_SN on MES4.H_KP_REPLACE (P_SN);
create index MES4.H_KP_REPLACE_SN on MES4.H_KP_REPLACE (REPLACE_SN)
  nologging;
grant select, insert, update, delete, alter on MES4.H_KP_REPLACE to MES1;

prompt
prompt Creating table H_KP_SN
prompt ======================
prompt
create table MES4.H_KP_SN
(
  tr_sn            VARCHAR2(12) not null,
  kp_sn            VARCHAR2(20) not null,
  doc_no           VARCHAR2(15) not null,
  doc_flag         VARCHAR2(1) not null,
  cust_kp_no       VARCHAR2(20) not null,
  mfr_kp_no        VARCHAR2(100) not null,
  mfr_code         VARCHAR2(15) not null,
  date_code        VARCHAR2(20),
  lot_code         VARCHAR2(20),
  location_flag    VARCHAR2(1) not null,
  work_flag        VARCHAR2(1) not null,
  start_time       DATE not null,
  end_time         DATE,
  emp_no           VARCHAR2(10) not null,
  accept_flag      NUMBER(1) default 0 not null,
  accept_data      VARCHAR2(25),
  deviation_period VARCHAR2(25),
  data1            VARCHAR2(20),
  data2            VARCHAR2(20),
  data3            VARCHAR2(20)
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_KP_SN to MES1;

prompt
prompt Creating table H_KP_SN_DETAIL
prompt =============================
prompt
create table MES4.H_KP_SN_DETAIL
(
  wo           VARCHAR2(12) not null,
  p_sn         VARCHAR2(12) not null,
  kp_sn        VARCHAR2(20) not null,
  cust_kp_no   VARCHAR2(20) not null,
  mfr_kp_no    VARCHAR2(100) not null,
  mfr_code     VARCHAR2(15) not null,
  replace_flag VARCHAR2(1) default '0' not null,
  work_flag    VARCHAR2(1) default '0' not null,
  work_time    DATE not null,
  data1        VARCHAR2(20),
  data2        VARCHAR2(20),
  data3        VARCHAR2(20)
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_KP_SN_DETAIL to MES1;

prompt
prompt Creating table H_LABEL_REPRINT
prompt ==============================
prompt
create table MES4.H_LABEL_REPRINT
(
  tr_sn         VARCHAR2(12) not null,
  cust_kp_no    VARCHAR2(20) not null,
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  date_code     VARCHAR2(20),
  lot_code      VARCHAR2(20),
  qty           NUMBER(7) not null,
  ext_qty       NUMBER(7) not null,
  location_flag VARCHAR2(1) not null,
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_LABEL_REPRINT to MES1;

prompt
prompt Creating table H_LOGIN
prompt ======================
prompt
create table MES4.H_LOGIN
(
  user_id    VARCHAR2(10),
  ip         VARCHAR2(15),
  in_time    DATE,
  last_query DATE
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_LOGIN to MES1;

prompt
prompt Creating table H_MACHINE_STOP_LIST
prompt ==================================
prompt
create table MES4.H_MACHINE_STOP_LIST
(
  station    VARCHAR2(10) not null,
  start_time DATE not null,
  end_time   DATE,
  emp_no     VARCHAR2(10) not null
)
;
create index MES4.H_MACHINE_STOP_LISTSTATION on MES4.H_MACHINE_STOP_LIST (STATION)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.H_MACHINE_STOP_LIST to MES1;

prompt
prompt Creating table H_MRB
prompt ====================
prompt
create table MES4.H_MRB
(
  plant            VARCHAR2(6) not null,
  doc_no           VARCHAR2(15) not null,
  po_no            VARCHAR2(15),
  cust_kp_no       VARCHAR2(20) not null,
  cust_code        VARCHAR2(15),
  mfr_kp_no        VARCHAR2(100),
  mfr_code         VARCHAR2(15),
  buyer_code       VARCHAR2(3) not null,
  buyer_name       VARCHAR2(18) not null,
  grn_no           VARCHAR2(15),
  move_qty         NUMBER(10) not null,
  unit_price       NUMBER(10,3) not null,
  currency         VARCHAR2(5) not null,
  unit             VARCHAR2(6) not null,
  move_type        VARCHAR2(3) not null,
  from_location    VARCHAR2(4) not null,
  to_location      VARCHAR2(12) not null,
  move_flag        VARCHAR2(1) not null,
  move_time        DATE not null,
  qc_emp           VARCHAR2(10),
  waive_flag       VARCHAR2(1) default '0' not null,
  waive_no         VARCHAR2(25),
  deviation_period VARCHAR2(25),
  download_time    DATE not null,
  work_time        DATE
)
;
create index MES4.H_MRB_CUST_KP_NO on MES4.H_MRB (CUST_KP_NO)
  nologging;
create index MES4.H_MRB_DOC_NO on MES4.H_MRB (DOC_NO)
  nologging;
create index MES4.H_MRB_GRN_NO on MES4.H_MRB (GRN_NO)
  nologging;
create index MES4.H_MRB_MFR_CODE on MES4.H_MRB (MFR_CODE)
  nologging;
create index MES4.H_MRB_MFR_KP_NO on MES4.H_MRB (MFR_KP_NO)
  nologging;
create index MES4.H_MRB_WORK_TIME on MES4.H_MRB (WORK_TIME)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.H_MRB to MES1;

prompt
prompt Creating table H_MRB_CHANGE
prompt ===========================
prompt
create table MES4.H_MRB_CHANGE
(
  doc_no        VARCHAR2(12) not null,
  cust_kp_no    VARCHAR2(20) not null,
  cust_code     VARCHAR2(15),
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  date_code     VARCHAR2(20),
  lot_code      VARCHAR2(20),
  reject_qty    NUMBER(10) not null,
  reject_reason VARCHAR2(120),
  work_flag     VARCHAR2(1) not null,
  change_flag   VARCHAR2(1) not null,
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_MRB_CHANGE to MES1;

prompt
prompt Creating table H_MRB_REJECT
prompt ===========================
prompt
create table MES4.H_MRB_REJECT
(
  plant         VARCHAR2(6),
  doc_no        VARCHAR2(12) not null,
  cust_kp_no    VARCHAR2(20) not null,
  cust_code     VARCHAR2(15),
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  date_code     VARCHAR2(20),
  lot_code      VARCHAR2(20),
  reject_qty    NUMBER(10) not null,
  reject_reason VARCHAR2(120),
  work_flag     VARCHAR2(1) not null,
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null
)
;
create index MES4.H_MRB_REJECT_CUST_KP_NO on MES4.H_MRB_REJECT (CUST_KP_NO)
  nologging;
create index MES4.H_MRB_REJECT_DATE_CODE on MES4.H_MRB_REJECT (DATE_CODE)
  nologging;
create index MES4.H_MRB_REJECT_DOC_NO on MES4.H_MRB_REJECT (DOC_NO)
  nologging;
create index MES4.H_MRB_REJECT_LOT_CODE on MES4.H_MRB_REJECT (LOT_CODE)
  nologging;
create index MES4.H_MRB_REJECT_MFR_CODE on MES4.H_MRB_REJECT (MFR_CODE)
  nologging;
create index MES4.H_MRB_REJECT_MFR_KP_NO on MES4.H_MRB_REJECT (MFR_KP_NO)
  nologging;
create index MES4.H_MRB_REJECT_WORK_TIME on MES4.H_MRB_REJECT (WORK_TIME)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.H_MRB_REJECT to MES1;

prompt
prompt Creating table H_PSN_HISTORY
prompt ============================
prompt
create table MES4.H_PSN_HISTORY
(
  p_sn      VARCHAR2(25) not null,
  wo        VARCHAR2(12) not null,
  work_time DATE not null,
  work_flag VARCHAR2(1) default '0' not null
)
;
create index MES4.H_PSN_HISTORY_PSN on MES4.H_PSN_HISTORY (P_SN)
  nologging;
create index MES4.H_PSN_HISTORY_WO on MES4.H_PSN_HISTORY (WO)
  nologging;
grant select, insert, update, delete on MES4.H_PSN_HISTORY to MES1;

prompt
prompt Creating table H_ROHS_IQC
prompt =========================
prompt
create table MES4.H_ROHS_IQC
(
  doc_no            VARCHAR2(15) not null,
  substance_name    VARCHAR2(75) not null,
  substance_item    VARCHAR2(75) not null,
  substance_content VARCHAR2(10) not null,
  test_cycle        VARCHAR2(100) not null,
  specification     VARCHAR2(100) not null,
  emp_no            VARCHAR2(10) not null,
  edit_time         DATE default SYSDATE not null
)
;
grant select, insert, update, delete on MES4.H_ROHS_IQC to MES1;

prompt
prompt Creating table H_ROHS_REJECT
prompt ============================
prompt
create table MES4.H_ROHS_REJECT
(
  doc_no            VARCHAR2(15) not null,
  substance_name    VARCHAR2(75) not null,
  substance_item    VARCHAR2(75) not null,
  substance_content VARCHAR2(10) not null,
  test_cycle        VARCHAR2(100) not null,
  specification     VARCHAR2(100) not null,
  mass_ppm          NUMBER(10) not null,
  use_flag          VARCHAR2(1) default '0' not null,
  emp_no            VARCHAR2(10) not null,
  edit_time         DATE default SYSDATE not null
)
;
grant select, insert, update, delete on MES4.H_ROHS_REJECT to MES1;

prompt
prompt Creating table H_SHORTAGE_RETURN
prompt ================================
prompt
create table MES4.H_SHORTAGE_RETURN
(
  tr_code   VARCHAR2(25) not null,
  station   VARCHAR2(10) not null,
  kp_no     VARCHAR2(20) not null,
  work_time DATE not null,
  emp_no    VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_SHORTAGE_RETURN to MES1;

prompt
prompt Creating table H_SMT_AP_CHANGE
prompt ==============================
prompt
create table MES4.H_SMT_AP_CHANGE
(
  smt_code     VARCHAR2(6) not null,
  slot_no      VARCHAR2(7) not null,
  kp_no        VARCHAR2(20) not null,
  standard_qty NUMBER(4) not null,
  work_time    DATE default SYSDATE not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_SMT_AP_CHANGE to MES1;

prompt
prompt Creating table H_SN_LINK
prompt ========================
prompt
create table MES4.H_SN_LINK
(
  sn_code   VARCHAR2(9) not null,
  p_sn      VARCHAR2(25),
  wo        VARCHAR2(12) not null,
  work_time DATE not null,
  emp_no    VARCHAR2(10) not null
)
;
create index MES4.H_SN_LINK_PSN on MES4.H_SN_LINK (P_SN)
  nologging;
create index MES4.H_SN_LINK_SN_CODE on MES4.H_SN_LINK (SN_CODE)
  nologging;
create index MES4.H_SN_LINK_WO on MES4.H_SN_LINK (WO)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.H_SN_LINK to MES1;

prompt
prompt Creating table H_SOLDER_DETAIL
prompt ==============================
prompt
create table MES4.H_SOLDER_DETAIL
(
  tr_sn               VARCHAR2(12) not null,
  kp_no               VARCHAR2(20) not null,
  bd_code             VARCHAR2(10) not null,
  model_flag          VARCHAR2(1) default '0' not null,
  fifo_flag           VARCHAR2(1) default '0' not null,
  seq_no              NUMBER(4),
  work_flag           VARCHAR2(1) default '0' not null,
  out_whs_time        DATE not null,
  in_kitting_time     DATE,
  get_warm_time       DATE,
  out_kitting_time    DATE,
  return_kitting_time DATE,
  start_time          DATE,
  end_time            DATE
)
;
grant select, insert, update, delete on MES4.H_SOLDER_DETAIL to MES1;

prompt
prompt Creating table H_SQM_ATTAC
prompt ==========================
prompt
create table MES4.H_SQM_ATTAC
(
  attac_no   VARCHAR2(15) not null,
  attac_name VARCHAR2(100) not null,
  attac_blob BLOB not null
)
;
grant select, insert, update, delete on MES4.H_SQM_ATTAC to MES1;

prompt
prompt Creating table H_SQM_EMAIL
prompt ==========================
prompt
create table MES4.H_SQM_EMAIL
(
  email_no VARCHAR2(15) not null,
  to_mail  VARCHAR2(500) not null,
  cc_mail  VARCHAR2(500),
  bcc_mail VARCHAR2(500)
)
;
grant select, insert, update, delete on MES4.H_SQM_EMAIL to MES1;

prompt
prompt Creating table H_SQM_FILE
prompt =========================
prompt
create table MES4.H_SQM_FILE
(
  file_name       VARCHAR2(100) not null,
  plant_code      VARCHAR2(10) not null,
  type_code       VARCHAR2(10) not null,
  sqm_vendor_code VARCHAR2(10) not null,
  file_time       DATE not null,
  file_blob       BLOB,
  file_remark     VARCHAR2(200),
  edit_emp        VARCHAR2(25) not null,
  edit_time       DATE not null
)
;
grant select, insert, update, delete on MES4.H_SQM_FILE to MES1;

prompt
prompt Creating table H_SQM_INSPECT_DL
prompt ===============================
prompt
create table MES4.H_SQM_INSPECT_DL
(
  sheet_no   VARCHAR2(15) not null,
  cust_kp_no VARCHAR2(20) not null,
  date_code  VARCHAR2(20),
  lot_code   VARCHAR2(20),
  qty        NUMBER(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_SQM_INSPECT_DL to MES1;

prompt
prompt Creating table H_STATION_STATUS
prompt ===============================
prompt
create table MES4.H_STATION_STATUS
(
  tr_code   VARCHAR2(25) not null,
  station   VARCHAR2(10) not null,
  status    VARCHAR2(1) not null,
  slot_no   VARCHAR2(7),
  kp_no     VARCHAR2(20) not null,
  work_time DATE not null,
  emp_no    VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_STATION_STATUS to MES1;

prompt
prompt Creating table H_STENCIL_ACCEPT_DATA
prompt ====================================
prompt
create table MES4.H_STENCIL_ACCEPT_DATA
(
  mfr_sn        VARCHAR2(25) not null,
  item_code     VARCHAR2(5) not null,
  part_location VARCHAR2(15) not null,
  size_code     VARCHAR2(5) not null,
  size_result   NUMBER(7,3) not null,
  result_flag   VARCHAR2(1) default '0' not null,
  remark        VARCHAR2(60),
  edit_emp      VARCHAR2(25) not null,
  edit_time     DATE not null
)
;
grant select, insert, update, delete on MES4.H_STENCIL_ACCEPT_DATA to MES1;

prompt
prompt Creating table H_STENCIL_DEFECT
prompt ===============================
prompt
create table MES4.H_STENCIL_DEFECT
(
  stencil_sn      VARCHAR2(25) not null,
  duty_area       VARCHAR2(15) default '0' not null,
  duty_location   VARCHAR2(15) not null,
  duty_emp        VARCHAR2(10) not null,
  total_use_times NUMBER(8) default 0 not null,
  alert_times     NUMBER(8) not null,
  defect_flag     VARCHAR2(1) default '0' not null,
  record_time     DATE not null,
  record_emp      VARCHAR2(10) not null,
  defect_code     VARCHAR2(15),
  handle_desc     VARCHAR2(150),
  defect_remark   VARCHAR2(150),
  handle_status   VARCHAR2(1) default '0' not null,
  start_time      DATE,
  end_time        DATE,
  pe_emp          VARCHAR2(10),
  alarm_flag      VARCHAR2(1) default '0' not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_STENCIL_DEFECT to MES1;

prompt
prompt Creating table H_STENCIL_DETAIL
prompt ===============================
prompt
create table MES4.H_STENCIL_DETAIL
(
  stencil_sn   VARCHAR2(25) not null,
  line_name    VARCHAR2(8) not null,
  station_name VARCHAR2(8) not null,
  wo           VARCHAR2(12) not null,
  use_times    NUMBER(8) default 0 not null,
  start_time   DATE not null,
  start_emp    VARCHAR2(10) not null,
  end_time     DATE not null,
  end_emp      VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_STENCIL_DETAIL to MES1;

prompt
prompt Creating table H_STENCIL_WASH
prompt =============================
prompt
create table MES4.H_STENCIL_WASH
(
  stencil_sn   VARCHAR2(25) not null,
  line_name    VARCHAR2(8),
  station_name VARCHAR2(8),
  send_emp     VARCHAR2(10) not null,
  start_time   DATE not null,
  end_time     DATE,
  shift        VARCHAR2(1) default '0' not null,
  wash_emp     VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_STENCIL_WASH to MES1;

prompt
prompt Creating table H_STENCIL_WHS
prompt ============================
prompt
create table MES4.H_STENCIL_WHS
(
  stencil_sn      VARCHAR2(25) not null,
  total_use_times NUMBER(8) not null,
  line_name       VARCHAR2(8) not null,
  station_name    VARCHAR2(8) not null,
  wo              VARCHAR2(12) not null,
  loan_emp        VARCHAR2(10) not null,
  loan_time       DATE not null,
  deliver_emp     VARCHAR2(10) not null,
  return_emp      VARCHAR2(10),
  return_time     DATE,
  receive_emp     VARCHAR2(10)
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_STENCIL_WHS to MES1;

prompt
prompt Creating table H_TEMP_SN
prompt ========================
prompt
create table MES4.H_TEMP_SN
(
  temp_sn        VARCHAR2(11) not null,
  link_qty       NUMBER(2) default 1 not null,
  scan_qty       NUMBER(2) default 0 not null,
  wo             VARCHAR2(12) not null,
  flag           VARCHAR2(1) not null,
  start_time     DATE default SYSDATE not null,
  end_time       DATE,
  emp_no         VARCHAR2(10) not null,
  replace_emp_no VARCHAR2(10),
  reprint_qty    NUMBER(2) default 0 not null,
  data1          VARCHAR2(25),
  data2          VARCHAR2(25),
  data3          VARCHAR2(25)
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_TEMP_SN to MES1;

prompt
prompt Creating table H_TRAVEL_SN
prompt ==========================
prompt
create table MES4.H_TRAVEL_SN
(
  travel_sn       VARCHAR2(17) not null,
  smt_code        VARCHAR2(6),
  program_name    VARCHAR2(50),
  program_comment VARCHAR2(30),
  line_name       VARCHAR2(8) not null,
  line_section    VARCHAR2(3) not null,
  station         VARCHAR2(10) not null,
  station_flag    VARCHAR2(1) not null,
  p_no            VARCHAR2(20) not null,
  p_version       VARCHAR2(4) not null,
  wo              VARCHAR2(12) not null,
  wo_qty          NUMBER(5) not null,
  work_flag       VARCHAR2(1) not null,
  work_time       DATE not null,
  emp_no          VARCHAR2(10) not null,
  process_flag    VARCHAR2(1)
)
;
create index MES4.H_TRAVEL_SNSTATION on MES4.H_TRAVEL_SN (STATION);
create index MES4.H_TRAVEL_SNTRAVEL_SN on MES4.H_TRAVEL_SN (TRAVEL_SN);
create index MES4.H_TRAVLE_SN on MES4.H_TRAVEL_SN (WO);
grant select, insert, update, delete, references, alter, index on MES4.H_TRAVEL_SN to MES1;

prompt
prompt Creating table H_TR_CODE_DETAIL
prompt ===============================
prompt
create table MES4.H_TR_CODE_DETAIL
(
  tr_code        VARCHAR2(25) not null,
  smt_code       VARCHAR2(6),
  station        VARCHAR2(10) not null,
  station_flag   VARCHAR2(1) not null,
  p_no           VARCHAR2(20) not null,
  p_version      VARCHAR2(4) not null,
  slot_no        VARCHAR2(7),
  feeder_no      VARCHAR2(15),
  tr_sn          VARCHAR2(12) not null,
  kp_no          VARCHAR2(20) not null,
  mfr_kp_no      VARCHAR2(100) not null,
  mfr_code       VARCHAR2(15) not null,
  date_code      VARCHAR2(20),
  lot_code       VARCHAR2(20),
  standard_qty   NUMBER(4) not null,
  emp_no         VARCHAR2(10) not null,
  wo             VARCHAR2(12),
  process_flag   VARCHAR2(1),
  replacekp_flag VARCHAR2(1) default '0' not null,
  work_time      DATE
)
;
create index MES4.H012_KP_DATE_LOT on MES4.H_TR_CODE_DETAIL (KP_NO)
  nologging;
create index MES4.H_IDX_DET_TR_CODE on MES4.H_TR_CODE_DETAIL (TR_CODE)
  nologging;
create index MES4.H_TRCODEDETAIL_DATELOT on MES4.H_TR_CODE_DETAIL (DATE_CODE, LOT_CODE)
  nologging;
create index MES4.H_TR_CODE_DETAILDATE_CODE on MES4.H_TR_CODE_DETAIL (DATE_CODE)
  nologging;
create index MES4.H_TR_CODE_DETAILLOT_CODE on MES4.H_TR_CODE_DETAIL (LOT_CODE)
  nologging;
create index MES4.H_TR_CODE_DETAILSMT_CODE on MES4.H_TR_CODE_DETAIL (SMT_CODE)
  nologging;
create index MES4.H_TR_CODE_DETAILTR_SN on MES4.H_TR_CODE_DETAIL (TR_SN)
  nologging;
create index MES4.H_TR_CODE_DETAIL_WORKTIME on MES4.H_TR_CODE_DETAIL (WORK_TIME)
  nologging;
grant insert, update, delete, references, alter, index on MES4.H_TR_CODE_DETAIL to MES1;
grant select on MES4.H_TR_CODE_DETAIL to MES1 with grant option;

prompt
prompt Creating table H_TR_CODE_LIST
prompt =============================
prompt
create table MES4.H_TR_CODE_LIST
(
  tr_code    VARCHAR2(25) not null,
  wo         VARCHAR2(12) not null,
  station    VARCHAR2(10) not null,
  start_time DATE not null,
  end_time   DATE,
  emp_no     VARCHAR2(10) not null
)
;
create index MES4.H_TR_CODE_LISTEND_TIME on MES4.H_TR_CODE_LIST (END_TIME)
  nologging;
create index MES4.H_TR_CODE_LISTSTART_TIME on MES4.H_TR_CODE_LIST (START_TIME)
  nologging;
create index MES4.H_TR_CODE_LISTSTATION on MES4.H_TR_CODE_LIST (STATION)
  nologging;
create index MES4.H_TR_CODE_LISTTR_CODE on MES4.H_TR_CODE_LIST (TR_CODE)
  nologging;
create index MES4.H_TR_CODE_LIST_WO on MES4.H_TR_CODE_LIST (WO)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.H_TR_CODE_LIST to MES1;

prompt
prompt Creating table H_TR_PRODUCT_DETAIL
prompt ==================================
prompt
create table MES4.H_TR_PRODUCT_DETAIL
(
  wo           VARCHAR2(12) not null,
  p_sn         VARCHAR2(25) not null,
  smt_code     VARCHAR2(6),
  tr_code      VARCHAR2(25) not null,
  replace_flag VARCHAR2(1) default '0' not null,
  work_flag    VARCHAR2(1) default '0' not null,
  work_time    DATE not null,
  process_flag VARCHAR2(1)
)
;
create index MES4.H_TR_PRODUCT_DETAIL_P_SN on MES4.H_TR_PRODUCT_DETAIL (P_SN)
  nologging;
create index MES4.H_TR_PRODUCT_DETAIL_TR_CODE on MES4.H_TR_PRODUCT_DETAIL (TR_CODE)
  nologging;
create index MES4.H_TR_PRODUCT_DETAIL_WO on MES4.H_TR_PRODUCT_DETAIL (WO)
  nologging;
create index MES4.H_TR_PRODUCT_DETAIL_WORK_TIME on MES4.H_TR_PRODUCT_DETAIL (WORK_TIME)
  nologging;
grant insert, update, delete, references, alter, index on MES4.H_TR_PRODUCT_DETAIL to MES1;
grant select on MES4.H_TR_PRODUCT_DETAIL to MES1 with grant option;

prompt
prompt Creating table H_TR_SN
prompt ======================
prompt
create table MES4.H_TR_SN
(
  tr_sn          VARCHAR2(12) not null,
  doc_no         VARCHAR2(15) not null,
  doc_flag       VARCHAR2(1) not null,
  cust_kp_no     VARCHAR2(20) not null,
  mfr_kp_no      VARCHAR2(100) not null,
  mfr_code       VARCHAR2(15) not null,
  date_code      VARCHAR2(20),
  lot_code       VARCHAR2(20),
  qty            NUMBER(7) not null,
  ext_qty        NUMBER(7) not null,
  location_flag  VARCHAR2(1) not null,
  work_flag      VARCHAR2(1) not null,
  start_time     DATE not null,
  end_time       DATE,
  emp_no         VARCHAR2(10) not null,
  data1          VARCHAR2(10),
  data2          VARCHAR2(25),
  data3          VARCHAR2(25),
  kp_type        VARCHAR2(1),
  tr_sn_desc     VARCHAR2(50),
  ltb_flag       VARCHAR2(5),
  kp_rohs_status VARCHAR2(1),
  kitting_flag   VARCHAR2(1),
  kitting_wo     VARCHAR2(12),
  sap_stock      VARCHAR2(4),
  floor          VARCHAR2(15),
  actual_kp_no   VARCHAR2(40),
  wafer_no       VARCHAR2(20),
  standard_dc    VARCHAR2(20),
  over_time      VARCHAR2(20)
)
;
grant select, insert on MES4.H_TR_SN to MES1;

prompt
prompt Creating table H_TR_SN_ADJUST
prompt =============================
prompt
create table MES4.H_TR_SN_ADJUST
(
  sub_tr_sn     VARCHAR2(12) not null,
  tr_sn         VARCHAR2(12) not null,
  qty           NUMBER(7) not null,
  ext_qty       NUMBER(7) not null,
  sub_qty       NUMBER(7) not null,
  location_flag VARCHAR2(1) not null,
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null,
  require_emp   VARCHAR2(10),
  memo          VARCHAR2(250)
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_TR_SN_ADJUST to MES1;

prompt
prompt Creating table H_TR_SN_B
prompt ========================
prompt
create table MES4.H_TR_SN_B
(
  tr_sn          VARCHAR2(12) not null,
  doc_no         VARCHAR2(15) not null,
  doc_flag       VARCHAR2(1) not null,
  cust_kp_no     VARCHAR2(20) not null,
  mfr_kp_no      VARCHAR2(100) not null,
  mfr_code       VARCHAR2(15) not null,
  date_code      VARCHAR2(20),
  lot_code       VARCHAR2(20),
  qty            NUMBER(7) not null,
  ext_qty        NUMBER(7) not null,
  location_flag  VARCHAR2(1) not null,
  kp_type        VARCHAR2(1),
  work_flag      VARCHAR2(1) not null,
  start_time     DATE not null,
  end_time       DATE,
  emp_no         VARCHAR2(10) not null,
  data1          VARCHAR2(10),
  data2          VARCHAR2(25),
  data3          VARCHAR2(25),
  tr_sn_desc     VARCHAR2(50),
  ltb_flag       VARCHAR2(1),
  move_time      DATE not null,
  kp_rohs_status VARCHAR2(1)
)
;
grant select, insert, update, delete on MES4.H_TR_SN_B to MES1;

prompt
prompt Creating table H_TR_SN_CHANGE
prompt =============================
prompt
create table MES4.H_TR_SN_CHANGE
(
  tr_sn         VARCHAR2(12) not null,
  doc_no        VARCHAR2(15) not null,
  doc_flag      VARCHAR2(1) not null,
  cust_kp_no    VARCHAR2(20) not null,
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  date_code     VARCHAR2(20),
  lot_code      VARCHAR2(20),
  qty           NUMBER(7) not null,
  ext_qty       NUMBER(7) not null,
  location_flag VARCHAR2(1) not null,
  work_flag     VARCHAR2(1) not null,
  change_flag   VARCHAR2(1) not null,
  start_time    DATE not null,
  end_time      DATE,
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_TR_SN_CHANGE to MES1;

prompt
prompt Creating table H_TR_SN_DETAIL
prompt =============================
prompt
create table MES4.H_TR_SN_DETAIL
(
  tr_sn         VARCHAR2(12) not null,
  cust_kp_no    VARCHAR2(20) not null,
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  date_code     VARCHAR2(20),
  lot_code      VARCHAR2(20),
  qty           NUMBER(7) not null,
  ext_qty       NUMBER(7) not null,
  location_flag VARCHAR2(1) not null,
  work_flag     VARCHAR2(1) not null,
  wo            VARCHAR2(12),
  station       VARCHAR2(10),
  mfg_emp_no    VARCHAR2(10),
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null,
  remark        VARCHAR2(20)
)
;
create index MES4.H_TR_SN_DETAILTR_SN on MES4.H_TR_SN_DETAIL (TR_SN)
  nologging;
create index MES4.H_TR_SN_DETAILWORK_TIME on MES4.H_TR_SN_DETAIL (WORK_TIME)
  nologging;
create index MES4.H_TR_SN_DETAIL_WO on MES4.H_TR_SN_DETAIL (WO)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.H_TR_SN_DETAIL to MES1;

prompt
prompt Creating table H_TR_SN_HOLD
prompt ===========================
prompt
create table MES4.H_TR_SN_HOLD
(
  tr_sn         VARCHAR2(12) not null,
  doc_no        VARCHAR2(15) not null,
  doc_flag      VARCHAR2(1) not null,
  cust_kp_no    VARCHAR2(20) not null,
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  date_code     VARCHAR2(20),
  lot_code      VARCHAR2(20),
  qty           NUMBER(7) not null,
  ext_qty       NUMBER(7) not null,
  location_flag VARCHAR2(1) not null,
  work_flag     VARCHAR2(1) not null,
  start_time    DATE not null,
  end_time      DATE,
  hold_emp_no   VARCHAR2(10) not null,
  open_emp_no   VARCHAR2(10),
  data1         VARCHAR2(10),
  data2         VARCHAR2(25),
  data3         VARCHAR2(25)
)
;
create index MES4.H_TR_SN_HOLDCUST_KP_NO on MES4.H_TR_SN_HOLD (CUST_KP_NO)
  nologging;
create index MES4.H_TR_SN_HOLDTR_SN on MES4.H_TR_SN_HOLD (TR_SN)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.H_TR_SN_HOLD to MES1;

prompt
prompt Creating table H_TR_SN_NO
prompt =========================
prompt
create table MES4.H_TR_SN_NO
(
  tr_no     VARCHAR2(12) not null,
  tr_sn     VARCHAR2(12) not null,
  work_time DATE default SYSDATE not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_TR_SN_NO to MES1;

prompt
prompt Creating table H_TR_SN_WIP
prompt ==========================
prompt
create table MES4.H_TR_SN_WIP
(
  tr_sn        VARCHAR2(12) not null,
  wo           VARCHAR2(12) not null,
  kp_no        VARCHAR2(20) not null,
  mfr_kp_no    VARCHAR2(100) not null,
  mfr_code     VARCHAR2(15) not null,
  date_code    VARCHAR2(20),
  lot_code     VARCHAR2(100),
  qty          NUMBER(7) not null,
  ext_qty      NUMBER(7) not null,
  work_time    DATE not null,
  station      VARCHAR2(10) not null,
  station_flag VARCHAR2(1) not null,
  start_time   DATE,
  work_flag    VARCHAR2(1) default '0' not null,
  emp_no       VARCHAR2(10) not null
)
;
comment on column MES4.H_TR_SN_WIP.tr_sn
  is 'ALLPART???';
create index MES4.H_TR_SN_WIPKP_NO on MES4.H_TR_SN_WIP (KP_NO)
  nologging;
create index MES4.H_TR_SN_WIPTR_SN on MES4.H_TR_SN_WIP (TR_SN)
  nologging;
create index MES4.H_TR_SN_WIPWORK_TIME on MES4.H_TR_SN_WIP (WORK_TIME)
  nologging;
create index MES4.H_TR_SN_WIP_STATION on MES4.H_TR_SN_WIP (STATION)
  nologging;
create index MES4.H_TR_SN_WIP_WFLAG on MES4.H_TR_SN_WIP (WORK_FLAG)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.H_TR_SN_WIP to MES1;

prompt
prompt Creating table H_VDCS_BASE
prompt ==========================
prompt
create table MES4.H_VDCS_BASE
(
  sheet_no         VARCHAR2(15) not null,
  create_time      DATE not null,
  plant            VARCHAR2(10),
  model            VARCHAR2(20),
  customer         VARCHAR2(20),
  bu               VARCHAR2(20),
  cust_kp_no       VARCHAR2(20),
  material_code    VARCHAR2(10),
  vendor           VARCHAR2(20),
  vendor_kp_no     VARCHAR2(20),
  defect_qty       NUMBER(6),
  suspect_qty      NUMBER(10),
  failure_rate     VARCHAR2(15),
  po_no            VARCHAR2(15),
  initiator        VARCHAR2(25),
  defect_desc      VARCHAR2(200),
  attac_no         VARCHAR2(15),
  sample_qty       NUMBER(5),
  sample_send_time DATE,
  tracking_no      VARCHAR2(15),
  vdcs_expec       VARCHAR2(500),
  suspect_handle   VARCHAR2(20),
  email_no         VARCHAR2(15),
  prepare_emp      VARCHAR2(10) not null,
  prepare_time     DATE not null,
  vdcs_status      VARCHAR2(1) default '0' not null,
  close_time       DATE,
  delete_emp       VARCHAR2(10),
  delete_time      DATE
)
;
grant select, insert, update, delete on MES4.H_VDCS_BASE to MES1;

prompt
prompt Creating table H_VDCS_INSPECT
prompt =============================
prompt
create table MES4.H_VDCS_INSPECT
(
  sheet_no         VARCHAR2(15) not null,
  cust_kp_no       VARCHAR2(20) not null,
  po_no            VARCHAR2(15) not null,
  inspect_time     DATE not null,
  inspect_qty      NUMBER(10) not null,
  inspect_result   VARCHAR2(1) default '0' not null,
  inspect_remark   VARCHAR2(500),
  attac_no         VARCHAR2(15),
  prepare_email_no VARCHAR2(15),
  prepare_emp      VARCHAR2(10) not null,
  prepare_time     DATE not null,
  approve_email_no VARCHAR2(15),
  approve_emp      VARCHAR2(10),
  approve_time     DATE
)
;
grant select, insert, update, delete on MES4.H_VDCS_INSPECT to MES1;

prompt
prompt Creating table H_WHS
prompt ====================
prompt
create table MES4.H_WHS
(
  plant            VARCHAR2(6) not null,
  doc_no           VARCHAR2(15) not null,
  doc_type         VARCHAR2(1) not null,
  po_no            VARCHAR2(15),
  cust_code        VARCHAR2(15),
  cust_kp_no       VARCHAR2(20) not null,
  mfr_kp_no        VARCHAR2(100) not null,
  mfr_code         VARCHAR2(15) not null,
  vendor_code      VARCHAR2(15),
  buyer_code       VARCHAR2(3) not null,
  buyer_name       VARCHAR2(18) not null,
  receive_qty      NUMBER(10) not null,
  accept_qty       NUMBER(10) default 0 not null,
  reject_qty       NUMBER(10) default 0 not null,
  reject_reason    VARCHAR2(120),
  receive_time     DATE not null,
  accept_flag      NUMBER(1) default 0 not null,
  accept_data      VARCHAR2(25),
  deviation_period VARCHAR2(25),
  kp_status        VARCHAR2(25),
  qc_emp           VARCHAR2(10),
  guarantee        VARCHAR2(20),
  download_time    DATE not null,
  work_time        DATE,
  emp_no           VARCHAR2(10),
  npi_product      VARCHAR2(20),
  accept_desc      VARCHAR2(120),
  sap321_flag      VARCHAR2(1),
  gt_flag          VARCHAR2(2) default 0,
  po_type          VARCHAR2(4),
  new_part         VARCHAR2(1)
)
;

prompt
prompt Creating table H_WHS_CHANGE
prompt ===========================
prompt
create table MES4.H_WHS_CHANGE
(
  doc_no        VARCHAR2(15) not null,
  doc_type      VARCHAR2(1) not null,
  po_no         VARCHAR2(15),
  cust_kp_no    VARCHAR2(20) not null,
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  vendor_code   VARCHAR2(15),
  buyer_code    VARCHAR2(3) not null,
  buyer_name    VARCHAR2(18) not null,
  receive_qty   NUMBER(10) not null,
  accept_qty    NUMBER(10) default 0 not null,
  reject_qty    NUMBER(10) default 0 not null,
  reject_reason VARCHAR2(120),
  receive_time  DATE not null,
  download_time DATE not null,
  change_flag   VARCHAR2(1) not null,
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_WHS_CHANGE to MES1;

prompt
prompt Creating table H_WHS_DETAIL
prompt ===========================
prompt
create table MES4.H_WHS_DETAIL
(
  doc_no        VARCHAR2(15) not null,
  cust_kp_no    VARCHAR2(20) not null,
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  receive_qty   NUMBER(10) not null,
  accept_qty    NUMBER(10) default 0 not null,
  reject_qty    NUMBER(10) default 0 not null,
  reject_reason VARCHAR2(120),
  work_time     DATE
)
;
create index MES4.H_WHS_DETAILCUST_KP_NO on MES4.H_WHS_DETAIL (CUST_KP_NO)
  nologging;
create index MES4.H_WHS_DETAILDOC_NO on MES4.H_WHS_DETAIL (DOC_NO)
  nologging;
create index MES4.H_WHS_DETAILMFR_CODE on MES4.H_WHS_DETAIL (MFR_CODE)
  nologging;
create index MES4.H_WHS_DETAILMFR_KP_NO on MES4.H_WHS_DETAIL (MFR_KP_NO)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.H_WHS_DETAIL to MES1;

prompt
prompt Creating table H_WHS_MOVE
prompt =========================
prompt
create table MES4.H_WHS_MOVE
(
  tr_sn       VARCHAR2(12) not null,
  work_flag   VARCHAR2(1) not null,
  cost_center VARCHAR2(4) not null,
  qty         NUMBER(7) not null,
  work_time   DATE not null,
  emp_no      VARCHAR2(10) not null
)
;
create index MES4.H_WHS_MOVETR_SN on MES4.H_WHS_MOVE (TR_SN)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.H_WHS_MOVE to MES1;

prompt
prompt Creating table H_WO_BASE
prompt ========================
prompt
create table MES4.H_WO_BASE
(
  wo             VARCHAR2(12) not null,
  cust_code      VARCHAR2(15) not null,
  bu_code        VARCHAR2(10) not null,
  p_no           VARCHAR2(20) not null,
  p_version      VARCHAR2(4) not null,
  wo_qty         NUMBER(6) not null,
  process_side   VARCHAR2(6) not null,
  process_flag   VARCHAR2(1) not null,
  uph            VARCHAR2(9),
  ship_time      DATE,
  wo_create_date DATE not null,
  download_time  DATE not null,
  work_flag      VARCHAR2(1) not null,
  work_time      DATE,
  emp_no         VARCHAR2(10) not null,
  rohs_status    VARCHAR2(12),
  return_flag    VARCHAR2(1) default 0 not null,
  deviation_no   VARCHAR2(50),
  data1          VARCHAR2(25)
)
;
grant select, insert, update, delete, references, alter, index on MES4.H_WO_BASE to MES1;

prompt
prompt Creating table H_WO_REQUEST
prompt ===========================
prompt
create table MES4.H_WO_REQUEST
(
  wo            VARCHAR2(12),
  wo_qty        NUMBER(6),
  p_no          VARCHAR2(20),
  p_name        VARCHAR2(100),
  cust_kp_no    VARCHAR2(20),
  standard_qty  NUMBER(8),
  replace_kp_no VARCHAR2(20),
  wo_request    NUMBER(10),
  deliver_qty   NUMBER(10) default 0,
  download_time DATE,
  checkout_qty  NUMBER(7) default 0,
  return_qty    NUMBER(7) default 0,
  item_no       VARCHAR2(25),
  wastage_qty   NUMBER(7) default 0
)
;
grant select on MES4.H_WO_REQUEST to MES1;

prompt
prompt Creating table H_XML_ERROR
prompt ==========================
prompt
create table MES4.H_XML_ERROR
(
  file_name  VARCHAR2(50) not null,
  data_name  VARCHAR2(50) not null,
  tag_name   VARCHAR2(50) not null,
  tag_data   VARCHAR2(45),
  p_sn       VARCHAR2(12),
  p_no       VARCHAR2(20),
  tr_sn      VARCHAR2(12),
  error_desc VARCHAR2(120),
  status     VARCHAR2(1) not null,
  start_time DATE default SYSDATE not null,
  end_time   DATE,
  emp_no     VARCHAR2(10) not null
)
;
grant select, insert, update, delete on MES4.H_XML_ERROR to MES1;

prompt
prompt Creating table LOGMNR_666
prompt =========================
prompt
create table MES4.LOGMNR_666
(
  sqlarea VARCHAR2(2000)
)
;

prompt
prompt Creating table MRB_AGENT_SETTING
prompt ================================
prompt
create table MES4.MRB_AGENT_SETTING
(
  guid        NVARCHAR2(64) not null,
  code        NVARCHAR2(50) not null,
  agent_code  NVARCHAR2(50) not null,
  agent_email NVARCHAR2(50) not null,
  tel         NVARCHAR2(50) not null,
  agent_name  NVARCHAR2(50) not null,
  name        NVARCHAR2(50)
)
;
alter table MES4.MRB_AGENT_SETTING
  add constraint AGENT_PK primary key (GUID);
alter index MES4.AGENT_PK nologging;
grant select, insert, update, delete on MES4.MRB_AGENT_SETTING to MES1;

prompt
prompt Creating table MRB_BILL_FLOW
prompt ============================
prompt
create table MES4.MRB_BILL_FLOW
(
  bill_id      NVARCHAR2(50),
  order_num    NUMBER,
  processor_id NVARCHAR2(20),
  result       NVARCHAR2(50),
  backup_info  NVARCHAR2(500),
  dispose_bill NVARCHAR2(100),
  dataid       NUMBER not null,
  operate      NVARCHAR2(50),
  operatetime  DATE,
  out_num      NUMBER
)
;
comment on column MES4.MRB_BILL_FLOW.bill_id
  is '對應表單ID';
comment on column MES4.MRB_BILL_FLOW.order_num
  is '流程順序';
comment on column MES4.MRB_BILL_FLOW.processor_id
  is '操作人編號';
comment on column MES4.MRB_BILL_FLOW.result
  is '處理結果';
comment on column MES4.MRB_BILL_FLOW.backup_info
  is '備註';
comment on column MES4.MRB_BILL_FLOW.dispose_bill
  is '提供證明路徑';
comment on column MES4.MRB_BILL_FLOW.dataid
  is '自增ID';
comment on column MES4.MRB_BILL_FLOW.operate
  is '操作';
comment on column MES4.MRB_BILL_FLOW.operatetime
  is '操作時間';
comment on column MES4.MRB_BILL_FLOW.out_num
  is '轉出數量';
alter table MES4.MRB_BILL_FLOW
  add constraint MRB_BILL_FOLOW_KEY primary key (DATAID);
alter index MES4.MRB_BILL_FOLOW_KEY nologging;

prompt
prompt Creating table MRB_ITEM_PRICE
prompt =============================
prompt
create table MES4.MRB_ITEM_PRICE
(
  item_no    NVARCHAR2(500) not null,
  item_price INTEGER
)
;
alter table MES4.MRB_ITEM_PRICE
  add constraint MRB_ITEM_PRICE_KEY primary key (ITEM_NO);
alter index MES4.MRB_ITEM_PRICE_KEY nologging;
grant select, insert, update, delete on MES4.MRB_ITEM_PRICE to MES1;

prompt
prompt Creating table MRB_MONTH_REPORT
prompt ===============================
prompt
create table MES4.MRB_MONTH_REPORT
(
  yearmonth     NVARCHAR2(20) not null,
  enter_money   NUMBER,
  out_money     NUMBER,
  in_money      NUMBER,
  in_num        NUMBER,
  enter_num     NUMBER,
  out_num       NUMBER,
  plant         NVARCHAR2(20) not null,
  storage       NVARCHAR2(20) not null,
  overdue_num   NUMBER default 0,
  overdue_money NUMBER default 0
)
;
comment on column MES4.MRB_MONTH_REPORT.yearmonth
  is '年月';
comment on column MES4.MRB_MONTH_REPORT.enter_money
  is '入庫金額';
comment on column MES4.MRB_MONTH_REPORT.out_money
  is '出庫金額';
comment on column MES4.MRB_MONTH_REPORT.in_money
  is '在庫金額';
comment on column MES4.MRB_MONTH_REPORT.in_num
  is '在庫單據數量';
comment on column MES4.MRB_MONTH_REPORT.enter_num
  is '入庫單據數量';
comment on column MES4.MRB_MONTH_REPORT.out_num
  is '出庫單據數量';
alter table MES4.MRB_MONTH_REPORT
  add constraint MRB_MONTH_REPORT_KEY primary key (YEARMONTH, PLANT, STORAGE);
grant select, insert, update, delete on MES4.MRB_MONTH_REPORT to MES1;

prompt
prompt Creating table MRB_OPERATE_LOG
prompt ==============================
prompt
create table MES4.MRB_OPERATE_LOG
(
  log_id      NUMBER not null,
  operater    NVARCHAR2(50),
  succeed     NUMBER,
  model       NVARCHAR2(50),
  input_data  NVARCHAR2(500),
  error_info  NVARCHAR2(500),
  create_date DATE
)
;
alter table MES4.MRB_OPERATE_LOG
  add constraint MRB_OPERATE_LOG_KEY primary key (LOG_ID);
alter index MES4.MRB_OPERATE_LOG_KEY nologging;
grant select, insert, update, delete on MES4.MRB_OPERATE_LOG to MES1;

prompt
prompt Creating table MRB_STATUS_INFO
prompt ==============================
prompt
create table MES4.MRB_STATUS_INFO
(
  status_id       NUMBER not null,
  status_name     NVARCHAR2(50),
  default_status  NUMBER,
  explain         NVARCHAR2(500),
  can_use_user_id NVARCHAR2(20)
)
;
alter table MES4.MRB_STATUS_INFO
  add constraint MRB_STATUS_INFO_KEY primary key (STATUS_ID);
alter index MES4.MRB_STATUS_INFO_KEY nologging;
grant select, insert, update, delete on MES4.MRB_STATUS_INFO to MES1;

prompt
prompt Creating table MRB_USER_INFO
prompt ============================
prompt
create table MES4.MRB_USER_INFO
(
  code                   NVARCHAR2(20) not null,
  username               NVARCHAR2(20),
  tel                    NVARCHAR2(50),
  model_tel_no           NVARCHAR2(50),
  email                  NVARCHAR2(50),
  levelname              NVARCHAR2(10),
  dept                   NVARCHAR2(20),
  director               NVARCHAR2(20),
  director_email         NVARCHAR2(50),
  director_tel           NVARCHAR2(50),
  factory_director       NVARCHAR2(50),
  factory_director_email NVARCHAR2(50),
  factory_director_tel   NVARCHAR2(50),
  leader                 NVARCHAR2(20),
  leader_email           NVARCHAR2(50),
  leader_tel             NVARCHAR2(50),
  sys_level              NUMBER
)
;
comment on column MES4.MRB_USER_INFO.code
  is '工號';
comment on column MES4.MRB_USER_INFO.username
  is '名字';
comment on column MES4.MRB_USER_INFO.tel
  is '分機';
comment on column MES4.MRB_USER_INFO.model_tel_no
  is '手機號';
comment on column MES4.MRB_USER_INFO.email
  is '電子郵件地址';
comment on column MES4.MRB_USER_INFO.levelname
  is '級別';
comment on column MES4.MRB_USER_INFO.dept
  is '部門';
comment on column MES4.MRB_USER_INFO.director
  is '課級主管名';
comment on column MES4.MRB_USER_INFO.director_email
  is '課級主管電子郵件';
comment on column MES4.MRB_USER_INFO.factory_director
  is '廠級主管名';
comment on column MES4.MRB_USER_INFO.factory_director_email
  is '廠級主管電子郵件';
comment on column MES4.MRB_USER_INFO.leader
  is '處級主管名';
comment on column MES4.MRB_USER_INFO.leader_email
  is '處級主管電子郵件';
alter table MES4.MRB_USER_INFO
  add constraint MRB_USER_INFO_KEY primary key (CODE);
alter index MES4.MRB_USER_INFO_KEY nologging;
grant select, insert, update, delete on MES4.MRB_USER_INFO to MES1;

prompt
prompt Creating table MRB_STORAGE_INFO
prompt ===============================
prompt
create table MES4.MRB_STORAGE_INFO
(
  dataid         NVARCHAR2(50) not null,
  item_no        NVARCHAR2(50),
  stock_no       NVARCHAR2(20),
  provider       NVARCHAR2(50),
  num            NUMBER,
  badness_reason NVARCHAR2(500),
  alarmtime      NUMBER,
  reigningtime   NUMBER,
  director       NVARCHAR2(50),
  backupinfo     NVARCHAR2(500),
  matentertime   DATE,
  matouttime     DATE,
  dataentertime  DATE,
  dataouttime    DATE,
  pre_director   NVARCHAR2(50),
  status_id      NUMBER,
  inyearweek     NVARCHAR2(20),
  outyearweek    NVARCHAR2(20),
  edittime       DATE,
  alarmstyle     NVARCHAR2(10),
  mvtype         NUMBER,
  plant          NVARCHAR2(10),
  uom            VARCHAR2(5),
  stgsum         NUMBER(16,2),
  sapdoc         NVARCHAR2(20),
  out_provider   NVARCHAR2(100),
  last_out_time  DATE,
  out_num        NUMBER default 0,
  mayfinishtime  DATE,
  stno           NVARCHAR2(50),
  copyto         NVARCHAR2(50),
  copytoemail    NVARCHAR2(500),
  cust_kp_desc   VARCHAR2(100),
  duemark        DATE
)
;
comment on column MES4.MRB_STORAGE_INFO.item_no
  is '料號';
comment on column MES4.MRB_STORAGE_INFO.stock_no
  is '倉碼';
comment on column MES4.MRB_STORAGE_INFO.provider
  is '來源';
comment on column MES4.MRB_STORAGE_INFO.num
  is '數量';
comment on column MES4.MRB_STORAGE_INFO.badness_reason
  is '不良原因';
comment on column MES4.MRB_STORAGE_INFO.alarmtime
  is '報警時間';
comment on column MES4.MRB_STORAGE_INFO.reigningtime
  is '在庫時間';
comment on column MES4.MRB_STORAGE_INFO.director
  is '負責人';
comment on column MES4.MRB_STORAGE_INFO.backupinfo
  is '備註';
comment on column MES4.MRB_STORAGE_INFO.matentertime
  is '實際入庫時間';
comment on column MES4.MRB_STORAGE_INFO.matouttime
  is '實際出庫時間';
comment on column MES4.MRB_STORAGE_INFO.dataentertime
  is '操作入庫時間';
comment on column MES4.MRB_STORAGE_INFO.dataouttime
  is '操作出庫時間';
comment on column MES4.MRB_STORAGE_INFO.pre_director
  is '前負責人';
comment on column MES4.MRB_STORAGE_INFO.status_id
  is '狀態ID';
comment on column MES4.MRB_STORAGE_INFO.inyearweek
  is '入庫年周';
comment on column MES4.MRB_STORAGE_INFO.outyearweek
  is '處理年周';
comment on column MES4.MRB_STORAGE_INFO.edittime
  is '編輯時間';
comment on column MES4.MRB_STORAGE_INFO.alarmstyle
  is '報警狀態';
comment on column MES4.MRB_STORAGE_INFO.mvtype
  is '異動類型';
comment on column MES4.MRB_STORAGE_INFO.plant
  is '工廠';
comment on column MES4.MRB_STORAGE_INFO.uom
  is '單位';
comment on column MES4.MRB_STORAGE_INFO.stgsum
  is '總價';
comment on column MES4.MRB_STORAGE_INFO.sapdoc
  is 'SAPDOC';
comment on column MES4.MRB_STORAGE_INFO.out_provider
  is '供應商';
comment on column MES4.MRB_STORAGE_INFO.last_out_time
  is '最後一次轉出時間';
comment on column MES4.MRB_STORAGE_INFO.out_num
  is '轉出數量';
comment on column MES4.MRB_STORAGE_INFO.mayfinishtime
  is '預計完成時間';
comment on column MES4.MRB_STORAGE_INFO.stno
  is '貯位';
comment on column MES4.MRB_STORAGE_INFO.copyto
  is '抄送對象';
comment on column MES4.MRB_STORAGE_INFO.copytoemail
  is '抄送對象的郵箱';
alter table MES4.MRB_STORAGE_INFO
  add constraint MRB_STORAGE_INFO_KEY primary key (DATAID);
alter table MES4.MRB_STORAGE_INFO
  add constraint MRB_STATUS_INFO_ID_KEY foreign key (STATUS_ID)
  references MES4.MRB_STATUS_INFO (STATUS_ID);
alter table MES4.MRB_STORAGE_INFO
  add constraint MRB_USER_INFO_CODE_PK1 foreign key (DIRECTOR)
  references MES4.MRB_USER_INFO (CODE);
grant select, insert, update, delete on MES4.MRB_STORAGE_INFO to MES1;

prompt
prompt Creating table MRB_STORAGE_LIST
prompt ===============================
prompt
create table MES4.MRB_STORAGE_LIST
(
  storagename NVARCHAR2(50) not null,
  plant       NVARCHAR2(50) not null
)
;
alter table MES4.MRB_STORAGE_LIST
  add constraint STORAGENAME primary key (STORAGENAME, PLANT);
alter index MES4.STORAGENAME nologging;
grant select, insert, update, delete on MES4.MRB_STORAGE_LIST to MES1;

prompt
prompt Creating table MRB_WEEK_REPORT
prompt ==============================
prompt
create table MES4.MRB_WEEK_REPORT
(
  yearweek      NVARCHAR2(20) not null,
  enter_money   NUMBER,
  out_money     NUMBER,
  in_money      NUMBER,
  enter_num     NUMBER,
  out_num       NUMBER,
  in_num        NUMBER,
  plant         NVARCHAR2(20) not null,
  storage       NVARCHAR2(20) not null,
  overdue_num   NUMBER default 0,
  overdue_money NUMBER default 0
)
;
comment on column MES4.MRB_WEEK_REPORT.yearweek
  is '年周';
comment on column MES4.MRB_WEEK_REPORT.enter_money
  is '入庫金額';
comment on column MES4.MRB_WEEK_REPORT.out_money
  is '出庫金額';
comment on column MES4.MRB_WEEK_REPORT.in_money
  is '在庫金額';
comment on column MES4.MRB_WEEK_REPORT.enter_num
  is '入庫單據數量';
comment on column MES4.MRB_WEEK_REPORT.out_num
  is '出庫單據數量';
comment on column MES4.MRB_WEEK_REPORT.in_num
  is '在庫單據數量';
alter table MES4.MRB_WEEK_REPORT
  add constraint MRB_WEEK_REPORT_KEY primary key (YEARWEEK, PLANT, STORAGE);
alter index MES4.MRB_WEEK_REPORT_KEY nologging;
grant select, insert, update, delete on MES4.MRB_WEEK_REPORT to MES1;

prompt
prompt Creating table R_2D_SN_RELATION
prompt ===============================
prompt
create table MES4.R_2D_SN_RELATION
(
  tr_sn              VARCHAR2(80) not null,
  barcode_2d         VARCHAR2(500) not null,
  pkg_id             VARCHAR2(50) not null,
  cust_kp_no         VARCHAR2(50) not null,
  cust_kp_no_version VARCHAR2(50),
  mfr_kp_no          VARCHAR2(200),
  mfr_code           VARCHAR2(50),
  vender_code        VARCHAR2(50),
  date_code          VARCHAR2(100),
  lot_code           VARCHAR2(200),
  updated_date       DATE,
  updated_by         VARCHAR2(50),
  created_date       DATE default SYSDATE,
  created_by         VARCHAR2(50),
  upload_flag        NUMBER default 0,
  data1              VARCHAR2(300),
  data2              VARCHAR2(300),
  data3              VARCHAR2(300),
  barcode_type       VARCHAR2(30),
  rosh_flag          VARCHAR2(10)
)
;
create unique index MES4.IDX_R_2D_SN_RELATION_2DSN on MES4.R_2D_SN_RELATION (BARCODE_2D)
  nologging;
create unique index MES4.IDX_R_2D_SN_RELATION_PID on MES4.R_2D_SN_RELATION (PKG_ID)
  nologging;
create unique index MES4.IDX_R_2D_SN_RELATION_SN on MES4.R_2D_SN_RELATION (TR_SN)
  nologging;
grant select, insert, update, delete on MES4.R_2D_SN_RELATION to MES1;

prompt
prompt Creating table R_ALARM_MACHINE
prompt ==============================
prompt
create table MES4.R_ALARM_MACHINE
(
  department   VARCHAR2(15),
  station      VARCHAR2(20) not null,
  wo           VARCHAR2(18),
  alarm_reason VARCHAR2(300) not null,
  from_program VARCHAR2(50),
  alarm_emp    VARCHAR2(15),
  alarm_time   DATE,
  data1        VARCHAR2(50),
  data2        VARCHAR2(50),
  data3        VARCHAR2(50),
  data4        VARCHAR2(50)
)
;
create index MES4.IDX_R_ALARM_MACHINE_ST on MES4.R_ALARM_MACHINE (STATION);

prompt
prompt Creating table R_ALARM_MACHINE_BACKUP
prompt =====================================
prompt
create table MES4.R_ALARM_MACHINE_BACKUP
(
  department   VARCHAR2(15),
  station      VARCHAR2(20) not null,
  wo           VARCHAR2(18),
  alarm_reason VARCHAR2(300) not null,
  from_program VARCHAR2(50),
  alarm_emp    VARCHAR2(15),
  alarm_time   DATE,
  data1        VARCHAR2(50),
  data2        VARCHAR2(50),
  data3        VARCHAR2(50),
  data4        VARCHAR2(50)
)
;
create index MES4.IDX_R_ALARM_MACHINE_BACKUP_ST on MES4.R_ALARM_MACHINE_BACKUP (STATION);
create index MES4.IDX_R_ALARM_MACHINE_BACKUP_WO on MES4.R_ALARM_MACHINE_BACKUP (WO);

prompt
prompt Creating table R_ALARM_MAIL
prompt ===========================
prompt
create table MES4.R_ALARM_MAIL
(
  alarm_tr_sn     VARCHAR2(13) not null,
  mail_subject    VARCHAR2(300),
  mail_info       VARCHAR2(4000),
  mail_attac      BLOB,
  mail_attac_name VARCHAR2(50)
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_ALARM_MAIL to MES1;

prompt
prompt Creating table R_ALARM_SEND_TASK
prompt ================================
prompt
create table MES4.R_ALARM_SEND_TASK
(
  alarm_tr_sn VARCHAR2(13) not null,
  alarm_type  VARCHAR2(3) not null,
  alarm_code  VARCHAR2(6) not null,
  send_type   VARCHAR2(1) default '0' not null,
  send_orig   VARCHAR2(50),
  remark      VARCHAR2(400) not null,
  work_flag   VARCHAR2(1) default '0' not null,
  work_time   DATE not null
)
;
grant select, insert, update, delete on MES4.R_ALARM_SEND_TASK to MES1;

prompt
prompt Creating table R_ALARM_TASK_HISTORY
prompt ===================================
prompt
create table MES4.R_ALARM_TASK_HISTORY
(
  alarm_tr_sn VARCHAR2(13) not null,
  send_dest   VARCHAR2(1000) not null,
  send_cc     VARCHAR2(500),
  send_bcc    VARCHAR2(500),
  send_status VARCHAR2(1) not null,
  work_time   DATE not null
)
;
grant select, insert, update, delete on MES4.R_ALARM_TASK_HISTORY to MES1;

prompt
prompt Creating table R_ALARM_TASK_TEMP
prompt ================================
prompt
create table MES4.R_ALARM_TASK_TEMP
(
  alarm_tr_sn VARCHAR2(13) not null,
  send_dest   VARCHAR2(3000) not null,
  send_cc     VARCHAR2(500),
  send_bcc    VARCHAR2(500),
  send_times  NUMBER(2) default 0 not null,
  send_status VARCHAR2(1) default '1' not null,
  work_time   DATE not null
)
;
grant select, insert, update, delete on MES4.R_ALARM_TASK_TEMP to MES1;

prompt
prompt Creating table R_APS_SCHEDULE
prompt =============================
prompt
create table MES4.R_APS_SCHEDULE
(
  plant      VARCHAR2(20) not null,
  wo         VARCHAR2(20) not null,
  side       VARCHAR2(20) not null,
  line       VARCHAR2(20) not null,
  qty        NUMBER not null,
  begin_time DATE,
  end_time   DATE,
  edit_time  DATE default SYSDATE not null
)
;
grant select, insert, update, delete, alter on MES4.R_APS_SCHEDULE to MES1;

prompt
prompt Creating table R_AP_DATA
prompt ========================
prompt
create table MES4.R_AP_DATA
(
  ap_name       VARCHAR2(25) not null,
  function_name VARCHAR2(25) not null,
  mac           VARCHAR2(17),
  data1         VARCHAR2(25),
  data2         VARCHAR2(25),
  data3         VARCHAR2(25),
  data4         VARCHAR2(25),
  data5         VARCHAR2(25),
  data6         VARCHAR2(25),
  data7         VARCHAR2(25),
  data8         VARCHAR2(25),
  data9         VARCHAR2(25),
  data10        VARCHAR2(25),
  data11        VARCHAR2(25),
  data12        VARCHAR2(25),
  data13        VARCHAR2(25),
  data14        VARCHAR2(25),
  data15        VARCHAR2(25),
  data16        VARCHAR2(25),
  data17        VARCHAR2(25),
  data18        VARCHAR2(25),
  data19        VARCHAR2(25),
  data20        VARCHAR2(25),
  work_time     DATE default SYSDATE not null
)
;
grant select, insert, update, delete on MES4.R_AP_DATA to MES1;

prompt
prompt Creating table R_AP_TEMP
prompt ========================
prompt
create table MES4.R_AP_TEMP
(
  data1     VARCHAR2(25) not null,
  data2     VARCHAR2(25),
  data3     VARCHAR2(25),
  data4     VARCHAR2(25),
  data5     VARCHAR2(25),
  data6     VARCHAR2(25),
  data7     VARCHAR2(25),
  data8     VARCHAR2(25),
  data9     VARCHAR2(25),
  data10    VARCHAR2(25),
  data11    VARCHAR2(25),
  data12    VARCHAR2(25),
  data13    VARCHAR2(25),
  data14    VARCHAR2(25),
  data15    VARCHAR2(25),
  data16    VARCHAR2(25),
  data17    VARCHAR2(25),
  data18    VARCHAR2(25),
  data19    VARCHAR2(25),
  data20    VARCHAR2(25),
  work_time DATE default SYSDATE not null
)
;
create index MES4.IDX_R_AP_TEMP_DATA1 on MES4.R_AP_TEMP (DATA1);
create index MES4.IDX_R_AP_TEMP_DATA2 on MES4.R_AP_TEMP (DATA2);
create index MES4.IDX_R_AP_TEMP_DATA3 on MES4.R_AP_TEMP (DATA3);
create index MES4.IDX_R_AP_TEMP_DATA6 on MES4.R_AP_TEMP (DATA6);
create index MES4.IDX_R_AP_TEMP_DATA9 on MES4.R_AP_TEMP (DATA9);
grant select, insert, update, delete, references, alter, index on MES4.R_AP_TEMP to MES1;

prompt
prompt Creating table R_ATTACHMENT_DETAIL
prompt ==================================
prompt
create table MES4.R_ATTACHMENT_DETAIL
(
  seqno               VARCHAR2(30) not null,
  subject             VARCHAR2(100) not null,
  mainid              VARCHAR2(50) not null,
  commentid           VARCHAR2(200) not null,
  attachment          BLOB,
  attachmenttype      VARCHAR2(10),
  attachmentname      VARCHAR2(100),
  mainxlminfo         BLOB,
  signxmlinfo         BLOB,
  sendsigntime        DATE,
  sendsignempno       VARCHAR2(20),
  signflowdescription VARCHAR2(250),
  signcancleflag      VARCHAR2(1) default 'N',
  closedflag          INTEGER default '0',
  closedtime          DATE,
  description         VARCHAR2(250),
  maininfo            VARCHAR2(200),
  signinfo            VARCHAR2(2000),
  workflowid          VARCHAR2(10)
)
;
comment on column MES4.R_ATTACHMENT_DETAIL.seqno
  is '唯一系列號';
comment on column MES4.R_ATTACHMENT_DETAIL.sendsignempno
  is '生成人員工號';
comment on column MES4.R_ATTACHMENT_DETAIL.signflowdescription
  is '簽核流程描述';
comment on column MES4.R_ATTACHMENT_DETAIL.signcancleflag
  is '是否取消簽核(Y->取消,N->默認)';
comment on column MES4.R_ATTACHMENT_DETAIL.closedflag
  is '是否完成簽核(1->完成,0->默認)';
comment on column MES4.R_ATTACHMENT_DETAIL.closedtime
  is '完成時間';
comment on column MES4.R_ATTACHMENT_DETAIL.description
  is '其它描述';
comment on column MES4.R_ATTACHMENT_DETAIL.maininfo
  is '附件關鍵信息';
comment on column MES4.R_ATTACHMENT_DETAIL.signinfo
  is '簽核關鍵信息';
comment on column MES4.R_ATTACHMENT_DETAIL.workflowid
  is '工作流ID';
grant select, insert, update, delete, alter on MES4.R_ATTACHMENT_DETAIL to MES1;

prompt
prompt Creating table R_AUTOAP_LOG
prompt ===========================
prompt
create table MES4.R_AUTOAP_LOG
(
  ip            VARCHAR2(15) not null,
  ap_name       VARCHAR2(20) not null,
  function_name VARCHAR2(80) not null,
  work_time     DATE not null,
  work_flag     VARCHAR2(1) default '0' not null
)
;

prompt
prompt Creating table R_AUTOSCAN_DETAIL
prompt ================================
prompt
create table MES4.R_AUTOSCAN_DETAIL
(
  p_sn         VARCHAR2(50),
  wo           VARCHAR2(100),
  p_no         VARCHAR2(250),
  process_flag VARCHAR2(12) default '0',
  work_time    DATE,
  station      VARCHAR2(30),
  data1        VARCHAR2(250),
  data2        VARCHAR2(250),
  data3        VARCHAR2(250),
  data4        VARCHAR2(250)
)
;
grant select, insert, update, delete on MES4.R_AUTOSCAN_DETAIL to MES1;

prompt
prompt Creating table R_AUTO_GAUGE_ALARM
prompt =================================
prompt
create table MES4.R_AUTO_GAUGE_ALARM
(
  name         VARCHAR2(50) not null,
  status       VARCHAR2(2),
  sn           VARCHAR2(50),
  p_no         VARCHAR2(50),
  p_version    VARCHAR2(50),
  line_name    VARCHAR2(50),
  wo           VARCHAR2(50),
  machine      VARCHAR2(50),
  gauge_type   VARCHAR2(20),
  process      VARCHAR2(50),
  request_qty  NUMBER default 0,
  alarm_flag   VARCHAR2(1) default 'N',
  alarm_time   DATE,
  ip           VARCHAR2(30),
  work_time    DATE default SYSDATE,
  control_flag VARCHAR2(10) default 1,
  remark       VARCHAR2(100),
  call_emp     VARCHAR2(10)
)
;
create index MES4.IDX_R_AUTO_GAUGE_ALARM on MES4.R_AUTO_GAUGE_ALARM (NAME, LINE_NAME, ALARM_FLAG)
  nologging;
create index MES4.IDX_R_AUTO_GAUGE_ALARM2 on MES4.R_AUTO_GAUGE_ALARM (NAME, SN)
  nologging;
grant select, insert, update, delete, alter on MES4.R_AUTO_GAUGE_ALARM to MES1;

prompt
prompt Creating table R_AUTO_INSPECT_CONFIG_DETAIL
prompt ===========================================
prompt
create table MES4.R_AUTO_INSPECT_CONFIG_DETAIL
(
  cust_kp_no  VARCHAR2(20) not null,
  mfr_kp_no   VARCHAR2(100),
  mfr_name    VARCHAR2(100),
  flag        VARCHAR2(1) not null,
  edit_emp    VARCHAR2(10) not null,
  edit_time   DATE not null,
  modify_desc VARCHAR2(200)
)
;
grant select, insert, update, delete on MES4.R_AUTO_INSPECT_CONFIG_DETAIL to MES1;

prompt
prompt Creating table R_AUTO_INSPECT_SMART_DETAIL
prompt ==========================================
prompt
create table MES4.R_AUTO_INSPECT_SMART_DETAIL
(
  cust_kp_no  VARCHAR2(20) not null,
  mfr_kp_no   VARCHAR2(100),
  mfr_name    VARCHAR2(100),
  flag        VARCHAR2(1) not null,
  edit_emp    VARCHAR2(10) not null,
  edit_time   DATE not null,
  modify_desc VARCHAR2(200)
)
;
grant select, insert, update, delete on MES4.R_AUTO_INSPECT_SMART_DETAIL to MES1;

prompt
prompt Creating table R_AUTO_KITTING_ALARM
prompt ===================================
prompt
create table MES4.R_AUTO_KITTING_ALARM
(
  name         VARCHAR2(50) not null,
  status       VARCHAR2(2),
  line_name    VARCHAR2(50),
  wo           VARCHAR2(500) not null,
  v_wo         VARCHAR2(50),
  machine      VARCHAR2(50),
  kp_no        VARCHAR2(100) not null,
  slot_no      VARCHAR2(50),
  process_flag VARCHAR2(50) default 'D',
  uph_qty      NUMBER default 0,
  fact_qty     NUMBER default 0,
  sfc_qty      NUMBER default 0,
  used_qty     NUMBER default 0,
  exist_qty    NUMBER default 0,
  request_qty  NUMBER default 0,
  checkout_qty NUMBER default 0,
  return_qty   NUMBER default 0,
  buff_qty     NUMBER default 0,
  wastge_qty   NUMBER default 0,
  mpq_qty      NUMBER default 0,
  p_no         VARCHAR2(50),
  alarm_flag   VARCHAR2(1) default 'N',
  alarm_time   DATE,
  ip           VARCHAR2(30),
  work_time    DATE default SYSDATE,
  control_flag VARCHAR2(10) default 1,
  standard_qty NUMBER
)
;
comment on column MES4.R_AUTO_KITTING_ALARM.name
  is '程序名稱';
comment on column MES4.R_AUTO_KITTING_ALARM.status
  is '當前狀態';
comment on column MES4.R_AUTO_KITTING_ALARM.line_name
  is '線別名';
comment on column MES4.R_AUTO_KITTING_ALARM.wo
  is '聯合工單中的所有單體工單串接';
comment on column MES4.R_AUTO_KITTING_ALARM.v_wo
  is '聯合工單的聯合工單名';
comment on column MES4.R_AUTO_KITTING_ALARM.machine
  is '設備';
comment on column MES4.R_AUTO_KITTING_ALARM.kp_no
  is '富士康料號';
comment on column MES4.R_AUTO_KITTING_ALARM.slot_no
  is '設備料槽號';
comment on column MES4.R_AUTO_KITTING_ALARM.process_flag
  is '產品面別';
comment on column MES4.R_AUTO_KITTING_ALARM.uph_qty
  is '每小時最大產能數量';
comment on column MES4.R_AUTO_KITTING_ALARM.fact_qty
  is '實際產出數量';
comment on column MES4.R_AUTO_KITTING_ALARM.sfc_qty
  is 'SFC系統中的數量';
comment on column MES4.R_AUTO_KITTING_ALARM.used_qty
  is '已經用掉的物料料件單體數量';
comment on column MES4.R_AUTO_KITTING_ALARM.exist_qty
  is '現存的物料料件單體數量';
comment on column MES4.R_AUTO_KITTING_ALARM.request_qty
  is '聯合工單的該物料料件總需求數量';
comment on column MES4.R_AUTO_KITTING_ALARM.checkout_qty
  is '聯合工單的該物料料件總發出數量';
comment on column MES4.R_AUTO_KITTING_ALARM.return_qty
  is '聯合工單的該物料料件總退回數量';
comment on column MES4.R_AUTO_KITTING_ALARM.buff_qty
  is '物料料件需要預留的物料料件數量';
comment on column MES4.R_AUTO_KITTING_ALARM.wastge_qty
  is '聯合工單的該物料料件總損耗數量';
comment on column MES4.R_AUTO_KITTING_ALARM.mpq_qty
  is '該物料料件的一個裝載單位滿載情況下的數量';
comment on column MES4.R_AUTO_KITTING_ALARM.p_no
  is '半成品機種';
comment on column MES4.R_AUTO_KITTING_ALARM.alarm_flag
  is '是否報警';
comment on column MES4.R_AUTO_KITTING_ALARM.alarm_time
  is '報警的時間';
comment on column MES4.R_AUTO_KITTING_ALARM.ip
  is '物理';
create index MES4.IDX_R_AUTO_KITTING_ALARM on MES4.R_AUTO_KITTING_ALARM (NAME, LINE_NAME, ALARM_FLAG)
  nologging;
grant select, insert, update, delete on MES4.R_AUTO_KITTING_ALARM to MES1;

prompt
prompt Creating table R_BACKBACKFLUSH_DETAIL
prompt =====================================
prompt
create table MES4.R_BACKBACKFLUSH_DETAIL
(
  wo          VARCHAR2(13) not null,
  plant       VARCHAR2(10) not null,
  cust_kp_no  VARCHAR2(20) not null,
  move_type   VARCHAR2(40),
  from_stock  VARCHAR2(10) not null,
  to_stock    VARCHAR2(10) not null,
  qty         NUMBER(10,2) not null,
  unit        VARCHAR2(5) not null,
  move_remark VARCHAR2(160),
  move_result VARCHAR2(160),
  fail_times  NUMBER(7) default 0 not null,
  edit_emp    VARCHAR2(25),
  edit_time   DATE,
  closed      VARCHAR2(1) default '0' not null,
  closed_time DATE,
  send_flag   VARCHAR2(2) default '0' not null,
  send_time   DATE
)
;
comment on column MES4.R_BACKBACKFLUSH_DETAIL.send_flag
  is 'MAIN IS SEND OK';
grant select, insert, update, delete on MES4.R_BACKBACKFLUSH_DETAIL to MES1;

prompt
prompt Creating table R_BENT_LEAD_STATUS
prompt =================================
prompt
create table MES4.R_BENT_LEAD_STATUS
(
  tr_sn       VARCHAR2(12) not null,
  action_flag VARCHAR2(1) not null,
  action_desc VARCHAR2(2) not null,
  action_time DATE not null
)
;

prompt
prompt Creating table R_BGA_KP_DETAIL
prompt ==============================
prompt
create table MES4.R_BGA_KP_DETAIL
(
  tr_sn      VARCHAR2(12) not null,
  kp_no      VARCHAR2(20) not null,
  start_time DATE not null,
  end_time   DATE,
  work_flag  VARCHAR2(1) not null,
  total_time NUMBER,
  start_emp  VARCHAR2(10) not null,
  end_emp    VARCHAR2(10),
  data1      VARCHAR2(1),
  data2      VARCHAR2(20)
)
;
grant select, insert, update, delete on MES4.R_BGA_KP_DETAIL to MES1;

prompt
prompt Creating table R_BGA_LOCK_SETUP
prompt ===============================
prompt
create table MES4.R_BGA_LOCK_SETUP
(
  kp_no       VARCHAR2(20) not null,
  lock_time   DATE,
  lock_desc   VARCHAR2(200),
  lock_emp    VARCHAR2(10),
  unlock_time DATE not null,
  unlock_desc VARCHAR2(200) not null,
  unlock_emp  VARCHAR2(10) not null,
  data1       VARCHAR2(20),
  data2       VARCHAR2(20),
  tr_sn       VARCHAR2(12) not null
)
;
grant select, insert, update, delete on MES4.R_BGA_LOCK_SETUP to MES1;

prompt
prompt Creating table R_BGA_TEMP
prompt =========================
prompt
create table MES4.R_BGA_TEMP
(
  kp_no     VARCHAR2(20) not null,
  sum_kp    NUMBER(5) not null,
  data1     VARCHAR2(25),
  data2     VARCHAR2(25),
  edit_time DATE
)
;
grant select, insert, update, delete on MES4.R_BGA_TEMP to MES1;

prompt
prompt Creating table R_BU_DPPM
prompt ========================
prompt
create table MES4.R_BU_DPPM
(
  kp_no     VARCHAR2(20) not null,
  mfr_name  VARCHAR2(80) not null,
  total_qty NUMBER not null,
  fail_qty  NUMBER not null,
  dppm      VARCHAR2(15) not null,
  l_bu_code VARCHAR2(10),
  work_time DATE default SYSDATE
)
;
grant select, insert, delete on MES4.R_BU_DPPM to MES1;

prompt
prompt Creating table R_BU_DPPM_DRAFT
prompt ==============================
prompt
create table MES4.R_BU_DPPM_DRAFT
(
  kp_no     VARCHAR2(20) not null,
  mfr_name  VARCHAR2(80) not null,
  total_qty NUMBER not null,
  fail_qty  NUMBER not null,
  dppm      NUMBER not null,
  l_bu_code VARCHAR2(10),
  work_flag VARCHAR2(2),
  work_date DATE,
  goal      NUMBER
)
;
grant select, insert, update, delete on MES4.R_BU_DPPM_DRAFT to MES1;

prompt
prompt Creating table R_CHANGE_WO_TIME
prompt ===============================
prompt
create table MES4.R_CHANGE_WO_TIME
(
  travel_sn    VARCHAR2(17) not null,
  line_name    VARCHAR2(8) not null,
  station      VARCHAR2(10) not null,
  p_no         VARCHAR2(20) not null,
  p_version    VARCHAR2(4) not null,
  wo           VARCHAR2(12) not null,
  wo_qty       NUMBER(6) not null,
  start_time   DATE not null,
  end_time     DATE,
  process_flag VARCHAR2(1)
)
;
create index MES4.R_CHANGE_WO_TIMESTATION on MES4.R_CHANGE_WO_TIME (STATION)
  nologging;
create index MES4.R_CHANGE_WO_TIME_WO on MES4.R_CHANGE_WO_TIME (WO)
  nologging;
grant select, insert, update, delete, alter on MES4.R_CHANGE_WO_TIME to MES1;

prompt
prompt Creating table R_CHECKLIST_TEMP
prompt ===============================
prompt
create table MES4.R_CHECKLIST_TEMP
(
  new_travel_sn VARCHAR2(17) not null,
  old_travel_sn VARCHAR2(17) not null,
  new_slot_no   VARCHAR2(7),
  kp_no         VARCHAR2(20) not null,
  feeder_type   VARCHAR2(40),
  standard_qty  NUMBER(4) not null,
  old_slot      VARCHAR2(7),
  old_feeder_no VARCHAR2(15),
  status        VARCHAR2(1) not null,
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_CHECKLIST_TEMP to MES1;

prompt
prompt Creating table R_CHECK_ALARMTRSN_DUP
prompt ====================================
prompt
create table MES4.R_CHECK_ALARMTRSN_DUP
(
  sn        VARCHAR2(13) not null,
  work_time DATE default SYSDATE not null
)
;
alter table MES4.R_CHECK_ALARMTRSN_DUP
  add constraint CHECK_ALARMTRSN_PK primary key (SN);
grant select, insert, update, delete on MES4.R_CHECK_ALARMTRSN_DUP to MES1;

prompt
prompt Creating table R_CHECK_DETAIL
prompt =============================
prompt
create table MES4.R_CHECK_DETAIL
(
  check_type      VARCHAR2(30) not null,
  check_code      VARCHAR2(50) not null,
  check_sn        VARCHAR2(50) not null,
  check_serial_no VARCHAR2(20) not null,
  check_content   VARCHAR2(500) not null,
  check_result    VARCHAR2(300) not null,
  remarks         VARCHAR2(300),
  edit_emp        VARCHAR2(12),
  edit_time       DATE,
  data1           VARCHAR2(50),
  data2           VARCHAR2(100),
  data3           VARCHAR2(100),
  isok            VARCHAR2(10),
  input_type      VARCHAR2(1),
  candidate_value VARCHAR2(1000)
)
;
create index MES4.IDX_R_CHECK_DETAIL_CHECKSN on MES4.R_CHECK_DETAIL (CHECK_SN);
grant select, insert, update, delete, alter on MES4.R_CHECK_DETAIL to MES1;

prompt
prompt Creating table R_CHECK_DOCNO_DUP
prompt ================================
prompt
create table MES4.R_CHECK_DOCNO_DUP
(
  sn        VARCHAR2(15) not null,
  work_time DATE default SYSDATE not null
)
;
alter table MES4.R_CHECK_DOCNO_DUP
  add constraint CHECK_DOCNO_PK primary key (SN);
grant select, insert, update, delete on MES4.R_CHECK_DOCNO_DUP to MES1;

prompt
prompt Creating table R_CHECK_FEEDER_DUP
prompt =================================
prompt
create table MES4.R_CHECK_FEEDER_DUP
(
  sn        VARCHAR2(15) not null,
  work_time DATE default SYSDATE not null
)
;
alter table MES4.R_CHECK_FEEDER_DUP
  add constraint CHECK_FEEDER_SNPK primary key (SN);
alter index MES4.CHECK_FEEDER_SNPK nologging;
grant select, insert, update, delete on MES4.R_CHECK_FEEDER_DUP to MES1;

prompt
prompt Creating table R_CHECK_SN_DUP
prompt =============================
prompt
create table MES4.R_CHECK_SN_DUP
(
  sn        VARCHAR2(50) not null,
  work_time DATE default SYSDATE not null
)
;
alter table MES4.R_CHECK_SN_DUP
  add primary key (SN);
alter index MES4.SYS_C0013690 nologging;
grant select, insert, update, delete, references, alter, index on MES4.R_CHECK_SN_DUP to MES1;

prompt
prompt Creating table R_CHECK_TIMELINESS_DETAIL
prompt ========================================
prompt
create table MES4.R_CHECK_TIMELINESS_DETAIL
(
  wo           VARCHAR2(200),
  kp_no        VARCHAR2(30),
  tr_sn        VARCHAR2(20),
  offline_time DATE,
  return_time  DATE,
  flag         VARCHAR2(10),
  edit_time    DATE,
  edit_emp     VARCHAR2(40),
  data_type    VARCHAR2(30) default '工單退料結束時間' not null,
  line_name    VARCHAR2(12),
  check_time   DATE,
  notice       VARCHAR2(50)
)
;
comment on column MES4.R_CHECK_TIMELINESS_DETAIL.wo
  is '工單';
comment on column MES4.R_CHECK_TIMELINESS_DETAIL.kp_no
  is '物料';
comment on column MES4.R_CHECK_TIMELINESS_DETAIL.offline_time
  is '下線時間';
comment on column MES4.R_CHECK_TIMELINESS_DETAIL.return_time
  is '退料完成時間';
comment on column MES4.R_CHECK_TIMELINESS_DETAIL.check_time
  is '盤料完成時間';
comment on column MES4.R_CHECK_TIMELINESS_DETAIL.notice
  is '備註';
create index MES4.IDX_R_CHECK_TIMELINESS_DETAIL on MES4.R_CHECK_TIMELINESS_DETAIL (WO, KP_NO, TR_SN)
  nologging;
create index MES4.IDX_R_CHECK_TIMELINESS_DETAIL2 on MES4.R_CHECK_TIMELINESS_DETAIL (DATA_TYPE)
  nologging;

prompt
prompt Creating table R_CLEAR_MATERIAL
prompt ===============================
prompt
create table MES4.R_CLEAR_MATERIAL
(
  snumber        VARCHAR2(30) not null,
  hcust          VARCHAR2(15) default 'N/A',
  cust_kp_no     VARCHAR2(500),
  specification  VARCHAR2(500),
  date_code      VARCHAR2(300),
  mfr_name       VARCHAR2(100),
  mfr_kp_no      VARCHAR2(100),
  fail_qty       INTEGER,
  start_time     DATE not null,
  end_time       DATE,
  router         VARCHAR2(100),
  clear_reson    VARCHAR2(300),
  effect_product VARCHAR2(300),
  edit_emp       VARCHAR2(25),
  lot_code       VARCHAR2(100),
  effect_qty     NUMBER,
  ext_number     VARCHAR2(20),
  c_status       VARCHAR2(20),
  c_people       VARCHAR2(20),
  d_status       VARCHAR2(20),
  d_people       VARCHAR2(20),
  c_suggestion   VARCHAR2(100),
  d_suggestion   VARCHAR2(100),
  action_code    VARCHAR2(50),
  unlock_time    DATE,
  date_code2     VARCHAR2(50),
  purge_level    VARCHAR2(10),
  sap_flag       VARCHAR2(2),
  foxconn_site   VARCHAR2(50),
  product_level  VARCHAR2(50),
  clear_location VARCHAR2(20),
  close_emp      VARCHAR2(20),
  close_reason   VARCHAR2(200),
  rev            VARCHAR2(20),
  owner          VARCHAR2(20),
  purge_snumber  VARCHAR2(30),
  flag           VARCHAR2(35),
  c_sign_time    DATE,
  d_sign_time    DATE,
  mfr_code       VARCHAR2(15),
  e_status       VARCHAR2(20),
  e_people       VARCHAR2(50),
  e_sign_time    DATE,
  originator     VARCHAR2(20),
  e_suggestion   VARCHAR2(100),
  routeid        VARCHAR2(30),
  close_type     VARCHAR2(30),
  close_time     DATE,
  unlock_emp     VARCHAR2(20)
)
;
grant select, insert, update, delete, alter on MES4.R_CLEAR_MATERIAL to MES1;

prompt
prompt Creating table R_CLEAR_MATERIAL_DETAIL
prompt ======================================
prompt
create table MES4.R_CLEAR_MATERIAL_DETAIL
(
  snumber      VARCHAR2(30) not null,
  clear_object VARCHAR2(50),
  fz_dw        VARCHAR2(20),
  fzr          VARCHAR2(20),
  qty          INTEGER default 0,
  work_time    DATE,
  reson        VARCHAR2(300),
  emp_no       VARCHAR2(200),
  y_qty        INTEGER default 0,
  location     VARCHAR2(20),
  status       VARCHAR2(20),
  y_emp_no     VARCHAR2(20),
  y_work_time  DATE
)
;
grant select, insert, update, delete, alter on MES4.R_CLEAR_MATERIAL_DETAIL to MES1;

prompt
prompt Creating table R_COMBOX_DATA
prompt ============================
prompt
create table MES4.R_COMBOX_DATA
(
  ap_name        VARCHAR2(50),
  function_name  VARCHAR2(50),
  combox_name    VARCHAR2(50),
  combox_explain VARCHAR2(50),
  value1         VARCHAR2(100),
  value2         VARCHAR2(100),
  value3         VARCHAR2(100),
  value4         VARCHAR2(100),
  edit_emp       VARCHAR2(25),
  edit_time      DATE default SYSDATE
)
;
create index MES4.IDX_R_COMBOX_DATA_1 on MES4.R_COMBOX_DATA (COMBOX_NAME);

prompt
prompt Creating table R_DATA_FOR_DPPM
prompt ==============================
prompt
create table MES4.R_DATA_FOR_DPPM
(
  online_num NUMBER,
  kp_no      VARCHAR2(20),
  p_no       VARCHAR2(20),
  date_code  VARCHAR2(40),
  lot_code   VARCHAR2(50),
  mfr_name   VARCHAR2(80),
  work_time  DATE,
  mfr_kp_no  VARCHAR2(100),
  sn_qty     NUMBER(10) default 0
)
;
create index MES4.IDX_H_DATA_DPPM_KPWTIME on MES4.R_DATA_FOR_DPPM (KP_NO, WORK_TIME);
create index MES4.IDX_H_DPPM_WORKTIME on MES4.R_DATA_FOR_DPPM (WORK_TIME);
create index MES4.IX_H_DPPM_PNO on MES4.R_DATA_FOR_DPPM (P_NO);
grant select, insert, update, delete on MES4.R_DATA_FOR_DPPM to MES1;

prompt
prompt Creating table R_DATA_TEMP
prompt ==========================
prompt
create table MES4.R_DATA_TEMP
(
  item1  VARCHAR2(25),
  item2  VARCHAR2(25),
  data1  VARCHAR2(25),
  data2  VARCHAR2(25),
  data3  VARCHAR2(25),
  data4  VARCHAR2(25),
  data5  VARCHAR2(25),
  data6  VARCHAR2(25),
  data7  VARCHAR2(25),
  data8  VARCHAR2(25),
  data9  VARCHAR2(25),
  data10 VARCHAR2(25),
  data11 VARCHAR2(25),
  data12 VARCHAR2(25),
  data13 VARCHAR2(25),
  data14 VARCHAR2(25),
  data15 VARCHAR2(25),
  flag1  CHAR(25),
  flag2  CHAR(25),
  time1  DATE,
  time2  DATE,
  time3  DATE,
  temp1  VARCHAR2(25),
  temp2  VARCHAR2(25),
  temp3  VARCHAR2(25)
)
;
create index MES4.IDX_RDT_DATA1_10 on MES4.R_DATA_TEMP (DATA1, DATA10)
  nologging;
create index MES4.IDX_RDT_DATA3 on MES4.R_DATA_TEMP (DATA3)
  nologging;
grant select, insert, update, delete, alter on MES4.R_DATA_TEMP to MES1;

prompt
prompt Creating table R_DEVICE_FILE
prompt ============================
prompt
create table MES4.R_DEVICE_FILE
(
  search_id         VARCHAR2(25),
  file_type         VARCHAR2(25) not null,
  actual_file_name  VARCHAR2(500) not null,
  virtual_file_name VARCHAR2(100) not null,
  file_path         VARCHAR2(500) not null,
  edit_time         DATE,
  edit_emp          VARCHAR2(20)
)
;
comment on table MES4.R_DEVICE_FILE
  is '文件上傳記錄';
comment on column MES4.R_DEVICE_FILE.search_id
  is '預留';
comment on column MES4.R_DEVICE_FILE.file_type
  is '文件類型';
comment on column MES4.R_DEVICE_FILE.actual_file_name
  is '實際文件名稱';
comment on column MES4.R_DEVICE_FILE.virtual_file_name
  is '服務器保存文件的名稱';
comment on column MES4.R_DEVICE_FILE.file_path
  is '存放地址';
grant select, insert, update, delete, alter on MES4.R_DEVICE_FILE to MES1;

prompt
prompt Creating table R_DEVICE_MAINTAIN
prompt ================================
prompt
create table MES4.R_DEVICE_MAINTAIN
(
  line              VARCHAR2(8) not null,
  maintain_type     VARCHAR2(15) not null,
  id                VARCHAR2(8) not null,
  plan_time_start   VARCHAR2(25),
  plan_time_end     VARCHAR2(25),
  change_time_start VARCHAR2(25),
  change_time_end   VARCHAR2(25),
  changed_flag      VARCHAR2(1) not null,
  maintain_time     DATE,
  maintain_flag     VARCHAR2(1) not null,
  edit_emp          VARCHAR2(10),
  edit_time         DATE,
  data1             VARCHAR2(25),
  data2             VARCHAR2(25),
  data3             VARCHAR2(25)
)
;
grant select, insert, update, delete, alter on MES4.R_DEVICE_MAINTAIN to MES1;

prompt
prompt Creating table R_DEVICE_MAINTAIN_DETAIL
prompt =======================================
prompt
create table MES4.R_DEVICE_MAINTAIN_DETAIL
(
  sn             VARCHAR2(25) not null,
  maintain_month VARCHAR2(10) not null,
  maintain_type  VARCHAR2(50),
  line           VARCHAR2(5),
  id             VARCHAR2(50),
  maintain_emp   VARCHAR2(10),
  edit_time      DATE,
  edit_emp       VARCHAR2(10),
  remark         VARCHAR2(50)
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_DEVICE_MAINTAIN_DETAIL to MES1;

prompt
prompt Creating table R_DFGRN_FAIL
prompt ===========================
prompt
create table MES4.R_DFGRN_FAIL
(
  doc_no    VARCHAR2(20),
  plant     VARCHAR2(10),
  fail_code VARCHAR2(10),
  edit_time DATE,
  data4     VARCHAR2(50)
)
;

prompt
prompt Creating table R_DOC_NO
prompt =======================
prompt
create table MES4.R_DOC_NO
(
  doc_no     VARCHAR2(15) not null,
  whs_doc_no VARCHAR2(15) not null,
  work_time  DATE not null
)
;
create index MES4.DOC_NO on MES4.R_DOC_NO (DOC_NO);
create index MES4.WHS_DOC_NO on MES4.R_DOC_NO (WHS_DOC_NO);
grant select, insert, update, delete, references, alter, index on MES4.R_DOC_NO to MES1;

prompt
prompt Creating table R_DOMI_ERROR
prompt ===========================
prompt
create table MES4.R_DOMI_ERROR
(
  p_sn          VARCHAR2(25) not null,
  test_date     DATE not null,
  p_no          VARCHAR2(20) not null,
  error_type    VARCHAR2(1) not null,
  error_data    VARCHAR2(100),
  handle_flag   VARCHAR2(1) default '0' not null,
  efox_emp_name VARCHAR2(30) not null,
  edit_time     DATE not null
)
;
grant select, insert, update, delete on MES4.R_DOMI_ERROR to MES1;

prompt
prompt Creating table R_DOMI_HISTORY
prompt =============================
prompt
create table MES4.R_DOMI_HISTORY
(
  p_sn          VARCHAR2(25) not null,
  test_date     DATE not null,
  efox_station  VARCHAR2(20) not null,
  p_no          VARCHAR2(20) not null,
  efox_emp_name VARCHAR2(30) not null,
  edit_time     DATE not null
)
;
create index MES4.R_DOMI_HISTORY_PNO on MES4.R_DOMI_HISTORY (P_NO)
  nologging;
create index MES4.R_DOMI_HISTORY_PSN on MES4.R_DOMI_HISTORY (P_SN)
  nologging;
grant select, insert, update, delete on MES4.R_DOMI_HISTORY to MES1;

prompt
prompt Creating table R_DOMI_TEMP
prompt ==========================
prompt
create table MES4.R_DOMI_TEMP
(
  p_sn          VARCHAR2(25) not null,
  test_date     DATE not null,
  efox_station  VARCHAR2(20) not null,
  p_no          VARCHAR2(20) not null,
  efox_emp_name VARCHAR2(30) not null,
  edit_time     DATE not null
)
;
grant select, insert, update, delete on MES4.R_DOMI_TEMP to MES1;

prompt
prompt Creating table R_DPPM_SUMMARY
prompt =============================
prompt
create table MES4.R_DPPM_SUMMARY
(
  work_date DATE not null,
  p_no      VARCHAR2(20) not null,
  kp_no     VARCHAR2(20) not null,
  mfr_code  VARCHAR2(15) not null,
  date_code VARCHAR2(20),
  lot_code  VARCHAR2(20),
  total_qty NUMBER(10) not null,
  fail_qty  NUMBER(10) not null,
  edit_time DATE not null
)
;
grant select, insert, update, delete on MES4.R_DPPM_SUMMARY to MES1;

prompt
prompt Creating table R_ECN_BASE
prompt =========================
prompt
create table MES4.R_ECN_BASE
(
  sheet_no            VARCHAR2(15) not null,
  create_time         DATE not null,
  plant               VARCHAR2(10),
  customer            VARCHAR2(20),
  vendor              VARCHAR2(20),
  change_desc         VARCHAR2(300),
  change_type         VARCHAR2(50),
  affected_mfg_kp_no  VARCHAR2(500),
  affected_cust_kp_no VARCHAR2(500),
  issued_time         DATE,
  effected_date       DATE,
  attac_no            VARCHAR2(15),
  prepare_email_no    VARCHAR2(15),
  prepare_emp         VARCHAR2(10) not null,
  prepare_time        DATE not null,
  approve_email_no    VARCHAR2(15),
  approve_emp         VARCHAR2(10),
  approve_time        DATE,
  ecn_status          VARCHAR2(1) default '0' not null,
  close_time          DATE,
  delete_emp          VARCHAR2(10),
  delete_time         DATE
)
;
grant select, insert, update, delete on MES4.R_ECN_BASE to MES1;

prompt
prompt Creating table R_ECN_CE_CONFIRM
prompt ===============================
prompt
create table MES4.R_ECN_CE_CONFIRM
(
  sheet_no         VARCHAR2(15) not null,
  inspect_comment  VARCHAR2(500) not null,
  run_flag         VARCHAR2(300) default '0' not null,
  prepare_email_no VARCHAR2(15),
  prepare_emp      VARCHAR2(10) not null,
  prepare_time     DATE not null,
  approve_email_no VARCHAR2(15),
  approve_emp      VARCHAR2(10),
  approve_time     DATE
)
;
grant select, insert, update, delete on MES4.R_ECN_CE_CONFIRM to MES1;

prompt
prompt Creating table R_ECN_INSPECT
prompt ============================
prompt
create table MES4.R_ECN_INSPECT
(
  sheet_no         VARCHAR2(15) not null,
  po_no            VARCHAR2(15) not null,
  inspect_time     DATE not null,
  inspect_qty      NUMBER(10) not null,
  prepare_email_no VARCHAR2(15),
  prepare_emp      VARCHAR2(10) not null,
  prepare_time     DATE not null,
  approve_email_no VARCHAR2(15),
  approve_emp      VARCHAR2(10),
  approve_time     DATE
)
;
grant select, insert, update, delete on MES4.R_ECN_INSPECT to MES1;

prompt
prompt Creating table R_ECN_PQE_CONFIRM
prompt ================================
prompt
create table MES4.R_ECN_PQE_CONFIRM
(
  sheet_no         VARCHAR2(15) not null,
  run_qty          NUMBER(5) not null,
  date_code        VARCHAR2(20),
  lot_code         VARCHAR2(20),
  failed_qty       NUMBER(5) not null,
  evaluation       VARCHAR2(100),
  run_result       VARCHAR2(1) default '0' not null,
  prepare_email_no VARCHAR2(15),
  prepare_emp      VARCHAR2(10) not null,
  prepare_time     DATE not null,
  approve_email_no VARCHAR2(15),
  approve_emp      VARCHAR2(10),
  approve_time     DATE
)
;
grant select, insert, update, delete on MES4.R_ECN_PQE_CONFIRM to MES1;

prompt
prompt Creating table R_ECN_SQE_ACTION
prompt ===============================
prompt
create table MES4.R_ECN_SQE_ACTION
(
  sheet_no         VARCHAR2(15) not null,
  action_result    VARCHAR2(1) default '0' not null,
  attac_no         VARCHAR2(15) not null,
  prepare_email_no VARCHAR2(15),
  prepare_emp      VARCHAR2(10) not null,
  prepare_time     DATE not null,
  approve_email_no VARCHAR2(15),
  approve_emp      VARCHAR2(10),
  approve_time     DATE
)
;
grant select, insert, update, delete on MES4.R_ECN_SQE_ACTION to MES1;

prompt
prompt Creating table R_FAR_BASE
prompt =========================
prompt
create table MES4.R_FAR_BASE
(
  sheet_no         VARCHAR2(15) not null,
  create_time      DATE not null,
  plant            VARCHAR2(10),
  model            VARCHAR2(20),
  customer         VARCHAR2(20),
  bu               VARCHAR2(20),
  cust_kp_no       VARCHAR2(20),
  material_code    VARCHAR2(10),
  vendor           VARCHAR2(20),
  vendor_kp_no     VARCHAR2(20),
  defect_qty       NUMBER(6),
  suspect_qty      NUMBER(10),
  failure_rate     VARCHAR2(15),
  po_no            VARCHAR2(15),
  initiator        VARCHAR2(25),
  defect_desc      VARCHAR2(200),
  attac_no         VARCHAR2(15),
  sample_qty       NUMBER(5),
  sample_send_time DATE,
  tracking_no      VARCHAR2(15),
  far_expec        VARCHAR2(500),
  email_no         VARCHAR2(15),
  prepare_emp      VARCHAR2(10) not null,
  prepare_time     DATE not null,
  far_status       VARCHAR2(1) default '0' not null,
  close_time       DATE,
  delete_emp       VARCHAR2(10),
  delete_time      DATE,
  defect_code      VARCHAR2(10),
  critical_issue   VARCHAR2(1)
)
;
grant select, insert, update, delete on MES4.R_FAR_BASE to MES1;

prompt
prompt Creating table R_FAR_CONFIRM
prompt ============================
prompt
create table MES4.R_FAR_CONFIRM
(
  sheet_no       VARCHAR2(15) not null,
  sqm_group      VARCHAR2(5) not null,
  work_flag      VARCHAR2(1) default '0' not null,
  confirm_remark VARCHAR2(500),
  email_no       VARCHAR2(15),
  confirm_emp    VARCHAR2(10) not null,
  confirm_time   DATE not null
)
;
grant select, insert, update, delete on MES4.R_FAR_CONFIRM to MES1;

prompt
prompt Creating table R_FAR_DL
prompt =======================
prompt
create table MES4.R_FAR_DL
(
  sheet_no   VARCHAR2(15) not null,
  cust_kp_no VARCHAR2(20) not null,
  date_code  VARCHAR2(20),
  lot_code   VARCHAR2(20)
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_FAR_DL to MES1;

prompt
prompt Creating table R_FAR_LOCATION
prompt =============================
prompt
create table MES4.R_FAR_LOCATION
(
  sheet_no      VARCHAR2(15) not null,
  location_code VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_FAR_LOCATION to MES1;

prompt
prompt Creating table R_FAR_RESPONSE
prompt =============================
prompt
create table MES4.R_FAR_RESPONSE
(
  sheet_no      VARCHAR2(15) not null,
  response_type VARCHAR2(1) not null,
  attac_no      VARCHAR2(15) not null,
  replied_time  DATE not null,
  attac_emp     VARCHAR2(10) not null,
  attac_time    DATE not null
)
;
grant select, insert, update, delete on MES4.R_FAR_RESPONSE to MES1;

prompt
prompt Creating table R_FB_ALARM
prompt =========================
prompt
create table MES4.R_FB_ALARM
(
  alarm_no      VARCHAR2(12) not null,
  alarm_code    VARCHAR2(6) not null,
  alarm_type    VARCHAR2(1) default '1' not null,
  alarm_cond    VARCHAR2(3) not null,
  p_no          VARCHAR2(20) not null,
  p_version     VARCHAR2(4) not null,
  alarm_time    DATE not null,
  aoi_station   VARCHAR2(10) not null,
  alarm_station VARCHAR2(10) not null,
  alarm_status  VARCHAR2(1) default '0' not null,
  alarm_message VARCHAR2(200) not null,
  remove_emp    VARCHAR2(10),
  remove_time   DATE
)
;
grant select, insert, update, delete on MES4.R_FB_ALARM to MES1;

prompt
prompt Creating table R_FB_ALARM_CAR
prompt =============================
prompt
create table MES4.R_FB_ALARM_CAR
(
  alarm_no    VARCHAR2(10) not null,
  handle_desc VARCHAR2(100),
  handle_emp  VARCHAR2(10),
  handle_time DATE
)
;
grant select, insert, update, delete on MES4.R_FB_ALARM_CAR to MES1;

prompt
prompt Creating table R_FB_ALARM_DEFECT
prompt ================================
prompt
create table MES4.R_FB_ALARM_DEFECT
(
  alarm_no  VARCHAR2(10) not null,
  file_name VARCHAR2(30) not null,
  defect_no NUMBER(6) not null
)
;
grant select, insert, update, delete on MES4.R_FB_ALARM_DEFECT to MES1;

prompt
prompt Creating table R_FB_DEFECT
prompt ==========================
prompt
create table MES4.R_FB_DEFECT
(
  file_name      VARCHAR2(50) not null,
  inspect_time   DATE not null,
  station_name   VARCHAR2(10) not null,
  defect_no      NUMBER(6) not null,
  p_no           VARCHAR2(30) not null,
  p_version      VARCHAR2(4) not null,
  process_flag   VARCHAR2(1) not null,
  comp_name      VARCHAR2(15) not null,
  comp_type      VARCHAR2(20) not null,
  defect_name    VARCHAR2(50) not null,
  reinspect_time DATE default sysdate
)
;
grant select, insert, update, delete on MES4.R_FB_DEFECT to MES1;

prompt
prompt Creating table R_FB_INSPECT
prompt ===========================
prompt
create table MES4.R_FB_INSPECT
(
  file_name       VARCHAR2(50) not null,
  station_name    VARCHAR2(10) not null,
  inspect_time    DATE not null,
  multiboard_no   VARCHAR2(2) not null,
  program_name    VARCHAR2(30) not null,
  p_sn            VARCHAR2(30) not null,
  work_flag       VARCHAR2(1) default '0' not null,
  comp_qty        NUMBER(6) not null,
  defect_qty      NUMBER(6) not null,
  collection_time DATE not null,
  alarm_flag      VARCHAR2(1) default '0' not null,
  file_type       VARCHAR2(10) default 'AOI' not null,
  process_flag    VARCHAR2(3) default 'N/A'
)
;
comment on column MES4.R_FB_INSPECT.process_flag
  is '1';
create index MES4.R_FB_INSPECT_FILE_NAME on MES4.R_FB_INSPECT (FILE_NAME);
create index MES4.R_FB_INSPECT_INSPECTTIME on MES4.R_FB_INSPECT (INSPECT_TIME);
create index MES4.R_FB_INSPECT_REPORT on MES4.R_FB_INSPECT (FILE_TYPE, PROGRAM_NAME, STATION_NAME, P_SN);
grant select, insert, update, delete, alter on MES4.R_FB_INSPECT to MES1;

prompt
prompt Creating table R_FB_SN_LINK
prompt ===========================
prompt
create table MES4.R_FB_SN_LINK
(
  group_type VARCHAR2(5),
  group_id   VARCHAR2(50),
  sn         VARCHAR2(50),
  link_qty   NUMBER,
  edit_emp   VARCHAR2(10) not null,
  edit_time  DATE not null
)
;
create index MES4.R_FB_SN_LINK_IDX1 on MES4.R_FB_SN_LINK (GROUP_ID)
  nologging;
create index MES4.R_FB_SN_LINK_IDX2 on MES4.R_FB_SN_LINK (SN)
  nologging;
grant select, insert, update, delete on MES4.R_FB_SN_LINK to MES1;

prompt
prompt Creating table R_FB_STOP_CAR
prompt ============================
prompt
create table MES4.R_FB_STOP_CAR
(
  alarm_no          VARCHAR2(10) not null,
  notice_no         VARCHAR2(25) not null,
  issue_date        DATE not null,
  shift             VARCHAR2(10),
  cust_code         VARCHAR2(15) not null,
  line_name         VARCHAR2(8) not null,
  initiator         VARCHAR2(25) not null,
  stop_reason       VARCHAR2(500) not null,
  handle_desc       VARCHAR2(500),
  handle_emp        VARCHAR2(10),
  handle_time       DATE,
  work_flag         VARCHAR2(1) default '0',
  temp_strategy     VARCHAR2(500),
  affected_lot      VARCHAR2(100),
  duty_confirm      VARCHAR2(10),
  duty_confirm_time DATE,
  smt_confirm       VARCHAR2(10),
  smt_confirm_time  DATE,
  qc_confirm        VARCHAR2(10),
  qc_confirm_time   DATE,
  send_flag         VARCHAR2(1) default '0' not null
)
;
grant select, insert, update, delete on MES4.R_FB_STOP_CAR to MES1;

prompt
prompt Creating table R_FEEDER_CHECK_DETAIL
prompt ====================================
prompt
create table MES4.R_FEEDER_CHECK_DETAIL
(
  feeder_no    VARCHAR2(30) not null,
  feeder_sn    VARCHAR2(30) not null,
  check_date   VARCHAR2(14) not null,
  x_cpk        VARCHAR2(14) not null,
  y_cpk        VARCHAR2(14) not null,
  check_result VARCHAR2(10) not null,
  edit_time    DATE,
  edit_emp     VARCHAR2(30),
  feeder_level VARCHAR2(10)
)
;
create index MES4.IDX_FEEDER_CHECK_DETAIL1 on MES4.R_FEEDER_CHECK_DETAIL (FEEDER_NO)
  nologging;
create index MES4.IDX_FEEDER_CHECK_DETAIL2 on MES4.R_FEEDER_CHECK_DETAIL (EDIT_TIME)
  nologging;
grant select, insert, update, delete, alter on MES4.R_FEEDER_CHECK_DETAIL to MES1;

prompt
prompt Creating table R_FEEDER_DETAIL
prompt ==============================
prompt
create table MES4.R_FEEDER_DETAIL
(
  feeder_no     VARCHAR2(20) not null,
  feeder_sn     VARCHAR2(20) not null,
  feeder_type   VARCHAR2(40) not null,
  feederno_rule VARCHAR2(10) not null,
  work_flag     VARCHAR2(1) not null,
  use_times     NUMBER(10) not null,
  mfr_emp       VARCHAR2(10),
  work_time     DATE default SYSDATE not null,
  emp_no        VARCHAR2(10) not null
)
;
create index MES4.R_FEEDER_DETAILFEEDER_NO on MES4.R_FEEDER_DETAIL (FEEDER_NO);
create index MES4.R_FEEDER_DETAIL_WF on MES4.R_FEEDER_DETAIL (WORK_FLAG);
grant select, insert, update, delete, references, alter, index on MES4.R_FEEDER_DETAIL to MES1;

prompt
prompt Creating table R_FEEDER_LB_REPLACE
prompt ==================================
prompt
create table MES4.R_FEEDER_LB_REPLACE
(
  feederno_code VARCHAR2(15) not null,
  feeder_sn     VARCHAR2(15) not null,
  feeder_no     VARCHAR2(15),
  feeder_type   VARCHAR2(40) not null,
  feederno_rule VARCHAR2(10) not null,
  status        VARCHAR2(1) not null,
  work_time     DATE default SYSDATE not null,
  emp_no        VARCHAR2(10) not null
)
;
create index MES4.R_FEEDER_LB_REPLACEFEEDER_NO on MES4.R_FEEDER_LB_REPLACE (FEEDER_NO)
  nologging;
create index MES4.R_FEEDER_LB_REPLACE_CODE on MES4.R_FEEDER_LB_REPLACE (FEEDERNO_CODE)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.R_FEEDER_LB_REPLACE to MES1;

prompt
prompt Creating table R_FEEDER_REPAIR
prompt ==============================
prompt
create table MES4.R_FEEDER_REPAIR
(
  feeder_no     VARCHAR2(15) not null,
  work_flag     VARCHAR2(1) not null,
  repair_status VARCHAR2(1) not null,
  error_desc    VARCHAR2(120) not null,
  adjust_reason VARCHAR2(150),
  repair_remark VARCHAR2(120),
  work_time     DATE not null,
  start_time    DATE,
  end_time      DATE,
  emp_no        VARCHAR2(10) not null
)
;
create index MES4.R_FEEDER_REPAIRFEEDER_NO on MES4.R_FEEDER_REPAIR (FEEDER_NO)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.R_FEEDER_REPAIR to MES1;

prompt
prompt Creating table R_FEEDER_REPAIR_LOCK
prompt ===================================
prompt
create table MES4.R_FEEDER_REPAIR_LOCK
(
  feeder_no      VARCHAR2(20) not null,
  line_emp       VARCHAR2(10),
  me_emp         VARCHAR2(10),
  err_desc       VARCHAR2(200),
  last_station   VARCHAR2(10),
  priority_level VARCHAR2(20),
  lock_time      DATE,
  acc_emp        VARCHAR2(10),
  sender_emp     VARCHAR2(10),
  acc_time       DATE,
  rej_emp        VARCHAR2(10),
  action_mode    VARCHAR2(10),
  rej_reason     VARCHAR2(200),
  rej_time       DATE,
  repair_emp     VARCHAR2(10),
  repair_reason  VARCHAR2(500),
  repair_time    DATE,
  confirm_emp    VARCHAR2(10),
  confirm_result VARCHAR2(10),
  confirm_remark VARCHAR2(200),
  confirm_time   DATE,
  status         VARCHAR2(20)
)
;
create index MES4.IDX_R_FEEDER_REPAIR_LOCK on MES4.R_FEEDER_REPAIR_LOCK (FEEDER_NO)
  nologging;
grant select, insert, update, delete on MES4.R_FEEDER_REPAIR_LOCK to MES1;

prompt
prompt Creating table R_FIXTURE_DEFECT
prompt ===============================
prompt
create table MES4.R_FIXTURE_DEFECT
(
  fixture_sn    VARCHAR2(25) not null,
  duty_area     VARCHAR2(15) default 0 not null,
  duty_location VARCHAR2(15) not null,
  duty_emp      VARCHAR2(10) not null,
  defect_flag   VARCHAR2(1) default 0 not null,
  record_time   DATE not null,
  record_emp    VARCHAR2(10) not null,
  defect_code   VARCHAR2(15),
  handle_desc   VARCHAR2(150),
  defect_remark VARCHAR2(150),
  handle_status VARCHAR2(1) default 0 not null,
  start_time    DATE,
  end_time      DATE,
  pe_emp        VARCHAR2(10),
  alarm_flag    VARCHAR2(1) default 0
)
;
grant select, insert, update, delete on MES4.R_FIXTURE_DEFECT to MES1;

prompt
prompt Creating table R_FIXTURE_DETAIL
prompt ===============================
prompt
create table MES4.R_FIXTURE_DETAIL
(
  fixture_sn        VARCHAR2(50) not null,
  line_name         VARCHAR2(20) not null,
  station_name      VARCHAR2(50) not null,
  wo                VARCHAR2(12),
  use_flag          VARCHAR2(30),
  start_emp         VARCHAR2(10),
  start_time        DATE,
  end_emp           VARCHAR2(10),
  end_time          DATE,
  check_outqty      VARCHAR2(4),
  return_qty        VARCHAR2(4),
  return_line       VARCHAR2(16),
  fixture_type_code VARCHAR2(50),
  fixture_type      VARCHAR2(50)
)
;
grant select, insert, update, delete on MES4.R_FIXTURE_DETAIL to MES1;

prompt
prompt Creating table R_FIXTURE_HANDLE
prompt ===============================
prompt
create table MES4.R_FIXTURE_HANDLE
(
  fixture_sn    VARCHAR2(25) not null,
  location      VARCHAR2(15) default 0,
  use_times     NUMBER(8),
  handle_code   VARCHAR2(15) not null,
  remark        VARCHAR2(300),
  shift         VARCHAR2(1) default 0,
  start_time    DATE,
  start_emp     VARCHAR2(10),
  status        VARCHAR2(2) not null,
  end_emp       VARCHAR2(15),
  end_time      DATE,
  old_work_flag VARCHAR2(20),
  send_remark   VARCHAR2(500)
)
;
grant select, insert, update, delete, alter on MES4.R_FIXTURE_HANDLE to MES1;

prompt
prompt Creating table R_FIXTURE_HOLD
prompt =============================
prompt
create table MES4.R_FIXTURE_HOLD
(
  fixture_sn  VARCHAR2(50) not null,
  location    VARCHAR2(30) not null,
  error_desc  VARCHAR2(1000) not null,
  unlock_desc VARCHAR2(1000),
  lock_emp    VARCHAR2(20) not null,
  unlock_emp  VARCHAR2(20),
  lock_time   DATE,
  unlock_time DATE,
  lock_type   VARCHAR2(15) not null
)
;
grant select, insert, update, delete on MES4.R_FIXTURE_HOLD to MES1;

prompt
prompt Creating table R_FIXTURE_MAINTAIN
prompt =================================
prompt
create table MES4.R_FIXTURE_MAINTAIN
(
  skuno      VARCHAR2(30),
  line       VARCHAR2(20),
  station    VARCHAR2(20),
  error_desc VARCHAR2(800),
  root_cause VARCHAR2(800),
  action     VARCHAR2(800),
  result     VARCHAR2(10),
  engineer   VARCHAR2(20),
  cuser      VARCHAR2(20),
  cdate      DATE,
  uuser      VARCHAR2(20),
  udate      DATE,
  memo       VARCHAR2(200),
  code       VARCHAR2(20),
  title      VARCHAR2(200)
)
;
create index MES4.R_FIXTURE_MAINTAIN_CODE on MES4.R_FIXTURE_MAINTAIN (CODE);
create index MES4.R_FIXTURE_MAINTAIN_TITLE on MES4.R_FIXTURE_MAINTAIN (TITLE);
grant select, insert, update, delete, references, alter, index on MES4.R_FIXTURE_MAINTAIN to MES1;

prompt
prompt Creating table R_FIXTURE_OUTPUT
prompt ===============================
prompt
create table MES4.R_FIXTURE_OUTPUT
(
  skuno        VARCHAR2(50),
  workorderno  VARCHAR2(50),
  line         VARCHAR2(50),
  station      VARCHAR2(50),
  machinemodel VARCHAR2(50),
  needqty      NUMBER,
  currentqty   NUMBER,
  marginqty    NUMBER,
  cdate        DATE
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_FIXTURE_OUTPUT to MES1;

prompt
prompt Creating table R_FIXTURE_PRODUCTS
prompt =================================
prompt
create table MES4.R_FIXTURE_PRODUCTS
(
  name        VARCHAR2(50),
  provider    VARCHAR2(50),
  model       VARCHAR2(50),
  sn          VARCHAR2(50),
  pn          VARCHAR2(50),
  line        VARCHAR2(50),
  count       NUMBER default 1,
  status      NUMBER default '0',
  remark      VARCHAR2(100),
  cuser       VARCHAR2(20),
  cdate       DATE,
  uuser       VARCHAR2(20),
  udate       DATE,
  depositary  VARCHAR2(30),
  group_name  VARCHAR2(15),
  skuno       VARCHAR2(50),
  workorderno VARCHAR2(50),
  station     VARCHAR2(50),
  times       NUMBER default 0,
  utimes      NUMBER default 0,
  count_time  DATE default sysdate,
  parts_type  VARCHAR2(50),
  vender      VARCHAR2(50),
  parts_spec  VARCHAR2(50)
)
;
create index MES4.R_FIXTURE_PRODUCTS_MODEL on MES4.R_FIXTURE_PRODUCTS (MODEL);
create index MES4.R_FIXTURE_PRODUCTS_NAME on MES4.R_FIXTURE_PRODUCTS (NAME);
grant select, insert, update, delete, references, alter, index on MES4.R_FIXTURE_PRODUCTS to MES1;

prompt
prompt Creating table R_FIXTURE_SCAN_DETAIL
prompt ====================================
prompt
create table MES4.R_FIXTURE_SCAN_DETAIL
(
  fixture_type        VARCHAR2(20) not null,
  fixture_sn          VARCHAR2(50) not null,
  p_no                VARCHAR2(20),
  wo                  VARCHAR2(12),
  out_line            VARCHAR2(16),
  out_name            VARCHAR2(16),
  out_time            DATE,
  online_name         VARCHAR2(16),
  online_time         DATE,
  offline_name        VARCHAR2(16),
  offline_time        DATE,
  return_line         VARCHAR2(16),
  return_name         VARCHAR2(16),
  return_time         DATE,
  keep_send_name      VARCHAR2(16),
  keep_start_name     VARCHAR2(16),
  keep_start_time     DATE,
  keep_end_name       VARCHAR2(16),
  keep_endtime        DATE,
  keep_remark         VARCHAR2(4000),
  stockin_send_name   VARCHAR2(16),
  stockin_name        VARCHAR2(16),
  stockin_time        DATE,
  data1               VARCHAR2(100),
  data2               VARCHAR2(200),
  data3               VARCHAR2(300),
  data4               VARCHAR2(300),
  data5               VARCHAR2(300),
  out_sation          VARCHAR2(50),
  out_qty             VARCHAR2(4),
  out_receive_name    VARCHAR2(16),
  return_receive_name VARCHAR2(16),
  return_over_remark  VARCHAR2(500),
  keep_voer_remark    VARCHAR2(500),
  repair_over_remark  VARCHAR2(500),
  stockin_over_remark VARCHAR2(500)
)
;
create index MES4.IDX_R_FIXTURE_SCAN_DETAIL on MES4.R_FIXTURE_SCAN_DETAIL (FIXTURE_SN, FIXTURE_TYPE)
  nologging;
grant select, insert, update, delete on MES4.R_FIXTURE_SCAN_DETAIL to MES1;

prompt
prompt Creating table R_FIXTURE_SN
prompt ===========================
prompt
create table MES4.R_FIXTURE_SN
(
  fixture_sn        VARCHAR2(25) not null,
  mfr_sn            VARCHAR2(50) not null,
  fixture_rohs      VARCHAR2(10),
  p_no              VARCHAR2(20),
  wo                VARCHAR2(15),
  vendor_code       VARCHAR2(5),
  fixture_type_code VARCHAR2(25) not null,
  location_flag     VARCHAR2(2) not null,
  work_flag         VARCHAR2(2) not null,
  station_name      VARCHAR2(50),
  loan_emp          VARCHAR2(25) not null,
  total_used_times  VARCHAR2(8) default 0 not null,
  deliver_emp       VARCHAR2(10) not null,
  start_use_time    DATE,
  receive_emp       VARCHAR2(10) not null,
  end_use_time      DATE
)
;
grant select, insert, update, delete on MES4.R_FIXTURE_SN to MES1;

prompt
prompt Creating table R_FIXTURE_WASH
prompt =============================
prompt
create table MES4.R_FIXTURE_WASH
(
  fixture_sn   VARCHAR2(25) not null,
  line_name    VARCHAR2(8),
  station_name VARCHAR2(50),
  send_emp     VARCHAR2(10) not null,
  start_time   DATE not null,
  end_time     DATE,
  shift        VARCHAR2(2),
  wash_emp     VARCHAR2(10) not null
)
;
grant select, insert, update, delete on MES4.R_FIXTURE_WASH to MES1;

prompt
prompt Creating table R_FIXTURE_WHS
prompt ============================
prompt
create table MES4.R_FIXTURE_WHS
(
  fixture_sn      VARCHAR2(25) not null,
  total_use_times NUMBER(8) not null,
  line_name       VARCHAR2(8) not null,
  wo              VARCHAR2(12) not null,
  loan_emp        VARCHAR2(10) not null,
  loan_time       DATE not null,
  delieve_emp     VARCHAR2(10) not null,
  return_emp      VARCHAR2(10),
  return_time     DATE,
  receive_emp     VARCHAR2(10),
  station_name    VARCHAR2(50)
)
;
grant select, insert, update, delete, alter on MES4.R_FIXTURE_WHS to MES1;

prompt
prompt Creating table R_FIXTURE_WIP
prompt ============================
prompt
create table MES4.R_FIXTURE_WIP
(
  fixture_sn        VARCHAR2(25),
  line_name         VARCHAR2(8),
  station_name      VARCHAR2(50),
  wo                VARCHAR2(12),
  work_flag         VARCHAR2(1),
  start_emp         VARCHAR2(10),
  start_time        DATE,
  check_outqty      VARCHAR2(4),
  fixture_type_code VARCHAR2(50),
  fixture_type      VARCHAR2(50)
)
;
grant select, insert, update, delete on MES4.R_FIXTURE_WIP to MES1;

prompt
prompt Creating table R_GAUGE_ACCEPT_DATA
prompt ==================================
prompt
create table MES4.R_GAUGE_ACCEPT_DATA
(
  mfr_sn        VARCHAR2(25) not null,
  item_code     VARCHAR2(5) not null,
  part_location VARCHAR2(15) not null,
  size_code     VARCHAR2(5) not null,
  size_result   NUMBER(7,3) not null,
  result_flag   VARCHAR2(1) default '0' not null,
  remark        VARCHAR2(60),
  edit_emp      VARCHAR2(25) not null,
  edit_time     DATE not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_GAUGE_ACCEPT_DATA to MES1;

prompt
prompt Creating table R_GAUGE_DEFECT
prompt =============================
prompt
create table MES4.R_GAUGE_DEFECT
(
  sn              VARCHAR2(25) not null,
  duty_area       VARCHAR2(15) default '0' not null,
  duty_location   VARCHAR2(15) not null,
  duty_emp        VARCHAR2(10) not null,
  total_use_times NUMBER(8) default 0 not null,
  alert_times     NUMBER(8) not null,
  defect_flag     VARCHAR2(1) default '0' not null,
  record_time     DATE not null,
  record_emp      VARCHAR2(10) not null,
  defect_code     VARCHAR2(15),
  handle_desc     VARCHAR2(150),
  defect_remark   VARCHAR2(150),
  handle_status   VARCHAR2(1) default '0' not null,
  start_time      DATE,
  end_time        DATE,
  pe_emp          VARCHAR2(10),
  alarm_flag      VARCHAR2(1) default '0' not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_GAUGE_DEFECT to MES1;

prompt
prompt Creating table R_GAUGE_DETAIL
prompt =============================
prompt
create table MES4.R_GAUGE_DETAIL
(
  sn             VARCHAR2(25) not null,
  move_from      VARCHAR2(20) not null,
  move_to        VARCHAR2(20) not null,
  move_type      VARCHAR2(10) not null,
  move_time      DATE default SYSDATE not null,
  edit_emp       VARCHAR2(30) not null,
  p_no           VARCHAR2(30),
  p_version      VARCHAR2(30),
  remark         VARCHAR2(50),
  other_side_emp VARCHAR2(30)
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_GAUGE_DETAIL to MES1;

prompt
prompt Creating table R_GAUGE_DETAIL_BAK
prompt =================================
prompt
create table MES4.R_GAUGE_DETAIL_BAK
(
  sn           VARCHAR2(25) not null,
  line_name    VARCHAR2(8) not null,
  station_name VARCHAR2(8) not null,
  wo           VARCHAR2(12) not null,
  use_times    NUMBER(8) default 0 not null,
  start_time   DATE not null,
  start_emp    VARCHAR2(10) not null,
  end_time     DATE not null,
  end_emp      VARCHAR2(10) not null
)
;

prompt
prompt Creating table R_GAUGE_DEVICE_DEFECT
prompt ====================================
prompt
create table MES4.R_GAUGE_DEVICE_DEFECT
(
  sn               VARCHAR2(25) not null,
  location         VARCHAR2(50),
  duty_area        VARCHAR2(50),
  repair_part      VARCHAR2(50),
  partno           VARCHAR2(50),
  start_time       DATE,
  end_time         DATE,
  crash_time       NUMBER(10),
  duty_emp         VARCHAR2(20),
  defect_remark    VARCHAR2(150),
  defect_analysis  VARCHAR2(150),
  temp_disposal    VARCHAR2(150),
  long_disposal    VARCHAR2(150),
  dowith_edit_time DATE,
  dowith_edit_emp  VARCHAR2(20),
  remark           VARCHAR2(150),
  start_edit_time  DATE,
  start_edit_emp   VARCHAR2(20),
  end_edit_time    DATE,
  end_edit_emp     VARCHAR2(20),
  dowith_time      DATE
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_GAUGE_DEVICE_DEFECT to MES1;

prompt
prompt Creating table R_GAUGE_WASH
prompt ===========================
prompt
create table MES4.R_GAUGE_WASH
(
  sn           VARCHAR2(25) not null,
  line_name    VARCHAR2(50),
  station_name VARCHAR2(8),
  send_emp     VARCHAR2(10) not null,
  start_time   DATE not null,
  end_time     DATE,
  shift        VARCHAR2(1) default '0' not null,
  wash_emp     VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_GAUGE_WASH to MES1;

prompt
prompt Creating table R_GAUGE_WHS
prompt ==========================
prompt
create table MES4.R_GAUGE_WHS
(
  gauge_type        VARCHAR2(30),
  sn                VARCHAR2(30) not null,
  p_no              VARCHAR2(30),
  p_version         VARCHAR2(30),
  wo                VARCHAR2(12),
  work_flag         VARCHAR2(2) default '0',
  line_name         VARCHAR2(50) not null,
  station_name      VARCHAR2(20) not null,
  check_out_emp     VARCHAR2(30),
  check_out_time    DATE,
  edit_emp          VARCHAR2(30),
  edit_time         DATE,
  last_use_times    NUMBER(8) not null,
  current_use_times NUMBER(8) default 0,
  remark            VARCHAR2(50)
)
;
comment on column MES4.R_GAUGE_WHS.work_flag
  is '0未上線,1是上線';
grant select, insert, update, delete, references, alter, index on MES4.R_GAUGE_WHS to MES1;

prompt
prompt Creating table R_GAUGE_WIP
prompt ==========================
prompt
create table MES4.R_GAUGE_WIP
(
  gauge_type   VARCHAR2(10) not null,
  sn           VARCHAR2(30) not null,
  p_no         VARCHAR2(30),
  p_version    VARCHAR2(10),
  line_name    VARCHAR2(50) not null,
  station_name VARCHAR2(20) not null,
  wo           VARCHAR2(12),
  use_times    NUMBER(8) default 0 not null,
  edit_emp     VARCHAR2(10) not null,
  edit_time    DATE default SYSDATE not null,
  process      VARCHAR2(20)
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_GAUGE_WIP to MES1;

prompt
prompt Creating table R_GRN
prompt ====================
prompt
create table MES4.R_GRN
(
  doc_no           VARCHAR2(20) not null,
  cust_kp_no       VARCHAR2(20) not null,
  po_no            VARCHAR2(20) not null,
  po_item          VARCHAR2(10) not null,
  deliver_note     VARCHAR2(25),
  plant            VARCHAR2(4) not null,
  vendor_code      VARCHAR2(20) not null,
  mfr_code         VARCHAR2(25) not null,
  mfr_kp_no        VARCHAR2(100) not null,
  receive_qty      NUMBER(10) not null,
  download_time    DATE not null,
  account          VARCHAR2(20) not null,
  floor            VARCHAR2(20),
  stock            VARCHAR2(6),
  receive_time     DATE,
  whs_emp          VARCHAR2(20),
  receive_status   VARCHAR2(4),
  whs_remark       VARCHAR2(200),
  stockin_qty      NUMBER(10),
  iqc_emp          VARCHAR2(20),
  iqc_status       VARCHAR2(4),
  iqc_remark       VARCHAR2(500),
  iqc_qty          NUMBER(10),
  iqc_time         DATE,
  whs_keeper       VARCHAR2(20),
  stockin_time     DATE,
  whs_admin        VARCHAR2(20),
  grn_status       VARCHAR2(4),
  buyer_remark     VARCHAR2(80),
  buyer            VARCHAR2(10),
  buyer_time       DATE,
  grn_flag         VARCHAR2(2) default 0 not null,
  grn_event        VARCHAR2(20) default 'WHS_RECEIVE' not null,
  iv_number        VARCHAR2(20),
  gt_flag          VARCHAR2(1) default '0' not null,
  check_iqc_status VARCHAR2(4),
  check_iqc_remark VARCHAR2(200),
  check_iqc_time   DATE,
  check_iqc_emp    VARCHAR2(20),
  unit             VARCHAR2(10)
)
;
create index MES4.IX_R_GRN_CUST_KP_NO on MES4.R_GRN (CUST_KP_NO);
create index MES4.R_GRN_DOWNLOAD_TIME on MES4.R_GRN (DOWNLOAD_TIME);
alter table MES4.R_GRN
  add constraint UX_R_GRN_DOC_NO primary key (DOC_NO);
grant select, insert, update on MES4.R_GRN to MES1;

prompt
prompt Creating table R_GRN_DF
prompt =======================
prompt
create table MES4.R_GRN_DF
(
  doc_no         VARCHAR2(12) not null,
  cust_kp_no     VARCHAR2(20) not null,
  po_no          VARCHAR2(12) not null,
  po_item        VARCHAR2(10) not null,
  deliver_note   VARCHAR2(25),
  plant          VARCHAR2(4) not null,
  vendor_code    VARCHAR2(20) not null,
  mfr_code       VARCHAR2(25) not null,
  mfr_kp_no      VARCHAR2(100) not null,
  receive_qty    NUMBER(10) not null,
  download_time  DATE not null,
  account        VARCHAR2(20) not null,
  floor          VARCHAR2(20),
  stock          VARCHAR2(6),
  receive_time   DATE,
  whs_emp        VARCHAR2(10),
  receive_status VARCHAR2(4),
  whs_remark     VARCHAR2(80),
  stockin_qty    NUMBER(10),
  iqc_emp        VARCHAR2(10),
  iqc_status     VARCHAR2(4),
  iqc_remark     VARCHAR2(200),
  iqc_qty        NUMBER(10),
  iqc_time       DATE,
  whs_keeper     VARCHAR2(10),
  stockin_time   DATE,
  whs_admin      VARCHAR2(10),
  grn_status     VARCHAR2(4),
  buyer_remark   VARCHAR2(80),
  buyer          VARCHAR2(10),
  buyer_time     DATE,
  grn_flag       VARCHAR2(2) default 0 not null,
  grn_event      VARCHAR2(20) default 'WHS_RECEIVE' not null,
  iv_number      VARCHAR2(20),
  gt_flag        VARCHAR2(1) default '0' not null
)
;

prompt
prompt Creating table R_GRN_DF_CENTER
prompt ==============================
prompt
create table MES4.R_GRN_DF_CENTER
(
  doc_no        VARCHAR2(12) not null,
  cust_kp_no    VARCHAR2(20) not null,
  deliver_note  VARCHAR2(25),
  download_time DATE not null,
  accept_flag   VARCHAR2(10) not null,
  accept_data   VARCHAR2(25),
  plant         VARCHAR2(4) not null,
  cust_kp_desc  VARCHAR2(80),
  po_no         VARCHAR2(12) not null,
  po_item       VARCHAR2(10) not null,
  vendor_code   VARCHAR2(20) not null,
  vender_name   VARCHAR2(80),
  mfr_kp_no     VARCHAR2(100),
  receive_qty   NUMBER(10) not null,
  iqc_qty       NUMBER(10) not null,
  stockin_qty   NUMBER(10) not null,
  stock         VARCHAR2(6),
  iqc_emp       VARCHAR2(20),
  whs_emp       VARCHAR2(20),
  iqc_remark    VARCHAR2(200),
  floor         VARCHAR2(20),
  sign_name     VARCHAR2(20),
  df_flag       VARCHAR2(2) default 0 not null,
  whs_keeper    VARCHAR2(20),
  remark        VARCHAR2(200)
)
;
create unique index MES4.IDX_R_DF_DOCNO on MES4.R_GRN_DF_CENTER (DOC_NO)
  nologging;

prompt
prompt Creating table R_GRN_LOG
prompt ========================
prompt
create table MES4.R_GRN_LOG
(
  grn       VARCHAR2(20),
  data1     VARCHAR2(10),
  data2     VARCHAR2(10),
  data3     VARCHAR2(10),
  edit_time DATE,
  data4     VARCHAR2(10)
)
;

prompt
prompt Creating table R_GRN_MRB_TEMP
prompt =============================
prompt
create table MES4.R_GRN_MRB_TEMP
(
  doc_no    VARCHAR2(20),
  stock     VARCHAR2(10),
  plant     VARCHAR2(10),
  kp_no     VARCHAR2(30),
  move_type VARCHAR2(10),
  move_flag VARCHAR2(5),
  qty       NUMBER,
  edit_time DATE default SYSDATE
)
;
create index MES4.IDX_R_GRN_MRB_TEMP_1 on MES4.R_GRN_MRB_TEMP (DOC_NO, PLANT, STOCK)
  nologging;
grant select, insert, update, delete on MES4.R_GRN_MRB_TEMP to MES1;

prompt
prompt Creating table R_GRN_SIGN
prompt =========================
prompt
create table MES4.R_GRN_SIGN
(
  file_id       VARCHAR2(100),
  grn           VARCHAR2(20) not null,
  sign_name     VARCHAR2(10),
  get_file_time DATE,
  sign_time     DATE,
  manage_name   VARCHAR2(10),
  new_file_id   VARCHAR2(50),
  doc_type      VARCHAR2(50),
  new_file_flow VARCHAR2(50),
  plant         VARCHAR2(10),
  floor         VARCHAR2(10),
  cust_kp_no    VARCHAR2(20),
  vendor_code   VARCHAR2(20)
)
;
alter table MES4.R_GRN_SIGN
  add constraint UX_R_GRN_SIGN_GRN primary key (GRN);
grant select, insert, update, delete on MES4.R_GRN_SIGN to MES1;

prompt
prompt Creating table R_GRN_SIGN_MAPPING
prompt =================================
prompt
create table MES4.R_GRN_SIGN_MAPPING
(
  logonname VARCHAR2(20) not null,
  username  VARCHAR2(20) not null,
  pl        VARCHAR2(20) not null,
  plant     VARCHAR2(50)
)
;

prompt
prompt Creating table R_GRN_SIGN_TEMP
prompt ==============================
prompt
create table MES4.R_GRN_SIGN_TEMP
(
  file_id       VARCHAR2(100),
  grn           VARCHAR2(20) not null,
  sign_name     VARCHAR2(10),
  get_file_time DATE,
  sign_time     DATE,
  manage_name   VARCHAR2(10),
  new_file_id   VARCHAR2(50),
  doc_type      VARCHAR2(50),
  new_file_flow VARCHAR2(50),
  plant         VARCHAR2(10),
  floor         VARCHAR2(10),
  cust_kp_no    VARCHAR2(20),
  vendor_code   VARCHAR2(20)
)
;
grant select, insert, update, delete on MES4.R_GRN_SIGN_TEMP to MES1;

prompt
prompt Creating table R_GT_DATA
prompt ========================
prompt
create table MES4.R_GT_DATA
(
  doc_no        VARCHAR2(15) not null,
  move_type     VARCHAR2(10) not null,
  grn_no        VARCHAR2(15),
  plant         VARCHAR2(10) not null,
  cust_kp_no    VARCHAR2(30) not null,
  cust_kp_des   VARCHAR2(100),
  qty           NUMBER not null,
  unit          VARCHAR2(10) not null,
  from_sloc     VARCHAR2(10),
  to_sloc       VARCHAR2(10),
  cost_center   VARCHAR2(20),
  gl_account    VARCHAR2(20),
  crate_time    VARCHAR2(20),
  download_time DATE,
  send_flag     VARCHAR2(2) default 'N' not null
)
;

prompt
prompt Creating table R_GW26_ALARM
prompt ===========================
prompt
create table MES4.R_GW26_ALARM
(
  gw26_id      VARCHAR2(10) not null,
  station_no   VARCHAR2(10) not null,
  alarm_flag   VARCHAR2(1) default '0' not null,
  alarm_reason VARCHAR2(1)
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_GW26_ALARM to MES1;

prompt
prompt Creating table R_HOLD_SETUP
prompt ===========================
prompt
create table MES4.R_HOLD_SETUP
(
  cust_kp_no     VARCHAR2(20) not null,
  mfr_kp_no      VARCHAR2(100),
  mfr_no         VARCHAR2(50),
  date_code      VARCHAR2(300),
  lot_code       VARCHAR2(300),
  qty            NUMBER(10) not null,
  ext_qty        NUMBER(10) not null,
  sn_qty         NUMBER(10) not null,
  work_flag      VARCHAR2(1) not null,
  start_time     DATE not null,
  end_time       DATE,
  hold_emp_no    VARCHAR2(10) not null,
  open_emp_no    VARCHAR2(10),
  hold_no        VARCHAR2(15),
  hold_remark    VARCHAR2(100),
  open_remark    VARCHAR2(100),
  date_code2     VARCHAR2(20) default 'NULL',
  snumber        VARCHAR2(20),
  send_flag      VARCHAR2(5),
  hold_reason    VARCHAR2(300),
  unhold_reason  VARCHAR2(200),
  unpurge_number VARCHAR2(100),
  unpurge_emp    VARCHAR2(20),
  unpurge_time   DATE
)
;
create index MES4.R_HOLD_SETUPCUST_KP_NO on MES4.R_HOLD_SETUP (CUST_KP_NO)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.R_HOLD_SETUP to MES1;

prompt
prompt Creating table R_ICBODY_TEST
prompt ============================
prompt
create table MES4.R_ICBODY_TEST
(
  tr_sn       VARCHAR2(30) not null,
  cust_kp_no  VARCHAR2(120),
  result      VARCHAR2(50),
  test_result VARCHAR2(8),
  create_time DATE default SYSDATE,
  emp_no      VARCHAR2(10),
  data1       VARCHAR2(255),
  data2       VARCHAR2(255),
  data3       VARCHAR2(255)
)
;
create index MES4.R_ICBODY_TEST_INDEX on MES4.R_ICBODY_TEST (TR_SN)
  nologging;
grant select, insert, update, delete, references on MES4.R_ICBODY_TEST to MES1;

prompt
prompt Creating table R_IC_CONTROL
prompt ===========================
prompt
create table MES4.R_IC_CONTROL
(
  taskno           VARCHAR2(20) not null,
  pcba_no          VARCHAR2(20) not null,
  ic_no            VARCHAR2(20) not null,
  request_qty      NUMBER(7),
  work_flag        VARCHAR2(1) default '0' not null,
  edit_time        DATE,
  edit_emp         VARCHAR2(10),
  kit_checkout_qty NUMBER(7) default 0,
  ic_receive_qty   NUMBER(7) default 0,
  ic_checkout_qty  NUMBER(7) default 0
)
;
create index MES4.IDX_R_IC_CONTROL_IC on MES4.R_IC_CONTROL (IC_NO)
  nologging;
create index MES4.IDX_R_IC_CONTROL_TASK on MES4.R_IC_CONTROL (TASKNO)
  nologging;
grant select, insert, update, delete, alter on MES4.R_IC_CONTROL to MES1;

prompt
prompt Creating table R_IC_SCAN_DETAIL
prompt ===============================
prompt
create table MES4.R_IC_SCAN_DETAIL
(
  tr_sn         VARCHAR2(12) not null,
  cust_kp_no    VARCHAR2(20) not null,
  taskno        VARCHAR2(20) not null,
  qty           NUMBER(7) not null,
  from_location VARCHAR2(12),
  to_location   VARCHAR2(12),
  move_type     VARCHAR2(1),
  move_time     DATE,
  move_emp      VARCHAR2(10),
  keep_emp      VARCHAR2(10),
  data1         VARCHAR2(20),
  data2         VARCHAR2(20)
)
;
create index MES4.IDX_R_IC_SCAN_DETAIL_TASK on MES4.R_IC_SCAN_DETAIL (TASKNO)
  nologging;
create index MES4.IDX_R_IC_SCAN_DETAIL_TRSN on MES4.R_IC_SCAN_DETAIL (TR_SN)
  nologging;
grant select, insert, update, delete, alter on MES4.R_IC_SCAN_DETAIL to MES1;

prompt
prompt Creating table R_INSPECTION_RESULT
prompt ==================================
prompt
create table MES4.R_INSPECTION_RESULT
(
  doc_no               VARCHAR2(20) not null,
  mfr_kp_no_flag       VARCHAR2(3),
  mfr_name_flag        VARCHAR2(3),
  shelf_life_flag      VARCHAR2(3),
  qualify_status_flag  VARCHAR2(3),
  rohs_status_flag     VARCHAR2(3),
  package_1_flag       VARCHAR2(3),
  package_2_flag       VARCHAR2(3),
  package_3_flag       VARCHAR2(3),
  visual_1_flag        VARCHAR2(3),
  visual_2_flag        VARCHAR2(3),
  visual_3_flag        VARCHAR2(3),
  visual_4_flag        VARCHAR2(3),
  visual_5_flag        VARCHAR2(3),
  board_1_flag         VARCHAR2(3),
  board_2_flag         VARCHAR2(3),
  board_3_flag         VARCHAR2(3),
  plated_1_flag        VARCHAR2(3),
  plated_2_flag        VARCHAR2(3),
  plated_3_flag        VARCHAR2(3),
  non_plated_1_flag    VARCHAR2(3),
  non_plated_2_flag    VARCHAR2(3),
  functional_1_flag    VARCHAR2(3),
  functional_2_flag    VARCHAR2(3),
  functional_3_flag    VARCHAR2(3),
  functional_4_flag    VARCHAR2(3),
  functional_5_flag    VARCHAR2(3),
  functional_6_flag    VARCHAR2(3),
  functional_7_flag    VARCHAR2(3),
  edit_emp             VARCHAR2(25),
  inspection_date      DATE,
  version_flag         VARCHAR2(10),
  penalization_flag    VARCHAR2(10),
  plated_4_flag        VARCHAR2(3),
  non_plated_3_flag    VARCHAR2(3),
  non_plated_4_flag    VARCHAR2(3),
  other_cdf            VARCHAR2(3),
  cfd5_flag            VARCHAR2(3),
  cfd6_flag            VARCHAR2(3),
  board_d1_falg        VARCHAR2(3),
  board_d2_falg        VARCHAR2(3),
  board_d3_falg        VARCHAR2(3),
  board_d4_falg        VARCHAR2(3),
  board_d5_falg        VARCHAR2(3),
  plated_add1_flag     VARCHAR2(3),
  plated_add2_flag     VARCHAR2(3),
  plated_add3_flag     VARCHAR2(3),
  non_plated_add1_flag VARCHAR2(3),
  non_plated_add2_flag VARCHAR2(3),
  checkemp             VARCHAR2(15),
  approvemp            VARCHAR2(15),
  mbb_flag             VARCHAR2(3),
  bag_flag             VARCHAR2(3),
  mbb_result           VARCHAR2(3),
  ul_model_flag        VARCHAR2(3),
  ul_fire_flag         VARCHAR2(3)
)
;
create index MES4.R_INSPECTION_RESULT_DOCNO on MES4.R_INSPECTION_RESULT (DOC_NO);
grant select, insert, update, delete on MES4.R_INSPECTION_RESULT to MES1;

prompt
prompt Creating table R_INSPECTION_RESULT_EXTEND
prompt =========================================
prompt
create table MES4.R_INSPECTION_RESULT_EXTEND
(
  doc_no          VARCHAR2(20),
  cfd_7_flag      VARCHAR2(3),
  cfd_8_flag      VARCHAR2(3),
  cfd_9_flag      VARCHAR2(3),
  cfd_10_flag     VARCHAR2(3),
  cfd11_flag      VARCHAR2(3),
  cfd12_flag      VARCHAR2(3),
  cfd13_flag      VARCHAR2(3),
  cfd14_flag      VARCHAR2(3),
  cfd15_flag      VARCHAR2(3),
  cfd16_flag      VARCHAR2(3),
  cfd17_flag      VARCHAR2(3),
  cfd18_flag      VARCHAR2(3),
  edit_emp        VARCHAR2(25),
  inspection_date DATE default SYSDATE
)
;
create index MES4.R_INSPECTION_RESULT_EXTEND_DN on MES4.R_INSPECTION_RESULT_EXTEND (DOC_NO);
grant select, insert, update, delete on MES4.R_INSPECTION_RESULT_EXTEND to MES1;

prompt
prompt Creating table R_IPQC_CHECK_DETAIL
prompt ==================================
prompt
create table MES4.R_IPQC_CHECK_DETAIL
(
  check_type VARCHAR2(20) not null,
  station    VARCHAR2(10),
  wo         VARCHAR2(12),
  slot_no    VARCHAR2(7),
  kp_no      VARCHAR2(20),
  tr_sn      VARCHAR2(12),
  check_time DATE,
  check_emp  VARCHAR2(20),
  result     VARCHAR2(100),
  remarks    VARCHAR2(100),
  edit_time  DATE,
  edit_emp   VARCHAR2(20)
)
;
create index MES4.R_IPQC_CHECK_DETAIL_1 on MES4.R_IPQC_CHECK_DETAIL (CHECK_TYPE)
  nologging;
create index MES4.R_IPQC_CHECK_DETAIL_2 on MES4.R_IPQC_CHECK_DETAIL (STATION)
  nologging;
create index MES4.R_IPQC_CHECK_DETAIL_3 on MES4.R_IPQC_CHECK_DETAIL (WO)
  nologging;
create index MES4.R_IPQC_CHECK_DETAIL_4 on MES4.R_IPQC_CHECK_DETAIL (CHECK_TIME)
  nologging;
grant select, insert, update, delete, alter on MES4.R_IPQC_CHECK_DETAIL to MES1;

prompt
prompt Creating table R_IQC_CHECK_LCR
prompt ==============================
prompt
create table MES4.R_IQC_CHECK_LCR
(
  doc_no     VARCHAR2(15) not null,
  cust_kp_no VARCHAR2(20) not null,
  mfr_kp_no  VARCHAR2(100),
  mfr_code   VARCHAR2(15),
  date_code  VARCHAR2(20),
  lot_code   VARCHAR2(100),
  lcr_value  VARCHAR2(20) not null,
  edit_time  DATE,
  edit_emp   VARCHAR2(20) not null,
  status     VARCHAR2(4) not null
)
;
create index MES4.R_IQC_CHECK_LCR_IDX01 on MES4.R_IQC_CHECK_LCR (CUST_KP_NO);
create index MES4.R_IQC_CHECK_LCR_IDX02 on MES4.R_IQC_CHECK_LCR (DOC_NO);
create index MES4.R_IQC_CHECK_LCR_IDX03 on MES4.R_IQC_CHECK_LCR (EDIT_TIME);
grant select, insert, update, delete, alter on MES4.R_IQC_CHECK_LCR to MES1;

prompt
prompt Creating table R_JOB_RECORD
prompt ===========================
prompt
create table MES4.R_JOB_RECORD
(
  category  VARCHAR2(25) not null,
  machine   VARCHAR2(25),
  data1     VARCHAR2(25),
  data2     VARCHAR2(25),
  data3     VARCHAR2(25),
  data4     VARCHAR2(30),
  data5     VARCHAR2(30),
  data6     VARCHAR2(25),
  work_time DATE default SYSDATE not null
)
;
create index MES4.R_JOB_RECORD_MA on MES4.R_JOB_RECORD (MACHINE)
  nologging;
create index MES4.R_JOB_RECORD_SN on MES4.R_JOB_RECORD (DATA1)
  nologging;
grant select, insert, update on MES4.R_JOB_RECORD to MES1;

prompt
prompt Creating table R_KITTING_CHECKOUT_TMP
prompt =====================================
prompt
create table MES4.R_KITTING_CHECKOUT_TMP
(
  tr_sn      VARCHAR2(12) not null,
  cust_kp_no VARCHAR2(20) not null,
  wo         VARCHAR2(12) not null,
  station    VARCHAR2(10) not null,
  work_time  DATE not null,
  emp_no     VARCHAR2(10) not null
)
;

prompt
prompt Creating table R_KITTING_CHECK_RESULT
prompt =====================================
prompt
create table MES4.R_KITTING_CHECK_RESULT
(
  doc_no       VARCHAR2(40),
  cust_kp_no   VARCHAR2(40),
  sap_qty      NUMBER(18),
  allpart_qty  NUMBER(18),
  ip_add       VARCHAR2(40),
  check_qty    NUMBER(18),
  deff_qty     NUMBER(18),
  edit_emp     VARCHAR2(20),
  work_time    DATE,
  reasonscript VARCHAR2(2000),
  reasonemp    VARCHAR2(20),
  reason_time  DATE,
  work_flag    VARCHAR2(2) default 0,
  area         VARCHAR2(10),
  sap_stock    VARCHAR2(50),
  completion   VARCHAR2(10),
  finish       VARCHAR2(10),
  batch        VARCHAR2(10)
)
;

prompt
prompt Creating table R_KITTING_SCAN_DETAIL
prompt ====================================
prompt
create table MES4.R_KITTING_SCAN_DETAIL
(
  tr_sn         VARCHAR2(12) not null,
  cust_kp_no    VARCHAR2(20) not null,
  qty           NUMBER(7) not null,
  from_location VARCHAR2(12) not null,
  to_location   VARCHAR2(12) not null,
  move_type     VARCHAR2(1) not null,
  move_reason   VARCHAR2(50),
  move_emp      VARCHAR2(10) not null,
  move_time     DATE not null,
  process_flag  VARCHAR2(25),
  data1         VARCHAR2(25),
  data2         VARCHAR2(25),
  data3         VARCHAR2(25),
  memo          VARCHAR2(250)
)
;
comment on column MES4.R_KITTING_SCAN_DETAIL.memo
  is '備註';
create index MES4.R_KITTING_SCAN_DETAIL_CKN on MES4.R_KITTING_SCAN_DETAIL (CUST_KP_NO);
create index MES4.R_KITTING_SCAN_DETAIL_F1 on MES4.R_KITTING_SCAN_DETAIL (FROM_LOCATION);
create index MES4.R_KITTING_SCAN_DETAIL_MT on MES4.R_KITTING_SCAN_DETAIL (MOVE_TIME);
create index MES4.R_KITTING_SCAN_DETAIL_TRSN on MES4.R_KITTING_SCAN_DETAIL (TR_SN);
grant select, insert, update, delete, alter on MES4.R_KITTING_SCAN_DETAIL to MES1;

prompt
prompt Creating table R_KITTING_SHORTAGE
prompt =================================
prompt
create table MES4.R_KITTING_SHORTAGE
(
  alarm_type             VARCHAR2(50) not null,
  line_name              VARCHAR2(50),
  wo                     VARCHAR2(500) not null,
  v_wo                   VARCHAR2(150),
  p_no                   VARCHAR2(50),
  process_flag           VARCHAR2(50) not null,
  pno_2h_uph             NUMBER,
  cust_kp_no             VARCHAR2(100) not null,
  standard_qty           NUMBER,
  kp_2huph_request_qty   NUMBER,
  alarm_qty              NUMBER,
  wo_process_request_qty NUMBER,
  buff_towo_qty          NUMBER,
  check_out_qty          NUMBER,
  wo_process_alarm_times NUMBER,
  alarm_flag             VARCHAR2(50) default 'Y',
  alarm_time             DATE default SYSDATE,
  alarm_status           VARCHAR2(50),
  lastedit_time          DATE default SYSDATE,
  lastedit_emp           VARCHAR2(50),
  station                VARCHAR2(50),
  slot_no                VARCHAR2(50),
  data3                  VARCHAR2(100),
  data4                  VARCHAR2(100),
  data5                  VARCHAR2(100),
  data6                  DATE
)
;
comment on column MES4.R_KITTING_SHORTAGE.alarm_type
  is '????';
comment on column MES4.R_KITTING_SHORTAGE.line_name
  is '??';
comment on column MES4.R_KITTING_SHORTAGE.wo
  is '??';
comment on column MES4.R_KITTING_SHORTAGE.v_wo
  is '????';
comment on column MES4.R_KITTING_SHORTAGE.p_no
  is '????';
comment on column MES4.R_KITTING_SHORTAGE.process_flag
  is '??';
comment on column MES4.R_KITTING_SHORTAGE.pno_2h_uph
  is 'UPH';
comment on column MES4.R_KITTING_SHORTAGE.cust_kp_no
  is '??';
comment on column MES4.R_KITTING_SHORTAGE.standard_qty
  is '????';
comment on column MES4.R_KITTING_SHORTAGE.kp_2huph_request_qty
  is '?????UPH??????';
comment on column MES4.R_KITTING_SHORTAGE.alarm_qty
  is '????';
comment on column MES4.R_KITTING_SHORTAGE.wo_process_request_qty
  is '???????';
comment on column MES4.R_KITTING_SHORTAGE.buff_towo_qty
  is '????';
comment on column MES4.R_KITTING_SHORTAGE.check_out_qty
  is '????';
comment on column MES4.R_KITTING_SHORTAGE.wo_process_alarm_times
  is '????';
create index MES4.IDX_R_KITTING_SHORTAGE_LINE on MES4.R_KITTING_SHORTAGE (LINE_NAME)
  nologging;
create index MES4.IDX_R_KITTING_SHORTAGE_TIME on MES4.R_KITTING_SHORTAGE (LASTEDIT_TIME)
  nologging;
create index MES4.IDX_R_KITTING_SHORTAGE_WO on MES4.R_KITTING_SHORTAGE (WO)
  nologging;
grant select, insert, update, delete, alter on MES4.R_KITTING_SHORTAGE to MES1;

prompt
prompt Creating table R_KITTING_SHORTAGE_HIS
prompt =====================================
prompt
create table MES4.R_KITTING_SHORTAGE_HIS
(
  alarm_type             VARCHAR2(50) not null,
  line_name              VARCHAR2(50),
  wo                     VARCHAR2(50) not null,
  v_wo                   VARCHAR2(50),
  p_no                   VARCHAR2(50),
  process_flag           VARCHAR2(50) not null,
  pno_2h_uph             NUMBER,
  cust_kp_no             VARCHAR2(100) not null,
  standard_qty           NUMBER,
  kp_2huph_request_qty   NUMBER,
  alarm_qty              NUMBER,
  wo_process_request_qty NUMBER,
  buff_towo_qty          NUMBER,
  check_out_qty          NUMBER,
  wo_process_alarm_times NUMBER,
  alarm_flag             VARCHAR2(50) default 'Y',
  alarm_time             DATE default SYSDATE,
  alarm_status           VARCHAR2(50),
  lastedit_time          DATE default SYSDATE,
  lastedit_emp           VARCHAR2(50),
  station                VARCHAR2(50),
  slot_no                VARCHAR2(50),
  data3                  VARCHAR2(50),
  data4                  VARCHAR2(50),
  data5                  VARCHAR2(50),
  data6                  DATE
)
;
create index MES4.IDX_R_KITTING_SHORTAGE_HIS_LT on MES4.R_KITTING_SHORTAGE_HIS (LASTEDIT_TIME);
create index MES4.IDX_R_KITTING_SHORTAGE_HIS_WO on MES4.R_KITTING_SHORTAGE_HIS (WO);
grant select, insert, update, delete on MES4.R_KITTING_SHORTAGE_HIS to MES1;

prompt
prompt Creating table R_KITTING_SHORTAGE_TEMP
prompt ======================================
prompt
create table MES4.R_KITTING_SHORTAGE_TEMP
(
  alarm_type             VARCHAR2(50) not null,
  line_name              VARCHAR2(50),
  wo                     VARCHAR2(50) not null,
  v_wo                   VARCHAR2(50),
  p_no                   VARCHAR2(50),
  process_flag           VARCHAR2(50) not null,
  pno_2h_uph             NUMBER,
  cust_kp_no             VARCHAR2(100) not null,
  standard_qty           NUMBER,
  kp_2huph_request_qty   NUMBER,
  alarm_qty              NUMBER,
  wo_process_request_qty NUMBER,
  buff_towo_qty          NUMBER,
  check_out_qty          NUMBER,
  wo_process_alarm_times NUMBER,
  alarm_flag             VARCHAR2(50) default 'Y',
  alarm_time             DATE default SYSDATE,
  alarm_status           VARCHAR2(50),
  lastedit_time          DATE default SYSDATE,
  lastedit_emp           VARCHAR2(50),
  station                VARCHAR2(50),
  slot_no                VARCHAR2(50),
  data3                  VARCHAR2(50),
  data4                  VARCHAR2(50),
  data5                  VARCHAR2(50),
  data6                  DATE
)
;
create index MES4.IDX_R_KITTING_SHORTAGE_TMP_LT on MES4.R_KITTING_SHORTAGE_TEMP (LASTEDIT_TIME);
create index MES4.IDX_R_KITTING_SHORTAGE_TMP_LV on MES4.R_KITTING_SHORTAGE_TEMP (LINE_NAME);
create index MES4.IDX_R_KITTING_SHORTAGE_TMP_WO on MES4.R_KITTING_SHORTAGE_TEMP (WO);
grant select, insert, update, delete on MES4.R_KITTING_SHORTAGE_TEMP to MES1;

prompt
prompt Creating table R_KITTING_SHORTAGE_TIMES
prompt =======================================
prompt
create table MES4.R_KITTING_SHORTAGE_TIMES
(
  wo                  VARCHAR2(50) not null,
  process_flag        VARCHAR2(50) not null,
  pno                 VARCHAR2(50) not null,
  line_name           VARCHAR2(50) not null,
  first_checkout_time DATE default SYSDATE,
  first_output_time   DATE,
  next_alarm_time     DATE,
  alarm_times         NUMBER default 0,
  alarm_qty           NUMBER,
  alarm_status        VARCHAR2(50),
  lastedit_emp        VARCHAR2(50),
  lastedit_time       DATE default SYSDATE,
  data1               VARCHAR2(50),
  data2               VARCHAR2(50),
  data3               VARCHAR2(50)
)
;
create index MES4.IDX_R_KITTING_SHORTAGE_T_N_AL on MES4.R_KITTING_SHORTAGE_TIMES (NEXT_ALARM_TIME)
  nologging;
create index MES4.IDX_R_KITTING_SHORTAGE_T_WO on MES4.R_KITTING_SHORTAGE_TIMES (WO);
grant select, insert, update, delete on MES4.R_KITTING_SHORTAGE_TIMES to MES1;

prompt
prompt Creating table R_KITTING_WASTAGE
prompt ================================
prompt
create table MES4.R_KITTING_WASTAGE
(
  specialnumber VARCHAR2(20) not null,
  datetime      DATE,
  workorder     VARCHAR2(12),
  skuno         VARCHAR2(30),
  floor         VARCHAR2(5),
  lineid        VARCHAR2(5),
  qty           NUMBER,
  singleprice   NUMBER,
  totalvalue    NUMBER,
  username      VARCHAR2(10),
  reason        VARCHAR2(100),
  snum_flag     VARCHAR2(10),
  return_date   DATE
)
;
grant select, insert, update, delete on MES4.R_KITTING_WASTAGE to MES1;

prompt
prompt Creating table R_KP_LIST
prompt ========================
prompt
create table MES4.R_KP_LIST
(
  tr_sn             VARCHAR2(12) not null,
  wo                VARCHAR2(12) not null,
  kp_no             VARCHAR2(20) not null,
  mfr_kp_no         VARCHAR2(100) not null,
  mfr_code          VARCHAR2(15) not null,
  date_code         VARCHAR2(20),
  lot_code          VARCHAR2(100),
  add_qty           NUMBER(7) not null,
  ext_qty           NUMBER(7) default 0 not null,
  start_time        DATE not null,
  end_time          DATE,
  station           VARCHAR2(10) not null,
  emp_no            VARCHAR2(10) not null,
  check_emp         VARCHAR2(10),
  ipqc_check_emp    VARCHAR2(50),
  ipqc_check_time   DATE,
  ipqc_check_result VARCHAR2(100),
  memo              VARCHAR2(100),
  data1             VARCHAR2(50),
  data2             VARCHAR2(50),
  data3             VARCHAR2(50)
)
;
create index MES4.IDX_KP_TR_SN on MES4.R_KP_LIST (TR_SN);
create index MES4.IDX_KP_TR_STA on MES4.R_KP_LIST (STATION);
create index MES4.R_KP_LISTKP_NO on MES4.R_KP_LIST (KP_NO);
create index MES4.R_KP_LIST_WO on MES4.R_KP_LIST (WO);
grant select, insert, update, delete, references, alter, index on MES4.R_KP_LIST to MES1;

prompt
prompt Creating table R_KP_LIST_TEMP
prompt =============================
prompt
create table MES4.R_KP_LIST_TEMP
(
  wo             VARCHAR2(12) not null,
  station        VARCHAR2(10),
  slot_no        VARCHAR2(7),
  process_flag   VARCHAR2(1),
  standard_qty   NUMBER(4) default 0 not null,
  tr_sn          VARCHAR2(12) not null,
  kp_no          VARCHAR2(20) not null,
  qty            NUMBER(7) default 0 not null,
  ext_qty        NUMBER(8,1) default 0 not null,
  work_time      DATE default sysdate not null,
  emp_no         VARCHAR2(20),
  smt_code       VARCHAR2(6),
  work_flag      VARCHAR2(1) default 0,
  p_no           VARCHAR2(20),
  p_version      VARCHAR2(4),
  feeder_no      VARCHAR2(15),
  mfr_kp_no      VARCHAR2(100),
  mfr_code       VARCHAR2(15),
  date_code      VARCHAR2(20),
  lot_code       VARCHAR2(100),
  replacekp_flag VARCHAR2(1),
  tr_code        VARCHAR2(25),
  b_qty          NUMBER(4) default 0,
  t_qty          NUMBER(4) default 0
)
;
comment on column MES4.R_KP_LIST_TEMP.work_flag
  is '0可用,1不可用';
create index MES4.R_KP_LIST_TEMP_IDX_1 on MES4.R_KP_LIST_TEMP (TR_SN);
create index MES4.R_KP_LIST_TEMP_IDX_2 on MES4.R_KP_LIST_TEMP (WO);
create index MES4.R_KP_LIST_TEMP_IDX_3 on MES4.R_KP_LIST_TEMP (WORK_FLAG);
grant select, insert, update, delete, references, alter, index on MES4.R_KP_LIST_TEMP to MES1;

prompt
prompt Creating table R_KP_MFRCONFIG_WO
prompt ================================
prompt
create table MES4.R_KP_MFRCONFIG_WO
(
  wo        VARCHAR2(12) not null,
  kp_no     VARCHAR2(20) not null,
  mfr_name  VARCHAR2(100) not null,
  edit_emp  VARCHAR2(25) not null,
  edit_date DATE not null,
  p_no      VARCHAR2(20) not null,
  p_version VARCHAR2(5) not null,
  data1     VARCHAR2(8)
)
;
grant select, insert, update on MES4.R_KP_MFRCONFIG_WO to MES1;

prompt
prompt Creating table R_KP_OVERDUE_ALARM
prompt =================================
prompt
create table MES4.R_KP_OVERDUE_ALARM
(
  cust_kp_no VARCHAR2(25) not null,
  mfr_name   VARCHAR2(100) not null,
  date_code  VARCHAR2(25) not null,
  alarm_type VARCHAR2(1) not null,
  work_time  DATE default SYSDATE not null,
  memo       VARCHAR2(50)
)
;

prompt
prompt Creating table R_KP_REPLACE
prompt ===========================
prompt
create table MES4.R_KP_REPLACE
(
  replace_sn     VARCHAR2(8),
  p_sn           VARCHAR2(50) not null,
  wo             VARCHAR2(12) not null,
  kp_no          VARCHAR2(30) not null,
  date_code      VARCHAR2(50),
  lot_code       VARCHAR2(50),
  mfr_kp_no      VARCHAR2(100) not null,
  mfr_code       VARCHAR2(15) not null,
  error_station  VARCHAR2(20) not null,
  error_location VARCHAR2(10) not null,
  replace_tr_sn  VARCHAR2(12) not null,
  work_time      DATE not null,
  work_flag      VARCHAR2(1) default '0' not null,
  replace_flag   VARCHAR2(1) default '0' not null,
  old_kp_sn      VARCHAR2(20),
  new_kp_sn      VARCHAR2(20),
  emp_no         VARCHAR2(10) not null,
  p_no           VARCHAR2(30),
  fail_symptom   VARCHAR2(50),
  fail_id        VARCHAR2(20),
  new_tr_sn      VARCHAR2(12),
  old_kp_no      VARCHAR2(50),
  old_date_code  VARCHAR2(50),
  old_lot_code   VARCHAR2(50),
  old_mfr_code   VARCHAR2(50),
  old_mfr_kp_no  VARCHAR2(50),
  error_code     VARCHAR2(30),
  vanilla_pn     VARCHAR2(50),
  vanilla_sn     VARCHAR2(50)
)
;
create index MES4.R014_DATE_CODE on MES4.R_KP_REPLACE (DATE_CODE);
create index MES4.R014_KP_LOT_CODE on MES4.R_KP_REPLACE (LOT_CODE);
create index MES4.R014_KP_NO on MES4.R_KP_REPLACE (KP_NO);
create index MES4.R014_P_SN on MES4.R_KP_REPLACE (P_SN);
create index MES4.R_KP_REPLACE_SN on MES4.R_KP_REPLACE (REPLACE_SN)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.R_KP_REPLACE to MES1;

prompt
prompt Creating table R_KP_ROHS_TEST
prompt =============================
prompt
create table MES4.R_KP_ROHS_TEST
(
  cust_kp_no      VARCHAR2(20),
  mfr_name        VARCHAR2(100) not null,
  mfr_kp_no       VARCHAR2(100),
  qualify_status  VARCHAR2(20),
  rohs_status     VARCHAR2(10),
  date_code       VARCHAR2(20),
  work_time       DATE,
  due_date        DATE,
  test_dept       VARCHAR2(20),
  pb              VARCHAR2(20),
  hg              VARCHAR2(20),
  cd              VARCHAR2(20),
  crvi            VARCHAR2(20),
  pbb             VARCHAR2(20),
  pbde            VARCHAR2(20),
  load            VARCHAR2(100),
  final_judgement VARCHAR2(5),
  edit_emp        VARCHAR2(25),
  test_periods    VARCHAR2(5),
  test_type       VARCHAR2(10),
  material_type   VARCHAR2(15),
  sn              VARCHAR2(20),
  test1           VARCHAR2(50),
  spec1           VARCHAR2(50),
  record1         VARCHAR2(50),
  resu1           VARCHAR2(50),
  test2           VARCHAR2(50),
  spec2           VARCHAR2(50),
  record2         VARCHAR2(50),
  resu2           VARCHAR2(50),
  test3           VARCHAR2(50),
  spec3           VARCHAR2(50),
  record3         VARCHAR2(50),
  resu3           VARCHAR2(50),
  test4           VARCHAR2(50),
  spec4           VARCHAR2(50),
  record4         VARCHAR2(50),
  resu4           VARCHAR2(50),
  test5           VARCHAR2(50),
  spec5           VARCHAR2(50),
  record5         VARCHAR2(50),
  resu5           VARCHAR2(50),
  test6           VARCHAR2(50),
  spec6           VARCHAR2(50),
  record6         VARCHAR2(50),
  resu6           VARCHAR2(50),
  test7           VARCHAR2(50),
  spec7           VARCHAR2(50),
  record7         VARCHAR2(50),
  resu7           VARCHAR2(50),
  test8           VARCHAR2(50),
  spec8           VARCHAR2(50),
  record8         VARCHAR2(50),
  resu8           VARCHAR2(50),
  test9           VARCHAR2(50),
  spec9           VARCHAR2(50),
  record9         VARCHAR2(50),
  resu9           VARCHAR2(50),
  test10          VARCHAR2(50),
  spec10          VARCHAR2(50),
  record10        VARCHAR2(50),
  resu10          VARCHAR2(50),
  check_by        VARCHAR2(10),
  approved_by     VARCHAR2(10),
  status          VARCHAR2(5),
  data1           VARCHAR2(50),
  data2           VARCHAR2(350)
)
;
grant select, insert, update, delete on MES4.R_KP_ROHS_TEST to MES1;

prompt
prompt Creating table R_KP_SI_STOCK
prompt ============================
prompt
create table MES4.R_KP_SI_STOCK
(
  cust_kp_no   VARCHAR2(20) not null,
  checkin_qty  NUMBER(7) default 0,
  checkout_qty NUMBER(7) default 0,
  ext_qty      NUMBER(7) default 0,
  location     VARCHAR2(10),
  floor        VARCHAR2(10)
)
;

prompt
prompt Creating table R_KP_SN
prompt ======================
prompt
create table MES4.R_KP_SN
(
  tr_sn            VARCHAR2(12) not null,
  kp_sn            VARCHAR2(20) not null,
  doc_no           VARCHAR2(15) not null,
  doc_flag         VARCHAR2(1) not null,
  cust_kp_no       VARCHAR2(20) not null,
  mfr_kp_no        VARCHAR2(100) not null,
  mfr_code         VARCHAR2(15) not null,
  date_code        VARCHAR2(20),
  lot_code         VARCHAR2(20),
  location_flag    VARCHAR2(1) not null,
  work_flag        VARCHAR2(1) not null,
  start_time       DATE not null,
  end_time         DATE,
  emp_no           VARCHAR2(10) not null,
  accept_flag      NUMBER(1) default 0 not null,
  accept_data      VARCHAR2(25),
  deviation_period VARCHAR2(25),
  data1            VARCHAR2(20),
  data2            VARCHAR2(20),
  data3            VARCHAR2(20)
)
;
create index MES4.R_KP_SNKP_SN on MES4.R_KP_SN (KP_SN)
  nologging;
create index MES4.R_KP_SNTR_SN on MES4.R_KP_SN (TR_SN)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.R_KP_SN to MES1;

prompt
prompt Creating table R_KP_SN_DETAIL
prompt =============================
prompt
create table MES4.R_KP_SN_DETAIL
(
  wo           VARCHAR2(12) not null,
  p_sn         VARCHAR2(12) not null,
  kp_sn        VARCHAR2(20) not null,
  cust_kp_no   VARCHAR2(20) not null,
  mfr_kp_no    VARCHAR2(100) not null,
  mfr_code     VARCHAR2(15) not null,
  replace_flag VARCHAR2(1) default '0' not null,
  work_flag    VARCHAR2(1) default '0' not null,
  work_time    DATE not null,
  data1        VARCHAR2(20),
  data2        VARCHAR2(20),
  data3        VARCHAR2(20)
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_KP_SN_DETAIL to MES1;

prompt
prompt Creating table R_KP_SN_TEMP
prompt ===========================
prompt
create table MES4.R_KP_SN_TEMP
(
  sysserialno VARCHAR2(20) not null,
  cserialno   VARCHAR2(20) not null,
  lasteditdt  DATE default sysdate not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_KP_SN_TEMP to MES1;

prompt
prompt Creating table R_LABEL_REPRINT
prompt ==============================
prompt
create table MES4.R_LABEL_REPRINT
(
  tr_sn         VARCHAR2(12) not null,
  cust_kp_no    VARCHAR2(20) not null,
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  date_code     VARCHAR2(20),
  lot_code      VARCHAR2(100),
  qty           NUMBER(7) not null,
  ext_qty       NUMBER(7) not null,
  location_flag VARCHAR2(1) not null,
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_LABEL_REPRINT to MES1;

prompt
prompt Creating table R_LOCATION_STATUS
prompt ================================
prompt
create table MES4.R_LOCATION_STATUS
(
  stock_no    VARCHAR2(10) not null,
  location    VARCHAR2(30),
  skuno       VARCHAR2(20),
  defaulqty   NUMBER,
  stuffingqty NUMBER,
  lasteditdt  DATE,
  lasteditby  VARCHAR2(10),
  updatedt    DATE
)
;
grant select, insert, update, delete on MES4.R_LOCATION_STATUS to MES1;

prompt
prompt Creating table R_LOGIN
prompt ======================
prompt
create table MES4.R_LOGIN
(
  user_id    VARCHAR2(10),
  ip         VARCHAR2(15),
  in_time    DATE,
  last_query DATE
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_LOGIN to MES1;

prompt
prompt Creating table R_MACHINE_STOP_LIST
prompt ==================================
prompt
create table MES4.R_MACHINE_STOP_LIST
(
  station    VARCHAR2(10) not null,
  start_time DATE not null,
  end_time   DATE,
  emp_no     VARCHAR2(10) not null
)
;
create index MES4.R_MACHINE_STOP_LISTSTATION on MES4.R_MACHINE_STOP_LIST (STATION);
grant select, insert, update, delete, references, alter, index on MES4.R_MACHINE_STOP_LIST to MES1;

prompt
prompt Creating table R_MACHINE_STOP_LIST_EXTEND
prompt =========================================
prompt
create table MES4.R_MACHINE_STOP_LIST_EXTEND
(
  station   VARCHAR2(10) not null,
  wo        VARCHAR2(20),
  work_time DATE,
  emp_no    VARCHAR2(10) not null
)
;
create index MES4.IDX_R_MACHINE_STOP_LIST_EXT3 on MES4.R_MACHINE_STOP_LIST_EXTEND (WORK_TIME)
  nologging;
create index MES4.IDX_R_MACHINE_STOP_LIST_EXTEN2 on MES4.R_MACHINE_STOP_LIST_EXTEND (WO)
  nologging;
create index MES4.IDX_R_MACHINE_STOP_LIST_EXTEND on MES4.R_MACHINE_STOP_LIST_EXTEND (STATION)
  nologging;
grant select, insert, update, delete on MES4.R_MACHINE_STOP_LIST_EXTEND to MES1;

prompt
prompt Creating table R_MAIL_T
prompt =======================
prompt
create table MES4.R_MAIL_T
(
  mail_id           VARCHAR2(25),
  mail_to           VARCHAR2(1000),
  mail_from         VARCHAR2(50),
  mail_cc           VARCHAR2(1000),
  mail_bcc          VARCHAR2(1000),
  mail_att          VARCHAR2(1000),
  mail_subject      VARCHAR2(1000),
  mail_sequence     VARCHAR2(25),
  mail_content      VARCHAR2(3000),
  mail_date         DATE default SYSDATE,
  mail_flag         VARCHAR2(5),
  mail_program      VARCHAR2(50),
  mail_type         VARCHAR2(10),
  mail_att_content  CLOB,
  mail_html_content CLOB
)
;
create index MES4.IDX_MAIL_FLAG on MES4.R_MAIL_T (MAIL_FLAG);
grant select, insert, update, delete on MES4.R_MAIL_T to MES1;

prompt
prompt Creating table R_MATERIAL_NULLOFF_DETAIL
prompt ========================================
prompt
create table MES4.R_MATERIAL_NULLOFF_DETAIL
(
  wo           VARCHAR2(30),
  tr_sn        VARCHAR2(30),
  machine      VARCHAR2(20),
  process_flag VARCHAR2(25),
  qty          NUMBER(10),
  scan_action  VARCHAR2(20),
  location     VARCHAR2(12),
  move_emp     VARCHAR2(20),
  move_time    DATE,
  data1        VARCHAR2(25),
  data2        VARCHAR2(25),
  data3        VARCHAR2(25),
  ues_qty      NUMBER(10),
  ext_qty      NUMBER(10)
)
;

prompt
prompt Creating table R_MES_IFT01
prompt ==========================
prompt
create table MES4.R_MES_IFT01
(
  if_seq                NUMBER(12) not null,
  move_flag             CHAR(1),
  move_time             DATE,
  factory               VARCHAR2(10),
  return_flag           VARCHAR2(10) not null,
  ems_order_id          VARCHAR2(25),
  raw_mat_id            VARCHAR2(30) not null,
  old_raw_lot_id        VARCHAR2(30),
  raw_lot_id            VARCHAR2(128),
  line                  VARCHAR2(20),
  unit                  VARCHAR2(10),
  qty                   NUMBER(15,6) not null,
  supplier_raw_mat_code VARCHAR2(128),
  supplier_code         VARCHAR2(64),
  supplier_name         VARCHAR2(256),
  stock_in_time         DATE,
  lot_code              VARCHAR2(256),
  raw_mat_create_time   DATE,
  edit_time             DATE not null,
  edit_flag             NUMBER(1)
)
;
comment on column MES4.R_MES_IFT01.if_seq
  is '?????';
comment on column MES4.R_MES_IFT01.move_flag
  is '????,???????';
comment on column MES4.R_MES_IFT01.move_time
  is '????,???????';
comment on column MES4.R_MES_IFT01.factory
  is '??.???';
comment on column MES4.R_MES_IFT01.return_flag
  is '????.';
comment on column MES4.R_MES_IFT01.ems_order_id
  is '??';
comment on column MES4.R_MES_IFT01.raw_mat_id
  is '???????';
comment on column MES4.R_MES_IFT01.old_raw_lot_id
  is '?ALLPARTS??';
comment on column MES4.R_MES_IFT01.raw_lot_id
  is '??ALLPARTS??';
comment on column MES4.R_MES_IFT01.line
  is '??';
comment on column MES4.R_MES_IFT01.unit
  is '??';
comment on column MES4.R_MES_IFT01.qty
  is '????';
comment on column MES4.R_MES_IFT01.supplier_raw_mat_code
  is '?????????';
comment on column MES4.R_MES_IFT01.supplier_code
  is '?????';
comment on column MES4.R_MES_IFT01.supplier_name
  is '?????';
comment on column MES4.R_MES_IFT01.stock_in_time
  is '????';
comment on column MES4.R_MES_IFT01.lot_code
  is '???';
comment on column MES4.R_MES_IFT01.raw_mat_create_time
  is '??????';
create index MES4.IDX_R_EMS_ORDER_ID on MES4.R_MES_IFT01 (EMS_ORDER_ID)
  nologging;
create index MES4.IDX_R_RAW_LOT_ID on MES4.R_MES_IFT01 (RAW_LOT_ID)
  nologging;
create index MES4.IDX_R_RAW_MAT_ID on MES4.R_MES_IFT01 (RAW_MAT_ID)
  nologging;
alter table MES4.R_MES_IFT01
  add primary key (IF_SEQ);
alter index MES4.SYS_C0014162 nologging;
grant select, insert, update, delete, alter, index on MES4.R_MES_IFT01 to MES1;

prompt
prompt Creating table R_MES_IFT01_PTHSEQ
prompt =================================
prompt
create table MES4.R_MES_IFT01_PTHSEQ
(
  lot_id    NVARCHAR2(25) not null,
  edit_time DATE not null,
  edit_flag NUMBER(1) default 0 not null,
  post_time DATE default SYSDATE
)
;
create index MES4.IDX_R_MES_IFT01_PTHSEQ on MES4.R_MES_IFT01_PTHSEQ (LOT_ID)
  nologging;
create index MES4.IDX_R_MES_IFT01_PTHSEQ2 on MES4.R_MES_IFT01_PTHSEQ (EDIT_FLAG, EDIT_TIME)
  nologging;
grant select, insert, update, alter on MES4.R_MES_IFT01_PTHSEQ to MES1;

prompt
prompt Creating table R_MES_IFT01_TRSN
prompt ===============================
prompt
create table MES4.R_MES_IFT01_TRSN
(
  raw_lot_id NVARCHAR2(128),
  edit_time  DATE default SYSDATE not null,
  edit_flag  NUMBER(1) default 0 not null
)
;
create index MES4.R_MES_IFT01_TRSN_SN on MES4.R_MES_IFT01_TRSN (RAW_LOT_ID);
grant select, insert, update, delete, alter, index on MES4.R_MES_IFT01_TRSN to MES1;

prompt
prompt Creating table R_MES_IFT03
prompt ==========================
prompt
create table MES4.R_MES_IFT03
(
  factory              VARCHAR2(10) not null,
  ems_order_id         VARCHAR2(25) not null,
  parents_component_id VARCHAR2(30) not null,
  component_id         VARCHAR2(30) not null,
  wo_qty               NUMBER(10),
  component_desc       VARCHAR2(2000),
  require_qty          NUMBER(15,6),
  unit                 VARCHAR2(20),
  use_qty              NUMBER(10,3) not null,
  edit_time            DATE not null,
  edit_flag            NUMBER(1)
)
;
comment on column MES4.R_MES_IFT03.factory
  is '??.';
comment on column MES4.R_MES_IFT03.ems_order_id
  is 'WO';
comment on column MES4.R_MES_IFT03.parents_component_id
  is '??????: ????P_SN';
comment on column MES4.R_MES_IFT03.component_id
  is '??????: ALLPART??TR_SN????ALLPART?PCB??';
comment on column MES4.R_MES_IFT03.wo_qty
  is '????';
comment on column MES4.R_MES_IFT03.component_desc
  is '??';
comment on column MES4.R_MES_IFT03.require_qty
  is '????';
comment on column MES4.R_MES_IFT03.unit
  is '??';
comment on column MES4.R_MES_IFT03.use_qty
  is '????';
comment on column MES4.R_MES_IFT03.edit_time
  is '???ALLPART??????';
comment on column MES4.R_MES_IFT03.edit_flag
  is '???????????????';
alter table MES4.R_MES_IFT03
  add constraint R_IFT03_KEY primary key (FACTORY, EMS_ORDER_ID, PARENTS_COMPONENT_ID, COMPONENT_ID);
grant select, insert, update, delete, alter, index on MES4.R_MES_IFT03 to MES1;

prompt
prompt Creating table R_MES_IFT04
prompt ==========================
prompt
create table MES4.R_MES_IFT04
(
  mat_id          VARCHAR2(30) not null,
  customer_mat_id VARCHAR2(30) not null,
  mat_desc        VARCHAR2(500),
  customer_id     VARCHAR2(10),
  mat_type        VARCHAR2(20),
  edit_time       DATE not null
)
;
comment on column MES4.R_MES_IFT04.mat_id
  is '?????';
comment on column MES4.R_MES_IFT04.customer_mat_id
  is '????';
comment on column MES4.R_MES_IFT04.mat_desc
  is '????';
comment on column MES4.R_MES_IFT04.customer_id
  is '?BS??CS?????';
comment on column MES4.R_MES_IFT04.mat_type
  is '???RM';
create index MES4.R_MES_IFT04_CUSTOMER_MAT_ID on MES4.R_MES_IFT04 (CUSTOMER_MAT_ID);
create index MES4.R_MES_IFT04_MAT_ID on MES4.R_MES_IFT04 (MAT_ID);
alter table MES4.R_MES_IFT04
  add constraint R_IFT04_KEY primary key (MAT_ID);
grant select, insert, update, delete, alter, index on MES4.R_MES_IFT04 to MES1;

prompt
prompt Creating table R_MES_IFT05
prompt ==========================
prompt
create table MES4.R_MES_IFT05
(
  if_seq       NUMBER(12) not null,
  factory      VARCHAR2(25) not null,
  ems_order_id VARCHAR2(25) not null,
  raw_lot_id   VARCHAR2(128) not null,
  raw_mat_id   VARCHAR2(30) not null,
  qty          NUMBER(15,6) not null,
  line_id      VARCHAR2(20) not null,
  res_id       VARCHAR2(20),
  mount_type   VARCHAR2(10),
  slot         VARCHAR2(20),
  res_slot     VARCHAR2(30),
  tran_time    DATE,
  tran_code    VARCHAR2(12),
  edit_time    DATE not null,
  foxconn_key  VARCHAR2(100) not null,
  edit_flag    NUMBER(1)
)
;
comment on column MES4.R_MES_IFT05.if_seq
  is '???????';
comment on column MES4.R_MES_IFT05.factory
  is '??';
comment on column MES4.R_MES_IFT05.ems_order_id
  is 'WO';
comment on column MES4.R_MES_IFT05.raw_lot_id
  is 'TR_SN';
comment on column MES4.R_MES_IFT05.raw_mat_id
  is 'CUST_KP_NO';
comment on column MES4.R_MES_IFT05.qty
  is '????';
comment on column MES4.R_MES_IFT05.line_id
  is '??';
comment on column MES4.R_MES_IFT05.res_id
  is '??';
comment on column MES4.R_MES_IFT05.mount_type
  is '????,??/??/???';
comment on column MES4.R_MES_IFT05.slot
  is 'FEEDER?';
comment on column MES4.R_MES_IFT05.res_slot
  is '???';
comment on column MES4.R_MES_IFT05.tran_time
  is '?????';
comment on column MES4.R_MES_IFT05.tran_code
  is '?? - ''INPUT''
?? - ''OUTPUT''';
comment on column MES4.R_MES_IFT05.edit_time
  is '???????';
comment on column MES4.R_MES_IFT05.foxconn_key
  is '??????????.??????.';
comment on column MES4.R_MES_IFT05.edit_flag
  is '???????';
create index MES4.R_MES_IFT05_EMS_ORDER_ID on MES4.R_MES_IFT05 (EMS_ORDER_ID);
create index MES4.R_MES_IFT05_FACTORY on MES4.R_MES_IFT05 (FACTORY);
create index MES4.R_MES_IFT05_IF_SEQ on MES4.R_MES_IFT05 (IF_SEQ);
create index MES4.R_MES_IFT05_LINE_ID on MES4.R_MES_IFT05 (LINE_ID);
create index MES4.R_MES_IFT05_MOUNT_TYPE on MES4.R_MES_IFT05 (MOUNT_TYPE);
create index MES4.R_MES_IFT05_QTY on MES4.R_MES_IFT05 (QTY);
create index MES4.R_MES_IFT05_RAW_LOT_ID on MES4.R_MES_IFT05 (RAW_LOT_ID);
create index MES4.R_MES_IFT05_RAW_MAT_ID on MES4.R_MES_IFT05 (RAW_MAT_ID);
create index MES4.R_MES_IFT05_RES_ID on MES4.R_MES_IFT05 (RES_ID);
create index MES4.R_MES_IFT05_SLOT on MES4.R_MES_IFT05 (SLOT);
create index MES4.R_MES_IFT05_TRAN_CODE on MES4.R_MES_IFT05 (TRAN_CODE);
create index MES4.R_MES_IFT05_TRAN_TIME on MES4.R_MES_IFT05 (TRAN_TIME);
grant select, insert, update, delete, alter, index on MES4.R_MES_IFT05 to MES1;

prompt
prompt Creating table R_MES_IFT06
prompt ==========================
prompt
create table MES4.R_MES_IFT06
(
  if_seq         NUMBER(12) not null,
  move_flag      CHAR(1),
  move_time      DATE,
  lot_id         VARCHAR2(25) not null,
  ems_order_id   VARCHAR2(25) not null,
  oper           VARCHAR2(10),
  line_id        VARCHAR2(20),
  res_id         VARCHAR2(20),
  mother_lot_id  VARCHAR2(25),
  pass_fail_flag VARCHAR2(20),
  defect_code    VARCHAR2(10),
  tran_time      DATE,
  tran_comment   VARCHAR2(50),
  tran_user_id   VARCHAR2(20),
  edit_time      DATE not null,
  edit_flag      NUMBER(1),
  foxconn_key    VARCHAR2(50) not null
)
;
comment on column MES4.R_MES_IFT06.move_flag
  is 'MOVE_FLAG';
comment on column MES4.R_MES_IFT06.move_time
  is 'MOVE_TIME';
comment on column MES4.R_MES_IFT06.lot_id
  is '?????,P_SN';
comment on column MES4.R_MES_IFT06.ems_order_id
  is 'WO';
comment on column MES4.R_MES_IFT06.oper
  is '????';
comment on column MES4.R_MES_IFT06.line_id
  is '??';
comment on column MES4.R_MES_IFT06.res_id
  is '???';
comment on column MES4.R_MES_IFT06.mother_lot_id
  is '????';
comment on column MES4.R_MES_IFT06.pass_fail_flag
  is '????????????.P??F';
comment on column MES4.R_MES_IFT06.defect_code
  is '????';
comment on column MES4.R_MES_IFT06.tran_time
  is '????';
comment on column MES4.R_MES_IFT06.tran_comment
  is '????';
comment on column MES4.R_MES_IFT06.tran_user_id
  is '???';
create index MES4.R_MES_IFT06_DEFECT_CODE on MES4.R_MES_IFT06 (DEFECT_CODE)
  nologging;
create index MES4.R_MES_IFT06_EMS_ORDER_ID on MES4.R_MES_IFT06 (EMS_ORDER_ID)
  nologging;
create index MES4.R_MES_IFT06_IF_SEQ on MES4.R_MES_IFT06 (IF_SEQ)
  nologging;
create index MES4.R_MES_IFT06_LOT_ID on MES4.R_MES_IFT06 (LOT_ID)
  nologging;
create index MES4.R_MES_IFT06_MOVE_FLAG on MES4.R_MES_IFT06 (MOVE_FLAG)
  nologging;
create index MES4.R_MES_IFT06_MOVE_TIME on MES4.R_MES_IFT06 (MOVE_TIME)
  nologging;
create index MES4.R_MES_IFT06_PASS_FAIL_FLAG on MES4.R_MES_IFT06 (PASS_FAIL_FLAG)
  nologging;
create index MES4.R_MES_IFT06_TRAN_TIME on MES4.R_MES_IFT06 (TRAN_TIME)
  nologging;
alter table MES4.R_MES_IFT06
  add constraint R_IFT06_KEY primary key (IF_SEQ);
grant select, insert, update, delete, alter, index on MES4.R_MES_IFT06 to MES1;

prompt
prompt Creating table R_MES_IFT07
prompt ==========================
prompt
create table MES4.R_MES_IFT07
(
  if_seq       NUMBER(12) not null,
  move_flag    CHAR(1),
  move_time    DATE,
  raw_lot_id   VARCHAR2(128) not null,
  ems_order_id VARCHAR2(25) not null,
  lot_id       VARCHAR2(10) not null,
  use_qty      NUMBER(10,3),
  tran_time    DATE,
  tran_user_id VARCHAR2(20),
  edit_time    DATE not null,
  edit_flag    NUMBER(1)
)
;
comment on column MES4.R_MES_IFT07.move_flag
  is 'MOVE_FLAG';
comment on column MES4.R_MES_IFT07.move_time
  is 'MOVE_TIME';
comment on column MES4.R_MES_IFT07.raw_lot_id
  is 'TR_SN';
comment on column MES4.R_MES_IFT07.ems_order_id
  is 'WO';
comment on column MES4.R_MES_IFT07.lot_id
  is '?????,P_SN';
comment on column MES4.R_MES_IFT07.use_qty
  is '????';
comment on column MES4.R_MES_IFT07.tran_time
  is '????';
comment on column MES4.R_MES_IFT07.tran_user_id
  is '???';
create index MES4.R_MES_IFT07_EMS_ORDER_ID on MES4.R_MES_IFT07 (EMS_ORDER_ID)
  nologging;
create index MES4.R_MES_IFT07_IF_SEQ on MES4.R_MES_IFT07 (IF_SEQ)
  nologging;
create index MES4.R_MES_IFT07_LOT_ID on MES4.R_MES_IFT07 (LOT_ID)
  nologging;
create index MES4.R_MES_IFT07_MOVE_FLAG on MES4.R_MES_IFT07 (MOVE_FLAG)
  nologging;
create index MES4.R_MES_IFT07_MOVE_TIME on MES4.R_MES_IFT07 (MOVE_TIME)
  nologging;
create index MES4.R_MES_IFT07_RAW_LOT_ID on MES4.R_MES_IFT07 (RAW_LOT_ID)
  nologging;
create index MES4.R_MES_IFT07_TRAN_TIME on MES4.R_MES_IFT07 (TRAN_TIME)
  nologging;
create index MES4.R_MES_IFT07_USE_QTY on MES4.R_MES_IFT07 (USE_QTY)
  nologging;
alter table MES4.R_MES_IFT07
  add constraint R_IFT07_KEY primary key (IF_SEQ);
grant select, insert, update, delete, alter, index on MES4.R_MES_IFT07 to MES1;

prompt
prompt Creating table R_MRB
prompt ====================
prompt
create table MES4.R_MRB
(
  plant            VARCHAR2(6) not null,
  doc_no           VARCHAR2(15) not null,
  po_no            VARCHAR2(15),
  cust_kp_no       VARCHAR2(20) not null,
  cust_code        VARCHAR2(15),
  mfr_kp_no        VARCHAR2(100),
  mfr_code         VARCHAR2(15),
  buyer_code       VARCHAR2(3) not null,
  buyer_name       VARCHAR2(18) not null,
  grn_no           VARCHAR2(15),
  move_qty         NUMBER(10) not null,
  unit_price       NUMBER(10,3) not null,
  currency         VARCHAR2(5) not null,
  unit             VARCHAR2(6) not null,
  move_type        VARCHAR2(3) not null,
  from_location    VARCHAR2(4) not null,
  to_location      VARCHAR2(12) not null,
  move_flag        VARCHAR2(1) not null,
  move_time        DATE not null,
  qc_emp           VARCHAR2(10),
  waive_flag       VARCHAR2(1) default '0' not null,
  waive_no         VARCHAR2(25),
  deviation_period VARCHAR2(25),
  download_time    DATE not null,
  work_time        DATE
)
;
create index MES4.R_MRBCUST_KP_NO on MES4.R_MRB (CUST_KP_NO);
create index MES4.R_MRBDOC_NO on MES4.R_MRB (DOC_NO);
create index MES4.R_MRBGRN_NO on MES4.R_MRB (GRN_NO);
create index MES4.R_MRBMFR_CODE on MES4.R_MRB (MFR_CODE);
create index MES4.R_MRBMFR_KP_NO on MES4.R_MRB (MFR_KP_NO);
create index MES4.R_MRBWORK_TIME on MES4.R_MRB (WORK_TIME);
grant select, insert, update, delete, references, alter, index on MES4.R_MRB to MES1;

prompt
prompt Creating table R_MRB_APPLY
prompt ==========================
prompt
create table MES4.R_MRB_APPLY
(
  doc_no        VARCHAR2(15) not null,
  cust_kp_no    VARCHAR2(30) not null,
  mfr_code      VARCHAR2(25) not null,
  mfr_kp_no     VARCHAR2(100),
  apply_type    VARCHAR2(30) not null,
  apply_reason  VARCHAR2(100),
  apply_qty     NUMBER(10),
  date_code     VARCHAR2(20),
  lot_code      VARCHAR2(30),
  move_type     VARCHAR2(10),
  from_location VARCHAR2(10),
  to_location   VARCHAR2(10),
  from_bu       VARCHAR2(10),
  owner_name    VARCHAR2(20),
  operate_type  VARCHAR2(10),
  attachment    VARCHAR2(200),
  edit_name     VARCHAR2(10) not null,
  download_time DATE,
  accept_name   VARCHAR2(10),
  accept_time   DATE,
  doc_status    CHAR(10) not null,
  wo            VARCHAR2(20),
  remark        VARCHAR2(200),
  apply_class   VARCHAR2(100)
)
;
grant select, insert, update on MES4.R_MRB_APPLY to MES1;

prompt
prompt Creating table R_MRB_CHANGE
prompt ===========================
prompt
create table MES4.R_MRB_CHANGE
(
  doc_no        VARCHAR2(12) not null,
  cust_kp_no    VARCHAR2(20) not null,
  cust_code     VARCHAR2(15),
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  date_code     VARCHAR2(20),
  lot_code      VARCHAR2(20),
  reject_qty    NUMBER(10) not null,
  reject_reason VARCHAR2(120),
  work_flag     VARCHAR2(1) not null,
  change_flag   VARCHAR2(1) not null,
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_MRB_CHANGE to MES1;

prompt
prompt Creating table R_MRB_CYCLECOUNT
prompt ===============================
prompt
create table MES4.R_MRB_CYCLECOUNT
(
  cyclecount_time DATE,
  cust_kp_no      VARCHAR2(20),
  owner_name      VARCHAR2(20),
  real_number     VARCHAR2(25),
  work_time       DATE,
  remake          VARCHAR2(40),
  location        VARCHAR2(50),
  floor           VARCHAR2(20),
  work_flag       NUMBER
)
;
grant select, insert, update, delete on MES4.R_MRB_CYCLECOUNT to MES1;

prompt
prompt Creating table R_MRB_DETAIL
prompt ===========================
prompt
create table MES4.R_MRB_DETAIL
(
  doc_no       VARCHAR2(20) not null,
  cust_kp_no   VARCHAR2(20),
  mfr_code     VARCHAR2(20),
  mfr_kp_no    VARCHAR2(100),
  move_type    VARCHAR2(40),
  move_flag    VARCHAR2(2),
  qty          NUMBER not null,
  move_remark  VARCHAR2(230),
  edit_emp     VARCHAR2(25),
  edit_time    DATE,
  mrb_stock    VARCHAR2(10),
  apply_remark VARCHAR2(160),
  apply_emp    VARCHAR2(10)
)
;
grant insert on MES4.R_MRB_DETAIL to MES1;

prompt
prompt Creating table R_MRB_DOC_TMP
prompt ============================
prompt
create table MES4.R_MRB_DOC_TMP
(
  sapdoc       VARCHAR2(20),
  plant        VARCHAR2(10),
  stgno        VARCHAR2(10),
  item_no      VARCHAR2(40),
  stgnum       NUMBER,
  uom          VARCHAR2(5),
  stgsum       NUMBER(16,2),
  downdate     DATE,
  mvtype       VARCHAR2(3),
  postdate     DATE,
  prctr        VARCHAR2(10),
  currency     VARCHAR2(5),
  usedflg      CHAR(1) default 'N',
  mvflag       VARCHAR2(10),
  cust_kp_desc VARCHAR2(100)
)
;
grant select, insert, update, delete on MES4.R_MRB_DOC_TMP to MES1;

prompt
prompt Creating table R_MRB_GRN
prompt ========================
prompt
create table MES4.R_MRB_GRN
(
  doc_no        VARCHAR2(20) not null,
  cust_kp_no    VARCHAR2(20) not null,
  po_no         VARCHAR2(20) not null,
  mfr_code      VARCHAR2(25) not null,
  mfr_kp_no     VARCHAR2(100) not null,
  receive_qty   NUMBER(10) not null,
  floor         VARCHAR2(10),
  stock         VARCHAR2(6),
  receive_time  DATE,
  iqc_emp       VARCHAR2(10),
  iqc_remark    VARCHAR2(500),
  iqc_time      DATE,
  reject_qty    NUMBER(10) not null,
  completed_qty NUMBER(10) not null,
  pending_qty   NUMBER(10) not null,
  buyer_remark  VARCHAR2(160),
  buyer         VARCHAR2(10),
  buyer_time    DATE,
  closed_time   DATE,
  work_flag     VARCHAR2(2) default '0' not null,
  owner_name    VARCHAR2(60),
  accept_name   VARCHAR2(10),
  kp_bu         VARCHAR2(10),
  location      VARCHAR2(50),
  mrb_stock     VARCHAR2(10)
)
;
grant select, insert, update on MES4.R_MRB_GRN to MES1;

prompt
prompt Creating table R_MRB_IN
prompt =======================
prompt
create table MES4.R_MRB_IN
(
  doc_no        VARCHAR2(20) not null,
  type          VARCHAR2(12) not null,
  edit_emp      VARCHAR2(12) not null,
  cust_kp_no    VARCHAR2(50) not null,
  mfr_name      VARCHAR2(50) not null,
  qty           NUMBER not null,
  from_location VARCHAR2(10),
  wo            VARCHAR2(15),
  to_location   VARCHAR2(10),
  material_type VARCHAR2(100) not null,
  doc_status    VARCHAR2(50) default 'Ready' not null,
  sap_result    VARCHAR2(500),
  sap_no        VARCHAR2(50),
  edit_time     DATE not null,
  work_flag     VARCHAR2(5),
  move_type     VARCHAR2(5)
)
;
grant select, insert, update, delete on MES4.R_MRB_IN to MES1;

prompt
prompt Creating table R_MRB_INOUT
prompt ==========================
prompt
create table MES4.R_MRB_INOUT
(
  grn_no      VARCHAR2(20) not null,
  doc_no      VARCHAR2(12),
  cust_kp_no  VARCHAR2(20) not null,
  move_type   VARCHAR2(40) not null,
  move_code   VARCHAR2(10) not null,
  from_stock  VARCHAR2(10) not null,
  to_stock    VARCHAR2(10) not null,
  qty         NUMBER(10) not null,
  move_remark VARCHAR2(160),
  move_result VARCHAR2(160),
  edit_emp    VARCHAR2(25),
  edit_time   DATE
)
;
grant insert on MES4.R_MRB_INOUT to MES1;

prompt
prompt Creating table R_MRB_LINEPURG
prompt =============================
prompt
create table MES4.R_MRB_LINEPURG
(
  doc_no         VARCHAR2(20),
  mrb_doc_no     VARCHAR2(20),
  defect_type    VARCHAR2(20) not null,
  move_type      VARCHAR2(5) not null,
  owner          VARCHAR2(20),
  cust_kp_no     VARCHAR2(20),
  from_location  VARCHAR2(10),
  to_location    VARCHAR2(10),
  mpn            VARCHAR2(50),
  mfr_name       VARCHAR2(100),
  description    VARCHAR2(100),
  reason         VARCHAR2(200),
  reply          VARCHAR2(200),
  data_code      VARCHAR2(20),
  lot_code       VARCHAR2(20),
  qty            NUMBER,
  wo             VARCHAR2(20),
  edit_date      DATE,
  work_flag      VARCHAR2(10),
  sap_flag       VARCHAR2(20),
  edit_emp       VARCHAR2(25),
  apply_emp      VARCHAR2(25),
  bu             VARCHAR2(10),
  fol_mpn        VARCHAR2(100),
  brand          VARCHAR2(20),
  model_date     VARCHAR2(20),
  coo            VARCHAR2(100),
  cusoms_element VARCHAR2(200)
)
;
grant select, insert, update, delete on MES4.R_MRB_LINEPURG to MES1;

prompt
prompt Creating table R_MRB_LOCATION
prompt =============================
prompt
create table MES4.R_MRB_LOCATION
(
  cust_kp_no VARCHAR2(50),
  qty        VARCHAR2(20),
  stock      VARCHAR2(20),
  location   VARCHAR2(50),
  status     VARCHAR2(20),
  work_time  DATE,
  edit_emp   VARCHAR2(20),
  remarks    VARCHAR2(100)
)
;
grant select, insert, update, delete on MES4.R_MRB_LOCATION to MES1;

prompt
prompt Creating table R_MRB_NO
prompt =======================
prompt
create table MES4.R_MRB_NO
(
  mrb_no        VARCHAR2(20) not null,
  edit_emp      VARCHAR2(12) not null,
  doc_no        VARCHAR2(12) not null,
  cust_kp_no    VARCHAR2(50) not null,
  alter_kp_no   VARCHAR2(50),
  qty           NUMBER not null,
  from_location VARCHAR2(10) not null,
  material_type VARCHAR2(100) not null,
  doc_status    VARCHAR2(50) default 'Ready' not null,
  sap_result    VARCHAR2(500),
  sap_no        VARCHAR2(50),
  edit_time     DATE not null
)
;
grant select, insert, update, delete on MES4.R_MRB_NO to MES1;

prompt
prompt Creating table R_MRB_REJECT
prompt ===========================
prompt
create table MES4.R_MRB_REJECT
(
  plant         VARCHAR2(6),
  doc_no        VARCHAR2(12) not null,
  cust_kp_no    VARCHAR2(20) not null,
  cust_code     VARCHAR2(15),
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  date_code     VARCHAR2(20),
  lot_code      VARCHAR2(20),
  reject_qty    NUMBER(10) not null,
  reject_reason VARCHAR2(120),
  work_flag     VARCHAR2(1) not null,
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null
)
;
create index MES4.R_MRB_REJECT_CUST_KP_NO on MES4.R_MRB_REJECT (CUST_KP_NO)
  nologging;
create index MES4.R_MRB_REJECT_DATE_CODE on MES4.R_MRB_REJECT (DATE_CODE)
  nologging;
create index MES4.R_MRB_REJECT_DOC_NO on MES4.R_MRB_REJECT (DOC_NO)
  nologging;
create index MES4.R_MRB_REJECT_LOT_CODE on MES4.R_MRB_REJECT (LOT_CODE)
  nologging;
create index MES4.R_MRB_REJECT_MFR_CODE on MES4.R_MRB_REJECT (MFR_CODE)
  nologging;
create index MES4.R_MRB_REJECT_MFR_KP_NO on MES4.R_MRB_REJECT (MFR_KP_NO)
  nologging;
create index MES4.R_MRB_REJECT_WORK_TIME on MES4.R_MRB_REJECT (WORK_TIME)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.R_MRB_REJECT to MES1;

prompt
prompt Creating table R_MRB_REPAIR
prompt ===========================
prompt
create table MES4.R_MRB_REPAIR
(
  doc_no               VARCHAR2(20),
  mrb_doc_no           VARCHAR2(20),
  defect_type          VARCHAR2(20) not null,
  move_type            VARCHAR2(10) not null,
  owner                VARCHAR2(20),
  wh_cord              VARCHAR2(20),
  cust_kp_no           VARCHAR2(20),
  mfr_name             VARCHAR2(100),
  description          VARCHAR2(100),
  reason               VARCHAR2(200),
  reply                VARCHAR2(200),
  data_code            VARCHAR2(20),
  lot_code             VARCHAR2(20),
  qty                  NUMBER,
  edit_date            DATE,
  work_flag            VARCHAR2(10),
  sap_flag             VARCHAR2(10),
  sn_of_pcba           VARCHAR2(25),
  sn_of_sys            VARCHAR2(25),
  station              VARCHAR2(25),
  location             VARCHAR2(10),
  device_id            VARCHAR2(25),
  repairer             VARCHAR2(10),
  department_cost_code VARCHAR2(25),
  edit_emp             VARCHAR2(25),
  apply_emp            VARCHAR2(25),
  bu                   VARCHAR2(10),
  fol_mpn              VARCHAR2(15),
  mpn                  VARCHAR2(20),
  brand                VARCHAR2(20),
  model                VARCHAR2(20),
  fail_symptom         VARCHAR2(300),
  cusoms_element       VARCHAR2(300),
  country_of_origin    VARCHAR2(50),
  skumodel             VARCHAR2(50)
)
;
grant select, insert, update, delete on MES4.R_MRB_REPAIR to MES1;

prompt
prompt Creating table R_MRB_SAP
prompt ========================
prompt
create table MES4.R_MRB_SAP
(
  grn_no        VARCHAR2(20) not null,
  doc_no        VARCHAR2(12),
  cust_kp_no    VARCHAR2(20) not null,
  move_type     VARCHAR2(40) not null,
  move_code     VARCHAR2(10) not null,
  from_stock    VARCHAR2(10) not null,
  to_stock      VARCHAR2(10) not null,
  qty           NUMBER(10) not null,
  move_remark   VARCHAR2(160),
  move_result   VARCHAR2(160),
  fail_times    NUMBER(7) default 0 not null,
  edit_emp      VARCHAR2(25),
  edit_time     DATE,
  closed        VARCHAR2(1) default '0' not null,
  closed_time   DATE,
  repair_times  NUMBER(7) default 0,
  feedback_msg  VARCHAR2(160),
  feedback_emp  VARCHAR2(10),
  feedback_time DATE,
  doc_event     VARCHAR2(20)
)
;
grant select, insert, update, delete on MES4.R_MRB_SAP to MES1;

prompt
prompt Creating table R_MRB_SAP_REPAIR
prompt ===============================
prompt
create table MES4.R_MRB_SAP_REPAIR
(
  grn_no    VARCHAR2(12) not null,
  move_code VARCHAR2(10) not null,
  edit_emp  VARCHAR2(25),
  edit_time DATE
)
;
grant select, insert, update, delete on MES4.R_MRB_SAP_REPAIR to MES1;

prompt
prompt Creating table R_MSD_KP_CONTROL
prompt ===============================
prompt
create table MES4.R_MSD_KP_CONTROL
(
  tr_sn         VARCHAR2(12) not null,
  location_flag VARCHAR2(1) not null,
  total_time    NUMBER(10,5) not null,
  action_code   VARCHAR2(2) not null,
  work_flag     VARCHAR2(1) not null,
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null,
  kp_level      VARCHAR2(4) not null,
  roast_type    VARCHAR2(5)
)
;
alter table MES4.R_MSD_KP_CONTROL
  add primary key (TR_SN);
grant select, insert, update, delete on MES4.R_MSD_KP_CONTROL to MES1;

prompt
prompt Creating table R_MSD_KP_DETAIL
prompt ==============================
prompt
create table MES4.R_MSD_KP_DETAIL
(
  tr_sn         VARCHAR2(12) not null,
  location_flag VARCHAR2(1) not null,
  total_time    NUMBER(10,5) not null,
  action_code   VARCHAR2(2) not null,
  kp_flag       VARCHAR2(1) not null,
  work_flag     VARCHAR2(1) not null,
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null,
  roast_type    VARCHAR2(5)
)
;
grant select, insert, update, delete on MES4.R_MSD_KP_DETAIL to MES1;

prompt
prompt Creating table R_NCMR_REJECT
prompt ============================
prompt
create table MES4.R_NCMR_REJECT
(
  doc_no              VARCHAR2(20) not null,
  reject_reason       VARCHAR2(500),
  attach_path         VARCHAR2(100),
  department          VARCHAR2(200),
  reject_emailto      VARCHAR2(100),
  status              VARCHAR2(1) default 0,
  reject_emp          VARCHAR2(20),
  reject_date         DATE,
  reject_emailaddress VARCHAR2(1000),
  ncmr_no             VARCHAR2(20),
  owner_dpt           VARCHAR2(30),
  iqc_result          VARCHAR2(20),
  reject_dpt          VARCHAR2(20),
  reject_qty          NUMBER(10) default '0',
  waive_qty           NUMBER(10) default '0',
  mrb_stock           VARCHAR2(10),
  due_date            DATE,
  vdcs_no             VARCHAR2(20),
  work_flag           VARCHAR2(1),
  owner_empno         VARCHAR2(50),
  attach_iqc_path     VARCHAR2(100),
  unusual_type        VARCHAR2(500),
  heigth_risk         CHAR(1),
  unusual_reason      VARCHAR2(500),
  blame               VARCHAR2(500)
)
;
create index MES4.IDXR_NCMR_REJECT1 on MES4.R_NCMR_REJECT (DOC_NO)
  nologging;
grant select, insert, update, delete on MES4.R_NCMR_REJECT to MES1;

prompt
prompt Creating table R_NCMR_REJECT_ACTION
prompt ===================================
prompt
create table MES4.R_NCMR_REJECT_ACTION
(
  doc_no           VARCHAR2(20),
  eng_remark       VARCHAR2(500),
  eng_emailto      VARCHAR2(100),
  eng_emp          VARCHAR2(30),
  eng_editdate     DATE,
  qa_result        VARCHAR2(10),
  qa_remark        VARCHAR2(500),
  qa_emailto       VARCHAR2(100),
  qa_emp           VARCHAR2(20),
  qa_editdate      DATE,
  flag             VARCHAR2(1) default 0,
  qa_emailaddress  VARCHAR2(1000),
  eng_emailaddress VARCHAR2(1000),
  ncmr_no          VARCHAR2(20),
  class_leader     VARCHAR2(50),
  leader_result    VARCHAR2(10),
  leader_remark    VARCHAR2(500)
)
;
grant select, insert, update, delete on MES4.R_NCMR_REJECT_ACTION to MES1;

prompt
prompt Creating table R_NCMR_REJECT_REASON
prompt ===================================
prompt
create table MES4.R_NCMR_REJECT_REASON
(
  doc_no         VARCHAR2(20) not null,
  unusual_type   VARCHAR2(500),
  unusual_reason VARCHAR2(500),
  blame          VARCHAR2(20),
  data1          VARCHAR2(100),
  data2          VARCHAR2(100),
  edit_emp       VARCHAR2(20),
  edit_time      DATE
)
;
create index MES4.IDXR_NCMR_REJECT_REASON1 on MES4.R_NCMR_REJECT_REASON (DOC_NO)
  nologging;
grant select, insert, update, delete on MES4.R_NCMR_REJECT_REASON to MES1;

prompt
prompt Creating table R_NCMR_SQE
prompt =========================
prompt
create table MES4.R_NCMR_SQE
(
  doc_no       VARCHAR2(12) not null,
  ncmr_no      VARCHAR2(20) not null,
  issue        VARCHAR2(5),
  sqe_reason   VARCHAR2(500),
  supplier8d   VARCHAR2(5) default '0',
  due_date     DATE,
  emailaddress VARCHAR2(1000),
  edit_emp     VARCHAR2(20) not null,
  edit_time    DATE,
  status       VARCHAR2(10) not null
)
;
grant select, insert, update, delete on MES4.R_NCMR_SQE to MES1;

prompt
prompt Creating table R_OTHER_INSPECTION
prompt =================================
prompt
create table MES4.R_OTHER_INSPECTION
(
  doc_no               VARCHAR2(20) not null,
  date_code            VARCHAR2(40),
  mfr_kp_no_1          VARCHAR2(80),
  mfr_name_1           VARCHAR2(100),
  shelf_life_1         VARCHAR2(40),
  qualify_status_1     VARCHAR2(20),
  rohs_status_1        VARCHAR2(30),
  package_1            VARCHAR2(300),
  package_2            VARCHAR2(300),
  package_3            VARCHAR2(300),
  visual_1             VARCHAR2(300),
  visual_2             VARCHAR2(300),
  cfd1                 VARCHAR2(300),
  cfd2                 VARCHAR2(300),
  cfd3                 VARCHAR2(300),
  cfd4                 VARCHAR2(300),
  surface_markup       VARCHAR2(300),
  test1                VARCHAR2(300),
  test2                VARCHAR2(300),
  test3                VARCHAR2(300),
  msl                  VARCHAR2(300),
  information          VARCHAR2(30),
  type                 VARCHAR2(20),
  final_judgement      VARCHAR2(3),
  edit_emp             VARCHAR2(25),
  inspection_date      DATE,
  kpno_config_time     DATE,
  cust_kp_no           VARCHAR2(20),
  mfr_name             VARCHAR2(100),
  kp_type              VARCHAR2(10),
  insp_category        VARCHAR2(20),
  version              VARCHAR2(10),
  cfd5                 VARCHAR2(300),
  cfd6                 VARCHAR2(300),
  attachfile           VARCHAR2(50),
  add_remark           VARCHAR2(500),
  edit_emp_no          VARCHAR2(15),
  surface_inspection   VARCHAR2(300),
  surface_color        VARCHAR2(300),
  cust_kp_remrk        VARCHAR2(1024),
  aql                  VARCHAR2(10),
  mbb_date             VARCHAR2(20),
  mbb_mark             VARCHAR2(50),
  board_d1_falg        VARCHAR2(3),
  board_d2_falg        VARCHAR2(3),
  board_d3_falg        VARCHAR2(3),
  board_d4_falg        VARCHAR2(3),
  board_d5_falg        VARCHAR2(3),
  plated_add1_flag     VARCHAR2(3),
  plated_add2_flag     VARCHAR2(3),
  plated_add3_flag     VARCHAR2(3),
  non_plated_add1_flag VARCHAR2(3),
  non_plated_add2_flag VARCHAR2(3),
  checkemp             VARCHAR2(15),
  approvemp            VARCHAR2(15),
  mbb_flag             VARCHAR2(3),
  bag_flag             VARCHAR2(3),
  mbb_result           VARCHAR2(3),
  equipment_no         VARCHAR2(50),
  lot_code             VARCHAR2(100)
)
;
create index MES4.IX_R_OTHER_INSPECTION_DOC_NO on MES4.R_OTHER_INSPECTION (DOC_NO);
grant select, insert, update, delete on MES4.R_OTHER_INSPECTION to MES1;

prompt
prompt Creating table R_OTHER_INSPECTION_EXTEND
prompt ========================================
prompt
create table MES4.R_OTHER_INSPECTION_EXTEND
(
  doc_no          VARCHAR2(20) not null,
  cfd7            VARCHAR2(300),
  cfd8            VARCHAR2(300),
  cfd9            VARCHAR2(300),
  cfd10           VARCHAR2(300),
  apply_date      DATE,
  inspection_vi   VARCHAR2(40),
  sampling_vi     VARCHAR2(40),
  aql_vi          VARCHAR2(40),
  ac_vi           VARCHAR2(40),
  re_vi           VARCHAR2(40),
  inspection_dm   VARCHAR2(40),
  sampling_dm     VARCHAR2(40),
  aql_dm          VARCHAR2(40),
  ac_dm           VARCHAR2(40),
  re_dm           VARCHAR2(40),
  inspection_fi   VARCHAR2(40),
  sampling_fi     VARCHAR2(40),
  aql_fi          VARCHAR2(40),
  ac_fi           VARCHAR2(40),
  re_fi           VARCHAR2(40),
  cust_kp_no_desc VARCHAR2(100),
  cfd11           VARCHAR2(300),
  cfd12           VARCHAR2(300),
  cfd13           VARCHAR2(300),
  cfd14           VARCHAR2(300),
  cfd15           VARCHAR2(300),
  cfd16           VARCHAR2(300),
  cfd17           VARCHAR2(300),
  cfd18           VARCHAR2(300)
)
;
create index MES4.IX_R_OTHER_INSPECTION_DN on MES4.R_OTHER_INSPECTION_EXTEND (DOC_NO);
grant select, insert, update, delete on MES4.R_OTHER_INSPECTION_EXTEND to MES1;

prompt
prompt Creating table R_PAPERLESS_DATA
prompt ===============================
prompt
create table MES4.R_PAPERLESS_DATA
(
  line_name   VARCHAR2(15) not null,
  p_no        VARCHAR2(50),
  p_sn        VARCHAR2(50),
  wo          VARCHAR2(12),
  status      VARCHAR2(20) not null,
  error_class VARCHAR2(50) not null,
  error_code  VARCHAR2(50),
  error_cat   VARCHAR2(100),
  error_desc  VARCHAR2(300),
  emp_no      VARCHAR2(20),
  time        DATE,
  unlock_emp  VARCHAR2(20),
  unlock_time DATE
)
;
create index MES4.R_PAPERLESS_DATA_ERROR_CLASS on MES4.R_PAPERLESS_DATA (ERROR_CLASS);
create index MES4.R_PAPERLESS_DATA_LINE on MES4.R_PAPERLESS_DATA (LINE_NAME);
create index MES4.R_PAPERLESS_DATA_STATUS on MES4.R_PAPERLESS_DATA (STATUS);
create index MES4.R_PAPERLESS_DATA_TIME on MES4.R_PAPERLESS_DATA (TIME);
grant select, insert, update, delete on MES4.R_PAPERLESS_DATA to MES1;

prompt
prompt Creating table R_PCBA_LINK
prompt ==========================
prompt
create table MES4.R_PCBA_LINK
(
  skuno      VARCHAR2(30) not null,
  pcba_skuno VARCHAR2(30) not null,
  editby     VARCHAR2(20),
  editdt     DATE
)
;
grant select, insert, update, delete on MES4.R_PCBA_LINK to MES1;

prompt
prompt Creating table R_PCB_INSPECTION
prompt ===============================
prompt
create table MES4.R_PCB_INSPECTION
(
  doc_no            VARCHAR2(20) not null,
  date_code         VARCHAR2(20),
  mfr_kp_no_1       VARCHAR2(300),
  mfr_name_1        VARCHAR2(100),
  shelf_life_1      VARCHAR2(15),
  qualify_status_1  VARCHAR2(20),
  rohs_status_1     VARCHAR2(15),
  package_1         VARCHAR2(300),
  package_2         VARCHAR2(300),
  package_3         VARCHAR2(300),
  visual_1          VARCHAR2(300),
  visual_2          VARCHAR2(300),
  visual_3          VARCHAR2(300),
  visual_4          VARCHAR2(300),
  visual_5          VARCHAR2(300),
  board_1           VARCHAR2(300),
  board_2           VARCHAR2(300),
  board_3           VARCHAR2(300),
  plated_1          VARCHAR2(300),
  plated_2          VARCHAR2(300),
  plated_3          VARCHAR2(300),
  non_plated_1      VARCHAR2(300),
  non_plated_2      VARCHAR2(300),
  functional_1      VARCHAR2(300),
  functional_2      VARCHAR2(300),
  functional_3      VARCHAR2(300),
  functional_4      VARCHAR2(300),
  functional_5      VARCHAR2(300),
  functional_6      VARCHAR2(300),
  functional_7      VARCHAR2(300),
  final_judgement   VARCHAR2(3) not null,
  edit_emp          VARCHAR2(25) not null,
  inspection_date   DATE not null,
  kpno_config_time  DATE not null,
  cust_kp_no        VARCHAR2(20) not null,
  mfr_name          VARCHAR2(100),
  kp_type           VARCHAR2(10),
  insp_category     VARCHAR2(20),
  version           VARCHAR2(10),
  plated_4          VARCHAR2(300),
  non_plated_3      VARCHAR2(300),
  non_plated_4      VARCHAR2(300),
  other_cfd         VARCHAR2(300),
  surface_type      VARCHAR2(10),
  valid_date        VARCHAR2(20),
  penalization_flag VARCHAR2(3),
  attachfile        VARCHAR2(50),
  add_remark        VARCHAR2(500),
  edit_emp_no       VARCHAR2(20),
  amination         VARCHAR2(20) not null,
  mot               VARCHAR2(20) not null,
  compliance        VARCHAR2(10) not null,
  msl               VARCHAR2(300),
  cust_kp_remrk     VARCHAR2(1024),
  d1                VARCHAR2(300),
  d2                VARCHAR2(300),
  d3                VARCHAR2(300),
  d4                VARCHAR2(300),
  d5                VARCHAR2(300),
  plated_5          VARCHAR2(300),
  plated_6          VARCHAR2(300),
  final_judgevalue  VARCHAR2(500),
  purge_info        VARCHAR2(1024),
  aql               VARCHAR2(10),
  customer          VARCHAR2(20),
  equipment_no      VARCHAR2(50),
  lot_code          VARCHAR2(100),
  ul_model          VARCHAR2(100),
  ul_fireproof      VARCHAR2(100)
)
;
create index MES4.R_PCB_INSPECTION_DOC_NO on MES4.R_PCB_INSPECTION (DOC_NO);
grant select, insert, update, delete on MES4.R_PCB_INSPECTION to MES1;

prompt
prompt Creating table R_PDA_GUI
prompt ========================
prompt
create table MES4.R_PDA_GUI
(
  sn    VARCHAR2(100),
  guid  VARCHAR2(100),
  data1 VARCHAR2(100),
  data2 VARCHAR2(100),
  data3 VARCHAR2(100),
  data4 VARCHAR2(100),
  data5 VARCHAR2(100),
  data6 VARCHAR2(100),
  data7 VARCHAR2(100),
  data8 VARCHAR2(100)
)
;
grant select, insert, update, delete on MES4.R_PDA_GUI to MES1;

prompt
prompt Creating table R_PROGRAM_LOG
prompt ============================
prompt
create table MES4.R_PROGRAM_LOG
(
  prg_name    VARCHAR2(25) not null,
  fun_name    VARCHAR2(25),
  action_type VARCHAR2(25),
  oldsn       VARCHAR2(50),
  newsn       VARCHAR2(50),
  out_emp     VARCHAR2(16),
  to_emp      VARCHAR2(16),
  memo        VARCHAR2(400),
  time        DATE default SYSDATE,
  data1       VARCHAR2(50),
  data2       VARCHAR2(150),
  data3       VARCHAR2(50),
  data4       VARCHAR2(50),
  data5       VARCHAR2(50),
  data6       VARCHAR2(50)
)
;
create index MES4.R_PROGRAM_LOG_ACTION_TYPE on MES4.R_PROGRAM_LOG (ACTION_TYPE);
create index MES4.R_PROGRAM_LOG_FN on MES4.R_PROGRAM_LOG (FUN_NAME);
create index MES4.R_PROGRAM_LOG_OLDSN on MES4.R_PROGRAM_LOG (OLDSN);
grant select, insert, update, delete on MES4.R_PROGRAM_LOG to MES1;

prompt
prompt Creating table R_PSN_AOI
prompt ========================
prompt
create table MES4.R_PSN_AOI
(
  bu         VARCHAR2(10),
  kp_no      VARCHAR2(20),
  event_name VARCHAR2(10),
  line_name  VARCHAR2(10),
  p_sn       VARCHAR2(25),
  wo         VARCHAR2(12),
  message    VARCHAR2(50),
  edit_time  DATE
)
;
create index MES4.IDX_R_PSN_AOI_PSN on MES4.R_PSN_AOI (P_SN)
  nologging;
create index MES4.IDX_R_PSN_AOT_ET on MES4.R_PSN_AOI (EDIT_TIME)
  nologging;
grant select, insert on MES4.R_PSN_AOI to MES1;

prompt
prompt Creating table R_PSN_FIXTURE_LINK
prompt =================================
prompt
create table MES4.R_PSN_FIXTURE_LINK
(
  fixture_sn   VARCHAR2(25),
  line_name    VARCHAR2(50) not null,
  station_name VARCHAR2(50) not null,
  wo           VARCHAR2(12) not null,
  p_sn         VARCHAR2(20) not null,
  emp          VARCHAR2(10) not null,
  work_time    DATE not null
)
;

prompt
prompt Creating table R_PSN_HISTORY
prompt ============================
prompt
create table MES4.R_PSN_HISTORY
(
  p_sn      VARCHAR2(25) not null,
  wo        VARCHAR2(12) not null,
  work_time DATE not null,
  work_flag VARCHAR2(1) default '0' not null
)
;
create index MES4.R_PSN_HISTORY_PSN on MES4.R_PSN_HISTORY (P_SN)
  nologging;
create index MES4.R_PSN_HISTORY_WO on MES4.R_PSN_HISTORY (WO)
  nologging;
grant select, insert, update, delete on MES4.R_PSN_HISTORY to MES1;

prompt
prompt Creating table R_PSN_TEMP
prompt =========================
prompt
create table MES4.R_PSN_TEMP
(
  p_sn      VARCHAR2(25) not null,
  wo        VARCHAR2(12) not null,
  work_time DATE not null,
  work_flag VARCHAR2(1) default '0' not null
)
;
grant select, insert, update, delete on MES4.R_PSN_TEMP to MES1;

prompt
prompt Creating table R_PTH_QTY_TEMP
prompt =============================
prompt
create table MES4.R_PTH_QTY_TEMP
(
  tr_sn        VARCHAR2(12) not null,
  wo           VARCHAR2(12) not null,
  kp_no        VARCHAR2(20) not null,
  station_name VARCHAR2(10) not null,
  ext_qty      NUMBER(7) not null,
  data1        VARCHAR2(25),
  data2        VARCHAR2(25),
  edit_emp     VARCHAR2(25) not null,
  edit_time    DATE not null
)
;
grant select, insert, update, delete on MES4.R_PTH_QTY_TEMP to MES1;

prompt
prompt Creating table R_PURGE_SAP_DATA
prompt ===============================
prompt
create table MES4.R_PURGE_SAP_DATA
(
  cust_kp_no VARCHAR2(50) not null,
  stock      VARCHAR2(20),
  plant      VARCHAR2(10),
  use_qty    VARCHAR2(20),
  insp_qty   VARCHAR2(20),
  snumber    VARCHAR2(20) not null,
  work_time  DATE default SYSDATE
)
;

prompt
prompt Creating table R_PURGE_SAP_DATA3
prompt ================================
prompt
create table MES4.R_PURGE_SAP_DATA3
(
  cust_kp_no VARCHAR2(30),
  plant      VARCHAR2(10),
  use_bu     VARCHAR2(20),
  where_use  VARCHAR2(30),
  snumber    VARCHAR2(20),
  work_time  DATE default SYSDATE not null
)
;

prompt
prompt Creating table R_QUADRIS_HALT
prompt =============================
prompt
create table MES4.R_QUADRIS_HALT
(
  station      VARCHAR2(10),
  wo           VARCHAR2(12),
  process_flag VARCHAR2(1),
  slot_no      VARCHAR2(7),
  halt_qty     NUMBER,
  start_time   DATE,
  end_time     DATE,
  work_flag    CHAR(1),
  standard_qty NUMBER(4) default 1
)
;
grant select, insert, update, delete, alter on MES4.R_QUADRIS_HALT to MES1;

prompt
prompt Creating table R_QUADRIS_LINK
prompt =============================
prompt
create table MES4.R_QUADRIS_LINK
(
  station      VARCHAR2(10),
  wo           VARCHAR2(12),
  process_flag CHAR(1),
  link_qty     INTEGER default 0,
  start_time   DATE
)
;
grant select, insert, update, delete, alter on MES4.R_QUADRIS_LINK to MES1;

prompt
prompt Creating table R_QUADRIS_LOG
prompt ============================
prompt
create table MES4.R_QUADRIS_LOG
(
  station      VARCHAR2(10),
  wo           VARCHAR2(12),
  process_flag CHAR(1),
  slot_no      VARCHAR2(7),
  action       VARCHAR2(200),
  err_desc     VARCHAR2(200),
  work_time    DATE,
  start_time   DATE
)
;
grant select, insert, update, delete, alter on MES4.R_QUADRIS_LOG to MES1;

prompt
prompt Creating table R_QUADRIS_REDO
prompt =============================
prompt
create table MES4.R_QUADRIS_REDO
(
  station      VARCHAR2(10),
  wo           VARCHAR2(12),
  process_flag CHAR(1),
  slot_no      VARCHAR2(7),
  seq_no       INTEGER,
  sql_block    VARCHAR2(200),
  p1           VARCHAR2(50),
  p2           VARCHAR2(50),
  p3           VARCHAR2(50),
  p4           VARCHAR2(50),
  p5           VARCHAR2(50),
  p6           VARCHAR2(50)
)
;
grant select, insert, update, delete, alter on MES4.R_QUADRIS_REDO to MES1;

prompt
prompt Creating table R_RACK_LINK_WO
prompt =============================
prompt
create table MES4.R_RACK_LINK_WO
(
  wo         VARCHAR2(12),
  rack_id    VARCHAR2(10),
  rack_side  VARCHAR2(1),
  cust_kp_no VARCHAR2(20),
  rack_flag  VARCHAR2(1) default '0',
  r_location VARCHAR2(10),
  link_emp   VARCHAR2(10),
  link_time  DATE,
  edit_emp   VARCHAR2(10),
  edit_time  DATE,
  data1      VARCHAR2(50),
  data2      VARCHAR2(50),
  data3      VARCHAR2(50)
)
;
grant select, insert, update, delete on MES4.R_RACK_LINK_WO to MES1;

prompt
prompt Creating table R_RGN
prompt ====================
prompt
create table MES4.R_RGN
(
  bill_no       VARCHAR2(10) not null,
  bill_type     VARCHAR2(20),
  part_no       VARCHAR2(20) not null,
  rg_version    VARCHAR2(10) not null,
  hfj_grn_no    VARCHAR2(20) not null,
  rsn_no        VARCHAR2(20) not null,
  po_no         VARCHAR2(20) not null,
  po_item       VARCHAR2(10) not null,
  unit          VARCHAR2(20) not null,
  rg_amount     INTEGER not null,
  rg_whs        VARCHAR2(20) not null,
  plant         VARCHAR2(20) not null,
  vendor_code   VARCHAR2(20) not null,
  vendor_name   VARCHAR2(50) not null,
  rg_handle     VARCHAR2(500),
  note          VARCHAR2(500),
  sap_account   VARCHAR2(20) not null,
  sap_rg_date   DATE not null,
  creater       VARCHAR2(20) not null,
  whs_keeper    VARCHAR2(20) not null,
  leader1       VARCHAR2(20),
  leader2       VARCHAR2(20),
  cm            VARCHAR2(20),
  year          VARCHAR2(4) not null,
  download_time DATE not null
)
;
alter table MES4.R_RGN
  add constraint UX_R_RG primary key (BILL_NO, YEAR);
alter index MES4.UX_R_RG nologging;

prompt
prompt Creating table R_ROHS_IQC
prompt =========================
prompt
create table MES4.R_ROHS_IQC
(
  doc_no            VARCHAR2(15) not null,
  substance_name    VARCHAR2(75) not null,
  substance_item    VARCHAR2(75) not null,
  substance_content VARCHAR2(10) not null,
  test_cycle        VARCHAR2(100) not null,
  specification     VARCHAR2(100) not null,
  emp_no            VARCHAR2(10) not null,
  edit_time         DATE default SYSDATE not null
)
;
grant select, insert, update, delete on MES4.R_ROHS_IQC to MES1;

prompt
prompt Creating table R_ROHS_REJECT
prompt ============================
prompt
create table MES4.R_ROHS_REJECT
(
  doc_no            VARCHAR2(15) not null,
  substance_name    VARCHAR2(75) not null,
  substance_item    VARCHAR2(75) not null,
  substance_content VARCHAR2(10) not null,
  test_cycle        VARCHAR2(100) not null,
  specification     VARCHAR2(100) not null,
  mass_ppm          NUMBER(10) not null,
  use_flag          VARCHAR2(1) default '0' not null,
  emp_no            VARCHAR2(10) not null,
  edit_time         DATE default SYSDATE not null
)
;
grant select, insert, update, delete on MES4.R_ROHS_REJECT to MES1;

prompt
prompt Creating table R_SAP321FAILRECORD
prompt =================================
prompt
create table MES4.R_SAP321FAILRECORD
(
  doc_no     VARCHAR2(20) not null,
  failmsg    VARCHAR2(200),
  lasteditdt DATE
)
;

prompt
prompt Creating table R_SAP_STOCK
prompt ==========================
prompt
create table MES4.R_SAP_STOCK
(
  plant          VARCHAR2(4) not null,
  cust_kp_no     VARCHAR2(25) not null,
  stock_location VARCHAR2(4) not null,
  sap_qty        NUMBER(10) default 0,
  inspect_qty    NUMBER(10) default 0,
  actrul_qty     NUMBER(10) default 0,
  work_time      DATE default SYSDATE,
  run_flag       INTEGER default 0
)
;

prompt
prompt Creating table R_SAP_TEMP
prompt =========================
prompt
create table MES4.R_SAP_TEMP
(
  data1     VARCHAR2(50) not null,
  data2     VARCHAR2(100),
  data3     VARCHAR2(300),
  data4     VARCHAR2(50),
  data5     VARCHAR2(100),
  data6     VARCHAR2(200),
  data7     VARCHAR2(50),
  data8     VARCHAR2(50),
  data9     VARCHAR2(50),
  data10    VARCHAR2(50),
  data11    VARCHAR2(50),
  data12    VARCHAR2(50),
  data13    VARCHAR2(50),
  data14    VARCHAR2(50),
  data15    VARCHAR2(50),
  data16    VARCHAR2(50),
  data17    VARCHAR2(50),
  data18    VARCHAR2(50),
  data19    VARCHAR2(50),
  data20    VARCHAR2(50),
  work_time DATE default SYSDATE not null
)
;
create index MES4.R_SAP_TEMP_IDX1 on MES4.R_SAP_TEMP (DATA1, DATA2, DATA3, DATA4);
grant select, insert, update, delete, references, alter, index on MES4.R_SAP_TEMP to MES1;

prompt
prompt Creating table R_SFCSHIPPACK
prompt ============================
prompt
create table MES4.R_SFCSHIPPACK
(
  packno         VARCHAR2(32) not null,
  skuno          VARCHAR2(32) not null,
  packuom        VARCHAR2(32),
  defaultuomqty  NUMBER,
  stuffingqty    NUMBER,
  parentbundleno VARCHAR2(32),
  location       VARCHAR2(32)
)
;
grant select, insert, update, delete on MES4.R_SFCSHIPPACK to MES1;

prompt
prompt Creating table R_SHIPPING_BACK
prompt ==============================
prompt
create table MES4.R_SHIPPING_BACK
(
  document_no       VARCHAR2(30) not null,
  factory_id        VARCHAR2(4) not null,
  line_id           VARCHAR2(25) not null,
  station_id        VARCHAR2(17) not null,
  linkage_timestamp DATE,
  product_number    VARCHAR2(20) not null,
  track_number      VARCHAR2(25) not null,
  factory_order     VARCHAR2(13),
  cust_number       VARCHAR2(20) not null,
  serial_number     VARCHAR2(22) not null,
  vendor_code       VARCHAR2(25),
  lot_code          VARCHAR2(20),
  data_code         VARCHAR2(20),
  operator_id       VARCHAR2(10),
  sales_order       VARCHAR2(25),
  line_item         VARCHAR2(25),
  customer_id       VARCHAR2(25),
  p_supplier_no     VARCHAR2(25),
  c_supplier_no     VARCHAR2(25),
  work_time         DATE default SYSDATE not null,
  flag              VARCHAR2(4),
  data1             VARCHAR2(50),
  data2             VARCHAR2(50)
)
;
grant select, insert, update, delete on MES4.R_SHIPPING_BACK to MES1;

prompt
prompt Creating table R_SHIPPING_DATA
prompt ==============================
prompt
create table MES4.R_SHIPPING_DATA
(
  factory_id        VARCHAR2(4) not null,
  line_id           VARCHAR2(25) not null,
  station_id        VARCHAR2(17) not null,
  linkage_timestamp DATE,
  product_number    VARCHAR2(20) not null,
  track_number      VARCHAR2(25) not null,
  factory_order     VARCHAR2(13),
  cust_number       VARCHAR2(20) not null,
  serial_number     VARCHAR2(22) not null,
  vendor_code       VARCHAR2(25),
  lot_code          VARCHAR2(20),
  data_code         VARCHAR2(20),
  operator_id       VARCHAR2(10),
  sales_order       VARCHAR2(25),
  line_item         VARCHAR2(25),
  customer_id       VARCHAR2(25),
  p_supplier_no     VARCHAR2(25),
  c_supplier_no     VARCHAR2(25),
  work_time         DATE default SYSDATE not null,
  data1             VARCHAR2(50),
  data2             VARCHAR2(50)
)
;
grant select, insert, update, delete on MES4.R_SHIPPING_DATA to MES1;

prompt
prompt Creating table R_SHIPPING_DATA_TEMP
prompt ===================================
prompt
create table MES4.R_SHIPPING_DATA_TEMP
(
  factory_id        VARCHAR2(4) not null,
  line_id           VARCHAR2(25) not null,
  station_id        VARCHAR2(17) not null,
  linkage_timestamp DATE,
  product_number    VARCHAR2(20) not null,
  track_number      VARCHAR2(25) not null,
  factory_order     VARCHAR2(13),
  cust_number       VARCHAR2(20) not null,
  serial_number     VARCHAR2(22) not null,
  vendor_code       VARCHAR2(25),
  lot_code          VARCHAR2(20),
  data_code         VARCHAR2(20),
  operator_id       VARCHAR2(10),
  sales_order       VARCHAR2(25),
  line_item         VARCHAR2(25),
  customer_id       VARCHAR2(25),
  p_supplier_no     VARCHAR2(25),
  c_supplier_no     VARCHAR2(25),
  work_time         DATE default SYSDATE not null,
  data1             VARCHAR2(50),
  data2             VARCHAR2(50)
)
;
grant select, insert, update, delete on MES4.R_SHIPPING_DATA_TEMP to MES1;

prompt
prompt Creating table R_SHORTAGE_RETURN
prompt ================================
prompt
create table MES4.R_SHORTAGE_RETURN
(
  tr_code   VARCHAR2(25) not null,
  station   VARCHAR2(10) not null,
  kp_no     VARCHAR2(20) not null,
  work_time DATE not null,
  emp_no    VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_SHORTAGE_RETURN to MES1;

prompt
prompt Creating table R_SILK_SCREEN
prompt ============================
prompt
create table MES4.R_SILK_SCREEN
(
  partno       VARCHAR2(30) not null,
  description  VARCHAR2(200),
  mfr_name     VARCHAR2(100) not null,
  mfr_partno   VARCHAR2(50) not null,
  silkscreen   VARCHAR2(30) not null,
  picture      VARCHAR2(100),
  picture_blob BLOB,
  remark       VARCHAR2(100),
  modifydate   DATE,
  modifyby     VARCHAR2(20),
  date1        VARCHAR2(50),
  date2        VARCHAR2(50)
)
;
grant select, insert, update, delete on MES4.R_SILK_SCREEN to MES1;

prompt
prompt Creating table R_SILK_SCREEN_LOG
prompt ================================
prompt
create table MES4.R_SILK_SCREEN_LOG
(
  partno     VARCHAR2(30) not null,
  mfr_partno VARCHAR2(50) not null,
  picture    VARCHAR2(100),
  remark     VARCHAR2(100),
  query_emp  VARCHAR2(30),
  query_time DATE
)
;
grant select, insert, update, delete, alter on MES4.R_SILK_SCREEN_LOG to MES1;

prompt
prompt Creating table R_SI_KP_IN
prompt =========================
prompt
create table MES4.R_SI_KP_IN
(
  cust_kp_no VARCHAR2(20) not null,
  in_qty     NUMBER(7) default 0,
  emp_no     VARCHAR2(10),
  location   VARCHAR2(10),
  work_time  DATE,
  floor      VARCHAR2(10)
)
;

prompt
prompt Creating table R_SI_KP_OUT
prompt ==========================
prompt
create table MES4.R_SI_KP_OUT
(
  cust_kp_no  VARCHAR2(20) not null,
  wo          VARCHAR2(12) not null,
  out_qty     NUMBER(7) not null,
  receiver    VARCHAR2(10),
  emp_no      VARCHAR2(10),
  work_time   DATE,
  floor       VARCHAR2(10),
  return_flag VARCHAR2(6),
  remark      VARCHAR2(80)
)
;

prompt
prompt Creating table R_SMT_AP_CHANGE
prompt ==============================
prompt
create table MES4.R_SMT_AP_CHANGE
(
  smt_code     VARCHAR2(6) not null,
  slot_no      VARCHAR2(7) not null,
  kp_no        VARCHAR2(20) not null,
  standard_qty NUMBER(4) not null,
  work_time    DATE default SYSDATE not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_SMT_AP_CHANGE to MES1;

prompt
prompt Creating table R_SMT_AP_LOCATION_DETAIL
prompt =======================================
prompt
create table MES4.R_SMT_AP_LOCATION_DETAIL
(
  smt_code_id VARCHAR2(50) not null,
  smt_code    VARCHAR2(6) not null,
  slot_no     VARCHAR2(7) not null,
  kp_no       VARCHAR2(20) not null,
  location    VARCHAR2(20) not null,
  type        VARCHAR2(7) not null,
  edit_time   DATE
)
;
create index MES4.R_SMT_AP_LOCATION_DETAIL_ID on MES4.R_SMT_AP_LOCATION_DETAIL (SMT_CODE_ID);
grant select, insert, update, delete on MES4.R_SMT_AP_LOCATION_DETAIL to MES1;

prompt
prompt Creating table R_SMT_EXCEPTION
prompt ==============================
prompt
create table MES4.R_SMT_EXCEPTION
(
  order_no      VARCHAR2(50) not null,
  line          VARCHAR2(20) not null,
  move_type     VARCHAR2(20) not null,
  message       VARCHAR2(200) not null,
  closed        VARCHAR2(50) not null,
  create_time   DATE,
  closed_time   DATE,
  closed_emp    VARCHAR2(20),
  closed_reason VARCHAR2(200)
)
;
grant select, insert, update, delete, alter on MES4.R_SMT_EXCEPTION to MES1;

prompt
prompt Creating table R_SMT_ORDER
prompt ==========================
prompt
create table MES4.R_SMT_ORDER
(
  order_no          VARCHAR2(50) not null,
  wo                VARCHAR2(20) not null,
  line_name         VARCHAR2(20) not null,
  station           VARCHAR2(20) not null,
  slot_no           VARCHAR2(10) not null,
  kp_no             VARCHAR2(50) not null,
  process           VARCHAR2(10) not null,
  part_type         VARCHAR2(100),
  location          VARCHAR2(100),
  wo_request        NUMBER(10),
  wo_deliver        NUMBER(10),
  wo_checkout       NUMBER(10),
  times             NUMBER(10),
  flag              VARCHAR2(20),
  tr_sn             VARCHAR2(30),
  status            VARCHAR2(20) not null,
  t_code            VARCHAR2(20) not null,
  create_time       DATE,
  receive_time      DATE,
  receive_emp       VARCHAR2(20),
  checkout_time     DATE,
  checkout_emp      VARCHAR2(20),
  accept_time       DATE,
  accept_emp        VARCHAR2(20),
  online_time       DATE,
  online_emp        VARCHAR2(20),
  checkout_overtime DATE,
  online_overtime   DATE
)
;
grant select, insert, update, delete, references, alter on MES4.R_SMT_ORDER to MES1;

prompt
prompt Creating table R_SMT_OVER_NEED
prompt ==============================
prompt
create table MES4.R_SMT_OVER_NEED
(
  alarm_type        VARCHAR2(50),
  line_name         VARCHAR2(50),
  wo                VARCHAR2(50) not null,
  v_wo              VARCHAR2(50),
  station           VARCHAR2(50),
  slot_no           VARCHAR2(50),
  p_no              VARCHAR2(50),
  cust_kp_no        VARCHAR2(100) not null,
  process_flag      VARCHAR2(50) not null,
  call_qty          NUMBER,
  deliver_qty       NUMBER,
  edit_time         DATE default SYSDATE,
  call_status       VARCHAR2(1),
  check_first_time  DATE,
  first_status      VARCHAR2(50) default '0',
  check_second_time DATE,
  second_status     VARCHAR2(1) default '0',
  lastedit_emp      VARCHAR2(50),
  data3             VARCHAR2(50),
  data4             NUMBER,
  data5             VARCHAR2(50) default 0,
  data6             DATE,
  data7             VARCHAR2(20),
  data8             VARCHAR2(20),
  data9             VARCHAR2(20),
  work_flag         VARCHAR2(1) default 0,
  standard_qty      NUMBER
)
;
grant select, insert, update, delete on MES4.R_SMT_OVER_NEED to MES1;

prompt
prompt Creating table R_SMT_START_STOP_DETAIL
prompt ======================================
prompt
create table MES4.R_SMT_START_STOP_DETAIL
(
  station   VARCHAR2(10),
  wo        VARCHAR2(20),
  process   VARCHAR2(20),
  status    VARCHAR2(20),
  t_code    VARCHAR2(20),
  emp_no    VARCHAR2(20),
  last_time DATE
)
;
grant select, insert, update, delete on MES4.R_SMT_START_STOP_DETAIL to MES1;

prompt
prompt Creating table R_SN_LINK
prompt ========================
prompt
create table MES4.R_SN_LINK
(
  sn_code   VARCHAR2(30) not null,
  p_sn      VARCHAR2(25),
  wo        VARCHAR2(12) not null,
  work_time DATE not null,
  emp_no    VARCHAR2(10) not null,
  panel_no  VARCHAR2(30),
  item      NUMBER(3) default 1 not null
)
;
create index MES4.R_SN_LINK_PANEL_NO on MES4.R_SN_LINK (PANEL_NO);
create index MES4.R_SN_LINK_PSN on MES4.R_SN_LINK (P_SN);
create index MES4.R_SN_LINK_SN_CODE on MES4.R_SN_LINK (SN_CODE);
create index MES4.R_SN_LINK_WO on MES4.R_SN_LINK (WO);
grant select, insert, update, delete, references, index on MES4.R_SN_LINK to MES1;

prompt
prompt Creating table R_SN_LINK_16
prompt ===========================
prompt
create table MES4.R_SN_LINK_16
(
  sn_code   VARCHAR2(30) not null,
  p_sn      VARCHAR2(25),
  wo        VARCHAR2(12) not null,
  work_time DATE not null,
  emp_no    VARCHAR2(10) not null,
  panel_no  VARCHAR2(30)
)
;

prompt
prompt Creating table R_SOLDER_DETAIL
prompt ==============================
prompt
create table MES4.R_SOLDER_DETAIL
(
  tr_sn               VARCHAR2(12) not null,
  kp_no               VARCHAR2(20) not null,
  bd_code             VARCHAR2(10) not null,
  model_flag          VARCHAR2(1) default '0' not null,
  fifo_flag           VARCHAR2(1) default '0' not null,
  seq_no              NUMBER(4),
  work_flag           VARCHAR2(1) default '0' not null,
  out_whs_time        DATE not null,
  in_kitting_time     DATE,
  get_warm_time       DATE,
  out_kitting_time    DATE,
  return_kitting_time DATE,
  start_time          DATE,
  end_time            DATE,
  floor               VARCHAR2(20),
  remak               VARCHAR2(50)
)
;
grant select, insert, update, delete on MES4.R_SOLDER_DETAIL to MES1;

prompt
prompt Creating table R_SOLDER_REQUEST
prompt ===============================
prompt
create table MES4.R_SOLDER_REQUEST
(
  wo            VARCHAR2(12) not null,
  wo_qty        NUMBER(6),
  p_no          VARCHAR2(20) not null,
  cust_kp_no    VARCHAR2(20) not null,
  standard_qty  NUMBER(4) not null,
  wo_request    NUMBER(10) not null,
  deliver_qty   NUMBER(10) default 0,
  download_time DATE not null,
  checkout_qty  NUMBER(7) default 0,
  return_qty    NUMBER(7) default 0,
  wastage_qty   NUMBER(7) default 0
)
;
grant select, insert, update, delete on MES4.R_SOLDER_REQUEST to MES1;

prompt
prompt Creating table R_SOLDER_SN_WIP
prompt ==============================
prompt
create table MES4.R_SOLDER_SN_WIP
(
  tr_sn     VARCHAR2(25) not null,
  kp_no     VARCHAR2(20) not null,
  work_time VARCHAR2(8) not null,
  sequence  NUMBER(4),
  work_flag VARCHAR2(1) default '0' not null,
  emp_no    VARCHAR2(10) not null
)
;

prompt
prompt Creating table R_SOLDER_WIP
prompt ===========================
prompt
create table MES4.R_SOLDER_WIP
(
  tr_code         VARCHAR2(25) not null,
  tr_sn           VARCHAR2(25) not null,
  station         VARCHAR2(50) not null,
  link_station    VARCHAR2(50) not null,
  limit_wash_time NUMBER(8) not null,
  start_time      DATE not null,
  wo              VARCHAR2(12)
)
;

prompt
prompt Creating table R_SQL_DATA_T
prompt ===========================
prompt
create table MES4.R_SQL_DATA_T
(
  sql_id              VARCHAR2(100) not null,
  first_load_time     VARCHAR2(100) not null,
  parsing_schema_name VARCHAR2(100),
  service             VARCHAR2(50),
  module              VARCHAR2(50),
  machine             VARCHAR2(50),
  terminal            VARCHAR2(50),
  osuser              VARCHAR2(50),
  program             VARCHAR2(50),
  logon_time          VARCHAR2(100),
  confirm_flag        INTEGER default 0,
  confirm_time        DATE,
  confirm_emp         VARCHAR2(50),
  file_name           VARCHAR2(500),
  reason              VARCHAR2(1000),
  executions          INTEGER,
  rows_processed      INTEGER,
  data1               VARCHAR2(100),
  data2               VARCHAR2(100),
  data3               VARCHAR2(100),
  sql_text            CLOB
)
;
create index MES4.IDX_R_SQL_DATA_T_LOADTIME on MES4.R_SQL_DATA_T (FIRST_LOAD_TIME);
create index MES4.IDX_R_SQL_DATA_T_SQLID on MES4.R_SQL_DATA_T (SQL_ID);

prompt
prompt Creating table R_SQM_ATTAC
prompt ==========================
prompt
create table MES4.R_SQM_ATTAC
(
  attac_no   VARCHAR2(15) not null,
  attac_name VARCHAR2(100) not null,
  attac_blob BLOB not null
)
;
grant select, insert, update, delete on MES4.R_SQM_ATTAC to MES1;

prompt
prompt Creating table R_SQM_EMAIL
prompt ==========================
prompt
create table MES4.R_SQM_EMAIL
(
  email_no VARCHAR2(15) not null,
  to_mail  VARCHAR2(500) not null,
  cc_mail  VARCHAR2(500),
  bcc_mail VARCHAR2(500)
)
;
grant select, insert, update, delete on MES4.R_SQM_EMAIL to MES1;

prompt
prompt Creating table R_SQM_FILE
prompt =========================
prompt
create table MES4.R_SQM_FILE
(
  file_name       VARCHAR2(100) not null,
  plant_code      VARCHAR2(10) not null,
  type_code       VARCHAR2(10) not null,
  sqm_vendor_code VARCHAR2(10) not null,
  file_time       DATE not null,
  file_blob       BLOB,
  file_remark     VARCHAR2(200),
  edit_emp        VARCHAR2(25) not null,
  edit_time       DATE not null
)
;
grant select, insert, update, delete on MES4.R_SQM_FILE to MES1;

prompt
prompt Creating table R_SQM_INSPECT_DL
prompt ===============================
prompt
create table MES4.R_SQM_INSPECT_DL
(
  sheet_no   VARCHAR2(15) not null,
  cust_kp_no VARCHAR2(20) not null,
  date_code  VARCHAR2(20),
  lot_code   VARCHAR2(20),
  qty        NUMBER(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_SQM_INSPECT_DL to MES1;

prompt
prompt Creating table R_SQM_SHEET_WIP
prompt ==============================
prompt
create table MES4.R_SQM_SHEET_WIP
(
  sheet_type      VARCHAR2(2) not null,
  sheet_no        VARCHAR2(15) not null,
  sheet_status    VARCHAR2(1) default '0' not null,
  group_no        VARCHAR2(4) not null,
  sqm_group       VARCHAR2(5) not null,
  email_no        VARCHAR2(15),
  send_times      VARCHAR2(1) default '0' not null,
  send_attac      BLOB,
  send_attac_name VARCHAR2(100),
  update_remark   VARCHAR2(500),
  edit_emp        VARCHAR2(25) not null,
  edit_time       DATE not null
)
;
grant select, insert, update, delete on MES4.R_SQM_SHEET_WIP to MES1;

prompt
prompt Creating table R_STATION_KP_OFFLINE_LOG
prompt =======================================
prompt
create table MES4.R_STATION_KP_OFFLINE_LOG
(
  station        VARCHAR2(10),
  emp_no         VARCHAR2(10),
  tr_sn          VARCHAR2(12),
  local_language VARCHAR2(50),
  data1          VARCHAR2(30),
  work_flag      NUMBER default 0,
  work_time      DATE
)
;
grant select, insert, update, delete on MES4.R_STATION_KP_OFFLINE_LOG to MES1;

prompt
prompt Creating table R_STATION_SCANTIME
prompt =================================
prompt
create table MES4.R_STATION_SCANTIME
(
  station_name  VARCHAR2(10) not null,
  ip            VARCHAR2(15) not null,
  lastscan_time DATE,
  page_flag     VARCHAR2(1) default '0'
)
;
grant select, insert, update, delete on MES4.R_STATION_SCANTIME to MES1;

prompt
prompt Creating table R_STATION_SHORTAGE
prompt =================================
prompt
create table MES4.R_STATION_SHORTAGE
(
  wo              VARCHAR2(500) not null,
  v_wo            VARCHAR2(50),
  station         VARCHAR2(50) not null,
  slot_no         VARCHAR2(50) not null,
  cust_kp_no      VARCHAR2(100) not null,
  tr_sn_count     NUMBER default '0',
  tr_sn_qty_count NUMBER default '0',
  output_qty      NUMBER default '0',
  fact_output_qty NUMBER default '0',
  ext_output_qty  NUMBER default '0',
  alarm_qty       NUMBER,
  alarm_flag      VARCHAR2(25) default 'N',
  lastedit_time   DATE default sysdate,
  lastedit_emp    VARCHAR2(50),
  data1           VARCHAR2(250),
  data2           VARCHAR2(100),
  data3           VARCHAR2(100),
  data4           VARCHAR2(100),
  data5           VARCHAR2(100),
  data6           VARCHAR2(100),
  tr_sn           VARCHAR2(100),
  process_flag    VARCHAR2(25)
)
;
create index MES4.IDX_R_STATION_SHORTAGE_SLOT on MES4.R_STATION_SHORTAGE (STATION, SLOT_NO);
create index MES4.IDX_R_STATION_SHORTAGE_WO on MES4.R_STATION_SHORTAGE (WO);
grant select, insert, update, delete, alter on MES4.R_STATION_SHORTAGE to MES1;

prompt
prompt Creating table R_STATION_SHORTAGE_BACKUP
prompt ========================================
prompt
create table MES4.R_STATION_SHORTAGE_BACKUP
(
  wo              VARCHAR2(50) not null,
  v_wo            VARCHAR2(50),
  station         VARCHAR2(50) not null,
  slot_no         VARCHAR2(50) not null,
  cust_kp_no      VARCHAR2(100) not null,
  tr_sn_count     NUMBER default '0',
  tr_sn_qty_count NUMBER default '0',
  output_qty      NUMBER default '0',
  fact_output_qty NUMBER default '0',
  ext_output_qty  NUMBER default '0',
  alarm_qty       NUMBER,
  alarm_flag      VARCHAR2(25) default 'N',
  lastedit_time   DATE default sysdate,
  lastedit_emp    VARCHAR2(50),
  data1           VARCHAR2(50),
  data2           VARCHAR2(50),
  data3           VARCHAR2(50),
  data4           VARCHAR2(50),
  data5           VARCHAR2(50),
  data6           VARCHAR2(50),
  tr_sn           VARCHAR2(50),
  process_flag    VARCHAR2(25)
)
;
create index MES4.IDX_R_STATION_ST_SLOT_BACKUP on MES4.R_STATION_SHORTAGE_BACKUP (STATION, SLOT_NO)
  nologging;
create index MES4.IDX_R_STATION_ST_WO_BACKUP on MES4.R_STATION_SHORTAGE_BACKUP (WO)
  nologging;
grant select, insert, update, delete on MES4.R_STATION_SHORTAGE_BACKUP to MES1;

prompt
prompt Creating table R_STATION_SHORTAGE_HIS
prompt =====================================
prompt
create table MES4.R_STATION_SHORTAGE_HIS
(
  wo              VARCHAR2(50) not null,
  v_wo            VARCHAR2(50),
  station         VARCHAR2(50) not null,
  slot_no         VARCHAR2(50) not null,
  cust_kp_no      VARCHAR2(100) not null,
  tr_sn_count     NUMBER default '0',
  tr_sn_qty_count NUMBER default '0',
  output_qty      NUMBER default '0',
  fact_output_qty NUMBER default '0',
  ext_output_qty  NUMBER default '0',
  alarm_qty       NUMBER,
  alarm_flag      VARCHAR2(25) default 'N',
  lastedit_time   DATE default sysdate,
  lastedit_emp    VARCHAR2(50),
  data1           VARCHAR2(50),
  data2           VARCHAR2(50),
  data3           VARCHAR2(50),
  data4           VARCHAR2(50),
  data5           VARCHAR2(50),
  data6           VARCHAR2(50),
  tr_sn           VARCHAR2(50),
  process_flag    VARCHAR2(25)
)
;
create index MES4.IDX_R_STATION_SHORTAGE_HIS_ST on MES4.R_STATION_SHORTAGE_HIS (STATION, SLOT_NO);
create index MES4.IDX_R_STATION_SHORTAGE_HIS_TI on MES4.R_STATION_SHORTAGE_HIS (LASTEDIT_TIME);
create index MES4.IDX_R_STATION_SHORTAGE_HIS_WO on MES4.R_STATION_SHORTAGE_HIS (WO);
grant select, insert, update, delete on MES4.R_STATION_SHORTAGE_HIS to MES1;

prompt
prompt Creating table R_STATION_SHORTAGE_LOG
prompt =====================================
prompt
create table MES4.R_STATION_SHORTAGE_LOG
(
  wo              VARCHAR2(50),
  v_wo            VARCHAR2(50),
  station         VARCHAR2(50),
  slot_no         VARCHAR2(50),
  cust_kp_no      VARCHAR2(50),
  tr_sn           VARCHAR2(50),
  alarm_time      DATE,
  alarm_status    VARCHAR2(50),
  alarm_close_emp VARCHAR2(50),
  alarm_reason    VARCHAR2(200),
  action          VARCHAR2(200),
  action_time     DATE,
  action_emp      VARCHAR2(50),
  data1           VARCHAR2(50),
  data2           VARCHAR2(50),
  data3           VARCHAR2(50)
)
;
create index MES4.IDX_R_STATION_SHORTAGE_LOG_ST on MES4.R_STATION_SHORTAGE_LOG (STATION);
create index MES4.IDX_R_STATION_SHORTAGE_LOG_TI on MES4.R_STATION_SHORTAGE_LOG (ALARM_TIME);
create index MES4.IDX_R_STATION_SHORTAGE_LOG_WO on MES4.R_STATION_SHORTAGE_LOG (WO);
grant select, insert, update, delete on MES4.R_STATION_SHORTAGE_LOG to MES1;

prompt
prompt Creating table R_STATION_SHORTAGE_TEMP
prompt ======================================
prompt
create table MES4.R_STATION_SHORTAGE_TEMP
(
  wo              VARCHAR2(50) not null,
  v_wo            VARCHAR2(50),
  station         VARCHAR2(50) not null,
  slot_no         VARCHAR2(50) not null,
  cust_kp_no      VARCHAR2(100) not null,
  tr_sn_count     NUMBER default '0',
  tr_sn_qty_count NUMBER default '0',
  output_qty      NUMBER default '0',
  fact_output_qty NUMBER default '0',
  ext_output_qty  NUMBER default '0',
  alarm_qty       NUMBER,
  alarm_flag      VARCHAR2(25) default 'N',
  lastedit_time   DATE default sysdate,
  lastedit_emp    VARCHAR2(50),
  data1           VARCHAR2(50),
  data2           VARCHAR2(50),
  data3           VARCHAR2(50),
  data4           VARCHAR2(50),
  data5           VARCHAR2(50),
  data6           VARCHAR2(50),
  tr_sn           VARCHAR2(50),
  process_flag    VARCHAR2(25)
)
;
create index MES4.IDX_R_STATION_SHORTAGE_TEMP_SS on MES4.R_STATION_SHORTAGE_TEMP (STATION, SLOT_NO);
create index MES4.IDX_R_STATION_SHORTAGE_TEMP_WO on MES4.R_STATION_SHORTAGE_TEMP (WO);
grant select, insert, update, delete on MES4.R_STATION_SHORTAGE_TEMP to MES1;

prompt
prompt Creating table R_STATION_STATUS
prompt ===============================
prompt
create table MES4.R_STATION_STATUS
(
  tr_code   VARCHAR2(25) not null,
  station   VARCHAR2(10) not null,
  status    VARCHAR2(1) not null,
  slot_no   VARCHAR2(7),
  kp_no     VARCHAR2(20) not null,
  work_time DATE not null,
  emp_no    VARCHAR2(10) not null
)
;
create index MES4.R_STATION_STATUS_COMB1 on MES4.R_STATION_STATUS (TR_CODE, SLOT_NO, KP_NO, STATUS);
grant select, insert, update, delete, references, alter, index on MES4.R_STATION_STATUS to MES1;

prompt
prompt Creating table R_STATION_TEMP
prompt =============================
prompt
create table MES4.R_STATION_TEMP
(
  travel_sn      VARCHAR2(17) not null,
  smt_code       VARCHAR2(6),
  station        VARCHAR2(10) not null,
  station_flag   VARCHAR2(1) not null,
  wo             VARCHAR2(12) not null,
  p_no           VARCHAR2(20) not null,
  p_version      VARCHAR2(4) not null,
  tr_sn          VARCHAR2(12),
  slot_no        VARCHAR2(7),
  kp_no          VARCHAR2(20) not null,
  feeder_type    VARCHAR2(40),
  feeder_no      VARCHAR2(15),
  standard_qty   NUMBER(4) not null,
  shortage_flag  VARCHAR2(1) not null,
  shareslot_flag VARCHAR2(1) default '0' not null,
  work_time      DATE not null,
  emp_no         VARCHAR2(10) not null,
  process_flag   VARCHAR2(1),
  replacekp_flag VARCHAR2(1) default '0' not null,
  wip_use_flag   VARCHAR2(1) default '1' not null,
  b_qty          NUMBER(4) default 0,
  t_qty          NUMBER(4) default 0
)
;
create index MES4.R_STATION_TEMP_KP_NO on MES4.R_STATION_TEMP (KP_NO);
create index MES4.R_STATION_TEMP_SLOT_NO on MES4.R_STATION_TEMP (SLOT_NO);
create index MES4.R_STATION_TEMP_STATION on MES4.R_STATION_TEMP (STATION);
create index MES4.R_STATION_TEMP_TRAVEL_SN on MES4.R_STATION_TEMP (TRAVEL_SN);
grant select, insert, update, delete, references, alter, index on MES4.R_STATION_TEMP to MES1;

prompt
prompt Creating table R_STATION_WIP
prompt ============================
prompt
create table MES4.R_STATION_WIP
(
  tr_code        VARCHAR2(25),
  smt_code       VARCHAR2(6),
  station        VARCHAR2(10) not null,
  station_flag   VARCHAR2(1) not null,
  wo             VARCHAR2(12) not null,
  p_no           VARCHAR2(20) not null,
  p_version      VARCHAR2(4) not null,
  tr_sn          VARCHAR2(12),
  slot_no        VARCHAR2(7),
  kp_no          VARCHAR2(20) not null,
  feeder_type    VARCHAR2(40),
  feeder_no      VARCHAR2(15),
  standard_qty   NUMBER(4) not null,
  shortage_flag  VARCHAR2(1) not null,
  shareslot_flag VARCHAR2(1) default '0' not null,
  work_time      DATE not null,
  emp_no         VARCHAR2(10) not null,
  replacekp_flag VARCHAR2(1) default '0' not null,
  process_flag   VARCHAR2(1),
  wip_use_flag   VARCHAR2(1) default '1' not null,
  ext_qty        NUMBER(14,1) default 0,
  b_qty          NUMBER(4) default 0,
  t_qty          NUMBER(4) default 0
)
;
create index MES4.R_STATION_WIP_FEEDER_TYPE on MES4.R_STATION_WIP (FEEDER_TYPE);
create index MES4.R_STATION_WIP_KP_NO on MES4.R_STATION_WIP (KP_NO);
create index MES4.R_STATION_WIP_SLOT_NO on MES4.R_STATION_WIP (SLOT_NO);
create index MES4.R_STATION_WIP_STATION on MES4.R_STATION_WIP (STATION);
create index MES4.R_STATION_WIP_TR_SN on MES4.R_STATION_WIP (TR_SN);
grant select, insert, update, delete, references, alter, index on MES4.R_STATION_WIP to MES1;

prompt
prompt Creating table R_STATION_WIP_EXTEND
prompt ===================================
prompt
create table MES4.R_STATION_WIP_EXTEND
(
  tr_code    VARCHAR2(25),
  smt_code   VARCHAR2(6),
  station    VARCHAR2(10) not null,
  wo         VARCHAR2(12) not null,
  slot_no    VARCHAR2(7),
  ext_qty    NUMBER(10,1),
  data       VARCHAR2(12),
  type       VARCHAR2(35),
  valid_flag VARCHAR2(2)
)
;
create index MES4.R_STATION_WIP_EXTEND_1 on MES4.R_STATION_WIP_EXTEND (TYPE, STATION, WO, SLOT_NO);
create index MES4.R_STATION_WIP_EXTEND_2 on MES4.R_STATION_WIP_EXTEND (VALID_FLAG);
grant select, insert, update, delete on MES4.R_STATION_WIP_EXTEND to MES1;

prompt
prompt Creating table R_STENCIL_ACCEPT_DATA
prompt ====================================
prompt
create table MES4.R_STENCIL_ACCEPT_DATA
(
  mfr_sn        VARCHAR2(25) not null,
  item_code     VARCHAR2(5) not null,
  part_location VARCHAR2(15) not null,
  size_code     VARCHAR2(5) not null,
  size_result   NUMBER(7,3) not null,
  result_flag   VARCHAR2(1) default '0' not null,
  remark        VARCHAR2(60),
  edit_emp      VARCHAR2(25) not null,
  edit_time     DATE not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_STENCIL_ACCEPT_DATA to MES1;

prompt
prompt Creating table R_STENCIL_DEFECT
prompt ===============================
prompt
create table MES4.R_STENCIL_DEFECT
(
  stencil_sn      VARCHAR2(25) not null,
  duty_area       VARCHAR2(15) default '0' not null,
  duty_location   VARCHAR2(15) not null,
  duty_emp        VARCHAR2(10) not null,
  total_use_times NUMBER(8) default 0 not null,
  alert_times     NUMBER(8) not null,
  defect_flag     VARCHAR2(1) default '0' not null,
  record_time     DATE not null,
  record_emp      VARCHAR2(10) not null,
  defect_code     VARCHAR2(15),
  handle_desc     VARCHAR2(150),
  defect_remark   VARCHAR2(150),
  handle_status   VARCHAR2(1) default '0' not null,
  start_time      DATE,
  end_time        DATE,
  pe_emp          VARCHAR2(10),
  alarm_flag      VARCHAR2(1) default '0' not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_STENCIL_DEFECT to MES1;

prompt
prompt Creating table R_STENCIL_DETAIL
prompt ===============================
prompt
create table MES4.R_STENCIL_DETAIL
(
  stencil_sn   VARCHAR2(25) not null,
  line_name    VARCHAR2(8) not null,
  station_name VARCHAR2(8) not null,
  wo           VARCHAR2(12) not null,
  use_times    NUMBER(8) default 0 not null,
  start_time   DATE not null,
  start_emp    VARCHAR2(10) not null,
  end_time     DATE not null,
  end_emp      VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_STENCIL_DETAIL to MES1;

prompt
prompt Creating table R_STENCIL_TEST
prompt =============================
prompt
create table MES4.R_STENCIL_TEST
(
  stencil_sn   VARCHAR2(30) not null,
  tension1     NUMBER(6,2) not null,
  tension2     NUMBER(6,2) not null,
  tension3     NUMBER(6,2),
  tension4     NUMBER(6,2),
  tension5     NUMBER(6,2),
  tension6     NUMBER(6,2),
  tension7     NUMBER(6,2),
  tension8     NUMBER(6,2),
  wash_emp     VARCHAR2(10),
  wash_time    DATE,
  tension_flag VARCHAR2(1)
)
;
create index MES4.IDX_R_STENCIL_TEST on MES4.R_STENCIL_TEST (STENCIL_SN, TENSION_FLAG)
  nologging;
grant select, insert, update on MES4.R_STENCIL_TEST to MES1;

prompt
prompt Creating table R_STENCIL_WASH
prompt =============================
prompt
create table MES4.R_STENCIL_WASH
(
  stencil_sn      VARCHAR2(25) not null,
  line_name       VARCHAR2(8),
  station_name    VARCHAR2(8),
  send_emp        VARCHAR2(10) not null,
  start_time      DATE not null,
  end_time        DATE,
  shift           VARCHAR2(1) default '0' not null,
  wash_emp        VARCHAR2(10) not null,
  ipqc_emp        VARCHAR2(50) default '0',
  tension         VARCHAR2(100),
  data1           VARCHAR2(100),
  data2           VARCHAR2(100),
  data3           VARCHAR2(100),
  data4           VARCHAR2(100),
  description     VARCHAR2(100),
  stencil_status  VARCHAR2(20),
  engineer        VARCHAR2(20),
  remark          VARCHAR2(100),
  lastusetimes    NUMBER,
  check_serial_no VARCHAR2(20)
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_STENCIL_WASH to MES1;

prompt
prompt Creating table R_STENCIL_WHS
prompt ============================
prompt
create table MES4.R_STENCIL_WHS
(
  stencil_sn      VARCHAR2(25) not null,
  total_use_times NUMBER(8) not null,
  line_name       VARCHAR2(8) not null,
  station_name    VARCHAR2(10) not null,
  wo              VARCHAR2(12) not null,
  loan_emp        VARCHAR2(10) not null,
  loan_time       DATE not null,
  deliver_emp     VARCHAR2(10) not null,
  return_emp      VARCHAR2(10),
  return_time     DATE,
  receive_emp     VARCHAR2(10)
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_STENCIL_WHS to MES1;

prompt
prompt Creating table R_STENCIL_WIP
prompt ============================
prompt
create table MES4.R_STENCIL_WIP
(
  stencil_sn   VARCHAR2(30) not null,
  line_name    VARCHAR2(8) not null,
  station_name VARCHAR2(8) not null,
  wo           VARCHAR2(12) not null,
  use_times    NUMBER(8) default 0 not null,
  start_time   DATE not null,
  start_emp    VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_STENCIL_WIP to MES1;

prompt
prompt Creating table R_STOCKINOUT_WHS
prompt ===============================
prompt
create table MES4.R_STOCKINOUT_WHS
(
  stock_no    VARCHAR2(10),
  p_no        VARCHAR2(25),
  packno      VARCHAR2(32) not null,
  location    VARCHAR2(32),
  stuffingqty NUMBER(5),
  flag        VARCHAR2(10),
  lasteditdt  DATE
)
;
grant select, insert, update, delete on MES4.R_STOCKINOUT_WHS to MES1;

prompt
prompt Creating table R_SYSTEM_KPI_T
prompt =============================
prompt
create table MES4.R_SYSTEM_KPI_T
(
  kpi_id       VARCHAR2(10) not null,
  kpi_name     VARCHAR2(30) not null,
  kpi_value    NUMBER(10) not null,
  kpi_time     VARCHAR2(8) not null,
  work_section NUMBER(10),
  kpi_remark   VARCHAR2(30)
)
;

prompt
prompt Creating table R_SYSTEM_LOG
prompt ===========================
prompt
create table MES4.R_SYSTEM_LOG
(
  emp_no      VARCHAR2(25),
  prg_name    VARCHAR2(25) not null,
  action_type VARCHAR2(50),
  action_desc VARCHAR2(1024),
  time        DATE default SYSDATE
)
;

prompt
prompt Creating table R_TEMPERATURE_DETAIL
prompt ===================================
prompt
create table MES4.R_TEMPERATURE_DETAIL
(
  sn        VARCHAR2(50) not null,
  use_times NUMBER(7) not null,
  process   VARCHAR2(1) not null,
  use_type  VARCHAR2(20) not null,
  work_flag VARCHAR2(1) not null,
  work_time DATE default sysdate,
  line      VARCHAR2(10),
  wo        VARCHAR2(12),
  p_no      VARCHAR2(20),
  edit_emp  VARCHAR2(20),
  edit_time VARCHAR2(20),
  remark    VARCHAR2(250)
)
;
comment on column MES4.R_TEMPERATURE_DETAIL.sn
  is '測溫板編號';
comment on column MES4.R_TEMPERATURE_DETAIL.use_times
  is '使用次數（當時的的狀態）';
comment on column MES4.R_TEMPERATURE_DETAIL.process
  is '面別B、T、D（當時的的狀態）';
comment on column MES4.R_TEMPERATURE_DETAIL.use_type
  is '測溫板類型（SMT OR PTH）（當時的的狀態）';
comment on column MES4.R_TEMPERATURE_DETAIL.work_flag
  is '狀態（0＝下線，1＝上線）（當時的的狀態）';
comment on column MES4.R_TEMPERATURE_DETAIL.work_time
  is '異動時間（當時的的狀態）';
comment on column MES4.R_TEMPERATURE_DETAIL.line
  is '線體（當時的的狀態）';
comment on column MES4.R_TEMPERATURE_DETAIL.wo
  is '工單（當時的的狀態）';
comment on column MES4.R_TEMPERATURE_DETAIL.p_no
  is '機種（當時的的狀態）';
comment on column MES4.R_TEMPERATURE_DETAIL.edit_emp
  is '編輯人員（當時的的狀態）';
comment on column MES4.R_TEMPERATURE_DETAIL.edit_time
  is '編輯時間（當時的的狀態）';
comment on column MES4.R_TEMPERATURE_DETAIL.remark
  is '備注（當時的的狀態）';
grant select, insert, update, delete, alter on MES4.R_TEMPERATURE_DETAIL to MES1;

prompt
prompt Creating table R_TEMP_REPLACE
prompt =============================
prompt
create table MES4.R_TEMP_REPLACE
(
  wo        VARCHAR2(12) not null,
  temp_sn   VARCHAR2(25) not null,
  link_qty  NUMBER(2) default 1 not null,
  p_sn      VARCHAR2(25) not null,
  sn_code   VARCHAR2(12) not null,
  work_time DATE,
  temp_code VARCHAR2(15)
)
;
create index MES4.IX_R_TEMP_REPLACE_PSN on MES4.R_TEMP_REPLACE (P_SN);
create index MES4.IX_R_TEMP_REPLACE_TEMPSN on MES4.R_TEMP_REPLACE (TEMP_SN);
grant select, insert, update, delete on MES4.R_TEMP_REPLACE to MES1;

prompt
prompt Creating table R_TEMP_SN
prompt ========================
prompt
create table MES4.R_TEMP_SN
(
  temp_sn        VARCHAR2(18) not null,
  link_qty       NUMBER(2) default 1,
  scan_qty       NUMBER(2) default 0,
  wo             VARCHAR2(12) default 000000000000,
  flag           VARCHAR2(1) default 0,
  start_time     DATE default SYSDATE,
  end_time       DATE default SYSDATE,
  emp_no         VARCHAR2(10),
  replace_emp_no VARCHAR2(10),
  reprint_qty    NUMBER(2) default 0,
  data1          VARCHAR2(25),
  data2          VARCHAR2(25),
  data3          VARCHAR2(25)
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_TEMP_SN to MES1;

prompt
prompt Creating table R_TEST_INSPECTION
prompt ================================
prompt
create table MES4.R_TEST_INSPECTION
(
  type                 VARCHAR2(50) not null,
  doc_no               VARCHAR2(20) not null,
  report_type          VARCHAR2(20),
  inspection_date      DATE,
  cust_kp_no           VARCHAR2(20),
  date_code            VARCHAR2(20),
  aql                  VARCHAR2(20),
  package_1            VARCHAR2(100),
  package_2            VARCHAR2(100),
  package_3            VARCHAR2(100),
  package_1_flag       VARCHAR2(20),
  package_2_flag       VARCHAR2(20),
  package_3_flag       VARCHAR2(20),
  test1                VARCHAR2(200),
  test2                VARCHAR2(200),
  test3                VARCHAR2(200),
  test4                VARCHAR2(200),
  test5                VARCHAR2(200),
  test6                VARCHAR2(200),
  test_device1         VARCHAR2(200),
  test_device2         VARCHAR2(200),
  test_device3         VARCHAR2(200),
  layer                VARCHAR2(10),
  test_protect1        VARCHAR2(200),
  test1_flag           VARCHAR2(20),
  test2_flag           VARCHAR2(20),
  test3_flag           VARCHAR2(20),
  test4_flag           VARCHAR2(20),
  test5_flag           VARCHAR2(20),
  test6_flag           VARCHAR2(20),
  test_device1_flag    VARCHAR2(20),
  test_device2_flag    VARCHAR2(20),
  test_device3_flag    VARCHAR2(20),
  layer_flag           VARCHAR2(20),
  test_protect1_flag   VARCHAR2(20),
  sn_path              VARCHAR2(200),
  final_judgement      VARCHAR2(20),
  rejreason            VARCHAR2(200),
  rejdetail            VARCHAR2(200),
  control_run_no       VARCHAR2(50),
  edit_emp             VARCHAR2(20) not null,
  edit_time            DATE not null,
  test_inspection_time DATE not null,
  check_flag           VARCHAR2(10),
  remark               VARCHAR2(200),
  ss                   VARCHAR2(10),
  attachfile           VARCHAR2(50)
)
;
create index MES4.R_TEST_INSPECTION_IDX1 on MES4.R_TEST_INSPECTION (TYPE, DOC_NO);
create index MES4.R_TEST_INSPECTION_IDX2 on MES4.R_TEST_INSPECTION (TEST_INSPECTION_TIME);
create index MES4.R_TEST_INSPECTION_IDX3 on MES4.R_TEST_INSPECTION (CUST_KP_NO);
grant select, insert, update, delete, alter on MES4.R_TEST_INSPECTION to MES1;

prompt
prompt Creating table R_TMP_LASER_ALARM
prompt ================================
prompt
create global temporary table MES4.R_TMP_LASER_ALARM
(
  line        VARCHAR2(10),
  cust_kp_no  VARCHAR2(30),
  wo          VARCHAR2(12),
  p_no        VARCHAR2(30),
  p_flag      VARCHAR2(1),
  target_qty  NUMBER(10),
  laser_qty   NUMBER(10),
  kitting_qty NUMBER(10),
  smt_wait    NUMBER(10),
  online_qty  NUMBER(10),
  data1       VARCHAR2(30),
  data2       VARCHAR2(30),
  data3       VARCHAR2(30)
)
on commit delete rows;

prompt
prompt Creating table R_TRAVEL_SN
prompt ==========================
prompt
create table MES4.R_TRAVEL_SN
(
  travel_sn       VARCHAR2(17) not null,
  smt_code        VARCHAR2(6),
  program_name    VARCHAR2(50),
  program_comment VARCHAR2(30),
  line_name       VARCHAR2(8) not null,
  line_section    VARCHAR2(3) not null,
  station         VARCHAR2(10) not null,
  station_flag    VARCHAR2(1) not null,
  p_no            VARCHAR2(20) not null,
  p_version       VARCHAR2(4) not null,
  wo              VARCHAR2(12) not null,
  wo_qty          NUMBER(6) not null,
  work_flag       VARCHAR2(1) not null,
  work_time       DATE not null,
  emp_no          VARCHAR2(10) not null,
  process_flag    VARCHAR2(1)
)
;
create index MES4.R_TRAVELSN_SNSTATION on MES4.R_TRAVEL_SN (TRAVEL_SN, STATION);
create index MES4.R_TRAVEL_SNSTATION on MES4.R_TRAVEL_SN (STATION);
create index MES4.R_TRAVLE_SN_WO on MES4.R_TRAVEL_SN (WO);
grant select, insert, update, delete, references, alter, index on MES4.R_TRAVEL_SN to MES1;

prompt
prompt Creating table R_TRSN_BUFFER
prompt ============================
prompt
create table MES4.R_TRSN_BUFFER
(
  cust_kp_no VARCHAR2(20) not null,
  tr_sn      VARCHAR2(20) not null,
  qty        NUMBER(10) not null,
  ip         VARCHAR2(15) not null,
  wo         VARCHAR2(20),
  whs_emp    VARCHAR2(10),
  stock      VARCHAR2(10)
)
;
grant select, insert, update, delete on MES4.R_TRSN_BUFFER to MES1;

prompt
prompt Creating table R_TRSN_BUFFER_WB
prompt ===============================
prompt
create table MES4.R_TRSN_BUFFER_WB
(
  cust_kp_no VARCHAR2(30) not null,
  tr_sn      VARCHAR2(20) not null,
  qty        NUMBER(10) not null,
  ip         VARCHAR2(15) not null,
  wo         VARCHAR2(20),
  whs_emp    VARCHAR2(10),
  stock      VARCHAR2(10),
  data1      VARCHAR2(30),
  data2      VARCHAR2(20),
  data3      VARCHAR2(20)
)
;
grant select, insert, update, delete on MES4.R_TRSN_BUFFER_WB to MES1;

prompt
prompt Creating table R_TRSN_ONLINE_ALARM
prompt ==================================
prompt
create table MES4.R_TRSN_ONLINE_ALARM
(
  tr_sn      VARCHAR2(12) not null,
  wo         VARCHAR2(12) not null,
  station    VARCHAR2(10) not null,
  kp_no      VARCHAR2(20) not null,
  ext_qty    NUMBER(7) not null,
  work_time  DATE not null,
  alarm_time DATE,
  p_sn       VARCHAR2(50)
)
;
grant select, insert, update, delete on MES4.R_TRSN_ONLINE_ALARM to MES1;

prompt
prompt Creating table R_TRSN_USAGE_ALERT
prompt =================================
prompt
create table MES4.R_TRSN_USAGE_ALERT
(
  tr_sn        VARCHAR2(12) not null,
  kp_no        VARCHAR2(20),
  wo           VARCHAR2(12),
  station      VARCHAR2(20),
  slot_no      VARCHAR2(20),
  standard_qty NUMBER,
  load_qty     NUMBER,
  load_time    DATE,
  link_qty     NUMBER,
  work_time    DATE not null,
  log          VARCHAR2(100),
  close_emp    VARCHAR2(10),
  closed_time  DATE,
  remark       VARCHAR2(100),
  closed_flag  VARCHAR2(1) default '0' not null,
  process_flag VARCHAR2(10)
)
;
grant select, insert, update, delete on MES4.R_TRSN_USAGE_ALERT to MES1;

prompt
prompt Creating table R_TR_CODE_DETAIL
prompt ===============================
prompt
create table MES4.R_TR_CODE_DETAIL
(
  tr_code        VARCHAR2(25) not null,
  smt_code       VARCHAR2(6),
  station        VARCHAR2(10) not null,
  station_flag   VARCHAR2(1) not null,
  p_no           VARCHAR2(20) not null,
  p_version      VARCHAR2(4) not null,
  slot_no        VARCHAR2(7),
  feeder_no      VARCHAR2(15),
  tr_sn          VARCHAR2(12) not null,
  kp_no          VARCHAR2(20) not null,
  mfr_kp_no      VARCHAR2(100) not null,
  mfr_code       VARCHAR2(15) not null,
  date_code      VARCHAR2(20),
  lot_code       VARCHAR2(100),
  standard_qty   NUMBER(4) not null,
  emp_no         VARCHAR2(10) not null,
  wo             VARCHAR2(12),
  process_flag   VARCHAR2(1),
  replacekp_flag VARCHAR2(1) default 0 not null,
  work_time      DATE,
  use_flag       VARCHAR2(1) default 0,
  use_time       DATE,
  b_qty          NUMBER(4) default 0,
  t_qty          NUMBER(4) default 0
)
;
create index MES4.IDX_RTCD_DATELOT on MES4.R_TR_CODE_DETAIL (DATE_CODE, LOT_CODE);
create index MES4.IDX_RTCD_KP_LOT on MES4.R_TR_CODE_DETAIL (KP_NO);
create index MES4.IDX_RTCD_LOT_CODE on MES4.R_TR_CODE_DETAIL (LOT_CODE);
create index MES4.IDX_RTCD_SMT_CODE on MES4.R_TR_CODE_DETAIL (SMT_CODE);
create index MES4.IDX_RTCD_STATION on MES4.R_TR_CODE_DETAIL (STATION);
create index MES4.IDX_RTCD_TR_CODE on MES4.R_TR_CODE_DETAIL (TR_CODE);
create index MES4.IDX_RTCD_TR_SN on MES4.R_TR_CODE_DETAIL (TR_SN);
create index MES4.IDX_RTCD_USE_FLAG on MES4.R_TR_CODE_DETAIL (USE_FLAG);
create index MES4.IDX_RTCD_USE_TIME on MES4.R_TR_CODE_DETAIL (USE_TIME);
create index MES4.IDX_RTCD_WO on MES4.R_TR_CODE_DETAIL (WO);
create index MES4.IDX_RTCD_WORKTIME on MES4.R_TR_CODE_DETAIL (WORK_TIME);
grant select, insert, update, delete, references on MES4.R_TR_CODE_DETAIL to MES1;

prompt
prompt Creating table R_TR_CODE_DETAIL_SIMON
prompt =====================================
prompt
create table MES4.R_TR_CODE_DETAIL_SIMON
(
  tr_code        VARCHAR2(25) not null,
  smt_code       VARCHAR2(6),
  station        VARCHAR2(10) not null,
  station_flag   VARCHAR2(1) not null,
  p_no           VARCHAR2(20) not null,
  p_version      VARCHAR2(4) not null,
  slot_no        VARCHAR2(7),
  feeder_no      VARCHAR2(15),
  tr_sn          VARCHAR2(12) not null,
  kp_no          VARCHAR2(20) not null,
  mfr_kp_no      VARCHAR2(100) not null,
  mfr_code       VARCHAR2(15) not null,
  date_code      VARCHAR2(20),
  lot_code       VARCHAR2(100),
  standard_qty   NUMBER(4) not null,
  emp_no         VARCHAR2(10) not null,
  wo             VARCHAR2(12),
  process_flag   VARCHAR2(1),
  replacekp_flag VARCHAR2(1) default '0' not null,
  work_time      DATE
)
;

prompt
prompt Creating table R_TR_CODE_LIST
prompt =============================
prompt
create table MES4.R_TR_CODE_LIST
(
  tr_code    VARCHAR2(25) not null,
  wo         VARCHAR2(12) not null,
  station    VARCHAR2(10) not null,
  start_time DATE not null,
  end_time   DATE,
  emp_no     VARCHAR2(10) not null
)
;
create index MES4.R021_TR_CODE on MES4.R_TR_CODE_LIST (TR_CODE);
create index MES4.R_TR_CODE_LISTEND_TIME on MES4.R_TR_CODE_LIST (END_TIME);
create index MES4.R_TR_CODE_LISTSTART_TIME on MES4.R_TR_CODE_LIST (START_TIME);
create index MES4.R_TR_CODE_LISTSTATION on MES4.R_TR_CODE_LIST (STATION);
create index MES4.R_TR_CODE_LIST_WO on MES4.R_TR_CODE_LIST (WO);
grant select, insert, update, delete, references, alter, index on MES4.R_TR_CODE_LIST to MES1;

prompt
prompt Creating table R_TR_PRODUCT_DETAIL
prompt ==================================
prompt
create table MES4.R_TR_PRODUCT_DETAIL
(
  wo           VARCHAR2(12) not null,
  p_sn         VARCHAR2(25) not null,
  smt_code     VARCHAR2(6),
  tr_code      VARCHAR2(25) not null,
  replace_flag VARCHAR2(1) default '0' not null,
  work_flag    VARCHAR2(1) default '0' not null,
  work_time    DATE not null,
  process_flag VARCHAR2(1)
)
;
create index MES4.R_TR_PRODUCT_DETAIL_P_SN on MES4.R_TR_PRODUCT_DETAIL (P_SN);
create index MES4.R_TR_PRODUCT_DETAIL_TR_CODE on MES4.R_TR_PRODUCT_DETAIL (TR_CODE);
create index MES4.R_TR_PRODUCT_DETAIL_WO on MES4.R_TR_PRODUCT_DETAIL (WO);
create index MES4.R_TR_PRODUCT_DETAIL_WORK_TIME on MES4.R_TR_PRODUCT_DETAIL (WORK_TIME);
grant insert, update, delete, references, alter, index on MES4.R_TR_PRODUCT_DETAIL to MES1;
grant select on MES4.R_TR_PRODUCT_DETAIL to MES1 with grant option;

prompt
prompt Creating table R_TR_PRODUCT_DETAIL_16
prompt =====================================
prompt
create table MES4.R_TR_PRODUCT_DETAIL_16
(
  wo           VARCHAR2(12) not null,
  p_sn         VARCHAR2(25) not null,
  smt_code     VARCHAR2(6),
  tr_code      VARCHAR2(25) not null,
  replace_flag VARCHAR2(1) not null,
  work_flag    VARCHAR2(1) not null,
  work_time    DATE not null,
  process_flag VARCHAR2(1)
)
;

prompt
prompt Creating table R_TR_SN
prompt ======================
prompt
create table MES4.R_TR_SN
(
  tr_sn          VARCHAR2(12) not null,
  doc_no         VARCHAR2(15) not null,
  doc_flag       VARCHAR2(1) not null,
  cust_kp_no     VARCHAR2(20) not null,
  mfr_kp_no      VARCHAR2(100) not null,
  mfr_code       VARCHAR2(15) not null,
  date_code      VARCHAR2(20),
  lot_code       VARCHAR2(100),
  qty            NUMBER(7) not null,
  ext_qty        NUMBER(7) not null,
  location_flag  VARCHAR2(1) not null,
  work_flag      VARCHAR2(1) not null,
  start_time     DATE not null,
  end_time       DATE,
  emp_no         VARCHAR2(10) not null,
  data1          VARCHAR2(50),
  data2          VARCHAR2(25),
  data3          VARCHAR2(25),
  kp_type        VARCHAR2(1),
  tr_sn_desc     VARCHAR2(500),
  ltb_flag       VARCHAR2(5),
  kp_rohs_status VARCHAR2(1),
  kitting_flag   VARCHAR2(1),
  kitting_wo     VARCHAR2(12),
  sap_stock      VARCHAR2(4),
  floor          VARCHAR2(15),
  actual_kp_no   VARCHAR2(40),
  wafer_no       VARCHAR2(20),
  standard_dc    VARCHAR2(20),
  over_time      VARCHAR2(20),
  data4          VARCHAR2(25),
  data5          VARCHAR2(50),
  data6          VARCHAR2(50),
  lcr_value      NUMBER(18,6),
  kp_version     VARCHAR2(50),
  auto_flag      VARCHAR2(10),
  receive_times  VARCHAR2(1) default 1
)
;
create index MES4.IDX_R_TR_SN on MES4.R_TR_SN (TR_SN);
create index MES4.R_TR_SNCUST_KP_NO on MES4.R_TR_SN (CUST_KP_NO);
create index MES4.R_TR_SNDOC_NO on MES4.R_TR_SN (DOC_NO);
create index MES4.R_TR_SNLOCATION_WFLAG on MES4.R_TR_SN (WORK_FLAG);
alter table MES4.R_TR_SN
  add constraint R_TR_SN_R01 unique (TR_SN);
grant select, insert, update, delete, references, alter, index on MES4.R_TR_SN to MES1;

prompt
prompt Creating table R_TR_SN_ADJUST
prompt =============================
prompt
create table MES4.R_TR_SN_ADJUST
(
  sub_tr_sn     VARCHAR2(12) not null,
  tr_sn         VARCHAR2(12) not null,
  qty           NUMBER(7) not null,
  ext_qty       NUMBER(7) not null,
  sub_qty       NUMBER(7) not null,
  location_flag VARCHAR2(1) not null,
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null,
  require_emp   VARCHAR2(10),
  memo          VARCHAR2(250)
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_TR_SN_ADJUST to MES1;

prompt
prompt Creating table R_TR_SN_B
prompt ========================
prompt
create table MES4.R_TR_SN_B
(
  tr_sn          VARCHAR2(12) not null,
  doc_no         VARCHAR2(15) not null,
  doc_flag       VARCHAR2(1) not null,
  cust_kp_no     VARCHAR2(20) not null,
  mfr_kp_no      VARCHAR2(100) not null,
  mfr_code       VARCHAR2(15) not null,
  date_code      VARCHAR2(20),
  lot_code       VARCHAR2(20),
  qty            NUMBER(7) not null,
  ext_qty        NUMBER(7) not null,
  location_flag  VARCHAR2(1) not null,
  kp_type        VARCHAR2(1),
  work_flag      VARCHAR2(1) not null,
  start_time     DATE not null,
  end_time       DATE,
  emp_no         VARCHAR2(10) not null,
  data1          VARCHAR2(10),
  data2          VARCHAR2(25),
  data3          VARCHAR2(25),
  tr_sn_desc     VARCHAR2(50),
  ltb_flag       VARCHAR2(1),
  move_time      DATE not null,
  kp_rohs_status VARCHAR2(1)
)
;
grant select, insert, update, delete on MES4.R_TR_SN_B to MES1;

prompt
prompt Creating table R_TR_SN_CHANGE
prompt =============================
prompt
create table MES4.R_TR_SN_CHANGE
(
  tr_sn         VARCHAR2(12) not null,
  doc_no        VARCHAR2(15) not null,
  doc_flag      VARCHAR2(1) not null,
  cust_kp_no    VARCHAR2(20) not null,
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  date_code     VARCHAR2(20),
  lot_code      VARCHAR2(100),
  qty           NUMBER(7) not null,
  ext_qty       NUMBER(7) not null,
  location_flag VARCHAR2(1) not null,
  work_flag     VARCHAR2(1) not null,
  change_flag   VARCHAR2(1) not null,
  start_time    DATE not null,
  end_time      DATE,
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_TR_SN_CHANGE to MES1;

prompt
prompt Creating table R_TR_SN_CHECK
prompt ============================
prompt
create table MES4.R_TR_SN_CHECK
(
  tr_sn     VARCHAR2(25) not null,
  flag      VARCHAR2(1),
  edit_time DATE default SYSDATE not null,
  edit_emp  VARCHAR2(10)
)
;
create index MES4.INDEX_R_TR_SN_CHECK_1 on MES4.R_TR_SN_CHECK (TR_SN, EDIT_EMP)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.R_TR_SN_CHECK to MES1;

prompt
prompt Creating table R_TR_SN_DETAIL
prompt =============================
prompt
create table MES4.R_TR_SN_DETAIL
(
  tr_sn         VARCHAR2(12) not null,
  cust_kp_no    VARCHAR2(20) not null,
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  date_code     VARCHAR2(20),
  lot_code      VARCHAR2(50),
  qty           NUMBER(7) not null,
  ext_qty       NUMBER(7) not null,
  location_flag VARCHAR2(1) not null,
  work_flag     VARCHAR2(1) not null,
  wo            VARCHAR2(12),
  station       VARCHAR2(10),
  mfg_emp_no    VARCHAR2(10),
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null,
  remark        VARCHAR2(500)
)
;
create index MES4.R_TR_SN_DETAILTR_SN on MES4.R_TR_SN_DETAIL (TR_SN);
create index MES4.R_TR_SN_DETAILTR_STATION on MES4.R_TR_SN_DETAIL (STATION);
create index MES4.R_TR_SN_DETAILWORK_TIME on MES4.R_TR_SN_DETAIL (WORK_TIME);
create index MES4.R_TR_SN_DETAIL_WO on MES4.R_TR_SN_DETAIL (WO);
grant select, insert, update, delete, references, alter, index on MES4.R_TR_SN_DETAIL to MES1;

prompt
prompt Creating table R_TR_SN_EXTEND
prompt =============================
prompt
create table MES4.R_TR_SN_EXTEND
(
  tr_sn          VARCHAR2(15) not null,
  cust_kp_no     VARCHAR2(30) not null,
  mfr_code       VARCHAR2(15) not null,
  mfr_name       VARCHAR2(100),
  cust_po        VARCHAR2(15),
  cust_track_no  VARCHAR2(50),
  track_wo       VARCHAR2(15),
  whs_move_desc  VARCHAR2(20),
  receive_type   VARCHAR2(20),
  data1          VARCHAR2(25),
  data2          VARCHAR2(25),
  data3          VARCHAR2(250),
  data4          VARCHAR2(25),
  data5          VARCHAR2(25),
  data6          VARCHAR2(50),
  mpn_barcode    VARCHAR2(25),
  dc_barcode     VARCHAR2(25),
  lc_barcode     VARCHAR2(25),
  qty_barcode    VARCHAR2(25),
  customer_kp_no VARCHAR2(50),
  change_kp_no   VARCHAR2(50)
)
;
create unique index MES4.INDEX_R_TR_SN_EXTEND on MES4.R_TR_SN_EXTEND (TR_SN);
create index MES4.INDEX_R_TR_SN_EXTEND_TRACKNO on MES4.R_TR_SN_EXTEND (TRACK_WO)
  nologging;
grant select, insert, update, delete on MES4.R_TR_SN_EXTEND to MES1;

prompt
prompt Creating table R_TR_SN_HOLD
prompt ===========================
prompt
create table MES4.R_TR_SN_HOLD
(
  tr_sn         VARCHAR2(12) not null,
  doc_no        VARCHAR2(15) not null,
  doc_flag      VARCHAR2(1) not null,
  cust_kp_no    VARCHAR2(20) not null,
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  date_code     VARCHAR2(20),
  lot_code      VARCHAR2(100),
  qty           NUMBER(7) not null,
  ext_qty       NUMBER(7) not null,
  location_flag VARCHAR2(1) not null,
  work_flag     VARCHAR2(1) not null,
  start_time    DATE not null,
  end_time      DATE,
  hold_emp_no   VARCHAR2(10) not null,
  open_emp_no   VARCHAR2(10),
  data1         VARCHAR2(10),
  data2         VARCHAR2(25),
  data3         VARCHAR2(25),
  hold_no       VARCHAR2(15),
  snumber       VARCHAR2(20),
  hold_reason   VARCHAR2(300),
  unhold_reason VARCHAR2(200)
)
;
create index MES4.R_TR_SN_HOLDCUST_KP_NO on MES4.R_TR_SN_HOLD (CUST_KP_NO);
create index MES4.R_TR_SN_HOLDTR_SN on MES4.R_TR_SN_HOLD (TR_SN);
grant select, insert, update, delete, references, alter, index on MES4.R_TR_SN_HOLD to MES1;

prompt
prompt Creating table R_TR_SN_NO
prompt =========================
prompt
create table MES4.R_TR_SN_NO
(
  tr_no     VARCHAR2(12) not null,
  tr_sn     VARCHAR2(12) not null,
  work_time DATE default SYSDATE not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_TR_SN_NO to MES1;

prompt
prompt Creating table R_TR_SN_NULL_CONFIRM
prompt ===================================
prompt
create table MES4.R_TR_SN_NULL_CONFIRM
(
  tr_sn          VARCHAR2(30),
  wo             VARCHAR2(12),
  kp_no          VARCHAR2(20),
  mfr_kp_no      VARCHAR2(100),
  mfr_code       VARCHAR2(15),
  date_code      VARCHAR2(20),
  lot_code       VARCHAR2(20),
  qty            NUMBER(7),
  ext_qty        NUMBER(7),
  work_time      DATE,
  station        VARCHAR2(10),
  station_flag   VARCHAR2(1),
  start_time     DATE,
  work_flag      VARCHAR2(1) default '0',
  emp_no         VARCHAR2(10),
  confirm_emp_no VARCHAR2(10),
  memo           VARCHAR2(200)
)
;
grant select, insert, update, delete on MES4.R_TR_SN_NULL_CONFIRM to MES1;

prompt
prompt Creating table R_TR_SN_PREFORMATING
prompt ===================================
prompt
create table MES4.R_TR_SN_PREFORMATING
(
  tr_sn            VARCHAR2(12),
  wo               VARCHAR2(12),
  stationno        VARCHAR2(250),
  stationname      VARCHAR2(250),
  msize            VARCHAR2(250),
  mtype            VARCHAR2(250),
  processing_notes VARCHAR2(250),
  qty              NUMBER(7),
  good_qty         NUMBER(7),
  bad_qty          NUMBER(7),
  unprocessed_qty  NUMBER(7),
  checkout_notes   VARCHAR2(250),
  work_flag        VARCHAR2(1) default 0,
  checkin_emp      VARCHAR2(20),
  checkin_time     DATE,
  work_emp         VARCHAR2(20),
  work_time        DATE,
  checkout_emp     VARCHAR2(20),
  checkout_time    DATE,
  data1            VARCHAR2(250),
  data2            VARCHAR2(250),
  data3            VARCHAR2(250),
  data4            VARCHAR2(250),
  data5            VARCHAR2(250)
)
;
comment on column MES4.R_TR_SN_PREFORMATING.tr_sn
  is 'tr_sn';
comment on column MES4.R_TR_SN_PREFORMATING.wo
  is 'wo';
comment on column MES4.R_TR_SN_PREFORMATING.stationno
  is '機台編號';
comment on column MES4.R_TR_SN_PREFORMATING.stationname
  is '機台名稱';
comment on column MES4.R_TR_SN_PREFORMATING.msize
  is '規格（加工）';
comment on column MES4.R_TR_SN_PREFORMATING.mtype
  is '類型（加工）';
comment on column MES4.R_TR_SN_PREFORMATING.processing_notes
  is '加工備註';
comment on column MES4.R_TR_SN_PREFORMATING.qty
  is '原盤異動前的數量';
comment on column MES4.R_TR_SN_PREFORMATING.good_qty
  is '加工的良品數';
comment on column MES4.R_TR_SN_PREFORMATING.bad_qty
  is '加工的不良品數';
comment on column MES4.R_TR_SN_PREFORMATING.unprocessed_qty
  is '未加工的數量';
comment on column MES4.R_TR_SN_PREFORMATING.checkout_notes
  is '退回KIT的備註';
comment on column MES4.R_TR_SN_PREFORMATING.work_flag
  is '默認是:0  ; 加工完成是: 1 ;';
comment on column MES4.R_TR_SN_PREFORMATING.checkin_emp
  is '收入Preformating的工號';
comment on column MES4.R_TR_SN_PREFORMATING.checkin_time
  is '收入Preformating的時間';
comment on column MES4.R_TR_SN_PREFORMATING.work_emp
  is '加工人員工號';
comment on column MES4.R_TR_SN_PREFORMATING.work_time
  is '加工完成時間';
comment on column MES4.R_TR_SN_PREFORMATING.checkout_emp
  is '退回KIT的人員工號';
comment on column MES4.R_TR_SN_PREFORMATING.checkout_time
  is '退回KIT的時間';
create index MES4.R_TR_SN_PREFORMATIOG_R02 on MES4.R_TR_SN_PREFORMATING (WO);
alter table MES4.R_TR_SN_PREFORMATING
  add constraint R_TR_SN_PREFORMATING_R01 unique (TR_SN);
grant select, insert, update, delete, alter on MES4.R_TR_SN_PREFORMATING to MES1;

prompt
prompt Creating table R_TR_SN_WIP
prompt ==========================
prompt
create table MES4.R_TR_SN_WIP
(
  tr_sn        VARCHAR2(12) not null,
  wo           VARCHAR2(12) not null,
  kp_no        VARCHAR2(20) not null,
  mfr_kp_no    VARCHAR2(100) not null,
  mfr_code     VARCHAR2(15) not null,
  date_code    VARCHAR2(20),
  lot_code     VARCHAR2(100),
  qty          NUMBER(7) not null,
  ext_qty      NUMBER(7) not null,
  work_time    DATE not null,
  station      VARCHAR2(10) not null,
  station_flag VARCHAR2(1) not null,
  start_time   DATE,
  work_flag    VARCHAR2(1) default '0' not null,
  emp_no       VARCHAR2(10) not null,
  slot_no      VARCHAR2(20),
  process_flag VARCHAR2(10)
)
;
comment on column MES4.R_TR_SN_WIP.tr_sn
  is 'ALLPART???';
create index MES4.R_TR_SN_WIPKP_NO on MES4.R_TR_SN_WIP (KP_NO);
create index MES4.R_TR_SN_WIPTR_SN on MES4.R_TR_SN_WIP (TR_SN);
create index MES4.R_TR_SN_WIPWORK_TIME on MES4.R_TR_SN_WIP (WORK_TIME);
create index MES4.R_TR_SN_WIP_STATION on MES4.R_TR_SN_WIP (STATION);
create index MES4.R_TR_SN_WIP_WFLAG on MES4.R_TR_SN_WIP (WORK_FLAG);
grant select, insert, update, delete, references, alter, index on MES4.R_TR_SN_WIP to MES1;

prompt
prompt Creating table R_VDCS_BASE
prompt ==========================
prompt
create table MES4.R_VDCS_BASE
(
  sheet_no         VARCHAR2(15) not null,
  create_time      DATE not null,
  plant            VARCHAR2(10),
  model            VARCHAR2(20),
  customer         VARCHAR2(20),
  bu               VARCHAR2(20),
  cust_kp_no       VARCHAR2(20),
  material_code    VARCHAR2(10),
  vendor           VARCHAR2(20),
  vendor_kp_no     VARCHAR2(20),
  defect_qty       NUMBER(6),
  suspect_qty      NUMBER(10),
  failure_rate     VARCHAR2(15),
  po_no            VARCHAR2(15),
  initiator        VARCHAR2(25),
  defect_desc      VARCHAR2(200),
  attac_no         VARCHAR2(15),
  sample_qty       NUMBER(5),
  sample_send_time DATE,
  tracking_no      VARCHAR2(15),
  vdcs_expec       VARCHAR2(500),
  suspect_handle   VARCHAR2(20),
  email_no         VARCHAR2(15),
  prepare_emp      VARCHAR2(10) not null,
  prepare_time     DATE not null,
  vdcs_status      VARCHAR2(1) default '0' not null,
  close_time       DATE,
  delete_emp       VARCHAR2(10),
  delete_time      DATE,
  defect_code      VARCHAR2(10),
  critical_issue   VARCHAR2(1)
)
;
grant select, insert, update, delete on MES4.R_VDCS_BASE to MES1;

prompt
prompt Creating table R_VDCS_INSPECT
prompt =============================
prompt
create table MES4.R_VDCS_INSPECT
(
  sheet_no         VARCHAR2(15) not null,
  cust_kp_no       VARCHAR2(20) not null,
  po_no            VARCHAR2(15) not null,
  inspect_time     DATE not null,
  inspect_qty      NUMBER(10) not null,
  inspect_result   VARCHAR2(1) default '0' not null,
  inspect_remark   VARCHAR2(500),
  attac_no         VARCHAR2(15),
  prepare_email_no VARCHAR2(15),
  prepare_emp      VARCHAR2(10) not null,
  prepare_time     DATE not null,
  approve_email_no VARCHAR2(15),
  approve_emp      VARCHAR2(10),
  approve_time     DATE
)
;
grant select, insert, update, delete on MES4.R_VDCS_INSPECT to MES1;

prompt
prompt Creating table R_VIRTUAL_SN_REPLACE
prompt ===================================
prompt
create table MES4.R_VIRTUAL_SN_REPLACE
(
  virtual_sn   VARCHAR2(15) not null,
  p_sn         VARCHAR2(25) not null,
  process_flag VARCHAR2(5),
  seq_no       VARCHAR2(5),
  emp_no       VARCHAR2(15) not null,
  edit_time    DATE not null
)
;
grant select, insert, update, delete, alter on MES4.R_VIRTUAL_SN_REPLACE to MES1;

prompt
prompt Creating table R_VMI_PICKLIST
prompt =============================
prompt
create table MES4.R_VMI_PICKLIST
(
  facilityno         VARCHAR2(50),
  customercode       VARCHAR2(50),
  picklistno         VARCHAR2(50) not null,
  customervendorcode VARCHAR2(50),
  customerpartno     VARCHAR2(50),
  customerrevision   VARCHAR2(50),
  shippingdatetime   VARCHAR2(50),
  shippingquantity   NUMBER(10) default 0,
  uom                VARCHAR2(5),
  vendorrefrenceno   VARCHAR2(50),
  customeraffairno   VARCHAR2(50),
  po                 VARCHAR2(50),
  grn                VARCHAR2(50),
  edisend            VARCHAR2(2),
  receive_qty        NUMBER(10) default 0,
  sapsend            VARCHAR2(1),
  lastedittime       DATE,
  tiptop             VARCHAR2(20),
  po_item            VARCHAR2(10),
  grtime             DATE
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_VMI_PICKLIST to MES1;

prompt
prompt Creating table R_VMI_QTY
prompt ========================
prompt
create table MES4.R_VMI_QTY
(
  cust_kp_no  VARCHAR2(20) not null,
  receive_qty NUMBER(10) not null,
  accept_qty  NUMBER(10) default 0 not null,
  work_time   DATE default SYSDATE not null
)
;
grant select, insert, update, delete on MES4.R_VMI_QTY to MES1;

prompt
prompt Creating table R_VMI_TEMP
prompt =========================
prompt
create table MES4.R_VMI_TEMP
(
  doc_no     VARCHAR2(15) not null,
  cust_kp_no VARCHAR2(20) not null,
  mfr_kp_no  VARCHAR2(100) not null,
  mfr_code   VARCHAR2(15) not null,
  ip         VARCHAR2(20) not null,
  vmi_date   VARCHAR2(6) not null,
  work_time  DATE default sysdate not null
)
;
grant select, insert, update, delete on MES4.R_VMI_TEMP to MES1;

prompt
prompt Creating table R_V_WO
prompt =====================
prompt
create table MES4.R_V_WO
(
  v_wo        VARCHAR2(10) not null,
  seq_no      VARCHAR2(2) not null,
  t_wo        VARCHAR2(12) not null,
  emp_no      VARCHAR2(10) not null,
  ledit_time  DATE not null,
  wo          VARCHAR2(12),
  change_flag VARCHAR2(1)
)
;
create index MES4.R_V_WO_IDX01 on MES4.R_V_WO (T_WO);
create index MES4.R_V_WO_IDX02 on MES4.R_V_WO (V_WO);
grant select, insert, update, delete on MES4.R_V_WO to MES1;

prompt
prompt Creating table R_WAIBAO_SN_DETAIL
prompt =================================
prompt
create table MES4.R_WAIBAO_SN_DETAIL
(
  serial_number    VARCHAR2(50),
  wo               VARCHAR2(25),
  model_name       VARCHAR2(25),
  line_name        VARCHAR2(8),
  station_name     VARCHAR2(16),
  in_station_time  DATE,
  end_station_time DATE,
  error_code       VARCHAR2(16),
  location_code    VARCHAR2(16),
  repair_time      DATE,
  data1            VARCHAR2(20),
  data2            VARCHAR2(20)
)
;
create index SYS.R_WAIBAO_SN_DETAIL_SN on MES4.R_WAIBAO_SN_DETAIL (STATION_NAME, SERIAL_NUMBER);

prompt
prompt Creating table R_WAIBAO_SN_LINK
prompt ===============================
prompt
create table MES4.R_WAIBAO_SN_LINK
(
  wo            VARCHAR2(25),
  serial_number VARCHAR2(30),
  panel_no      VARCHAR2(25),
  link_time     DATE,
  data1         VARCHAR2(20),
  data2         VARCHAR2(20)
)
;
create index SYS.IDX_R_WAIBAO_SN_LINK on MES4.R_WAIBAO_SN_LINK (WO, SERIAL_NUMBER);

prompt
prompt Creating table R_WAIBAO_TR_CODE_DETAIL
prompt ======================================
prompt
create table MES4.R_WAIBAO_TR_CODE_DETAIL
(
  tr_code      VARCHAR2(25),
  station      VARCHAR2(25),
  station_flag VARCHAR2(1),
  wo           VARCHAR2(12),
  p_no         VARCHAR2(20),
  slot_no      VARCHAR2(12),
  feeder_no    VARCHAR2(15),
  tr_sn        VARCHAR2(30),
  kp_no        VARCHAR2(20),
  mfr_kp_no    VARCHAR2(40),
  mfr_code     VARCHAR2(15),
  date_code    VARCHAR2(20),
  lot_code     VARCHAR2(20),
  process_flag VARCHAR2(5),
  work_time    DATE,
  data1        VARCHAR2(20),
  data2        VARCHAR2(20)
)
;
create index SYS.IDX_R_WAIBAO_TR_CODE_DETAIL on MES4.R_WAIBAO_TR_CODE_DETAIL (WO, TR_CODE, P_NO, KP_NO);

prompt
prompt Creating table R_WAIBAO_TR_PRODUCT_DETAIL
prompt =========================================
prompt
create table MES4.R_WAIBAO_TR_PRODUCT_DETAIL
(
  wo           VARCHAR2(12),
  p_sn         VARCHAR2(25),
  tr_code      VARCHAR2(250),
  process_flag VARCHAR2(5),
  work_time    DATE,
  station      VARCHAR2(25),
  data1        VARCHAR2(20),
  data2        VARCHAR2(20)
)
;
create index SYS.IDX_R_WAIBAO_TR_PRODUCT_DETAIL on MES4.R_WAIBAO_TR_PRODUCT_DETAIL (WO, TR_CODE, P_SN);

prompt
prompt Creating table R_WAIBAO_TR_SN_DETAIL
prompt ====================================
prompt
create table MES4.R_WAIBAO_TR_SN_DETAIL
(
  tr_sn      VARCHAR2(30),
  outside_sn VARCHAR2(30),
  wo         VARCHAR2(12),
  cust_kp_no VARCHAR2(20),
  mfr_kp_no  VARCHAR2(40),
  mfr_code   VARCHAR2(15),
  date_code  VARCHAR2(20),
  lot_code   VARCHAR2(20),
  qty        NUMBER(7),
  ext_qty    NUMBER(7),
  feeder_no  VARCHAR2(20),
  slot_no    VARCHAR2(20),
  start_time DATE,
  end_time   DATE,
  station    VARCHAR2(25),
  data1      VARCHAR2(20),
  data2      VARCHAR2(20)
)
;
create index SYS.IDX_R_WAIBAO_TR_SN_DETAIL on MES4.R_WAIBAO_TR_SN_DETAIL (WO, TR_SN, CUST_KP_NO);

prompt
prompt Creating table R_WHS
prompt ====================
prompt
create table MES4.R_WHS
(
  plant            VARCHAR2(6) not null,
  doc_no           VARCHAR2(15) not null,
  doc_type         VARCHAR2(1) not null,
  po_no            VARCHAR2(15),
  cust_code        VARCHAR2(15),
  cust_kp_no       VARCHAR2(20) not null,
  mfr_kp_no        VARCHAR2(100) not null,
  mfr_code         VARCHAR2(15) not null,
  vendor_code      VARCHAR2(15),
  buyer_code       VARCHAR2(3) not null,
  buyer_name       VARCHAR2(18) not null,
  receive_qty      NUMBER(10) not null,
  accept_qty       NUMBER(10) default 0 not null,
  reject_qty       NUMBER(10) default 0 not null,
  reject_reason    VARCHAR2(500),
  receive_time     DATE not null,
  accept_flag      NUMBER(1) default 0 not null,
  accept_data      VARCHAR2(25),
  deviation_period VARCHAR2(25),
  kp_status        VARCHAR2(25),
  qc_emp           VARCHAR2(10),
  guarantee        VARCHAR2(20),
  download_time    DATE not null,
  work_time        DATE,
  emp_no           VARCHAR2(10),
  npi_product      VARCHAR2(20),
  accept_desc      VARCHAR2(120),
  sap321_flag      VARCHAR2(1) default 0 not null,
  gt_flag          VARCHAR2(2) default 0,
  po_type          VARCHAR2(4),
  new_part         VARCHAR2(1)
)
;
create index MES4.R_WHS_A_QTY on MES4.R_WHS (ACCEPT_QTY);
create index MES4.R_WHS_CUST_KP_NO on MES4.R_WHS (CUST_KP_NO);
create index MES4.R_WHS_DOC_NO on MES4.R_WHS (DOC_NO);
create index MES4.R_WHS_DTIME on MES4.R_WHS (DOWNLOAD_TIME);
create index MES4.R_WHS_GTFLAG on MES4.R_WHS (GT_FLAG);
create index MES4.R_WHS_MFR_CODE on MES4.R_WHS (MFR_CODE);
create index MES4.R_WHS_MFR_KP_NO on MES4.R_WHS (MFR_KP_NO);
create index MES4.R_WHS_WORK_TIME on MES4.R_WHS (WORK_TIME);
grant select, insert, update, delete, references, alter, index on MES4.R_WHS to MES1;

prompt
prompt Creating table R_WHS_CHANGE
prompt ===========================
prompt
create table MES4.R_WHS_CHANGE
(
  doc_no        VARCHAR2(15) not null,
  doc_type      VARCHAR2(1) not null,
  po_no         VARCHAR2(15),
  cust_kp_no    VARCHAR2(20) not null,
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  vendor_code   VARCHAR2(15),
  buyer_code    VARCHAR2(3) not null,
  buyer_name    VARCHAR2(18) not null,
  receive_qty   NUMBER(10) not null,
  accept_qty    NUMBER(10) default 0 not null,
  reject_qty    NUMBER(10) default 0 not null,
  reject_reason VARCHAR2(210),
  receive_time  DATE not null,
  download_time DATE not null,
  change_flag   VARCHAR2(1) not null,
  work_time     DATE not null,
  emp_no        VARCHAR2(10) not null
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_WHS_CHANGE to MES1;

prompt
prompt Creating table R_WHS_CHECK_DETAIL
prompt =================================
prompt
create table MES4.R_WHS_CHECK_DETAIL
(
  checkid      VARCHAR2(12) not null,
  tr_sn        VARCHAR2(12) not null,
  cust_kp_no   VARCHAR2(20) not null,
  location     VARCHAR2(30),
  type         VARCHAR2(10),
  ext_qty      NUMBER(7) not null,
  multiple_qty NUMBER(5) default 1 not null,
  check_qty    NUMBER(7) not null,
  emp_no       VARCHAR2(20) not null,
  scandatetime DATE not null,
  work_emp     VARCHAR2(20) not null,
  work_time    DATE not null,
  data1        VARCHAR2(50),
  data2        VARCHAR2(50),
  data3        VARCHAR2(50),
  data4        VARCHAR2(50)
)
;

prompt
prompt Creating table R_WHS_CHECK_TEMP
prompt ===============================
prompt
create table MES4.R_WHS_CHECK_TEMP
(
  tr_sn        VARCHAR2(12) not null,
  cust_kp_no   VARCHAR2(20) not null,
  location     VARCHAR2(30),
  type         VARCHAR2(10),
  ext_qty      NUMBER(7) not null,
  multiple_qty NUMBER(5) default 1 not null,
  check_qty    NUMBER(7) not null,
  emp_no       VARCHAR2(10) not null,
  scandatetime DATE not null,
  data1        VARCHAR2(50),
  data2        VARCHAR2(50),
  data3        VARCHAR2(50),
  data4        VARCHAR2(50)
)
;

prompt
prompt Creating table R_WHS_DETAIL
prompt ===========================
prompt
create table MES4.R_WHS_DETAIL
(
  doc_no        VARCHAR2(15) not null,
  cust_kp_no    VARCHAR2(20) not null,
  mfr_kp_no     VARCHAR2(100) not null,
  mfr_code      VARCHAR2(15) not null,
  receive_qty   NUMBER(10) not null,
  accept_qty    NUMBER(10) default 0 not null,
  reject_qty    NUMBER(10) default 0 not null,
  reject_reason VARCHAR2(120),
  work_time     DATE
)
;
create index MES4.R_WHS_DETAILCUST_KP_NO on MES4.R_WHS_DETAIL (CUST_KP_NO)
  nologging;
create index MES4.R_WHS_DETAILDOC_NO on MES4.R_WHS_DETAIL (DOC_NO)
  nologging;
create index MES4.R_WHS_DETAILMFR_CODE on MES4.R_WHS_DETAIL (MFR_CODE)
  nologging;
create index MES4.R_WHS_DETAILMFR_KP_NO on MES4.R_WHS_DETAIL (MFR_KP_NO)
  nologging;
grant select, insert, update, delete, references, alter, index on MES4.R_WHS_DETAIL to MES1;

prompt
prompt Creating table R_WHS_DF
prompt =======================
prompt
create table MES4.R_WHS_DF
(
  plant            VARCHAR2(6) not null,
  doc_no           VARCHAR2(15) not null,
  doc_type         VARCHAR2(1) not null,
  po_no            VARCHAR2(15),
  cust_code        VARCHAR2(15),
  cust_kp_no       VARCHAR2(20) not null,
  mfr_kp_no        VARCHAR2(100) not null,
  mfr_code         VARCHAR2(15) not null,
  vendor_code      VARCHAR2(15),
  buyer_code       VARCHAR2(3) not null,
  buyer_name       VARCHAR2(18) not null,
  receive_qty      NUMBER(10) not null,
  accept_qty       NUMBER(10) default 0 not null,
  reject_qty       NUMBER(10) default 0 not null,
  reject_reason    VARCHAR2(200),
  receive_time     DATE not null,
  accept_flag      NUMBER(1) default 0 not null,
  accept_data      VARCHAR2(25),
  deviation_period VARCHAR2(25),
  kp_status        VARCHAR2(25),
  qc_emp           VARCHAR2(10),
  guarantee        VARCHAR2(20),
  download_time    DATE not null,
  work_time        DATE,
  emp_no           VARCHAR2(10),
  npi_product      VARCHAR2(20),
  gt_flag          VARCHAR2(2) default 0,
  po_type          VARCHAR2(4),
  new_part         VARCHAR2(1)
)
;

prompt
prompt Creating table R_WHS_KP_CHECK_RESULT
prompt ====================================
prompt
create table MES4.R_WHS_KP_CHECK_RESULT
(
  checkid    VARCHAR2(12) not null,
  cust_kp_no VARCHAR2(20) not null,
  location   VARCHAR2(30),
  sn_count   NUMBER(7) not null,
  check_qty  NUMBER(10) not null,
  sap_qty    NUMBER(10) not null,
  work_emp   VARCHAR2(20) not null,
  work_time  DATE not null,
  data1      VARCHAR2(50),
  data2      VARCHAR2(50),
  data3      VARCHAR2(50),
  data4      VARCHAR2(50)
)
;
grant select, insert, update, delete on MES4.R_WHS_KP_CHECK_RESULT to MES1;

prompt
prompt Creating table R_WHS_KP_UNCHECK_RESULT
prompt ======================================
prompt
create table MES4.R_WHS_KP_UNCHECK_RESULT
(
  checkid     VARCHAR2(12) not null,
  cust_kp_no  VARCHAR2(20) not null,
  location    VARCHAR2(30),
  sn_count    NUMBER(7) not null,
  uncheck_qty NUMBER(10) not null,
  sap_qty     NUMBER(10) not null,
  work_emp    VARCHAR2(20) not null,
  work_time   DATE not null,
  data1       VARCHAR2(50),
  data2       VARCHAR2(50),
  data3       VARCHAR2(50),
  data4       VARCHAR2(50)
)
;
grant select, insert, update, delete on MES4.R_WHS_KP_UNCHECK_RESULT to MES1;

prompt
prompt Creating table R_WHS_LOCATION
prompt =============================
prompt
create table MES4.R_WHS_LOCATION
(
  location   VARCHAR2(16) not null,
  tr_sn      VARCHAR2(12) not null,
  cust_kp_no VARCHAR2(20) not null,
  qty        NUMBER not null,
  work_emp   VARCHAR2(16),
  work_time  DATE default sysdate,
  memo       VARCHAR2(50),
  data2      VARCHAR2(2)
)
;
create index MES4.R_IX_RWL_TR on MES4.R_WHS_LOCATION (TR_SN)
  nologging;
grant select, insert, update, delete on MES4.R_WHS_LOCATION to MES1;

prompt
prompt Creating table R_WHS_LOCATION_NEW
prompt =================================
prompt
create table MES4.R_WHS_LOCATION_NEW
(
  location   VARCHAR2(15),
  tr_sn      VARCHAR2(12) not null,
  qty        NUMBER(7),
  cust_kp_no VARCHAR2(20),
  data2      VARCHAR2(20),
  over_time  VARCHAR2(20),
  print_type VARCHAR2(1) default '0',
  print_data VARCHAR2(20),
  start_time DATE
)
;
alter table MES4.R_WHS_LOCATION_NEW
  add constraint IX_R_WHS_LOCATION_TRSN primary key (TR_SN);
alter index MES4.IX_R_WHS_LOCATION_TRSN nologging;
grant select, insert, update, delete on MES4.R_WHS_LOCATION_NEW to MES1;

prompt
prompt Creating table R_WHS_MOVE
prompt =========================
prompt
create table MES4.R_WHS_MOVE
(
  tr_sn       VARCHAR2(12) not null,
  work_flag   VARCHAR2(1) not null,
  cost_center VARCHAR2(15) not null,
  qty         NUMBER(7) not null,
  work_time   DATE not null,
  emp_no      VARCHAR2(50) not null,
  cust_kp_no  VARCHAR2(25),
  mfr_kp_no   VARCHAR2(100),
  mfr_code    VARCHAR2(20),
  date_code   VARCHAR2(20),
  lot_code    VARCHAR2(100),
  move_type   VARCHAR2(1),
  move_desc   VARCHAR2(20),
  sap_doc     VARCHAR2(20),
  wo          VARCHAR2(16),
  move_reason VARCHAR2(50),
  data1       VARCHAR2(25),
  data2       VARCHAR2(25),
  data3       VARCHAR2(25),
  data4       VARCHAR2(25)
)
;
create index MES4.R005_TR_SN on MES4.R_WHS_MOVE (TR_SN);
grant select, insert, update, delete, references, alter, index on MES4.R_WHS_MOVE to MES1;

prompt
prompt Creating table R_WHS_NOSAP
prompt ==========================
prompt
create table MES4.R_WHS_NOSAP
(
  part_no     VARCHAR2(20),
  qty         NUMBER(10) not null,
  f_stock     VARCHAR2(6) not null,
  t_stock     VARCHAR2(6) not null,
  edit_time   DATE not null,
  plant       VARCHAR2(6) not null,
  action_code NUMBER(10) not null,
  emp_no      VARCHAR2(10) not null,
  work_flag   VARCHAR2(2),
  sap_doc     VARCHAR2(20)
)
;
grant select, insert, update, delete on MES4.R_WHS_NOSAP to MES1;

prompt
prompt Creating table R_WHS_SAP261
prompt ===========================
prompt
create table MES4.R_WHS_SAP261
(
  wo            VARCHAR2(20) not null,
  cust_kp_no    VARCHAR2(30) not null,
  qty           INTEGER not null,
  plant         VARCHAR2(10) not null,
  sap_flag      VARCHAR2(2) not null,
  sap_time      DATE default SYSDATE,
  out_stock     VARCHAR2(10) not null,
  sap_message   VARCHAR2(200),
  out_type      VARCHAR2(20),
  sap_emp       VARCHAR2(30),
  sap_real_time DATE,
  data1         VARCHAR2(40),
  kp_version    VARCHAR2(20),
  sap_stock     VARCHAR2(10),
  work_time     DATE default sysdate not null,
  sap_doc       VARCHAR2(20),
  fail_times    NUMBER(7),
  running       VARCHAR2(1),
  data2         VARCHAR2(50),
  data3         VARCHAR2(50),
  data4         VARCHAR2(50)
)
;
grant select, insert, update, delete on MES4.R_WHS_SAP261 to MES1;

prompt
prompt Creating table R_WHS_SAP_WO
prompt ===========================
prompt
create table MES4.R_WHS_SAP_WO
(
  wo           VARCHAR2(12) not null,
  cust_kp_no   VARCHAR2(20) not null,
  request_qty  INTEGER not null,
  checkout_qty INTEGER default 0,
  work_time    DATE,
  sap_stock    VARCHAR2(10),
  return_qty   INTEGER default 0,
  item_no      VARCHAR2(20)
)
;
grant select, insert, update on MES4.R_WHS_SAP_WO to MES1;

prompt
prompt Creating table R_WHS_SCAN_DETAIL
prompt ================================
prompt
create table MES4.R_WHS_SCAN_DETAIL
(
  tr_sn         VARCHAR2(15) not null,
  cust_kp_no    VARCHAR2(20) not null,
  qty           INTEGER not null,
  emp_no        VARCHAR2(10),
  work_time     DATE,
  accept_emp    VARCHAR2(15),
  flag          NUMBER not null,
  wo            VARCHAR2(20) not null,
  process       VARCHAR2(20),
  type          VARCHAR2(20),
  memo          VARCHAR2(20),
  from_location VARCHAR2(50),
  to_location   VARCHAR2(50),
  plant         VARCHAR2(20),
  sap_time      DATE,
  sap_doc       VARCHAR2(200),
  data1         VARCHAR2(200),
  data2         VARCHAR2(200),
  data3         VARCHAR2(200),
  data4         VARCHAR2(200)
)
;
create index MES4.IDX_WHS_SCAN_DETAIL_TRSN on MES4.R_WHS_SCAN_DETAIL (TR_SN);
create index MES4.IDX_WHS_SCAN_DETAIL_WO on MES4.R_WHS_SCAN_DETAIL (WO);
grant select, insert, update, delete on MES4.R_WHS_SCAN_DETAIL to MES1;

prompt
prompt Creating table R_WHS_STOCK
prompt ==========================
prompt
create table MES4.R_WHS_STOCK
(
  stock_no  VARCHAR2(10) not null,
  p_no      VARCHAR2(25) not null,
  stock_qty NUMBER not null,
  part_type VARCHAR2(1) not null,
  part_flag VARCHAR2(1) not null,
  work_time DATE not null,
  memo      VARCHAR2(50)
)
;
grant select, insert, update, delete on MES4.R_WHS_STOCK to MES1;

prompt
prompt Creating table R_WHS_UNCHECK_DETAIL
prompt ===================================
prompt
create table MES4.R_WHS_UNCHECK_DETAIL
(
  checkid    VARCHAR2(12) not null,
  tr_sn      VARCHAR2(12) not null,
  cust_kp_no VARCHAR2(20) not null,
  location   VARCHAR2(30),
  ext_qty    NUMBER(7) not null,
  work_emp   VARCHAR2(20) not null,
  work_time  DATE not null,
  data1      VARCHAR2(50),
  data2      VARCHAR2(50),
  data3      VARCHAR2(50),
  data4      VARCHAR2(50)
)
;
grant select, insert, update, delete on MES4.R_WHS_UNCHECK_DETAIL to MES1;

prompt
prompt Creating table R_WIRELESS_COUNT_DETAIL
prompt ======================================
prompt
create table MES4.R_WIRELESS_COUNT_DETAIL
(
  file_name VARCHAR2(80) not null,
  flag      VARCHAR2(1),
  edit_time DATE,
  edit_emp  VARCHAR2(16)
)
;
create index MES4.IDX_R_WIRELESS_COUNT_DETAIL on MES4.R_WIRELESS_COUNT_DETAIL (FILE_NAME, FLAG)
  nologging;

prompt
prompt Creating table R_WIRELESS_COUNT_STAT
prompt ====================================
prompt
create table MES4.R_WIRELESS_COUNT_STAT
(
  line_name       VARCHAR2(10) not null,
  date_shift      VARCHAR2(10) not null,
  wo              VARCHAR2(12) not null,
  p_no            VARCHAR2(30) not null,
  process_flag    VARCHAR2(1) not null,
  work_date       VARCHAR2(8) not null,
  work_section    VARCHAR2(2) not null,
  output_qty      NUMBER default 0,
  fact_output_qty NUMBER default 0
)
;
create index MES4.IX1_R_WIRELESS_COUNT_STAT on MES4.R_WIRELESS_COUNT_STAT (WO);
create index MES4.IX2_R_WIRELESS_COUNT_STAT on MES4.R_WIRELESS_COUNT_STAT (P_NO);
create index MES4.IX_R_WIRELESS_COUNT_STAT on MES4.R_WIRELESS_COUNT_STAT (LINE_NAME);
grant select, insert, update, delete on MES4.R_WIRELESS_COUNT_STAT to MES1;

prompt
prompt Creating table R_WORKFLOW_EVENT_DETAIL
prompt ======================================
prompt
create table MES4.R_WORKFLOW_EVENT_DETAIL
(
  id         VARCHAR2(50) not null,
  event_name VARCHAR2(50) not null,
  event_desc VARCHAR2(50),
  work_flag  VARCHAR2(50),
  edit_emp   VARCHAR2(20),
  edit_time  DATE,
  notice     VARCHAR2(100),
  line       VARCHAR2(10)
)
;
grant select, insert, update, delete, alter on MES4.R_WORKFLOW_EVENT_DETAIL to MES1;

prompt
prompt Creating table R_WORKFLOW_MAIN
prompt ==============================
prompt
create table MES4.R_WORKFLOW_MAIN
(
  type           VARCHAR2(50) not null,
  name           VARCHAR2(50) not null,
  data_value     VARCHAR2(50) not null,
  id             VARCHAR2(50) not null,
  current_status VARCHAR2(50) not null,
  next_status    VARCHAR2(50) not null,
  work_flag      VARCHAR2(1) not null,
  edit_emp       VARCHAR2(20),
  edit_time      DATE,
  notice         VARCHAR2(100),
  line           VARCHAR2(8)
)
;
grant select, insert, update, delete, alter on MES4.R_WORKFLOW_MAIN to MES1;

prompt
prompt Creating table R_WORKFLOW_MAIN_DETAIL
prompt =====================================
prompt
create table MES4.R_WORKFLOW_MAIN_DETAIL
(
  id        VARCHAR2(50) not null,
  data1     VARCHAR2(50),
  data2     VARCHAR2(50),
  data3     VARCHAR2(50),
  data4     VARCHAR2(50),
  data5     VARCHAR2(50),
  data6     VARCHAR2(50),
  data7     VARCHAR2(50),
  data8     VARCHAR2(50),
  edit_emp  VARCHAR2(20),
  edit_time DATE,
  notice    VARCHAR2(100)
)
;
grant select, insert, update, delete, alter on MES4.R_WORKFLOW_MAIN_DETAIL to MES1;

prompt
prompt Creating table R_WO_BASE
prompt ========================
prompt
create table MES4.R_WO_BASE
(
  wo             VARCHAR2(12) not null,
  cust_code      VARCHAR2(15) not null,
  bu_code        VARCHAR2(10) not null,
  p_no           VARCHAR2(20) not null,
  p_version      VARCHAR2(4) not null,
  wo_qty         NUMBER(6) not null,
  process_side   VARCHAR2(6) not null,
  process_flag   VARCHAR2(1) not null,
  uph            VARCHAR2(9),
  ship_time      DATE,
  wo_create_date DATE not null,
  download_time  DATE not null,
  work_flag      VARCHAR2(1) not null,
  work_time      DATE,
  emp_no         VARCHAR2(10) not null,
  rohs_status    VARCHAR2(12),
  return_flag    VARCHAR2(1) default 0 not null,
  deviation_no   VARCHAR2(50),
  data1          VARCHAR2(25)
)
;
grant select, insert, update, delete, references, alter, index on MES4.R_WO_BASE to MES1;

prompt
prompt Creating table R_WO_BEGIN
prompt =========================
prompt
create table MES4.R_WO_BEGIN
(
  wo         VARCHAR2(12) not null,
  begin_time DATE,
  end_time   DATE,
  work_flag  VARCHAR2(1) default 0 not null,
  edit_emp   VARCHAR2(25)
)
;
create index MES4.R_WO_BEGIN_WO on MES4.R_WO_BEGIN (WO);
grant select, insert, update, delete on MES4.R_WO_BEGIN to MES1;

prompt
prompt Creating table R_WO_CONJUNCT
prompt ============================
prompt
create table MES4.R_WO_CONJUNCT
(
  tr_sn      VARCHAR2(12) not null,
  cust_kp_no VARCHAR2(50) not null,
  mfr_kp_no  VARCHAR2(100) not null,
  wo_no      VARCHAR2(12) not null,
  mfr_code   VARCHAR2(50) not null,
  tr_qty     NUMBER(7) default 0 not null,
  wo_qty     NUMBER(7) default 0 not null,
  date_code  VARCHAR2(20),
  lot_code   VARCHAR2(100),
  lasteditdt DATE,
  edit_no    VARCHAR2(20)
)
;
grant select, insert, update, delete on MES4.R_WO_CONJUNCT to MES1;

prompt
prompt Creating table R_WO_HEAD
prompt ========================
prompt
create table MES4.R_WO_HEAD
(
  action_type VARCHAR2(100),
  aufnr       VARCHAR2(100),
  werks       VARCHAR2(100),
  auart       VARCHAR2(100),
  matnr       VARCHAR2(100),
  revlv       VARCHAR2(100),
  kdauf       VARCHAR2(100),
  gstrs       VARCHAR2(100),
  gamng       VARCHAR2(100),
  kdmat       VARCHAR2(100),
  aedat       VARCHAR2(100),
  aenam       VARCHAR2(100),
  matkl       VARCHAR2(100),
  maktx       VARCHAR2(100),
  erdat       VARCHAR2(100),
  gsups       VARCHAR2(100),
  erfzeit     VARCHAR2(100),
  gltrs       VARCHAR2(100),
  glups       VARCHAR2(100),
  lgort       VARCHAR2(100),
  ablad       VARCHAR2(100),
  rohs_value  VARCHAR2(100),
  ftrmi       VARCHAR2(100),
  mvgr3       VARCHAR2(100),
  wemng       VARCHAR2(100),
  bismt       VARCHAR2(100),
  charg       VARCHAR2(100),
  saenr       VARCHAR2(100),
  aetxt       VARCHAR2(100),
  gltrp       VARCHAR2(100)
)
;
grant select, insert, update, delete on MES4.R_WO_HEAD to MES1;

prompt
prompt Creating table R_WO_ITEM
prompt ========================
prompt
create table MES4.R_WO_ITEM
(
  aufnr     VARCHAR2(100),
  posnr     VARCHAR2(100),
  matnr     VARCHAR2(100),
  parts     VARCHAR2(100),
  kdmat     VARCHAR2(100),
  bdmng     VARCHAR2(100),
  meins     VARCHAR2(100),
  revlv     VARCHAR2(100),
  baugr     VARCHAR2(100),
  repno     VARCHAR2(100),
  reppartno VARCHAR2(100),
  auart     VARCHAR2(100),
  aenam     VARCHAR2(100),
  aedat     VARCHAR2(100),
  maktx     VARCHAR2(100),
  matkl     VARCHAR2(100),
  wgbez     VARCHAR2(100),
  alpos     VARCHAR2(100),
  ablad     VARCHAR2(100),
  mvgr3     VARCHAR2(100),
  rgekz     VARCHAR2(100),
  lgort     VARCHAR2(100),
  enmng     VARCHAR2(100),
  dumps     VARCHAR2(100),
  bismt     VARCHAR2(100),
  xloek     VARCHAR2(100),
  shkzg     VARCHAR2(100),
  charg     VARCHAR2(100),
  rspos     VARCHAR2(100),
  vornr     VARCHAR2(100),
  mnglg     VARCHAR2(100)
)
;
create index MES4.R_WO_ITEM_WO on MES4.R_WO_ITEM (AUFNR);
grant select, insert, update, delete on MES4.R_WO_ITEM to MES1;

prompt
prompt Creating table R_WO_OUTLINE
prompt ===========================
prompt
create table MES4.R_WO_OUTLINE
(
  wo             VARCHAR2(12) not null,
  p_sn           VARCHAR2(25),
  p_flag         VARCHAR2(1),
  emp_no         VARCHAR2(10),
  work_time      DATE,
  return_station VARCHAR2(10),
  wo_psn         VARCHAR2(12),
  w_wo           VARCHAR2(12),
  ww_wo          VARCHAR2(12)
)
;
grant select, insert, update, delete on MES4.R_WO_OUTLINE to MES1;

prompt
prompt Creating table R_WO_PASSAOI
prompt ===========================
prompt
create table MES4.R_WO_PASSAOI
(
  wo        VARCHAR2(12) not null,
  edit_emp  VARCHAR2(25) not null,
  edit_time DATE,
  p_sn      VARCHAR2(20),
  work_flag VARCHAR2(1),
  reason    VARCHAR2(300)
)
;
create index MES4.IDX_R_WO_PASSAOI on MES4.R_WO_PASSAOI (WO);
create index MES4.IDX_R_WO_PASSAOI2 on MES4.R_WO_PASSAOI (P_SN);
grant select on MES4.R_WO_PASSAOI to PUBLIC;

prompt
prompt Creating table R_WO_PLAN
prompt ========================
prompt
create table MES4.R_WO_PLAN
(
  wo            VARCHAR2(50) not null,
  plan_date     DATE not null,
  plan_line     VARCHAR2(50) not null,
  process_flag  VARCHAR2(25) not null,
  memo          VARCHAR2(150),
  data1         VARCHAR2(50),
  data2         VARCHAR2(50),
  data3         VARCHAR2(50),
  lastedit_time DATE default sysdate,
  lastedit_emp  VARCHAR2(50)
)
;
create index MES4.IDX_WO_PLAN_WO on MES4.R_WO_PLAN (WO)
  nologging;
grant select, insert, update, delete on MES4.R_WO_PLAN to MES1;

prompt
prompt Creating table R_WO_REMARK
prompt ==========================
prompt
create table MES4.R_WO_REMARK
(
  wo        VARCHAR2(12) not null,
  wo_type   VARCHAR2(20),
  wo_remark VARCHAR2(2000),
  edit_time DATE,
  edit_emp  VARCHAR2(10)
)
;
grant select, insert, update, delete, alter on MES4.R_WO_REMARK to MES1;

prompt
prompt Creating table R_WO_REQUEST
prompt ===========================
prompt
create table MES4.R_WO_REQUEST
(
  wo            VARCHAR2(12) not null,
  wo_qty        NUMBER(6),
  p_no          VARCHAR2(20) not null,
  p_name        VARCHAR2(100),
  cust_kp_no    VARCHAR2(20) not null,
  standard_qty  NUMBER(8) not null,
  replace_kp_no VARCHAR2(20),
  wo_request    NUMBER(10) not null,
  deliver_qty   NUMBER(10) default 0,
  download_time DATE not null,
  checkout_qty  NUMBER(10) default 0,
  return_qty    NUMBER(10) default 0,
  item_no       VARCHAR2(25),
  wastage_qty   NUMBER(10) default 0
)
;
create index MES4.R_WO_REQUEST_PNO on MES4.R_WO_REQUEST (CUST_KP_NO);
create index MES4.R_WO_REQUEST_WO on MES4.R_WO_REQUEST (WO);
alter table MES4.R_WO_REQUEST
  add constraint REQUEST_WO_NO unique (WO, CUST_KP_NO)
  deferrable;
grant select, insert, update, delete on MES4.R_WO_REQUEST to MES1;

prompt
prompt Creating table R_WO_REQUEST_PROCESS
prompt ===================================
prompt
create table MES4.R_WO_REQUEST_PROCESS
(
  wo                 VARCHAR2(12),
  wo_qty             NUMBER(7),
  p_no               VARCHAR2(20),
  process_flag       VARCHAR2(20),
  cust_kp_no         VARCHAR2(20),
  standard_qty       NUMBER(4),
  replace_kp_no      VARCHAR2(20),
  wo_process_request NUMBER(10),
  buff_towo_qty      NUMBER(10) default 0,
  checkout_qty       NUMBER(7) default 0,
  return_qty         NUMBER(7) default 0,
  wastage_qty        NUMBER(7) default 0,
  lastedit_time      DATE default SYSDATE,
  item_no            VARCHAR2(6),
  data1              VARCHAR2(50),
  data2              VARCHAR2(50)
)
;
create index MES4.R_WO_REQUEST_PROCESS_PNO on MES4.R_WO_REQUEST_PROCESS (CUST_KP_NO);
create index MES4.R_WO_REQUEST_WO_WO on MES4.R_WO_REQUEST_PROCESS (WO);
grant select, insert, update, delete on MES4.R_WO_REQUEST_PROCESS to MES1;

prompt
prompt Creating table R_WO_SCHEDULE_TEMP
prompt =================================
prompt
create table MES4.R_WO_SCHEDULE_TEMP
(
  builddate    VARCHAR2(10) not null,
  buildtime    VARCHAR2(11) not null,
  wo           VARCHAR2(20) not null,
  skuno        VARCHAR2(20) not null,
  linename     VARCHAR2(20) not null,
  buildfloor   VARCHAR2(20) not null,
  processname  VARCHAR2(15) not null,
  buildshift   VARCHAR2(15) not null,
  buildqty     NUMBER(10) default 0,
  uph          NUMBER(10) default 0,
  buildseq     VARCHAR2(5) default '0',
  starttime    DATE,
  batchno      VARCHAR2(15),
  offline_flag VARCHAR2(5),
  woid         VARCHAR2(20)
)
;
grant select, insert, update, delete, alter on MES4.R_WO_SCHEDULE_TEMP to MES1;

prompt
prompt Creating table R_WO_SINGLE_CONTROL
prompt ==================================
prompt
create table MES4.R_WO_SINGLE_CONTROL
(
  wo         VARCHAR2(12) not null,
  p_no       VARCHAR2(15),
  p_version  VARCHAR2(4),
  cust_kp_no VARCHAR2(20) not null,
  mfr_kp_no  VARCHAR2(100) not null,
  mfr_code   VARCHAR2(10) not null,
  emp_no     VARCHAR2(10),
  work_flag  VARCHAR2(2),
  work_time  DATE,
  date_code  VARCHAR2(40),
  lot_code   VARCHAR2(100)
)
;
create index MES4.IDX_SINGLE_CONTROL_PNO on MES4.R_WO_SINGLE_CONTROL (P_NO);
create index MES4.IDX_SINGLE_CONTROL_WO on MES4.R_WO_SINGLE_CONTROL (WO);
grant select, insert, update, delete on MES4.R_WO_SINGLE_CONTROL to MES1;

prompt
prompt Creating table R_XML_ERROR
prompt ==========================
prompt
create table MES4.R_XML_ERROR
(
  file_name  VARCHAR2(50) not null,
  data_name  VARCHAR2(50) not null,
  tag_name   VARCHAR2(50) not null,
  tag_data   VARCHAR2(45),
  p_sn       VARCHAR2(12),
  p_no       VARCHAR2(20),
  tr_sn      VARCHAR2(12),
  error_desc VARCHAR2(120),
  status     VARCHAR2(1) not null,
  start_time DATE default SYSDATE not null,
  end_time   DATE,
  emp_no     VARCHAR2(10) not null
)
;

prompt
prompt Creating table SCADA_EXCEPTION_MESSAGE
prompt ======================================
prompt
create table MES4.SCADA_EXCEPTION_MESSAGE
(
  message_id         VARCHAR2(50),
  ip_address         VARCHAR2(50),
  excption_type      VARCHAR2(10),
  excption_type_desc VARCHAR2(100),
  action_code        VARCHAR2(50),
  station_name       VARCHAR2(50),
  slot_no            VARCHAR2(50),
  tr_sn              VARCHAR2(50),
  receive_data       VARCHAR2(50),
  message_english    VARCHAR2(500),
  message_chinese    VARCHAR2(500),
  create_time        DATE,
  create_emp         VARCHAR2(20),
  kp_no_true         VARCHAR2(30)
)
;
create index MES4.SCADA_EXCEPTION_MESSAGE_IDX1 on MES4.SCADA_EXCEPTION_MESSAGE (MESSAGE_ID);
grant select, insert, update, delete, alter on MES4.SCADA_EXCEPTION_MESSAGE to MES1;

prompt
prompt Creating table SMT_DATA_SP_ERROR
prompt ================================
prompt
create table MES4.SMT_DATA_SP_ERROR
(
  station   VARCHAR2(10),
  error_log VARCHAR2(1000),
  edit_time DATE default SYSDATE
)
;
grant select, insert, update, delete, alter on MES4.SMT_DATA_SP_ERROR to MES1;

prompt
prompt Creating table SMT_FEEDER_DETAIL
prompt ================================
prompt
create table MES4.SMT_FEEDER_DETAIL
(
  station    VARCHAR2(10) not null,
  wo         VARCHAR2(14),
  slot_no    VARCHAR2(14),
  feeder_sn  VARCHAR2(20),
  start_time DATE default SYSDATE not null,
  end_time   DATE,
  data1      VARCHAR2(3) default 0 not null
)
;
grant select, insert, update, delete, alter on MES4.SMT_FEEDER_DETAIL to MES1;

prompt
prompt Creating table SMT_FIRST_PREPARE
prompt ================================
prompt
create table MES4.SMT_FIRST_PREPARE
(
  wo           VARCHAR2(25) not null,
  process      VARCHAR2(25) not null,
  line         VARCHAR2(25) not null,
  kp_no        VARCHAR2(40) not null,
  p_no         VARCHAR2(40) not null,
  load_time    DATE,
  station      VARCHAR2(25) not null,
  slot_no      VARCHAR2(25) not null,
  request_qty  NUMBER,
  checkout_qty NUMBER,
  data1        VARCHAR2(25),
  data2        VARCHAR2(25),
  edit_time    DATE,
  wo_request   NUMBER,
  last_wo_ext  NUMBER
)
;
grant select, insert, update, delete, alter on MES4.SMT_FIRST_PREPARE to MES1;

prompt
prompt Creating table SMT_GSMLINK_ADD
prompt ==============================
prompt
create table MES4.SMT_GSMLINK_ADD
(
  station   VARCHAR2(10),
  link_qty  NUMBER(10),
  data1     VARCHAR2(10),
  data2     VARCHAR2(10),
  last_time DATE
)
;
grant select, insert, update, delete, alter on MES4.SMT_GSMLINK_ADD to MES1;

prompt
prompt Creating table SMT_GSMLINK_BAK
prompt ==============================
prompt
create table MES4.SMT_GSMLINK_BAK
(
  station   VARCHAR2(10),
  link_qty  NUMBER(10),
  data1     VARCHAR2(10),
  data2     VARCHAR2(10),
  last_time DATE
)
;
grant select, insert, update, delete, alter on MES4.SMT_GSMLINK_BAK to MES1;

prompt
prompt Creating table SMT_GSMLINK_LOG
prompt ==============================
prompt
create table MES4.SMT_GSMLINK_LOG
(
  station   VARCHAR2(10),
  link_qty  NUMBER(10),
  data1     VARCHAR2(10),
  data2     VARCHAR2(10),
  last_time DATE
)
;
grant select, insert, update, delete, alter on MES4.SMT_GSMLINK_LOG to MES1;

prompt
prompt Creating table SMT_GSMLINK_LOG_USE
prompt ==================================
prompt
create table MES4.SMT_GSMLINK_LOG_USE
(
  station   VARCHAR2(10),
  link_qty  NUMBER(10),
  data1     VARCHAR2(10),
  data2     VARCHAR2(10),
  last_time DATE
)
;
grant select, insert, update, delete, alter on MES4.SMT_GSMLINK_LOG_USE to MES1;

prompt
prompt Creating table SMT_GSMLINK_SAVEPOINT
prompt ====================================
prompt
create table MES4.SMT_GSMLINK_SAVEPOINT
(
  station   VARCHAR2(10),
  link_qty  NUMBER(10),
  data1     VARCHAR2(10),
  data2     VARCHAR2(10),
  last_time DATE
)
;
grant select, insert, update, delete, alter on MES4.SMT_GSMLINK_SAVEPOINT to MES1;

prompt
prompt Creating table SMT_GSMLINK_STATION
prompt ==================================
prompt
create table MES4.SMT_GSMLINK_STATION
(
  station      VARCHAR2(10),
  link_qty     NUMBER(10),
  wo           VARCHAR2(20),
  process_flag VARCHAR2(10),
  work_time    DATE
)
;
grant select, insert, update, delete, alter on MES4.SMT_GSMLINK_STATION to MES1;

prompt
prompt Creating table SMT_LOAD_TRSN
prompt ============================
prompt
create table MES4.SMT_LOAD_TRSN
(
  tr_sn        VARCHAR2(14),
  wo           VARCHAR2(20),
  program_name VARCHAR2(20),
  station      VARCHAR2(10),
  slot_no      VARCHAR2(20),
  add_qty      NUMBER(10),
  return_qty   NUMBER(10) default 0,
  kp_no        VARCHAR2(20),
  flag         VARCHAR2(1) default 0,
  standard_qty NUMBER,
  start_time   DATE default SYSDATE,
  end_time     DATE,
  drop_qty     NUMBER default 0,
  process_flag VARCHAR2(1),
  use_flag     VARCHAR2(1) default '0' not null,
  linked_qty   NUMBER(10) default 0
)
;
create index MES4.SMT_LOAD_TRSN_TIME on MES4.SMT_LOAD_TRSN (START_TIME)
  nologging;
create index MES4.SMT_LOAD_TRSN_TRSN on MES4.SMT_LOAD_TRSN (TR_SN)
  nologging;
create index MES4.SMT_LOAD_TRSN_WO_IX on MES4.SMT_LOAD_TRSN (STATION, WO, PROGRAM_NAME)
  nologging;
grant select, insert, update, delete, alter on MES4.SMT_LOAD_TRSN to MES1;

prompt
prompt Creating table SMT_LOG
prompt ======================
prompt
create table MES4.SMT_LOG
(
  station     VARCHAR2(20),
  slot_no     VARCHAR2(20),
  total       NUMBER(10),
  fail        NUMBER(10),
  flag        CHAR(2) default 0,
  last_time   DATE default SYSDATE not null,
  beging_time VARCHAR2(20)
)
;
grant select, insert, update, delete, alter on MES4.SMT_LOG to MES1;

prompt
prompt Creating table SMT_LOG_ADD
prompt ==========================
prompt
create table MES4.SMT_LOG_ADD
(
  station     VARCHAR2(20),
  slot_no     VARCHAR2(20),
  total       NUMBER(10),
  fail        NUMBER(10),
  flag        CHAR(2) default 0,
  last_time   DATE default SYSDATE not null,
  beging_time VARCHAR2(20)
)
;
create index MES4.SMT_LOG_ADD_STATION on MES4.SMT_LOG_ADD (STATION)
  nologging;
grant select, insert, update, delete, alter on MES4.SMT_LOG_ADD to MES1;

prompt
prompt Creating table SMT_LOG_BAK
prompt ==========================
prompt
create table MES4.SMT_LOG_BAK
(
  station     VARCHAR2(20),
  slot_no     VARCHAR2(20),
  total       NUMBER(10),
  fail        NUMBER(10),
  flag        CHAR(2) default 0,
  last_time   DATE default SYSDATE not null,
  beging_time VARCHAR2(20)
)
;
grant select, insert, update, delete, alter on MES4.SMT_LOG_BAK to MES1;

prompt
prompt Creating table SMT_LOG_ERROR
prompt ============================
prompt
create table MES4.SMT_LOG_ERROR
(
  station     VARCHAR2(20),
  slot_no     VARCHAR2(20),
  total       NUMBER(10),
  fail        NUMBER(10),
  flag        CHAR(2) default 0,
  last_time   DATE default SYSDATE not null,
  beging_time VARCHAR2(20)
)
;
grant select, insert, update, delete, alter on MES4.SMT_LOG_ERROR to MES1;

prompt
prompt Creating table SMT_LOG_USE
prompt ==========================
prompt
create table MES4.SMT_LOG_USE
(
  station     VARCHAR2(20),
  slot_no     VARCHAR2(20),
  total       NUMBER(10),
  fail        NUMBER(10),
  flag        CHAR(2) default 0,
  last_time   DATE default SYSDATE not null,
  beging_time VARCHAR2(20)
)
;
grant select, insert, update, delete, alter on MES4.SMT_LOG_USE to MES1;

prompt
prompt Creating table SMT_ONLINE_ALARM
prompt ===============================
prompt
create table MES4.SMT_ONLINE_ALARM
(
  line            VARCHAR2(25) not null,
  kp_no           VARCHAR2(40),
  wo              VARCHAR2(25),
  process         VARCHAR2(25),
  station         VARCHAR2(25),
  slot_no         VARCHAR2(25),
  unit_use        NUMBER default 0,
  next_wo         VARCHAR2(25),
  next_process    VARCHAR2(10),
  next_station    VARCHAR2(25),
  next_slot_no    VARCHAR2(25),
  next_unit_use   NUMBER default 0,
  ext_pcba        NUMBER,
  online_request  NUMBER default 0,
  next_request    NUMBER default 0,
  edit_time       DATE,
  min_request     NUMBER default 0,
  online_trsn_qty NUMBER default 0,
  checkout_qty    NUMBER default 0,
  feeder_qty      NUMBER default 0,
  need_qty        NUMBER default 0,
  feeder_add      VARCHAR2(1) default 1
)
;
create index MES4.SMT_ONLINE_ALARM_CPN on MES4.SMT_ONLINE_ALARM (KP_NO)
  nologging;
create index MES4.SMT_ONLINE_ALARM_LINE on MES4.SMT_ONLINE_ALARM (LINE)
  nologging;
grant select, insert, update, delete, alter on MES4.SMT_ONLINE_ALARM to MES1;

prompt
prompt Creating table SMT_ONLINE_PREPARE
prompt =================================
prompt
create table MES4.SMT_ONLINE_PREPARE
(
  wo           VARCHAR2(25) not null,
  process      VARCHAR2(25) not null,
  line         VARCHAR2(25) not null,
  kp_no        VARCHAR2(40) not null,
  p_no         VARCHAR2(40),
  load_time    DATE,
  station      VARCHAR2(25),
  slot_no      VARCHAR2(25),
  request_qty  NUMBER,
  ext_qty      NUMBER,
  ext_time     NUMBER,
  checkout_qty NUMBER,
  status       VARCHAR2(25),
  data1        VARCHAR2(25),
  data2        VARCHAR2(25),
  edit_time    DATE
)
;
grant select, insert, update, delete, alter on MES4.SMT_ONLINE_PREPARE to MES1;

prompt
prompt Creating table SMT_PREPARE
prompt ==========================
prompt
create table MES4.SMT_PREPARE
(
  wo         VARCHAR2(25) not null,
  process    VARCHAR2(25) not null,
  line       VARCHAR2(25) not null,
  p_no       VARCHAR2(40),
  load_time  DATE,
  status     VARCHAR2(10),
  data1      VARCHAR2(25),
  data2      VARCHAR2(25),
  begin_time DATE,
  end_time   DATE,
  work_time  DATE,
  data3      VARCHAR2(10)
)
;
grant select, insert, update, delete, alter on MES4.SMT_PREPARE to MES1;

prompt
prompt Creating table SMT_SAVEPOINT
prompt ============================
prompt
create table MES4.SMT_SAVEPOINT
(
  station      VARCHAR2(10),
  slot_no      VARCHAR2(20),
  total        NUMBER(10),
  fail         NUMBER(10),
  flag         CHAR(2) default 0,
  wo           VARCHAR2(20),
  process_flag VARCHAR2(10),
  last_time    DATE default SYSDATE not null
)
;
grant select, insert, update, delete, alter on MES4.SMT_SAVEPOINT to MES1;

prompt
prompt Creating table SMT_TRSN_WIP
prompt ===========================
prompt
create table MES4.SMT_TRSN_WIP
(
  wo           VARCHAR2(20),
  program_name VARCHAR2(20),
  station      VARCHAR2(10),
  slot_no      VARCHAR2(20),
  total_qty    NUMBER(10),
  ext_qty      NUMBER(10),
  standard_qty NUMBER(5),
  tr_sn        VARCHAR2(14),
  process_flag VARCHAR2(1),
  work_time    DATE default SYSDATE
)
;
grant select, insert, update, delete, alter on MES4.SMT_TRSN_WIP to MES1;

prompt
prompt Creating table SMT_WO
prompt =====================
prompt
create table MES4.SMT_WO
(
  station      VARCHAR2(10),
  wo           VARCHAR2(20),
  process_flag VARCHAR2(10),
  work_time    DATE default SYSDATE not null,
  getfile_time DATE,
  gap          NUMBER(22,10),
  real_time    DATE,
  work_flag    VARCHAR2(10),
  edit_emp     VARCHAR2(20),
  link_qty     NUMBER default 0,
  last_time    DATE
)
;
grant select, insert, update, delete, alter on MES4.SMT_WO to MES1;

prompt
prompt Creating table SMT_WO_ACCOUNT
prompt =============================
prompt
create table MES4.SMT_WO_ACCOUNT
(
  program_name VARCHAR2(10),
  wo           VARCHAR2(14),
  station      VARCHAR2(10),
  slot_no      VARCHAR2(20),
  kp_no        VARCHAR2(20),
  total        NUMBER(10),
  fail         NUMBER(10),
  edit_time    DATE default sysdate not null,
  process_flag VARCHAR2(1)
)
;
create index MES4.SMT_WO_ACCOUNT_STATION on MES4.SMT_WO_ACCOUNT (STATION)
  nologging;
create index MES4.SMT_WO_ACCOUNT_WO on MES4.SMT_WO_ACCOUNT (WO)
  nologging;
grant select, insert, update, delete, alter on MES4.SMT_WO_ACCOUNT to MES1;

prompt
prompt Creating table SMT_WO_REQUEST
prompt =============================
prompt
create table MES4.SMT_WO_REQUEST
(
  wo              VARCHAR2(25) not null,
  station         VARCHAR2(25) not null,
  slot_no         VARCHAR2(10) not null,
  kp_no           VARCHAR2(40) not null,
  wo_request      NUMBER,
  next_wo         VARCHAR2(20),
  next_wo_request NUMBER default 0 not null,
  work_time       DATE not null,
  next_wo_process VARCHAR2(10)
)
;
grant select, insert, update, delete, alter on MES4.SMT_WO_REQUEST to MES1;

prompt
prompt Creating table SMT_WO_WIP
prompt =========================
prompt
create table MES4.SMT_WO_WIP
(
  station      VARCHAR2(10),
  slot_no      VARCHAR2(20),
  total        NUMBER(10) default 0,
  fail         NUMBER(10) default 0,
  flag         CHAR(2) default 0,
  wo           VARCHAR2(20),
  process_flag VARCHAR2(10),
  last_time    DATE default SYSDATE not null
)
;
grant select, insert, update, delete, alter on MES4.SMT_WO_WIP to MES1;

prompt
prompt Creating table TEST88
prompt =====================
prompt
create table MES4.TEST88
(
  sqlarea VARCHAR2(2000)
)
;

prompt
prompt Creating table TMP_CALLMATERIAL_DATA
prompt ====================================
prompt
create table MES4.TMP_CALLMATERIAL_DATA
(
  wo           VARCHAR2(20) not null,
  process_flag VARCHAR2(20) not null,
  station      VARCHAR2(20) not null,
  slot_no      VARCHAR2(10) not null,
  kp_no        VARCHAR2(50) not null,
  part_type    VARCHAR2(100) not null,
  location     VARCHAR2(100),
  wo_request   NUMBER(10),
  wo_deliver   NUMBER(10),
  wo_checkout  NUMBER(10),
  times        NUMBER(10),
  flag         VARCHAR2(20)
)
;
grant select, insert, update, delete on MES4.TMP_CALLMATERIAL_DATA to MES1;

prompt
prompt Creating table TRAN_ACTION_ID
prompt =============================
prompt
create table MES4.TRAN_ACTION_ID
(
  last_actionid NUMBER(10) not null
)
;
grant select, insert, update, delete on MES4.TRAN_ACTION_ID to MES1;

prompt
prompt Creating table TRAN_DETAIL
prompt ==========================
prompt
create table MES4.TRAN_DETAIL
(
  tr_sn        VARCHAR2(20) not null,
  part_no      VARCHAR2(20) not null,
  qty          NUMBER(10) not null,
  scandatetime DATE default sysdate not null,
  actionid     NUMBER(10) not null,
  mac          VARCHAR2(20) not null,
  sap_doc_no   VARCHAR2(50),
  move_type    VARCHAR2(50),
  kp_version   VARCHAR2(50),
  wo           VARCHAR2(50),
  process_flag VARCHAR2(50),
  from_stock   VARCHAR2(50),
  to_stock     VARCHAR2(50),
  ip_address   VARCHAR2(50),
  scan_desc    VARCHAR2(50),
  data1        VARCHAR2(50)
)
;
create index MES4.IDX_TRAN_DETAIL_ACTIONID on MES4.TRAN_DETAIL (ACTIONID);
create index MES4.IDX_TRAN_DETAIL_SCANDATETIME on MES4.TRAN_DETAIL (SCANDATETIME);
create index MES4.IDX_TRAN_DETAIL_SN on MES4.TRAN_DETAIL (TR_SN);
grant select, insert, update, delete on MES4.TRAN_DETAIL to MES1;

prompt
prompt Creating table TRAN_MONTH_END
prompt =============================
prompt
create table MES4.TRAN_MONTH_END
(
  part_no  VARCHAR2(20),
  qty      NUMBER(10),
  actionid NUMBER(10)
)
;
grant select, insert, update, delete on MES4.TRAN_MONTH_END to MES1;

prompt
prompt Creating table TRAN_PDA261_DETAIL
prompt =================================
prompt
create table MES4.TRAN_PDA261_DETAIL
(
  tr_sn        VARCHAR2(20) not null,
  part_no      VARCHAR2(20) not null,
  qty          NUMBER(10) not null,
  scandatetime DATE not null,
  actionid     NUMBER(10) not null,
  mac          VARCHAR2(20) not null,
  v_wo         VARCHAR2(20)
)
;
create index MES4.TRAN_PDA261_DETAIL_AC on MES4.TRAN_PDA261_DETAIL (ACTIONID);
create index MES4.TRAN_PDA261_DETAIL_PN on MES4.TRAN_PDA261_DETAIL (PART_NO);
create index MES4.TRAN_PDA261_DETAIL_SC on MES4.TRAN_PDA261_DETAIL (SCANDATETIME);
create index MES4.TRAN_PDA261_DETAIL_TS on MES4.TRAN_PDA261_DETAIL (TR_SN);
create index MES4.TRAN_PDA261_DETAIL_VW on MES4.TRAN_PDA261_DETAIL (V_WO);
grant select, insert, update, delete on MES4.TRAN_PDA261_DETAIL to MES1;

prompt
prompt Creating table TRAN_TOTAL
prompt =========================
prompt
create table MES4.TRAN_TOTAL
(
  part_no  VARCHAR2(20) not null,
  qty      NUMBER(10) not null,
  actionid NUMBER(10) not null
)
;
grant select, insert, update, delete on MES4.TRAN_TOTAL to MES1;

prompt
prompt Creating view V_SMT_KP
prompt ======================
prompt
CREATE OR REPLACE FORCE VIEW MES4.V_SMT_KP AS
SELECT A.CUST_KP_NO AS FOXCONN_KP_NO,
   A.AREA AS AREA,
   A.LOCATION AS LOCATION,
   A.PART_USE AS TYPE,
   B.CUST_CODE AS CUST_CODE,
   B.CUST_KP_DESC AS DESCRIPTION
    FROM MES1.C_KITTING_STOCK_CONFIG A
    LEFT JOIN MES1.C_CUST_KP_CONFIG B
      ON A.CUST_KP_NO = B.CUST_KP_NO
   WHERE PART_USE LIKE 'SMT%'
     AND B.CUST_CODE NOT IN ('HUAWEI')
WITH READ ONLY;

prompt
prompt Creating view V_SN
prompt ==================
prompt
CREATE OR REPLACE FORCE VIEW MES4.V_SN AS
SELECT TR_SN      AS SN,
       CUST_KP_NO AS FOXCONN_KP_NO,
       MFR_KP_NO  AS MANUFACTURE_KP_NO,
       DATE_CODE,
       LOT_CODE,
       QTY        AS original_QTY,
       EXT_QTY    AS QTY,
       DATA4      AS ORIGINAL_SN,
       DECODE(LOCATION_FLAG,'0','WHS','1','KITTING','2','LINE','3','MRB','OTHER') AS WAREHOUSE,
       DECODE(WORK_FLAG,'0','NORMAL','1','EMPTY','2','WAIT_MODIFY','4','LOCKED','9','SYSTEM_LOCKED','OTHER')  AS STATUS
  FROM MES4.R_TR_SN WHERE START_TIME > TO_DATE('20140101','YYYYMMDD')
WITH READ ONLY;


spool off
