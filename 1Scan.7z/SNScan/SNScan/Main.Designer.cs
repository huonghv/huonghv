﻿namespace SNScan
{
    partial class Main
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.pan_menu = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_output = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_uph = new System.Windows.Forms.Label();
            this.lbl_model = new System.Windows.Forms.Label();
            this.lbl_cur_sku = new System.Windows.Forms.Label();
            this.btn_exit = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_ok = new System.Windows.Forms.Button();
            this.btn_config = new System.Windows.Forms.Button();
            this.gb_scan = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_qty = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_msg = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_trSn = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_prompt = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dg_BOMList = new System.Windows.Forms.DataGridView();
            this.pno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kpno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.std_qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.desc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cb_model = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cb_station = new System.Windows.Forms.ComboBox();
            this.cb_line = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_timeInterval = new System.Windows.Forms.Label();
            this.gb_loadedm = new System.Windows.Forms.GroupBox();
            this.dg_loadedTrSn = new System.Windows.Forms.DataGridView();
            this.pno_loaded = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.extqty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timer_alert = new System.Windows.Forms.Timer(this.components);
            this.timer_freshQty = new System.Windows.Forms.Timer(this.components);
            this.timer_10 = new System.Windows.Forms.Timer(this.components);
            this.timer_1h = new System.Windows.Forms.Timer(this.components);
            this.pan_menu.SuspendLayout();
            this.gb_scan.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_BOMList)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.gb_loadedm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_loadedTrSn)).BeginInit();
            this.SuspendLayout();
            // 
            // pan_menu
            // 
            this.pan_menu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pan_menu.Controls.Add(this.label7);
            this.pan_menu.Controls.Add(this.lbl_output);
            this.pan_menu.Controls.Add(this.label4);
            this.pan_menu.Controls.Add(this.lbl_uph);
            this.pan_menu.Controls.Add(this.lbl_model);
            this.pan_menu.Controls.Add(this.lbl_cur_sku);
            this.pan_menu.Controls.Add(this.btn_exit);
            this.pan_menu.Controls.Add(this.btn_cancel);
            this.pan_menu.Controls.Add(this.btn_ok);
            this.pan_menu.Controls.Add(this.btn_config);
            this.pan_menu.Font = new System.Drawing.Font("Cambria", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pan_menu.Location = new System.Drawing.Point(11, 6);
            this.pan_menu.Name = "pan_menu";
            this.pan_menu.Size = new System.Drawing.Size(972, 58);
            this.pan_menu.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Cambria", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(793, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 34);
            this.label7.TabIndex = 9;
            this.label7.Text = "產出:";
            // 
            // lbl_output
            // 
            this.lbl_output.AutoSize = true;
            this.lbl_output.Font = new System.Drawing.Font("Cambria", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_output.ForeColor = System.Drawing.Color.Blue;
            this.lbl_output.Location = new System.Drawing.Point(870, 12);
            this.lbl_output.Name = "lbl_output";
            this.lbl_output.Size = new System.Drawing.Size(32, 34);
            this.lbl_output.TabIndex = 8;
            this.lbl_output.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cambria", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(629, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 34);
            this.label4.TabIndex = 7;
            this.label4.Text = "UPH:";
            // 
            // lbl_uph
            // 
            this.lbl_uph.AutoSize = true;
            this.lbl_uph.Font = new System.Drawing.Font("Cambria", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_uph.ForeColor = System.Drawing.Color.Blue;
            this.lbl_uph.Location = new System.Drawing.Point(704, 11);
            this.lbl_uph.Name = "lbl_uph";
            this.lbl_uph.Size = new System.Drawing.Size(83, 34);
            this.lbl_uph.TabIndex = 6;
            this.lbl_uph.Text = "1000";
            // 
            // lbl_model
            // 
            this.lbl_model.AutoSize = true;
            this.lbl_model.Font = new System.Drawing.Font("Cambria", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_model.ForeColor = System.Drawing.Color.Blue;
            this.lbl_model.Location = new System.Drawing.Point(424, 11);
            this.lbl_model.Name = "lbl_model";
            this.lbl_model.Size = new System.Drawing.Size(99, 34);
            this.lbl_model.TabIndex = 5;
            this.lbl_model.Text = "model";
            // 
            // lbl_cur_sku
            // 
            this.lbl_cur_sku.AutoSize = true;
            this.lbl_cur_sku.Font = new System.Drawing.Font("Cambria", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cur_sku.ForeColor = System.Drawing.Color.Blue;
            this.lbl_cur_sku.Location = new System.Drawing.Point(277, 11);
            this.lbl_cur_sku.Name = "lbl_cur_sku";
            this.lbl_cur_sku.Size = new System.Drawing.Size(147, 34);
            this.lbl_cur_sku.TabIndex = 4;
            this.lbl_cur_sku.Text = "當前機種:";
            // 
            // btn_exit
            // 
            this.btn_exit.Image = global::SNScan.Properties.Resources.exit;
            this.btn_exit.Location = new System.Drawing.Point(209, 3);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(60, 50);
            this.btn_exit.TabIndex = 3;
            this.btn_exit.Text = "Exit";
            this.btn_exit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.Image = global::SNScan.Properties.Resources.cancel;
            this.btn_cancel.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_cancel.Location = new System.Drawing.Point(143, 3);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(60, 50);
            this.btn_cancel.TabIndex = 2;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // btn_ok
            // 
            this.btn_ok.Image = global::SNScan.Properties.Resources.OK;
            this.btn_ok.Location = new System.Drawing.Point(72, 3);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(60, 50);
            this.btn_ok.TabIndex = 1;
            this.btn_ok.Text = "OK";
            this.btn_ok.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ok.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_ok.UseVisualStyleBackColor = true;
            this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
            // 
            // btn_config
            // 
            this.btn_config.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_config.Image = global::SNScan.Properties.Resources.config;
            this.btn_config.Location = new System.Drawing.Point(4, 3);
            this.btn_config.Name = "btn_config";
            this.btn_config.Size = new System.Drawing.Size(60, 50);
            this.btn_config.TabIndex = 0;
            this.btn_config.Text = "Config";
            this.btn_config.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_config.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_config.UseVisualStyleBackColor = true;
            this.btn_config.Click += new System.EventHandler(this.btn_config_Click);
            // 
            // gb_scan
            // 
            this.gb_scan.Controls.Add(this.label3);
            this.gb_scan.Controls.Add(this.txt_qty);
            this.gb_scan.Controls.Add(this.label11);
            this.gb_scan.Controls.Add(this.txt_msg);
            this.gb_scan.Controls.Add(this.label10);
            this.gb_scan.Controls.Add(this.txt_trSn);
            this.gb_scan.Controls.Add(this.label9);
            this.gb_scan.Controls.Add(this.txt_prompt);
            this.gb_scan.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_scan.Location = new System.Drawing.Point(11, 113);
            this.gb_scan.Name = "gb_scan";
            this.gb_scan.Size = new System.Drawing.Size(972, 113);
            this.gb_scan.TabIndex = 5;
            this.gb_scan.TabStop = false;
            this.gb_scan.Text = "Material Scan";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(286, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 22);
            this.label3.TabIndex = 22;
            this.label3.Text = "QTY:";
            // 
            // txt_qty
            // 
            this.txt_qty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_qty.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_qty.Location = new System.Drawing.Point(334, 13);
            this.txt_qty.Name = "txt_qty";
            this.txt_qty.Size = new System.Drawing.Size(80, 30);
            this.txt_qty.TabIndex = 21;
            this.txt_qty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_qty_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(4, 65);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 22);
            this.label11.TabIndex = 20;
            this.label11.Text = "Message:";
            // 
            // txt_msg
            // 
            this.txt_msg.BackColor = System.Drawing.Color.White;
            this.txt_msg.Font = new System.Drawing.Font("Cambria", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_msg.ForeColor = System.Drawing.Color.Black;
            this.txt_msg.Location = new System.Drawing.Point(88, 49);
            this.txt_msg.Multiline = true;
            this.txt_msg.Name = "txt_msg";
            this.txt_msg.ReadOnly = true;
            this.txt_msg.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_msg.Size = new System.Drawing.Size(728, 58);
            this.txt_msg.TabIndex = 19;
            this.txt_msg.Text = "Current Message";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(13, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(69, 22);
            this.label10.TabIndex = 18;
            this.label10.Text = "KP No.:";
            // 
            // txt_trSn
            // 
            this.txt_trSn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_trSn.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_trSn.Location = new System.Drawing.Point(88, 13);
            this.txt_trSn.Name = "txt_trSn";
            this.txt_trSn.Size = new System.Drawing.Size(193, 30);
            this.txt_trSn.TabIndex = 17;
            this.txt_trSn.Text = "undo";
            this.txt_trSn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_trSn_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(470, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 22);
            this.label9.TabIndex = 16;
            this.label9.Text = "Prompt:";
            // 
            // txt_prompt
            // 
            this.txt_prompt.BackColor = System.Drawing.Color.White;
            this.txt_prompt.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_prompt.ForeColor = System.Drawing.Color.Blue;
            this.txt_prompt.Location = new System.Drawing.Point(566, 13);
            this.txt_prompt.Name = "txt_prompt";
            this.txt_prompt.ReadOnly = true;
            this.txt_prompt.Size = new System.Drawing.Size(250, 30);
            this.txt_prompt.TabIndex = 15;
            this.txt_prompt.Text = "請掃入Undo";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dg_BOMList);
            this.groupBox1.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(11, 226);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(533, 366);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "BOM List";
            // 
            // dg_BOMList
            // 
            this.dg_BOMList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_BOMList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.pno,
            this.kpno,
            this.std_qty,
            this.desc});
            this.dg_BOMList.Location = new System.Drawing.Point(6, 11);
            this.dg_BOMList.Name = "dg_BOMList";
            this.dg_BOMList.RowHeadersVisible = false;
            this.dg_BOMList.RowTemplate.Height = 24;
            this.dg_BOMList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dg_BOMList.Size = new System.Drawing.Size(521, 350);
            this.dg_BOMList.TabIndex = 2;
            // 
            // pno
            // 
            this.pno.HeaderText = "P NO";
            this.pno.Name = "pno";
            // 
            // kpno
            // 
            this.kpno.HeaderText = "KP NO";
            this.kpno.Name = "kpno";
            // 
            // std_qty
            // 
            this.std_qty.HeaderText = "Standard QTY";
            this.std_qty.Name = "std_qty";
            this.std_qty.Width = 95;
            // 
            // desc
            // 
            this.desc.HeaderText = "Description";
            this.desc.Name = "desc";
            this.desc.Width = 230;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cb_model);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.cb_station);
            this.groupBox3.Controls.Add(this.cb_line);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(11, 64);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(1);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(972, 48);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            // 
            // cb_model
            // 
            this.cb_model.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_model.FormattingEnabled = true;
            this.cb_model.Location = new System.Drawing.Point(639, 14);
            this.cb_model.Name = "cb_model";
            this.cb_model.Size = new System.Drawing.Size(167, 27);
            this.cb_model.TabIndex = 13;
            this.cb_model.SelectedIndexChanged += new System.EventHandler(this.cb_model_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(571, 17);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 19);
            this.label8.TabIndex = 12;
            this.label8.Text = "Model:";
            // 
            // cb_station
            // 
            this.cb_station.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_station.FormattingEnabled = true;
            this.cb_station.Items.AddRange(new object[] {
            "PACK_CTN"});
            this.cb_station.Location = new System.Drawing.Point(333, 14);
            this.cb_station.Name = "cb_station";
            this.cb_station.Size = new System.Drawing.Size(164, 27);
            this.cb_station.TabIndex = 11;
            // 
            // cb_line
            // 
            this.cb_line.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_line.FormattingEnabled = true;
            this.cb_line.Location = new System.Drawing.Point(56, 14);
            this.cb_line.Name = "cb_line";
            this.cb_line.Size = new System.Drawing.Size(148, 27);
            this.cb_line.TabIndex = 10;
            this.cb_line.SelectedIndexChanged += new System.EventHandler(this.cb_line_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(265, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 19);
            this.label2.TabIndex = 8;
            this.label2.Text = "Station:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 19);
            this.label1.TabIndex = 7;
            this.label1.Text = "Line:";
            // 
            // lbl_timeInterval
            // 
            this.lbl_timeInterval.AutoSize = true;
            this.lbl_timeInterval.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_timeInterval.Location = new System.Drawing.Point(880, 444);
            this.lbl_timeInterval.Name = "lbl_timeInterval";
            this.lbl_timeInterval.Size = new System.Drawing.Size(0, 12);
            this.lbl_timeInterval.TabIndex = 10;
            // 
            // gb_loadedm
            // 
            this.gb_loadedm.Controls.Add(this.dg_loadedTrSn);
            this.gb_loadedm.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_loadedm.Location = new System.Drawing.Point(550, 226);
            this.gb_loadedm.Name = "gb_loadedm";
            this.gb_loadedm.Size = new System.Drawing.Size(433, 366);
            this.gb_loadedm.TabIndex = 11;
            this.gb_loadedm.TabStop = false;
            this.gb_loadedm.Text = "Loaded Material";
            // 
            // dg_loadedTrSn
            // 
            this.dg_loadedTrSn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_loadedTrSn.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.pno_loaded,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn1,
            this.extqty});
            this.dg_loadedTrSn.Location = new System.Drawing.Point(7, 11);
            this.dg_loadedTrSn.Name = "dg_loadedTrSn";
            this.dg_loadedTrSn.RowHeadersVisible = false;
            this.dg_loadedTrSn.RowTemplate.Height = 24;
            this.dg_loadedTrSn.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dg_loadedTrSn.Size = new System.Drawing.Size(420, 350);
            this.dg_loadedTrSn.TabIndex = 4;
            // 
            // pno_loaded
            // 
            this.pno_loaded.HeaderText = "P No";
            this.pno_loaded.Name = "pno_loaded";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "KP No.";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 135;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "QTY";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // extqty
            // 
            this.extqty.HeaderText = "ExtQTY";
            this.extqty.Name = "extqty";
            this.extqty.Width = 85;
            // 
            // timer_alert
            // 
            this.timer_alert.Interval = 180000;
            this.timer_alert.Tick += new System.EventHandler(this.timer_alert_Tick);
            // 
            // timer_freshQty
            // 
            this.timer_freshQty.Interval = 60000;
            this.timer_freshQty.Tick += new System.EventHandler(this.timer_freshQty_Tick);
            // 
            // timer_10
            // 
            this.timer_10.Interval = 600000;
            this.timer_10.Tick += new System.EventHandler(this.timer_10_Tick);
            // 
            // timer_1h
            // 
            this.timer_1h.Interval = 3600000;
            this.timer_1h.Tick += new System.EventHandler(this.timer_1h_Tick);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(994, 597);
            this.Controls.Add(this.gb_loadedm);
            this.Controls.Add(this.lbl_timeInterval);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gb_scan);
            this.Controls.Add(this.pan_menu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Main";
            this.Text = "Pack Material Control";
            this.Load += new System.EventHandler(this.Main_Load);
            this.pan_menu.ResumeLayout(false);
            this.pan_menu.PerformLayout();
            this.gb_scan.ResumeLayout(false);
            this.gb_scan.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dg_BOMList)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.gb_loadedm.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dg_loadedTrSn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pan_menu;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.Button btn_config;
        private System.Windows.Forms.GroupBox gb_scan;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_msg;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_trSn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_prompt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dg_BOMList;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cb_station;
        private System.Windows.Forms.ComboBox cb_line;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_timeInterval;
        private System.Windows.Forms.Label lbl_cur_sku;
        private System.Windows.Forms.ComboBox cb_model;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox gb_loadedm;
        private System.Windows.Forms.DataGridView dg_loadedTrSn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pno;
        private System.Windows.Forms.DataGridViewTextBoxColumn kpno;
        private System.Windows.Forms.DataGridViewTextBoxColumn std_qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn desc;
        private System.Windows.Forms.Label lbl_model;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn pno_loaded;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn extqty;
        private System.Windows.Forms.Timer timer_alert;
        private System.Windows.Forms.Label lbl_uph;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Timer timer_freshQty;
        private System.Windows.Forms.Timer timer_10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_output;
        private System.Windows.Forms.Timer timer_1h;
    }
}

