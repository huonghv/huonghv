﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using APM_NET;

namespace SNScan
{
    public partial class Main : Form
    {
        //public APM UserAPM = new APM();

        internal static APM UserAPM = new APM();
        internal bool reworkFlag=false;
        private DateTime lastScanTime = DateTime.Now;
        internal string actionCode = string.Empty;

        public static string StrFile_Path = System.IO.Directory.GetCurrentDirectory() + "\\SNScan.ini";
        public string emp = String.Empty;

        public Main()
        {
            InitializeComponent();
            this.ControlBox = false;
        }

        private void Main_Load(object sender, EventArgs e)
        {
            if (System.Diagnostics.Process.GetProcessesByName("SNScan").ToList().Count > 1)
            {
                MessageBox.Show("Program is Running,Pls do not start it again!", "Running Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (APM_Login())
            {
                if (UserAPM.IsTestSID)
                {
                    MessageBox.Show("Test Server=" + UserAPM.DSN, "Test Server!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                Application.Exit();
            }

            this.Text = "SN Scan:--->"+ ultis.getHostIP();

            /*cb_line.Items.Clear();
            foreach (DataRow dr in ultis.getLine().Rows)
            {
                cb_line.Items.Add(Convert.ToString(dr["line_name"]) + Convert.ToString(dr["line_section"]));
            }

            cb_model.Items.Clear();
            foreach (DataRow dr in ultis.loadModel().Rows)
            {
                cb_model.Items.Add(Convert.ToString(dr["model_name"]));
            }*/

            cb_line.Items.Clear();
            foreach (var line in preLoad.loadLine())
            {
                cb_line.Items.Add(line);
            }

            cb_model.Items.Clear();
            foreach (var model in preLoad.loadModel())
            {
                cb_model.Items.Add(model);
            }

            var fileName = Environment.CurrentDirectory + @"\SNScan.ini";
            cb_line.Text= FileHandle.Filehandle.ReadINI(fileName, "STATION", "LINE");
            cb_station.Text = FileHandle.Filehandle.ReadINI(fileName, "STATION", "STATION");
            cb_model.Text = FileHandle.Filehandle.ReadINI(fileName, "STATION", "MODEL");

            btn_config.Enabled = true;
            btn_ok.Enabled = false;
            btn_cancel.Enabled = false;
            cb_line.Enabled = false;
            cb_station.Enabled = false;
            cb_model.Enabled = false;

            /**/
            if (ultis.isAllLoaded(cb_line.Text, cb_station.Text, cb_model.Text))
            {
                timer_alert.Enabled = true;
                timer_freshQty.Enabled = true;
                timer_1h.Enabled = true;
                timer_10.Enabled = false;
            }
            /**/

            checkIPLoaded();

            ultis.updateAPStatus("OPEN", cb_line.Text, cb_station.Text, cb_model.Text);

            txt_trSn.Focus();
            txt_trSn.SelectAll();
        }

        /// <summary>
        /// /*check if IP has online material*/
        /// </summary>
        void checkIPLoaded()
        {
            var onLinePno = ultis.isIPWithOnlineMaterial();
            if (string.IsNullOrEmpty(onLinePno))
                return;
            else
            {
                var lpo=onLinePno.Split(new string[] { ":" }, StringSplitOptions.RemoveEmptyEntries);
                cb_line.Text = lpo[0];
                cb_model.Text = lpo[1];

                cb_model_SelectedIndexChanged(new object(),new EventArgs());
                MessageBox.Show("當前電腦IP "+ultis.getHostIP()+" 已有在綫機種,請知悉","在綫機種",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }                
        }

        private bool APM_Login()
        {
            UserAPM.IniFilePath = Environment.CurrentDirectory + @"\SNScan.ini";

            if (UserAPM.CheckFunction("SNSCAN", "LOGIN", true, false))
            {
                emp = UserAPM.EmpNO;
                return (true);
            }
            else
            {
                return (false);
            }
        }

        private void cb_line_SelectedIndexChanged(object sender, EventArgs e)
        {
            var sltLine = Convert.ToString(cb_line.SelectedItem);
            try
            {
                var dt = ultis.getStation(sltLine);

                foreach (DataRow dr in dt.Rows)
                {
                    cb_station.Items.Add(Convert.ToString(dr["station_name"]));
                }
            }
            catch { throw; }
        }

        private void cb_model_SelectedIndexChanged(object sender, EventArgs e)
        {
            txt_msg.Clear();
            txt_msg.BackColor = Color.WhiteSmoke;
            UpdateBOMStatus();
            getLoadedRecords();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(ultis.isIPWithOnlineMaterial()))
                MessageBox.Show("仍有在綫物料,請確認是否需要退出","退出預警",MessageBoxButtons.OK,MessageBoxIcon.Information);

            if (MessageBox.Show("Are you sure to exit?", "Exit", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                ultis.updateAPStatus("CLOSE",cb_line.Text,cb_station.Text,cb_model.Text);

                Application.Exit();
            }            
        }

        private void btn_config_Click(object sender, EventArgs e)
        {
            btn_config.Enabled = false;
            btn_ok.Enabled = true;
            btn_cancel.Enabled = true;
            cb_line.Enabled = true;
            cb_station.Enabled = true;
            cb_model.Enabled = true;

            cb_line.Text = "";
            cb_station.Text = "PACK_CTN";
            cb_model.Text = "";

            lbl_model.Text = "";
            lbl_uph.Text = "";
            
            /*cb_station.Items.Clear();

            cb_line.Items.Clear();
            foreach (DataRow dr in ultis.getLine().Rows)
            {
                cb_line.Items.Add(Convert.ToString(dr["line_name"]) + Convert.ToString(dr["line_section"]));
            }*/
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            cb_line.Text = "";
            cb_station.Text = "";
            cb_model.Text = "";

            cb_line.Enabled = false;
            cb_station.Enabled = false;
            cb_model.Enabled = false;

            cb_line.BackColor = Color.LightGray;
            cb_station.BackColor = Color.LightGray;
            cb_model.BackColor = Color.LightGray;

            btn_config.Enabled = true;
            btn_ok.Enabled = false;
            btn_cancel.Enabled = false;            
            btn_exit.Enabled = true;

            var fileName = Environment.CurrentDirectory + @"\SNScan.ini";
            cb_line.Text = FileHandle.Filehandle.ReadINI(fileName, "STATION", "LINE");
            cb_station.Text = FileHandle.Filehandle.ReadINI(fileName, "STATION", "STATION");
            cb_model.Text = FileHandle.Filehandle.ReadINI(fileName, "STATION", "MODEL");
        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
            var line = cb_line.Text;
            var station = cb_station.Text;
            var model = cb_model.Text;

            if (String.IsNullOrEmpty(line) || String.IsNullOrEmpty(model))
            {
                showMessage("NG", "請先選擇綫體和機種");
                MessageBox.Show("請先選擇綫體和機種", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var fileName = Environment.CurrentDirectory + @"\SNScan.ini";
            
            FileHandle.Filehandle.WriteINI(fileName, "STATION", "LINE",line);
            FileHandle.Filehandle.WriteINI(fileName, "STATION", "STATION", station);
            FileHandle.Filehandle.WriteINI(fileName, "STATION", "MODEL", model);

            btn_config.Enabled = true;
            btn_ok.Enabled = false;
            btn_cancel.Enabled = false;
            btn_exit.Enabled = true;

            cb_line.Enabled = false;
            cb_station.Enabled = false;
            cb_model.Enabled = false;

            txt_trSn.Focus();
            txt_trSn.SelectAll();                       

            timer_10.Enabled = true;
        }
        
        private void txt_trSn_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 13)
                return;

            if (cb_line.Enabled || cb_station.Enabled || cb_model.Enabled)
            {
                showMessage("NG","請先設置綫體,工站和機種信息,并點擊[OK]以確認");
                return;
            }

            var trSn = txt_trSn.Text.ToUpper().Trim();
            var line = cb_line.Text;
            var station = cb_station.Text;
            var stationNo = String.Empty;
            txt_qty.Clear();

            switch (trSn)
            {
                case "UNDO":
                    actionCode = "UNDO";
                    //UNDO();
                    break;
                case "ACTION-L-M":
                    actionCode = "ACTIONLM";
                    //ACTIONLM();
                    break;
                case "ACTION-U-M":
                    actionCode = "ACTIONUM";
                    //ACTIONUM();
                    break;
                case "ACTION-U-A":
                    actionCode = "ACTIONUA";
                    //ACTIONUA();
                    break;
                case "ACTION-C-M":
                    actionCode = "ACTIONCM";
                    //ACTIONCM();
                    break;
            }
                        
            if (String.IsNullOrEmpty(actionCode))
            {
                showMessage("NG", "請先掃描作正確的業代碼");
                FoucsSN();
                return;
            }

            switch (actionCode)
            {
                case "UNDO":
                    UNDO();
                    FoucsSN();
                    break;
                case "ACTIONLM":
                    ACTIONLM();
                    break;
                case "ACTIONUM":
                    ACTIONUM();
                    FoucsSN();
                    break;
                case "ACTIONUA":
                    ACTIONUA();
                    FoucsSN();
                    break;
                case "ACTIONCM":
                    ACTIONCM();
                    FoucsSN();
                    break;
            }
            UpdateBOMStatus();
            getLoadedRecords();            
        }
        private void ACTIONCM()
        {
            var station = cb_station.Text;
            var model = cb_model.Text;
            var pNo = txt_trSn.Text.Trim().ToUpper();
            var line = cb_line.Text;

            if (pNo == "ACTION-C-M")
            {
                if (MessageBox.Show("確認切換綫體["+line+"]在綫機種嗎?此操作會先下綫當前機種", "機種切換提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    txt_prompt.Text = "請輸入機種號->回車[Enter]";
                    FoucsSN();
                }
                return;
            }

            if (pNo != model)
            {
                showMessage("NG", "輸入的機種號和選擇的機種號不匹配,請確認.");
                txt_prompt.Text = "請重新輸入機種號";
                FoucsSN();
                return;
            }

            txt_prompt.Clear();
            var res = ultis.unLoadAllMaterial(station, line, model, emp);
            showMessage("OK", res);

        }
        private void ACTIONUA()
        {
            var station = cb_station.Text;
            var model = cb_model.Text;
            var kpNo = txt_trSn.Text.Trim().ToUpper();
            var line = cb_line.Text;

            if (kpNo == "ACTION-U-A")
            {
                if (MessageBox.Show("確認下綫本工站的所有在綫物料?", "下綫提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    txt_prompt.Clear();
                    var res=ultis.unLoadAllMaterial(station, line, model, emp);
                    if (res.Substring(0, 2) == "OK") {

                    }
                    showMessage(res.Substring(0,2), res);
                }                    
                return;
            }
        }
        private void ACTIONUM()
        {
            var station = cb_station.Text;
            var model = cb_model.Text;
            var kpNo = txt_trSn.Text.Trim().ToUpper();
            var line = cb_line.Text;

            if (kpNo == "ACTION-U-M")
            {
                if (MessageBox.Show("是否開始下綫物料?", "下綫提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    txt_prompt.Text = "OK,請掃描需要下綫的料號";
                    showMessage("OK", "開始下綫物料");
                    FoucsSN();
                }                
                return;
            }

            if (!ultis.iskpNoExist(kpNo))
            {
                showMessage("NG", "該料號不存在系統,請確認.");
                FoucsSN();
                return;
            }

            if (!ultis.isIntheBOM(kpNo, model))
            {
                showMessage("NG", "該料號不屬于此機種BOM清單,請確認.");
                FoucsSN();
                return;
            }

            if (!ultis.isKPLoaded(line, station,model,kpNo))
            {
                showMessage("NG", "該物料未掃描上綫或者已經下綫,不需要再掃下綫,請確認.");
                FoucsSN();
                return;
            }

            var res = ultis.unLoadMaterial(station, line, model, emp, kpNo);

            showMessage(res.Substring(0, 2), res.Substring(3));

            txt_prompt.Text = "請掃下一個下綫物料料號";

            FoucsSN();            
        }

        private bool checkKP()
        {
            var line = cb_line.Text;
            var station = cb_station.Text;
            var model = cb_model.Text;
            var kpNo = txt_trSn.Text.Trim().ToUpper();
            
            if (kpNo == "ACTION-L-M")
            {
                txt_prompt.Text = "請掃描需要上綫的 KP_NO";
                showMessage("OK", "請掃描需要上綫的 KP_NO");
                return false;
            }

            if (!ultis.iskpNoExist(kpNo))
            {
                showMessage("NG", "該料號不存在系統,請確認.");
                FoucsSN();
                return false;
            }

            if (!ultis.isIntheBOM(kpNo, model))
            {
                showMessage("NG", "該料號不屬于此機種BOM清單,請確認.");
                FoucsSN();
                return false;
            }

            var p_no = ultis.isOtherModelOnline(line, model);
            if (!string.IsNullOrEmpty(p_no))
            {
                showMessage("NG", "該綫已有其他在綫機種: "+ p_no+" ,請確認.");
                FoucsSN();
                return false;
            }

            /*if (ultis.restQTYLevel(line, station, model, kpNo)=="NORMAL")
            {
                if (MessageBox.Show("該物料在綫數量多於 2H 的消耗量,是否繼續上料?", "上料", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK)
                {
                    FoucsSN();
                    return false;
                }
            }*/

            return true;
        }
        private void ACTIONLM()
        {
            var trSn = txt_trSn.Text.Trim().ToUpper();
            if (checkKP())
            {
                txt_prompt.Text = "請輸入上料數量";
                showMessage("OK","請輸入上料數量");
                txt_qty.Focus();
                txt_qty.SelectAll();
            }
            else
            {
                FoucsSN();
            }        
        }

        private void txt_qty_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 13)
                return;

            if (actionCode != "ACTIONLM")
            {
                showMessage("NG", "當前不是上料模式,請確認.");
                txt_qty.Focus();
                txt_qty.SelectAll();
                return;
            }

            var qty = txt_qty.Text;

            if (!ultis.isNumber(qty))
            {
                showMessage("NG", "輸入的不是數字,請確認.");
                txt_qty.Focus();
                txt_qty.SelectAll();
                return;
            }
            try
            { 
                if (!checkKP())
                    return;

                var line = cb_line.Text;
                var station = cb_station.Text;
                var model = cb_model.Text;
                var kpNo = txt_trSn.Text.Trim().ToUpper();

                var res = ultis.LoadMaterial(line, station, kpNo, model, emp, qty);

                showMessage(res.Substring(0, 2), res.Substring(2));

                if (res.Substring(0, 2) == "OK")
                {
                    showMessage("OK", res);
                    txt_prompt.Text = "請掃描下一個";
                    FoucsSN();
                    UpdateBOMStatus();
                    getLoadedRecords();
                }
                else
                {
                    showMessage("NG", res);
                    FoucsSN();
                }

                if (ultis.isAllLoaded(line, station, model))
                {
                    showMessage("OK","所有物料均已經上綫");
                    txt_prompt.Text = "上料完畢";
                    timer_10.Enabled = false;
                    timer_freshQty.Enabled = true;
                    timer_1h.Enabled = true;
                    timer_alert.Enabled = true;
                }
            }
            catch(Exception ex) { showMessage("NG",Convert.ToString(ex.Message)); }

        }

        void FoucsSN()
        {
            txt_trSn.Focus();
            txt_trSn.SelectAll();
        }

        private void UNDO()
        {
            txt_prompt.Text = "請掃入作業代碼";
            showMessage("OK", "請掃入作業代碼");
            FoucsSN();
        }

        void showMessage(string res,string msg)
        {
            txt_msg.Text = msg;
            if (res == "OK")
                txt_msg.BackColor = Color.FromArgb(124, 252, 0);
            else
                txt_msg.BackColor = Color.FromArgb(240, 128, 128);//255, 0, 0
        }        

        void UpdateBOMStatus()
        {
            dg_BOMList.Rows.Clear();

            var model = cb_model.Text;
            var station = cb_station.Text;
            var line = cb_line.Text;
            
            try
            {
                var dt = ultis.loadBOM(model);

                if (dt.Rows.Count == 0)
                {
                    showMessage("NG", "該機種尚未配置BOM清單");
                    dg_BOMList.Rows.Clear();
                    dg_loadedTrSn.Rows.Clear();
                    lbl_model.Text = "";
                    lbl_uph.Text = "0";
                    cb_model.Focus();
                    return;
                }

                lbl_model.Text= Convert.ToString(dt.Rows[0]["p_no"]);
                lbl_uph.Text = ultis.loadUPH(Convert.ToString(dt.Rows[0]["p_no"]));

                foreach (DataRow dtr in dt.Rows)
                {
                    DataGridViewRow dr = new DataGridViewRow();
                    dr.CreateCells(dg_BOMList);
                    dr.Cells[0].Value = Convert.ToString(dtr["p_no"]);
                    dr.Cells[1].Value = Convert.ToString(dtr["kp_no"]);
                    dr.Cells[2].Value = Convert.ToString(dtr["standard_qty"]);
                    dr.Cells[3].Value = Convert.ToString(dtr["des"]);
                    dg_BOMList.Rows.Insert(0, dr);

                    if (ultis.isKPLoaded(line, station, model, Convert.ToString(dtr["kp_no"])))
                        dr.DefaultCellStyle.BackColor = Color.FromArgb(211, 211, 211);//220, 220, 220
                    else
                        dr.DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    
                    dg_BOMList.EndEdit();
                }
                //showMessage("OK","BOM已經加載,請掃作業代碼");
                //FoucsSN();
            }
            catch { throw; }            
        }

        private void getLoadedRecords()
        {
            dg_loadedTrSn.Rows.Clear();

            try
            {
                var model = cb_model.Text;
                var station =cb_station.Text;
                var line = cb_line.Text;
                var loadedPn = string.Empty;
                var dt = ultis.getLoadedKP(line,station, model);

                if (dt.Rows.Count == 0)
                {
                    return;/*load loaded materials and show it*/
                }

                lbl_model.Text = Convert.ToString(dt.Rows[0]["p_no"]);
                lbl_uph.Text = ultis.loadUPH(Convert.ToString(dt.Rows[0]["p_no"]));
                if (lbl_uph.Text == "0" || string.IsNullOrEmpty(lbl_uph.Text))
                {
                    MessageBox.Show("UPH 尚未設定","UPH");                    
                }

                foreach (DataRow dtr in dt.Rows)
                {
                    DataGridViewRow dr = new DataGridViewRow();
                    dr.CreateCells(dg_loadedTrSn);
                    dr.Cells[0].Value = Convert.ToString(dtr["p_no"]);
                    dr.Cells[1].Value = Convert.ToString(dtr["kp_no"]);
                    dr.Cells[2].Value = Convert.ToString(dtr["qty"]);
                    dr.Cells[3].Value = Convert.ToString(dtr["ext_qty"]);
                    dg_loadedTrSn.Rows.Insert(0, dr);
                    
                    switch (ultis.restQTYLevel(line, station, model, Convert.ToString(dtr["kp_no"])))
                    {
                        case "NORMAL"://GREEN
                            dr.DefaultCellStyle.BackColor = Color.FromArgb(127, 255, 0);
                            break;
                        case "GENERAL"://YELLOW
                            dr.DefaultCellStyle.BackColor = Color.FromArgb(255, 255, 0);
                            break;
                        case "URGENT"://RED
                            dr.DefaultCellStyle.BackColor = Color.FromArgb(255, 0, 0);
                            break;
                        default:
                            dr.DefaultCellStyle.BackColor = Color.FromArgb(245, 245, 245);
                            break;
                    }                    

                    dg_loadedTrSn.EndEdit();

                    loadedPn = Convert.ToString(dtr["p_no"]);
                }

                if (model != loadedPn)
                {
                    MessageBox.Show("已有另一機種在綫,請先下綫:"+ loadedPn + "","物料檢查");
                }
                               
                //FoucsSN();
            }
            catch { throw; }
        }        

        private void timer_alert_Tick(object sender, EventArgs e)
        {
            var line = cb_line.Text;
            var station = cb_station.Text;
            var model = cb_model.Text;

            if (string.IsNullOrEmpty(line) || string.IsNullOrEmpty(station) || string.IsNullOrEmpty(model))
                return;

           if (ultis.isAllLoaded(line, station, model))
            {
                ultis.sendShortageAlertMail(line, station, model);                
            }
        }

        private void timer_freshQty_Tick(object sender, EventArgs e)
        {
            var line = cb_line.Text;
            var station = cb_station.Text;
            var model = cb_model.Text;

            if (ultis.isAllLoaded(line, station, model))
            {
                ultis.freshRestQty(line, station, model);
                lbl_output.Text= ultis.loadOutpt(line, station, model);
                getLoadedRecords();
            }            
        }

        private void timer_10_Tick(object sender, EventArgs e)
        {
            var line = cb_line.Text;
            var station = cb_station.Text;
            var model = cb_model.Text;

            if (ultis.isAllLoaded(line, station, model))
            {
                timer_alert.Enabled = true;
                timer_freshQty.Enabled = true;
                timer_1h.Enabled = true;
                timer_10.Enabled = false;
            }
            else
            {
                ultis.ToBeloadedMaterialAlert(line, station, model);
            }
        }

        private void timer_1h_Tick(object sender, EventArgs e)
        {
            var line = cb_line.Text;
            var station = cb_station.Text;
            var model = cb_model.Text;

            if (ultis.isAllLoaded(line, station, model))
                ultis.ProducingStatusMail(line, station, model);

        }
    }
}
