﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNScan
{
    internal class preLoad
    {
        internal static List<string> loadLine()
        {
            var line = new List<string>();
            /*line.Add("D1");
            line.Add("D2");
            line.Add("F1");
            line.Add("F2");
            line.Add("O1");*/

            var file = Environment.CurrentDirectory + @"\SNScan.ini";

            var lines = FileHandle.Filehandle.ReadINI(file,"CONFIG","LINE");

            var l_lines = lines.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var l_line in l_lines)
            {
                line.Add(l_line);
            }

            return line;
        }

        internal static List<string> loadModel()
        {
            var model = new List<string>();
            /*model.Add("U73J049.00");
            model.Add("U73J049.09");
            model.Add("U73J049.06");
            model.Add("U73J049.04");
            model.Add("U73J049.14");
            model.Add("U73J049.15");
            model.Add("U73J049.18");
            model.Add("U73J053.00");
            model.Add("U73J053.01");
            model.Add("U73J053.02");
            model.Add("U73J041.00");
            model.Add("U73J041.02");
            model.Add("U73J041.05");
            model.Add("U73J041.06");
            model.Add("U73J041.07");
            model.Add("U73J050.00");
            model.Add("U73J050.02");
            model.Add("U73J050.05");
            model.Add("U73J050.06");*/

            var file = Environment.CurrentDirectory + @"\SNScan.ini";

            var models = FileHandle.Filehandle.ReadINI(file, "CONFIG", "MODEL");

            var l_models = models.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var l_model in l_models)
            {
                model.Add(l_model);
            }

            return model;
        }
    }
}
