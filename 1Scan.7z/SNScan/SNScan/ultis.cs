﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Net;
using DBConn_nsd;
using System.Text.RegularExpressions;

namespace SNScan
{
    internal class ultis
    {
        const string sql_line = @"select distinct line_name,line_section from mes1.c_line_station order by line_name,line_section";
        const string sql_station = @"select distinct station_name from  mes1.c_line_station where line_name||line_section = '{0}' order by station_name asc";
                
        const string sql_model = @"select model_name from sfis1.c_model_desc_t@sfcodbf6 where 1=1 order by model_name asc";
        const string sql_bom = @"select p_no,kp_no,standard_qty,b.cust_kp_desc des from mes1.c_pack_bom_config a,mes1.c_cust_kp_config b where a.kp_no=b.cust_kp_no and a.p_no ='{0}'";

        const string sql_mail = @"insert into sfis1.c_mail_t@sfcodb(mail_id,mail_to,mail_cc,mail_subject,mail_sequence,mail_content,mail_date,mail_flag)
                                  values(to_char(sysdate,'yyyymmddhh24miss'),'{0}','{1}','{2}','1','{3}',sysdate,'0')";
        const string sql_mail_short = @"select mail_to,mail_cc from c_mail_config where mail_type='PACKCTN_MaterialShort'";
        const string sql_mail_load = @"select mail_to,mail_cc from c_mail_config where mail_type='PACKCTN_LoadMaterial'";
        const string sql_mail_producing = @"select mail_to,mail_cc from c_mail_config where mail_type='PACKCTN_ProduceStatus'";

        internal static DataTable getLine()
        {
            return DB.GetDataTable(sql_line);
        }
        internal static DataTable getStation(string sltLine)
        {
            return DB.GetDataTable(String.Format(sql_station, sltLine));
        }

        internal static string getHostIP()
        {
            string strHostIP = "";
            IPHostEntry oIPHost = Dns.GetHostEntry(Environment.MachineName);
            /*if (oIPHost.AddressList.Length > 0)
            {
                strHostIP = oIPHost.AddressList[0].ToString();
            }*/
            for (int i = 0; i < oIPHost.AddressList.Length; i++)
            {
                var ip = Convert.ToString(oIPHost.AddressList[i]);

                if (ip.Substring(0, 3) == "10.")
                {
                    strHostIP = ip;
                    break;
                }
            }
            return strHostIP;
        }        

        /*simplify*/
        internal static DataTable loadModel()
        {
            return DB.GetDataTable(sql_model);
        }

        internal static DataTable loadBOM(string pno)
        {
            var sql = String.Format(sql_bom,pno);
            return DB.GetDataTable(sql);
        }

        internal static DataTable getLoadedKP(string line,string station,string pno)
        {
            var sql = @"select a.p_no,a.kp_no,qty,ext_qty,case when ext_qty>std_qty*uph*2 then '3' when ext_qty<std_qty*uph*2 and ext_qty>std_qty*uph*1 then '2' else '1' 
                        end status from r_pckkp_control_detail a,mes1.c_cust_kp_config b,mes1.c_pack_uph_config c where a.p_no=c.p_no and a.kp_no=b.cust_kp_no(+) and 
                        is_offline='N' and line='{0}' and station='{1}' and a.p_no='{2}' order by status desc,ext_qty desc,kp_no";

            sql = String.Format(sql, line, station, pno);
            return DB.GetDataTable(sql);
        }

        internal static bool iskpNoExist(string kpNo)
        {
            var sql = @"select 6 from mes1.c_cust_kp_config where cust_kp_no='{0}'";
            sql = String.Format(sql,kpNo);
            var dt = DB.GetDataTable(sql);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        internal static bool isKPLoaded(string line,string station, string pno,string kpno)
        {
            var sql = @"select 6 from r_pckkp_control_detail where is_offline='N' and line='{0}' and station='{1}' and p_no='{2}' and kp_no='{3}'";
            sql = String.Format(sql, line,station, pno, kpno);
            var dt = DB.GetDataTable(sql);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }        

        internal static bool isIntheBOM(string kpno,string model)
        {
            var sql = @"select 6 from mes1.c_pack_bom_config where p_no='{0}' and kp_no='{1}'";
            sql = String.Format(sql, model,kpno);
            var dt = DB.GetDataTable(sql);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        internal static string LoadMaterial(string line,string station,string kpNo,string model,string emp,string qty)
        {
            var batchNo = String.Empty;
            var withBatch = false;
            var sql = @"select line,max(data2) data2 from r_pckkp_control_detail where is_offline='N' and line='{0}' and station='{1}' and p_no='{2}' and data2 is not null group by line";
            sql = String.Format(sql, line, station, model);
            var dt2 = DB.GetDataTable(sql);
            if (dt2.Rows.Count > 0)
            {
                batchNo = Convert.ToString(dt2.Rows[0]["data2"]);
                withBatch = true;
            }

            sql = @"select 8 from r_pckkp_control_detail where is_offline='N' and line='{0}' and station='{1}' and p_no='{2}' and kp_no='{3}'";
            sql = String.Format(sql,line,station,model,kpNo);
            var dt1 = DB.GetDataTable(sql);
            if (dt1.Rows.Count > 0)
            {
                if (withBatch)
                {
                    sql = @"update r_pckkp_control_detail set qty=qty+{4},ext_qty=ext_qty+{4},edit_by='{5}',data2='{6}' where is_offline='N' and line='{0}' and station='{1}' and p_no='{2}' and kp_no='{3}'";
                    sql = String.Format(sql, line, station, model, kpNo, qty, emp,batchNo);//,edit_date=sysdate
                }
                else
                {
                    sql = @"update r_pckkp_control_detail set qty=qty+{4},ext_qty=ext_qty+{4},edit_by='{5}',data2=to_char(sysdate,'yyyymmddhh24miss') where is_offline='N' and line='{0}' and station='{1}' and p_no='{2}' and kp_no='{3}'";
                    sql = String.Format(sql, line, station, model, kpNo, qty, emp);//,edit_date=sysdate
                }                
            }
            else
            {
                if (withBatch)
                {
                    sql = @"insert into mes4.r_pckkp_control_detail(line,station,p_no,tr_sn,kp_no,std_qty,qty,ext_qty,is_offline,load_time,unload_time,edit_by,edit_date,data2,data3)
                            select '{0}'line,'{1}'station,p_no,''tr_sn,kp_no,standard_qty std_qty,'{2}' qty,'{2}'ext_qty,'N' is_offline,sysdate load_time,''unload_time,
                            '{3}' edit_by,sysdate edit_date,'{6}','{7}' data3 from mes1.c_pack_bom_config where p_no='{4}' and kp_no='{5}'";
                    sql = String.Format(sql, line, station, qty, emp, model, kpNo, batchNo, getHostIP());
                }
                else
                {
                    sql = @"insert into mes4.r_pckkp_control_detail(line,station,p_no,tr_sn,kp_no,std_qty,qty,ext_qty,is_offline,load_time,unload_time,edit_by,edit_date,data2,data3)
                            select '{0}'line,'{1}'station,p_no,''tr_sn,kp_no,standard_qty std_qty,'{2}' qty,'{2}'ext_qty,'N' is_offline,sysdate load_time,''unload_time,
                            '{3}' edit_by,sysdate edit_date,to_char(sysdate,'yyyymmddhh24miss') data2,'{6}'data3 from mes1.c_pack_bom_config where p_no='{4}' and kp_no='{5}'";
                    sql = String.Format(sql, line, station, qty, emp, model, kpNo, getHostIP());
                }                
            }                

            DB.Execute(sql);

            return "OK,該物料已經上綫,請掃下一個";            
        }

        internal static string unLoadMaterial(string station, string line, string model, string emp, string kpNo)
        {
            var sql = @"select 6 from r_pckkp_control_detail where is_offline='N' and line='{0}' and station='{1}' and p_no='{2}' and kp_no='{3}'";
            sql = String.Format(sql, line, station, model, kpNo);
            var dt = DB.GetDataTable(sql);
            if (dt.Rows.Count == 0)
            {
                return "NG,此物料["+ kpNo + "]未在["+line+"]上綫,請檢查";
            }

            sql = @"update r_pckkp_control_detail set is_offline='Y',unload_time=sysdate,data1='{4}',data2=to_char(sysdate,'yyyymmddhh24miss')  where is_offline='N' and line='{0}' and station='{1}' and p_no='{2}' and kp_no='{3}'";
            sql = String.Format(sql, line, station, model, kpNo, emp);

            DB.Execute(sql);

            return "OK,["+ kpNo + "]已經下綫,請掃下一個";
        }

        internal static string unLoadAllMaterial(string station, string line, string model, string emp)
        {
            var sql = @"select 6 from r_pckkp_control_detail where is_offline='N' and line='{0}' and station='{1}' and p_no='{2}'";
            sql = String.Format(sql, line, station, model);
            var dt = DB.GetDataTable(sql);
            if (dt.Rows.Count == 0)
            {
                return "NG,此機種[" + model + "]尚未在[" + line + "]上綫或者已經全部下綫,請檢查";
            }

            sql = @"update r_pckkp_control_detail set is_offline='Y',unload_time=sysdate,data1='{3}',data2=to_char(sysdate,'yyyymmddhh24miss')  where is_offline='N' and line='{0}' and station='{1}' and p_no='{2}'";
            sql = String.Format(sql, line, station, model, emp);

            DB.Execute(sql);

            return "OK,機種[" + model + "]所有物料均已下綫";
        }

        internal static string loadUPH(string pno)
        {
            var sql = @"select * from c_pack_uph_config where p_no='{0}'";
            sql = string.Format(sql,pno);
            var dt = DB.GetDataTable(sql);
            if (dt.Rows.Count > 0)
                return Convert.ToString(dt.Rows[0]["uph"]);
            else
                return "0";
        }

        internal static Boolean isNumber(string qty)
        {
            if (!Regex.IsMatch(qty, @"^\d+$"))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        internal static string restQTYLevel(string line,string station,string model,string kpNo)
        {
            var sql = @"select case when sext_qty>=std_qty*uph*2 then 'NORMAL' when sext_qty<std_qty*uph*2 and sext_qty>=std_qty*uph*1 then 'GENERAL' else 'URGENT' end status
                         from(select o.*,p.uph from (select line,station,p_no,kp_no,std_qty,sum(ext_qty) sext_qty from R_PCKKP_CONTROL_DETAIL where is_offline='N' and 
                        line='{0}' and station='{1}' and p_no='{2}' and kp_no='{3}' group by line,station,p_no,kp_no,std_qty) o,c_pack_uph_config p where o.p_no=p.p_no)";
            sql = string.Format(sql,line,station,model,kpNo);
            var dt = DB.GetDataTable(sql);

            if (dt.Rows.Count > 0)
                return Convert.ToString(dt.Rows[0]["status"]);
            else
                return "NULL";
        }

        internal static string isOtherModelOnline(string line,string model)
        {
            var sql = @"select p_no from r_pckkp_control_detail where is_offline='N' and line='{0}' and p_no<>'{1}' and rownum=1";
            sql = string.Format(sql,line,model);
            var dt = DB.GetDataTable(sql);
            if (dt.Rows.Count > 0)
                return Convert.ToString(dt.Rows[0]["p_no"]);
            else
                return string.Empty;
        }        

        internal static void freshRestQty(string line, string station, string model)
        {
            var sql_sLoadDate = @"select to_char(min(edit_date),'yyyy/mm/dd hh24:mi:ss') edate from r_pckkp_control_detail where is_offline = 'N' and line = '{0}' and station = '{1}' and p_no = '{2}'";
            var sql = String.Format(sql_sLoadDate, line, station, model);
            var dt = DB.GetDataTable(sql);
            var minDate = Convert.ToString(dt.Rows[0]["edate"]);

            dt.Clear();
                        
            var sql_output = @"select count(distinct serial_number) output from sfism4.r_sn_detail_t@sfcodbf6 where line_name='{0}' and group_name='{1}' and model_name='{2}' and in_station_time>to_date('{3}','yyyy/mm/dd hh24:mi:ss')";
            sql = String.Format(sql_output, line, station, model, minDate);
            dt = DB.GetDataTable(sql);
            var output = Convert.ToString(dt.Rows[0]["output"]);

            dt.Clear();

            var sql_qtyfresh = @"update r_pckkp_control_detail set ext_qty=qty-std_qty*{0} where is_offline='N' and line='{1}' and station='{2}' and p_no='{3}'";
            sql = String.Format(sql_qtyfresh, output, line, station, model);

            DB.Execute(sql);
        }

        internal static bool isAllLoaded(string line, string station, string model)
        {
            if (string.IsNullOrEmpty(line) || string.IsNullOrEmpty(model) || string.IsNullOrEmpty(station))
                return false;

            var sql = @"select * from (select n.p_no,n.kp_no,m.kp_no mkpno from(select p_no,kp_no from r_pckkp_control_detail where is_offline='N' 
                        and line='{0}' and station='{1}' and p_no='{2}')m,mes1.c_pack_bom_config n where n.p_no='{2}' and n.p_no=m.p_no(+) and n.kp_no=
                        m.kp_no(+)) where mkpno is null";

            sql = String.Format(sql,line,station,model);

            var dt = DB.GetDataTable(sql);
            if (dt.Rows.Count > 0)
                return false;
            else
                return true;
        }        

        internal static string isIPWithOnlineMaterial()
        {
            var sql = @"select distinct data3,line||':'||p_no lpno from r_pckkp_control_detail where is_offline='N' and data3='{0}'";
            var dt = DB.GetDataTable(string.Format(sql, getHostIP()));
            if (dt.Rows.Count > 0)
                return Convert.ToString(dt.Rows[0]["lpno"]);
            else
                return string.Empty;
        }

        internal static void updateAPStatus(string type,string line,string station,string model)
        {
            var status = string.Empty;

            switch (type)
            {
                case "CLOSE":
                    status = "Y";
                    break;
                case "OPEN":
                    status = "N";
                    break;
            }

            var sql = @"select 6 from r_pckkp_control_detail where is_offline='N' and data3='{0}' and line='{1}' and p_no='{2}' and station='{3}'";
            sql = string.Format(sql, getHostIP(), line, model, station);
            if (DB.GetDataTable(sql).Rows.Count > 0)
            {
                sql = @"update r_pckkp_control_detail set isProgramClosed='{4}' where is_offline='N' and data3='{0}' and line='{1}' and p_no='{2}' and station='{3}'";
                sql = string.Format(sql, getHostIP(), line, model, station, status);
                DB.Execute(sql);
            }
        }

        internal static string loadOutpt(string line,string station,string model)
        {
            var sql = @"select count(distinct serial_number) output from sfism4.r_sn_detail_t@sfcodbf6 p,(select min(edit_date) min_date,max(unload_time) max_date from 
                        r_pckkp_control_detail where is_offline = 'N' and line = '{0}' and station = '{1}' and p_no = '{2}')o where line_name = '{0}' and model_name='{2}'
                        and group_name = '{1}' and in_station_time>=o.min_date and in_station_time<(case when o.max_date is null then sysdate+1/24/6 else o.max_date end)";
            sql = string.Format(sql,line,station,model);
            var dt = DB.GetDataTable(sql);
            if (dt.Rows.Count > 0)
                return Convert.ToString(dt.Rows[0]["output"]);
            else
                return "0";
        }

        internal static void sendShortageAlertMail(string line, string station, string pno)
        {
            var sql = @"select * from(select replace(wm_concat(' '||line|| '   '|| station|| '      '|| p_no|| '     '|| kp_no|| '           '|| std_qty|| '             '|| uph|| '            '|| sext_qty|| '             '|| status),
                        ',',chr (10))mms from (select line,station,p_no,kp_no,std_qty,uph,sext_qty,case when sext_qty>=std_qty*uph*2 then'NORMAL' when sext_qty<std_qty*uph
                        *2 and sext_qty>=std_qty*uph*1 then 'GENERAL' else'URGENT' end status from (select o.*, p.uph from (select line,station,p_no,kp_no,std_qty,sum(ext_qty)
                        sext_qty from r_pckkp_control_detail where is_offline = 'N' and line = '{0}' and station = '{1}' and p_no = '{2}' group by line,
                        station,p_no,kp_no,std_qty) o, c_pack_uph_config p where o.p_no = p.p_no)) where status <> 'NORMAL') where mms is not null ";

            sql = String.Format(sql, line, station, pno);
            var dt = DB.GetDataTable(sql);
            if (dt.Rows.Count > 0)
            {
                var mailTo = string.Empty;
                var mailCc = string.Empty;
                var mailCont = string.Empty;
                var mailSubject = string.Empty;

                var dtMail = DB.GetDataTable(sql_mail_short);
                if (dtMail.Rows.Count > 0)
                {
                    mailTo = Convert.ToString(dtMail.Rows[0]["mail_to"]);
                    mailCc = Convert.ToString(dtMail.Rows[0]["mail_cc"]);

                    mailCont = @"Dear User'||chr(10)||chr(10)||'[" + line + " / " + station + "]剩餘物料不足,請提示生產部門上料,詳情如下(NORMAL:正常,剩余物料>2H消耗量; GENERAL:一般,剩余物料>1H 消耗量,< 2H 消耗量; URGENT:紧急,剩余物料<1H 消耗量):'||chr(10)||chr(10)||'Line      Station                P_No              KP_NO     Std_Qty        UPH        Sext_Qty           Status'||chr(10)||'" + Convert.ToString(dt.Rows[0]["mms"]);
                    mailSubject = @"Dear User,Pack CTN Line [" + line + "] is going to use up some online materials,Pls load them ASAP/你好,[" + line + " / " + station + "]剩餘物料不足，請提示生產及時上料";
                }
                else
                {
                    mailTo = @"shou-hong.li@mail.foxconn.com";
                    mailCc = @"lisa.j.liu@mail.foxconn.com";
                    mailCont = "未配置郵件類型:PACKCTN_MaterialShortage 的發送郵箱清單,請知悉";
                    mailSubject = "預警郵件的發送郵箱清單爲配置:PACKCTN_MaterialShortage";
                }
                /*mailTo = "shou-hong.li@mail.foxconn.com";
                mailCc = "";*/

                sql = String.Format(sql_mail, mailTo, mailCc, mailSubject, mailCont);

                DB.Execute(sql);
            }
        }

        internal static void ToBeloadedMaterialAlert(string line, string station, string model)
        {
            if (isAllLoaded(line, station, model)) { return; }

            var mailTo = string.Empty;
            var mailCc = string.Empty;
            var mailCont = string.Empty;
            var mailSubject = string.Empty;

            var dt = DB.GetDataTable(sql_mail_load);
            if (dt.Rows.Count > 0)
            {
                mailTo = Convert.ToString(dt.Rows[0]["mail_to"]);
                mailCc = Convert.ToString(dt.Rows[0]["mail_cc"]);
                mailCont = @"Dear User'||chr(10)||chr(10)||'[" + line + " / " + station + "] did not load all KP in BOM list of[" + model + "],Pls load it ASAP/[" + line + " / " + station + "]未上齊BOM清單上的物料,請及時上料'||chr(10)||'";
                mailSubject = @"Dear User,[" + line + " / " + station + "] 尚未上齊機種 [" + model + "] 所需物料,請提示生產上料. Thanks";
            }
            else
            {
                mailTo = @"shou-hong.li@mail.foxconn.com";
                mailCc = @"lisa.j.liu@mail.foxconn.com";
                mailCont = "未配置郵件類型:PACKCTN_LoadMaterial 的發送郵箱清單,請知悉";
                mailSubject = "預警郵件的發送郵箱清單爲配置:PACKCTN_LoadMaterial";
            }

            var sql = string.Format(sql_mail, mailTo, mailCc, mailSubject, mailCont);

            DB.Execute(sql);
        }
        /// <summary>
        /// by hour,for summerise data
        /// </summary>
        /// <param name="line"></param>
        /// <param name="station"></param>
        /// <param name="pno"></param>
        internal static void ProducingStatusMail(string line, string station, string pno)
        {
            var sql = @"select * from(select replace(wm_concat(' '||line||'       '||station||'       '||p_no||'       '||kp_no||mes1.right('       ',16-length(kp_no))||std_qty||'        '
                    ||qty||'       '||ext_qty||'       '||uph||'       '||output||'       '||(qty-ext_qty-output*std_qty)||'        '||status),',',chr(10))mms from(select 
                    line,station,m.p_no,kp_no,std_qty,qty,ext_qty,n.uph,(select count(distinct serial_number) output from sfism4.r_sn_detail_t@sfcodbf6 p,(select min
                    (edit_date) min_date,max(unload_time) max_date from r_pckkp_control_detail where is_offline = 'N' and line = '{0}' and station ='{1}' and 
                    p_no = '{2}')o where line_name = '{0}' and model_name='{2}' and group_name = '{1}' and in_station_time>o.min_date and in_station_time
                    <(case when o.max_date is null then sysdate+1 else o.max_date end)) output,case when ext_qty>=std_qty*uph*2 then'NORMAL' when ext_qty<std_qty*uph*2 and
                    ext_qty>=std_qty*uph*1 then 'GENERAL' else'URGENT' end status from r_pckkp_control_detail m,c_pack_uph_config n where m.p_no=n.p_no and m.is_offline =
                    'N' and m.line = '{0}' and m.station = '{1}' and m.p_no = '{2}')) where mms is not null";
            sql = String.Format(sql, line, station, pno);
            var dt = DB.GetDataTable(sql);
            if (dt.Rows.Count > 0)
            {
                var mailTo = string.Empty;
                var mailCc = string.Empty;
                var mailCont = string.Empty;
                var mailSubject = string.Empty;

                var dtMail = DB.GetDataTable(sql_mail_producing);
                if (dtMail.Rows.Count > 0)
                {
                    mailTo = Convert.ToString(dtMail.Rows[0]["mail_to"]);
                    mailCc = Convert.ToString(dtMail.Rows[0]["mail_cc"]);
                    mailCont = @"Dear USer'||chr(10)||chr(10)||'[" + line + " / " + station + "]生產詳情以及物料使用狀況詳情如下(NORMAL:正常，剩余物料>2*uph;GENERAL:一般,剩余物料在1*uph与2*uph之间;URGENT:紧急,剩余物料<1*uph):'||chr(10)||chr(10)||'Line       Station         P No.            KP No.      Std_Qty    QTY      Ext_Qty      UPH     Output   Diff_Qty     Status'||chr(10)||'" + Convert.ToString(dt.Rows[0]["mms"]);

                    mailSubject = @"Dear User,[" + line + " / " + station + "] 生產詳情以及物料使用狀況";
                }
                else
                {
                    mailTo = @"shou-hong.li@mail.foxconn.com";
                    mailCc = @"lisa.j.liu@mail.foxconn.com";
                    mailCont = "未配置郵件類型:PACKCTN_ProducingStatus 的發送郵箱清單,請知悉";
                    mailSubject = "預警郵件的發送郵箱清單爲配置:PACKCTN_ProducingStatus";
                }
                /*mailTo = "shou-hong.li@mail.foxconn.com";
                mailCc = "";*/

                sql = String.Format(sql_mail, mailTo, mailCc, mailSubject, mailCont);

                DB.Execute(sql);
            }
        }
    }
}
